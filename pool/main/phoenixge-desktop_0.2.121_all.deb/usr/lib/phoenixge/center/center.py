#!/usr/bin/env python3
"""PhoenixGe Center - welcome screen (first login) and control center in one app.

Pages are listed in PAGES (grouped sidebar, built lazily on first open, searchable).
  phoenixge-center               open the control center
  phoenixge-center --page <key>  open a page directly (keys: see PAGES or --list-pages; old titles work too)
  phoenixge-center --welcome     first-login welcome (shown once, from autostart)
"""
import html
import inspect
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

from PySide6.QtCore import QEvent, QPoint, QProcess, QRectF, Qt, QSize, QTimer
from PySide6.QtGui import QColor, QFont, QIcon, QKeySequence, QPainter, QPen, QPixmap, QShortcut
from PySide6.QtWidgets import (QAbstractButton, QAbstractSpinBox, QApplication, QCheckBox, QComboBox, QFileDialog, QFrame,
                               QGroupBox, QLineEdit, QGridLayout, QHBoxLayout, QLabel, QListWidget, QListWidgetItem,
                               QMessageBox, QPlainTextEdit, QPushButton, QScrollArea, QStackedWidget, QStyle,
                               QStyledItemDelegate, QTabWidget, QTextEdit, QToolButton, QVBoxLayout, QWidget)

HOME = Path.home()
CFG = HOME / ".config/phoenixge"
LNF = Path("/usr/share/plasma/look-and-feel")
VERSION = Path("/usr/share/phoenixge/version")
LOGO = "/usr/share/pixmaps/phoenixge.png"

sys.path.insert(0, str(Path(__file__).resolve().parent))
from store import CATEGORIES, STORE  # noqa: E402
import importlib  # noqa: E402
import importlib.util  # noqa: E402


def module_page(center, name):
    """Pages that live in their own module: a broken or missing module only breaks its own page, never the Center."""
    try:
        return importlib.import_module(name).build(center)
    except Exception as e:  # noqa: BLE001
        import traceback
        traceback.print_exc()
        w = QWidget(); lay = QVBoxLayout(w)
        lab = QLabel(f"This page could not be loaded ({name}): {e}\nPlease report it - the rest of PhoenixGe Center works.")
        lab.setWordWrap(True); lay.addWidget(lab); lay.addStretch()
        return w


def sh(cmd, timeout=10):
    try:
        return subprocess.run(cmd, shell=isinstance(cmd, str), capture_output=True, text=True, timeout=timeout).stdout.strip()
    except Exception:
        return ""


def kread(file, group, key):
    return sh(["kreadconfig6", "--file", file, "--group", group, "--key", key])


def accent():
    v = kread("kdeglobals", "General", "AccentColor")
    try:
        r, g, b = (int(x) for x in v.split(",")[:3])
        return QColor(r, g, b).name()
    except Exception:
        return "#ff7a2e"


def rgba(col, alpha):
    """Translucent stylesheet color. (Qt reads "#rrggbbaa" as #AARRGGBB, so never append alpha to a hex color.)"""
    c = QColor(col)
    return f"rgba({c.red()}, {c.green()}, {c.blue()}, {alpha})"


def themes():
    out = []
    for d in sorted(LNF.glob("org.phoenixge.*")):
        try:
            meta = json.loads((d / "metadata.json").read_text(encoding="utf-8"))["KPlugin"]
        except Exception:
            continue
        out.append(dict(id=d.name, name=meta.get("Name", d.name).replace("PhoenixGe ", ""),
                        desc=meta.get("Description", "").split("—")[-1].strip(),
                        preview=str(d / "contents/previews/preview.png")))
    return out


# ------------------------------------------------------------------ pages, groups, search vocabulary
GROUPS = [("start", "Start"), ("look", "Look & feel"), ("games", "Games"), ("media", "Media"), ("apps", "Apps"),
          ("devices", "Devices & network"), ("system", "System")]


def _p(key, group, title, icons, src, kw="", aliases=""):
    """One sidebar page. key = stable id for --page and code; src = "p_method" (in Center) or "mod:<module>" (own file)."""
    d = dict(key=key, group=group, title=title, icons=icons.split(), kw=kw.lower(), aliases=aliases.lower().split())
    if src.startswith("mod:"):
        d["module"] = src[4:]
    else:
        d["method"] = src
    return d


PAGES = [
    _p("welcome", "start", "Welcome", "go-home", "p_welcome", "start home first steps intro setup"),
    _p("themes", "look", "Themes", "preferences-desktop-theme", "p_themes",
       "look wallpaper colors colours dark light day night live fire appearance style design"),
    _p("display", "look", "Display & performance", "video-display preferences-desktop-display", "mod:gamedisplay",
       "screen monitor refresh rate hz 144 resolution hdr vrr freesync gsync scaling fps tearing", "gamedisplay"),
    _p("desktop", "look", "Desktop & touchpad", "preferences-desktop input-touchpad", "mod:desktopsetup",
       "touchpad mouse gestures taskbar panel desktop icons widgets scrolling click", "desktopsetup touchpad"),
    _p("gaming", "games", "Gaming", "applications-games", "p_gaming",
       "fps mangohud overlay steam proton ge-proton game mode gamescope big picture rgb lact fans replay anti-cheat ntsync kernel"),
    _p("friends", "games", "Play with friends", "network-workgroup", "mod:friends",
       "lan room multiplayer coop server minecraft terraria cs2 valheim easytier host join"),
    _p("deals", "games", "Free games & deals", "emblem-favorite starred bookmarks", "mod:deals_page",
       "free giveaway epic sale discount price cheap offers", "deals_page free"),
    _p("controllers", "games", "Controllers & keys", "input-gaming applications-games", "mod:inputmap",
       "gamepad joystick xbox playstation dualsense dualshock switch remap keys keyboard mouse macro buttons", "inputmap"),
    _p("benchmark", "games", "Benchmark", "speedometer utilities-system-monitor", "mod:bench",
       "benchmark score test fps cpu gpu speed compare stress", "bench"),
    _p("sound", "media", "Sound & camera", "audio-headset audio-card", "mod:avstudio",
       "mic microphone noise clean voice equalizer eq headphones 3d surround speakers volume webcam camera blur background "
       "phone webcam audio", "avstudio audio camera"),
    _p("streaming", "media", "Streaming & clips", "media-record", "mod:creator",
       "obs twitch youtube kick stream streaming record recording clips replay share discord", "creator clips"),
    _p("store", "apps", "Store", "plasmadiscover system-software-install", "p_store",
       "apps install flathub software discover programs vs code games", "apps phoenix-store"),
    _p("android", "apps", "Android", "smartphone phone", "p_android", "waydroid apk google play f-droid mobile phone apps"),
    _p("migrate", "apps", "Move from Windows", "document-import", "p_migrate",
       "windows import transfer migrate copy files bookmarks games programs", "move-from-windows windows"),
    _p("autoupdate", "apps", "Auto updates", "update-none view-refresh system-software-update", "mod:autoupdate",
       "automatic updates schedule background apps flatpak upgrade", "auto-updates"),
    _p("devices", "devices", "Devices", "computer-laptop computer", "p_devices",
       "battery power laptop charge charging tv cast miracast chromecast screens monitor graphics mode hybrid"),
    _p("phone", "devices", "Phone", "kdeconnect smartphone", "p_phone",
       "kde connect android iphone notifications clipboard sms files remote"),
    _p("network", "devices", "Network & Ping", "network-wireless network-wired", "mod:netping",
       "wifi wi-fi wlan internet ping lag latency dns speed test ethernet jitter packet loss router", "netping ping"),
    _p("drivers", "devices", "Drivers", "preferences-system", "p_drivers", "nvidia amd intel radeon graphics gpu driver geforce"),
    _p("health", "system", "Health", "utilities-system-monitor", "mod:health",
       "temperature temps disk smart clean cleanup cache space slow errors check"),
    _p("disk", "system", "Disk usage", "drive-harddisk", "mod:diskmap",
       "storage space full files big folders cleanup free disk", "diskmap disk-usage"),
    _p("backups", "system", "Backups", "timeshift document-save", "p_backups",
       "timeshift snapshot snapshots restore rollback undo safe updates"),
    _p("updates", "system", "Updates", "system-software-update", "p_updates", "upgrade update updates version discover"),
    _p("channel", "system", "Update channel", "system-software-update", "mod:channels",
       "beta stable channel changelog what's new whats new release"),
    _p("hibernate", "system", "Hibernate", "system-suspend-hibernate", "mod:hibernate", "sleep suspend swap resume lid power off"),
    _p("reset", "system", "Reset", "edit-undo", "mod:sysreset", "factory reset restore defaults repair reinstall", "sysreset"),
    _p("usb", "system", "USB Creator", "drive-removable-media-usb", "mod:usbmaker",
       "usb stick bootable iso flash write installer", "usbmaker usb-creator"),
    _p("security", "system", "Security", "security-high", "p_security",
       "firewall vpn wireguard password passwords keepass vault encrypt encrypted fingerprint"),
    _p("language", "system", "Language", "preferences-desktop-locale", "p_language",
       "georgian english keyboard layout locale translation ქართული"),
    _p("system", "system", "System", "computer", "p_system", "about info cpu memory ram kernel version toolbox kali"),
]

# search word -> [(page key, card text to jump to or None)]
SYNONYMS = {
    "fps": [("gaming", "Show FPS counter"), ("gaming", "PhoenixGe Overlay (Meta+G)"), ("display", None), ("benchmark", None)],
    "frames": [("gaming", "Show FPS counter"), ("display", None)],
    "overlay": [("gaming", "PhoenixGe Overlay (Meta+G)")],
    "wifi": [("network", None)], "wi-fi": [("network", None)], "wlan": [("network", None)], "internet": [("network", None)],
    "lag": [("network", "Ping to game servers")], "ping": [("network", "Ping to game servers")],
    "battery": [("devices", "Power mode"), ("hibernate", None)],
    "power": [("devices", "Power mode"), ("hibernate", None)],
    "nvidia": [("drivers", None), ("gaming", "Graphics card control (LACT)")],
    "gpu": [("drivers", None), ("gaming", "Graphics card control (LACT)")],
    "graphics": [("drivers", None), ("display", None)],
    "mic": [("sound", None)], "microphone": [("sound", None)], "noise": [("sound", None)], "headset": [("sound", None)],
    "webcam": [("sound", None)], "camera": [("sound", None)],
    "update": [("updates", None), ("autoupdate", None)], "updates": [("updates", None), ("autoupdate", None)],
    "upgrade": [("updates", None)],
    "vpn": [("security", "VPN (WireGuard)")], "firewall": [("security", "Firewall")],
    "password": [("security", "Password manager")], "fingerprint": [("security", "Fingerprint login")],
    "snapshot": [("backups", None)], "restore": [("backups", None), ("reset", None)], "undo": [("backups", None)],
    "reset": [("reset", None)], "factory": [("reset", None)],
    "controller": [("controllers", None), ("gaming", "Controllers")], "gamepad": [("controllers", None), ("gaming", "Controllers")],
    "bluetooth": [("gaming", "Controllers"), ("phone", None)],
    "rgb": [("gaming", "RGB lighting")], "fan": [("gaming", "Graphics card control (LACT)")],
    "proton": [("gaming", "GE-Proton")], "steam": [("gaming", "PhoenixGe Game Mode (like SteamOS)")],
    "record": [("streaming", None), ("gaming", "Instant Replay (like NVIDIA ShadowPlay)")],
    "replay": [("gaming", "Instant Replay (like NVIDIA ShadowPlay)"), ("streaming", None)],
    "stream": [("streaming", None)], "obs": [("streaming", None)],
    "tv": [("devices", "Show on a TV")], "cast": [("devices", "Show on a TV")],
    "monitor": [("display", None), ("devices", "Screens")], "hz": [("display", None), ("devices", "Screens")],
    "sleep": [("hibernate", None)], "space": [("disk", None), ("health", None)], "storage": [("disk", None), ("health", None)],
    "apps": [("store", None)], "install": [("store", None)], "apk": [("android", "Install APK file…")],
    "keyboard": [("language", None), ("controllers", None)], "touchpad": [("desktop", None)], "mouse": [("desktop", None)],
    "wallpaper": [("themes", "Live fire wallpaper")], "dark": [("themes", "Automatic day / night")],
    "minecraft": [("friends", None)], "server": [("friends", None)], "lan": [("friends", None)],
    "free": [("deals", None)], "temperature": [("health", None)], "usb": [("usb", None)],
}

ROLE_KIND, ROLE_KEY, ROLE_OPEN, ROLE_SUB, ROLE_HINT = (Qt.UserRole + i for i in range(1, 6))
SRC_RE = re.compile(r"\b(Card|Section|section|card|QCheckBox|QPushButton|QLabel|QGroupBox|QRadioButton)\(\s*f?([\"'])"
                    r"((?:\\.|(?!\2)[^\\]){3,120})\2(?:\s*,\s*f?([\"'])((?:\\.|(?!\4)[^\\]){3,400})\4)?")


def page_available(p):
    """Module pages show up only once their module is installed (other pages are written in parallel)."""
    if not p.get("module"):
        return True
    try:
        return importlib.util.find_spec(p["module"]) is not None
    except (ImportError, ValueError):
        return False


def resolve_page(name, pages=None):
    """--page argument -> page key. Accepts the key, aliases, module name or the page title (any case)."""
    if not name:
        return None
    n = str(name).strip().lower()
    for p in pages or PAGES:
        if n in (p["key"], p.get("module", ""), p["title"].lower(), p["title"].lower().replace("&", "and")) or n in p["aliases"]:
            return p["key"]
    return None


def page_icon(p):
    for n in p["icons"]:
        if QIcon.hasThemeIcon(n):
            return QIcon.fromTheme(n)
    return QIcon.fromTheme(p["icons"][0])


def clean_text(t):
    t = re.sub(r"<br\s*/?>", " ", t or "")
    t = html.unescape(re.sub(r"<[^>]+>", "", t))
    return " ".join(t.replace("\\n", " ").replace('\\"', '"').replace("\\'", "'").split())


def ui_text(t):
    return 3 <= len(t) <= 400 and re.search(r"[A-Za-zა-ჰ]{2}", t) is not None and not t.startswith(("/", "$", "-"))


def explicitly_shown(w, root):
    """False if w or a parent (up to root) was hidden on purpose. Pages of inner stacks/tabs count as shown."""
    while w is not None and w is not root:
        if (w.testAttribute(Qt.WA_WState_Hidden) and w.testAttribute(Qt.WA_WState_ExplicitShowHide)
                and not isinstance(w.parentWidget(), QStackedWidget)):
            return False
        w = w.parentWidget()
    return True


def card_of(w, root):
    while w is not None and w is not root:
        if isinstance(w, QFrame) and "card" in (w.objectName() or "").lower() and w.objectName() != "cardTitle":
            return w
        w = w.parentWidget()
    return None


def card_title(card):
    t = card.findChild(QLabel, "cardTitle")
    if t is None:
        labs = card.findChildren(QLabel)
        t = labs[0] if labs else None
    return clean_text(t.text()) if t is not None else ""


def shiboken_valid(w):
    try:
        import shiboken6
        return shiboken6.isValid(w)
    except Exception:  # noqa: BLE001
        return True


class NavDelegate(QStyledItemDelegate):
    """Paints sidebar rows: dim small-caps group headers, rounded accent selection, two-line search results."""

    def __init__(self, parent, acc):
        super().__init__(parent)
        self.acc = QColor(acc)

    def sizeHint(self, option, index):
        kind = index.data(ROLE_KIND)
        return QSize(200, {"group": 34, "result": 50, "empty": 40}.get(kind, 38))

    def paint(self, p, option, index):
        kind = index.data(ROLE_KIND)
        pal = option.palette
        r = option.rect.adjusted(4, 2, -6, -2)
        p.save()
        p.setRenderHint(QPainter.Antialiasing)
        text_c = pal.color(pal.ColorRole.Text)
        dim = pal.color(pal.ColorRole.PlaceholderText)
        f = QFont(option.font)
        if kind == "group":
            f.setPointSizeF(max(7.0, f.pointSizeF() * 0.78)); f.setBold(True)
            f.setCapitalization(QFont.AllUppercase); f.setLetterSpacing(QFont.PercentageSpacing, 112)
            p.setFont(f); p.setPen(dim)
            tr = r.adjusted(10, 8, -8, 0)
            p.drawText(tr, Qt.AlignLeft | Qt.AlignVCenter, index.data(Qt.DisplayRole))
            p.drawText(tr, Qt.AlignRight | Qt.AlignVCenter, "▾" if index.data(ROLE_OPEN) else "▸")
            p.restore()
            return
        if kind == "empty":
            p.setPen(dim); p.drawText(r.adjusted(12, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, index.data(Qt.DisplayRole))
            p.restore()
            return
        sel = bool(option.state & QStyle.State_Selected)
        hov = bool(option.state & QStyle.State_MouseOver)
        if sel:
            bg = QColor(self.acc); bg.setAlpha(52 if kind == "page" else 44)
            p.setPen(Qt.NoPen); p.setBrush(bg); p.drawRoundedRect(QRectF(r), 10, 10)
            if kind == "page":
                p.setBrush(self.acc); p.drawRoundedRect(QRectF(r.left() + 1, r.top() + 9, 3.5, r.height() - 18), 2, 2)
        elif hov:
            bg = QColor(text_c); bg.setAlpha(18)
            p.setPen(Qt.NoPen); p.setBrush(bg); p.drawRoundedRect(QRectF(r), 10, 10)
        icon = index.data(Qt.DecorationRole)
        if isinstance(icon, QIcon) and not icon.isNull():
            icon.paint(p, r.left() + 14, r.center().y() - 10, 20, 20)
        tr = r.adjusted(46, 0, -8, 0)
        fg = self.acc if (sel and kind == "page") else text_c
        if kind == "result":
            f.setBold(True); p.setFont(f); p.setPen(fg)
            top = tr.adjusted(0, 6, 0, -tr.height() // 2)
            p.drawText(top, Qt.AlignLeft | Qt.AlignBottom,
                       p.fontMetrics().elidedText(index.data(Qt.DisplayRole), Qt.ElideRight, top.width()))
            f2 = QFont(option.font); f2.setPointSizeF(max(7.0, f2.pointSizeF() * 0.86)); p.setFont(f2); p.setPen(dim)
            bot = tr.adjusted(0, tr.height() // 2 + 1, 0, -4)
            p.drawText(bot, Qt.AlignLeft | Qt.AlignTop,
                       p.fontMetrics().elidedText(str(index.data(ROLE_SUB) or ""), Qt.ElideRight, bot.width()))
        else:
            f.setBold(sel); p.setFont(f); p.setPen(fg)
            p.drawText(tr, Qt.AlignLeft | Qt.AlignVCenter,
                       p.fontMetrics().elidedText(index.data(Qt.DisplayRole), Qt.ElideRight, tr.width()))
        p.restore()


class Flash(QWidget):
    """Brief accent glow over a card that a search result pointed to."""

    def __init__(self, target, acc):
        super().__init__(target)
        self.acc, self.t = QColor(acc), 0
        self.setAttribute(Qt.WA_TransparentForMouseEvents); self.setAttribute(Qt.WA_DeleteOnClose)
        self.setGeometry(target.rect()); self.raise_(); self.show()
        self.timer = QTimer(self); self.timer.timeout.connect(self.step); self.timer.start(30)

    def step(self):
        self.t += 1
        if self.t > 60:  # ~1.8 s
            self.timer.stop(); self.close(); return
        self.update()

    def paintEvent(self, _e):
        import math
        k = self.t / 60
        a = (0.55 + 0.45 * math.cos(k * math.pi * 4)) * (1 - k) ** 0.6  # two pulses, fading
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        fill = QColor(self.acc); fill.setAlphaF(0.20 * a)
        line = QColor(self.acc); line.setAlphaF(min(1.0, 0.95 * a + 0.05))
        p.setBrush(fill); p.setPen(QPen(line, 2.5))
        p.drawRoundedRect(QRectF(self.rect()).adjusted(1.5, 1.5, -1.5, -1.5), 14, 14)


# ------------------------------------------------------------------ widgets
class Card(QFrame):
    def __init__(self, title="", text=""):
        super().__init__()
        self.setObjectName("card")
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(18, 16, 18, 16)
        self.lay.setSpacing(8)
        if title:
            t = QLabel(title); t.setObjectName("cardTitle"); self.lay.addWidget(t)
        if text:
            x = QLabel(text); x.setWordWrap(True); x.setObjectName("dim"); self.lay.addWidget(x)


def page(title, subtitle=""):
    w = QWidget()
    outer = QVBoxLayout(w); outer.setContentsMargins(0, 0, 0, 0)
    scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame)
    inner = QWidget(); lay = QVBoxLayout(inner); lay.setContentsMargins(36, 30, 36, 30); lay.setSpacing(16)
    h = QLabel(title); h.setObjectName("h1"); lay.addWidget(h)
    if subtitle:
        s = QLabel(subtitle); s.setObjectName("dim"); s.setWordWrap(True); lay.addWidget(s)
    scroll.setWidget(inner); outer.addWidget(scroll)
    return w, lay


class FlowGrid(QWidget):
    """Grid that re-flows its cards to the window width (1 column on narrow windows, 4+ when maximized)."""

    def __init__(self, min_w=300, max_cols=5):
        super().__init__()
        self.min_w, self.max_cols, self.items, self.cols = min_w, max_cols, [], 0
        self.grid = QGridLayout(self); self.grid.setContentsMargins(0, 0, 0, 0); self.grid.setSpacing(12)

    def set_items(self, widgets):
        for w in self.items:
            self.grid.removeWidget(w); w.deleteLater()
        self.items, self.cols = list(widgets), 0
        self.reflow()

    def add(self, w):
        self.items.append(w); self.cols = 0; self.reflow()

    def reflow(self):
        cols = max(1, min(self.max_cols, self.width() // self.min_w)) if self.width() > 50 else 3
        if cols == self.cols:
            return
        self.cols = cols
        for w in self.items:
            self.grid.removeWidget(w)
        for i, w in enumerate(self.items):
            self.grid.addWidget(w, i // cols, i % cols)
        for c in range(self.max_cols):
            self.grid.setColumnStretch(c, 1 if c < cols else 0)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self.reflow()


class Runner:
    """Runs commands with QProcess and streams output into a log box."""

    def __init__(self, log: QPlainTextEdit):
        self.log, self.procs = log, []

    def run(self, program, args, done=None):
        p = QProcess()
        p.setProcessChannelMode(QProcess.MergedChannels)
        p.readyReadStandardOutput.connect(lambda: self.log.appendPlainText(bytes(p.readAllStandardOutput()).decode(errors="replace").rstrip()))
        p.finished.connect(lambda code, _s: self._end(p, done, code, f"— finished ({code})"))
        p.errorOccurred.connect(lambda err: err == QProcess.ProcessError.FailedToStart and
                                self._end(p, done, -1, f"— could not start {program} (not installed?)"))
        self.procs.append(p)
        self.log.show()
        self.log.appendPlainText(f"$ {program} {' '.join(args)}")
        p.start(program, args)

    def _end(self, p, done, code, msg):
        if p not in self.procs:
            return
        self.procs.remove(p)
        self.log.appendPlainText(msg)
        if done:
            done(code)

    def root(self, script, args=(), done=None):
        """Run one of our scripts as root. Via /bin/sh so it works even if the file lost its exec bit."""
        self.run("pkexec", ["/bin/sh", script, *args], done)


# ------------------------------------------------------------------ main window
class Center(QWidget):
    def __init__(self, welcome=False, start=None):
        super().__init__()
        self.setWindowTitle("PhoenixGe Center")
        self.setWindowIcon(QIcon(LOGO))
        self.resize(1180, 760)
        self.setMinimumSize(760, 520)
        acc = accent()
        self.setStyleSheet(f"""
            QWidget {{ font-size: 13px; }}
            #sidebar {{ background: palette(alternate-base); }}
            #h1 {{ font-size: 26px; font-weight: 700; }}
            #dim {{ color: palette(placeholder-text); }}
            #card {{ background: palette(alternate-base); border-radius: 14px; border: 1px solid {rgba(acc, 0x3a)}; }}
            #cardTitle {{ font-size: 15px; font-weight: 600; }}
            QPushButton {{ padding: 8px 16px; border-radius: 10px; }}
            QPushButton#primary {{ background: {acc}; color: #1a0b06; font-weight: 600; border: none; }}
            QPushButton:checked {{ background: {acc}; color: #1a0b06; }}
            QToolButton#theme {{ border-radius: 14px; padding: 6px; }}
            QToolButton#theme:checked {{ border: 2px solid {acc}; background: {rgba(acc, 0x22)}; }}
            #side, #results {{ background: transparent; border: none; outline: none; }}
            #search {{ padding: 7px 10px; border-radius: 10px; border: 1px solid {rgba(acc, 0x44)}; background: palette(base); }}
            #search:focus {{ border: 1px solid {acc}; }}
            #sideFoot {{ color: palette(placeholder-text); font-size: 11px; }}
            QScrollBar:vertical {{ width: 8px; background: transparent; margin: 2px; }}
            QScrollBar::handle:vertical {{ background: {rgba(acc, 0x55)}; border-radius: 3px; min-height: 30px; }}
            QScrollBar::handle:vertical:hover {{ background: {rgba(acc, 0x99)}; }}
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{ background: transparent; }}
        """)
        self.acc = acc
        self.pages = [p for p in PAGES if page_available(p)]
        self.page_by_key = {p["key"]: p for p in self.pages}
        self.built = {}                     # key -> page widget (pages are built on first open)
        self.collapsed = set(self._nav_state().get("collapsed", []))

        root = QHBoxLayout(self); root.setContentsMargins(0, 0, 0, 0); root.setSpacing(0)
        side = QVBoxLayout(); side.setContentsMargins(10, 14, 6, 10); side.setSpacing(8)
        head = QHBoxLayout(); head.setSpacing(10); head.setContentsMargins(6, 0, 0, 2)
        brand = QLabel(); brand.setPixmap(QPixmap(LOGO).scaled(38, 38, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        name = QLabel("PhoenixGe\nCenter"); name.setStyleSheet("font-weight:700;font-size:15px;")
        head.addWidget(brand); head.addWidget(name, 1)
        self.search = QLineEdit(); self.search.setObjectName("search"); self.search.setClearButtonEnabled(True)
        self.search.setPlaceholderText("Search settings  (Ctrl+F)")
        self.search.addAction(QIcon.fromTheme("edit-find"), QLineEdit.ActionPosition.LeadingPosition)
        self.nav = QListWidget(); self.nav.setObjectName("side"); self.nav.setIconSize(QSize(20, 20))
        self.results = QListWidget(); self.results.setObjectName("results"); self.results.setIconSize(QSize(20, 20))
        for lw in (self.nav, self.results):
            lw.setItemDelegate(NavDelegate(lw, acc)); lw.setMouseTracking(True); lw.viewport().setAttribute(Qt.WA_Hover, True)
            lw.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff); lw.setVerticalScrollMode(QListWidget.ScrollPerPixel)
            lw.setFocusPolicy(Qt.StrongFocus)
        self.side_stack = QStackedWidget(); self.side_stack.addWidget(self.nav); self.side_stack.addWidget(self.results)
        ver = VERSION.read_text().strip() if VERSION.exists() else ""
        foot = QLabel(f"PhoenixGe OS {ver}".strip()); foot.setObjectName("sideFoot"); foot.setContentsMargins(8, 0, 0, 0)
        side.addLayout(head); side.addWidget(self.search); side.addWidget(self.side_stack, 1); side.addWidget(foot)
        sidew = QWidget(); sidew.setLayout(side); sidew.setFixedWidth(256)
        sidew.setObjectName("sidebar"); sidew.setAttribute(Qt.WA_StyledBackground, True)
        self.stack = QStackedWidget()
        right = QVBoxLayout(); right.setContentsMargins(0, 0, 0, 0); right.addWidget(self.stack)
        self.log = QPlainTextEdit(); self.log.setReadOnly(True); self.log.setMaximumHeight(150); self.log.hide()
        right.addWidget(self.log)
        root.addWidget(sidew); root.addLayout(right, 1)
        self.runner = Runner(self.log)
        if welcome:  # before the pages are built, so the "Show this window at login" checkbox shows the real state
            CFG.mkdir(parents=True, exist_ok=True)
            (CFG / "welcome-done").write_text("1")

        self.fill_nav()
        self.nav.currentItemChanged.connect(self._nav_changed)
        self.nav.itemClicked.connect(self._nav_clicked)
        self.results.itemActivated.connect(self._result_open)
        self.results.itemClicked.connect(self._result_open)
        self.search_timer = QTimer(self); self.search_timer.setSingleShot(True); self.search_timer.setInterval(120)
        self.search_timer.timeout.connect(self.run_search)
        self.search.textChanged.connect(lambda _t: self.search_timer.start())
        QShortcut(QKeySequence(QKeySequence.StandardKey.Find), self, activated=self.focus_search)
        QShortcut(QKeySequence("Ctrl+K"), self, activated=self.focus_search)
        QApplication.instance().installEventFilter(self)  # typing anywhere (outside text fields) starts a search
        self._src_index = None
        self.open_page(resolve_page(start, self.pages) or "welcome")

    # ---------------------------------------------------------------- navigation
    @staticmethod
    def _nav_state():
        try:
            return json.loads((CFG / "center-nav.json").read_text())
        except Exception:
            return {}

    def _save_nav_state(self):
        try:
            CFG.mkdir(parents=True, exist_ok=True)
            (CFG / "center-nav.json").write_text(json.dumps({"collapsed": sorted(self.collapsed)}))
        except OSError:
            pass

    def fill_nav(self):
        self.nav.blockSignals(True); self.nav.clear()
        for gid, gname in GROUPS:
            items = [p for p in self.pages if p["group"] == gid]
            if not items:
                continue
            if gid != "start":
                h = QListWidgetItem(gname, self.nav); h.setFlags(Qt.ItemIsEnabled)
                h.setData(ROLE_KIND, "group"); h.setData(ROLE_KEY, gid); h.setData(ROLE_OPEN, gid not in self.collapsed)
            for p in items:
                it = QListWidgetItem(page_icon(p), p["title"], self.nav)
                it.setData(ROLE_KIND, "page"); it.setData(ROLE_KEY, p["key"]); it.setToolTip(p["title"])
                it.setHidden(gid in self.collapsed)
        self.nav.blockSignals(False)

    def nav_item(self, key):
        for r in range(self.nav.count()):
            it = self.nav.item(r)
            if it.data(ROLE_KIND) == "page" and it.data(ROLE_KEY) == key:
                return it
        return None

    def toggle_group(self, gid, open_=None):
        now_open = gid in self.collapsed if open_ is None else open_
        (self.collapsed.discard if now_open else self.collapsed.add)(gid)
        for r in range(self.nav.count()):
            it = self.nav.item(r)
            if it.data(ROLE_KIND) == "group" and it.data(ROLE_KEY) == gid:
                it.setData(ROLE_OPEN, now_open)
            elif it.data(ROLE_KIND) == "page" and self.page_by_key[it.data(ROLE_KEY)]["group"] == gid:
                it.setHidden(not now_open)
        self._save_nav_state()

    def _nav_clicked(self, it):
        if it.data(ROLE_KIND) == "group":
            self.toggle_group(it.data(ROLE_KEY))

    def _nav_changed(self, it, _prev=None):
        if it is None:
            return
        kind = it.data(ROLE_KIND)
        if kind == "page":
            self.open_page(it.data(ROLE_KEY))
        elif kind is None and self.stack.count():  # item added by a module's stand-alone test harness
            self.stack.setCurrentIndex(self.stack.count() - 1)

    def build_page(self, key):
        p = self.page_by_key[key]
        if p.get("module"):
            return module_page(self, p["module"])
        try:
            return getattr(self, p["method"])()
        except Exception as e:  # noqa: BLE001 - one broken page never takes the Center down
            import traceback
            traceback.print_exc()
            w = QWidget(); lay = QVBoxLayout(w)
            lab = QLabel(f"This page could not be loaded ({key}): {e}\nPlease report it - the rest of PhoenixGe Center works.")
            lab.setWordWrap(True); lay.addWidget(lab); lay.addStretch()
            return w

    def open_page(self, key, hint=None):
        """Open a page by its stable key (see PAGES); builds it the first time. hint = card text or widget to flash."""
        key = resolve_page(key, self.pages)
        if not key:
            return False
        if key not in self.built:
            QApplication.setOverrideCursor(Qt.WaitCursor)
            try:
                w = self.build_page(key)
            finally:
                QApplication.restoreOverrideCursor()
            w.setProperty("pageKey", key)
            self.built[key] = w; self.stack.addWidget(w)
        self.stack.setCurrentWidget(self.built[key])
        p = self.page_by_key[key]
        if p["group"] in self.collapsed:
            self.toggle_group(p["group"], True)
        it = self.nav_item(key)
        if it is not None and self.nav.currentItem() is not it:
            self.nav.blockSignals(True); self.nav.setCurrentItem(it); self.nav.blockSignals(False)
            self.nav.scrollToItem(it)
        if hint is not None:
            QTimer.singleShot(90, lambda: self.reveal(key, hint))
        return True

    go = open_page  # short name for module pages: center.go("drivers")

    def current_key(self):
        w = self.stack.currentWidget()
        return w.property("pageKey") if w is not None else None

    # ---------------------------------------------------------------- search
    def focus_search(self):
        self.search.setFocus(); self.search.selectAll()

    def eventFilter(self, obj, ev):
        if obj is self.search and ev.type() == QEvent.KeyPress:
            k = ev.key()
            if k == Qt.Key_Escape and self.search.text():
                self.search.clear(); return True
            if k in (Qt.Key_Down, Qt.Key_Tab) and self.side_stack.currentWidget() is self.results and self.results.count():
                self.results.setFocus(); self.results.setCurrentRow(0); return True
            if k in (Qt.Key_Return, Qt.Key_Enter):
                self.run_search()
                if self.results.count():
                    self._result_open(self.results.item(0))
                return True
        elif ev.type() == QEvent.KeyPress and obj is QApplication.focusWidget() and obj is not self.search:
            try:
                mine = isinstance(obj, QWidget) and obj.window() is self
            except RuntimeError:
                mine = False
            if mine:
                txt = ev.text()
                if obj is self.results and ev.key() == Qt.Key_Escape:
                    self.search.clear(); self.nav.setFocus(); return True
                if (txt and txt.isprintable() and txt.strip() and (txt.isalnum() or obj is self.results or obj is self.nav)
                        and not (ev.modifiers() & (Qt.ControlModifier | Qt.AltModifier | Qt.MetaModifier))
                        and not isinstance(obj, (QLineEdit, QPlainTextEdit, QTextEdit, QAbstractSpinBox))
                        and not (isinstance(obj, QComboBox) and obj.isEditable())):
                    self.search.setFocus(); self.search.setText(self.search.text() + txt)
                    return True
        return super().eventFilter(obj, ev)

    def source_index(self):
        """Card titles / buttons / checkboxes of pages that are not built yet, read from their source code (cheap, no side effects)."""
        if self._src_index is None:
            self._src_index = {}
            for p in self.pages:
                try:
                    if p.get("module"):
                        spec = importlib.util.find_spec(p["module"])
                        src = Path(spec.origin).read_text(encoding="utf-8", errors="ignore") if spec and spec.origin else ""
                    else:
                        src = inspect.getsource(getattr(Center, p["method"]))
                except Exception:  # noqa: BLE001
                    src = ""
                out = []
                for m in SRC_RE.finditer(src):
                    t = clean_text(re.sub(r"\{[^}]*\}", "", m.group(3)))
                    d = clean_text(re.sub(r"\{[^}]*\}", "", m.group(5) or ""))
                    if ui_text(t):
                        out.append((t, d, m.group(1) in ("Card", "Section", "section", "card")))
                if p["key"] == "store":
                    out += [(name, what, True) for (_c, _k, _i, name, what) in STORE]
                self._src_index[p["key"]] = out
        return self._src_index

    def built_index(self, key):
        """(label, full text, widget, is_title) of everything readable on a built page."""
        root = self.built[key]
        out, seen = [], set()
        for w in root.findChildren(QWidget):
            if isinstance(w, QLabel):
                t = w.text()
            elif isinstance(w, QAbstractButton):
                t = w.text().replace("&&", "\0").replace("&", "").replace("\0", "&")
            elif isinstance(w, QGroupBox):
                t = w.title()
            else:
                continue
            t = clean_text(t)
            if not ui_text(t) or not explicitly_shown(w, root):
                continue
            card = card_of(w, root)
            title = card_title(card) if card is not None else ""
            is_title = bool(title) and t == title
            label = t if (len(t) <= 70 and (is_title or not title or isinstance(w, QAbstractButton))) else (title or t[:60] + "…")
            if (label, t) in seen:
                continue
            seen.add((label, t))
            out.append((label, t, w, is_title or (card is None and len(t) <= 70)))
        return out

    def search_hits(self, q):
        q = q.strip().lower()
        if not q:
            return []
        toks = q.split()

        pats = [re.compile(r"(?<![a-z0-9])" + re.escape(t)) for t in toks]

        def match(text):  # every word of the query starts a word in the text ("mic" finds "Microphone", not "dynamic")
            text = text.lower()
            return all(pt.search(text) for pt in pats)

        hits = {}  # (key, label) -> (score, sub, hint)

        def add(score, key, label, sub, hint):
            k = (key, label.lower())
            if k not in hits or hits[k][0] < score:
                hits[k] = (score, label, sub, hint, key)

        groups = dict(GROUPS)
        for i, p in enumerate(self.pages):
            title, gname = p["title"], groups[p["group"]]
            tl = title.lower()
            if tl.startswith(q):
                add(100, p["key"], title, gname, None)
            elif match(title):
                add(85, p["key"], title, gname, None)
            elif any(w.startswith(t) for t in toks for w in p["kw"].split()) and all(
                    any(w.startswith(t) for w in (p["kw"] + " " + tl).split()) for t in toks):
                add(62, p["key"], title, gname, None)
            elif match(gname):
                add(40, p["key"], title, gname, None)
        for term, targets in SYNONYMS.items():
            if term == q or (len(q) >= 3 and term.startswith(q)):
                for key, hint in targets:
                    if key in self.page_by_key:
                        p = self.page_by_key[key]
                        add(92 if term == q else 70, key, hint or p["title"], p["title"] if hint else groups[p["group"]], hint)
        for p in self.pages:
            key = p["key"]
            if key in self.built:
                for label, text, w, is_title in self.built_index(key):
                    if match(label):
                        add(58 if is_title else 50, key, label, p["title"], w)
                    elif match(text):
                        add(30, key, label, p["title"], w)
            else:
                for title, desc, is_title in self.source_index().get(key, []):
                    if match(title):
                        add(56 if is_title else 48, key, title, p["title"], title)
                    elif desc and match(desc):
                        add(28, key, title, p["title"], title)
        order = {p["key"]: i for i, p in enumerate(self.pages)}
        out = []
        for h in sorted(hits.values(), key=lambda h: (-h[0], order[h[4]], h[1].lower())):
            lab = h[1].lower()  # "Show FPS counter" (synonym) and the full checkbox text are the same thing
            if h[3] is None or not any(o[4] == h[4] and o[3] is not None and min(len(lab), len(o[1])) >= 8 and
                                       (lab.startswith(o[1].lower()) or o[1].lower().startswith(lab)) for o in out):
                out.append(h)
        return out[:50]

    def run_search(self):
        q = self.search.text()
        if not q.strip():
            self.side_stack.setCurrentWidget(self.nav)
            return
        self.side_stack.setCurrentWidget(self.results)
        self.results.clear()
        hits = self.search_hits(q)
        for score, label, sub, hint, key in hits:
            it = QListWidgetItem(page_icon(self.page_by_key[key]), label, self.results)
            it.setData(ROLE_KIND, "result"); it.setData(ROLE_KEY, key); it.setData(ROLE_SUB, sub)
            it.setData(ROLE_HINT, hint); it.setToolTip(f"{label}\n{sub}")
        if not hits:
            it = QListWidgetItem("No matches - try other words", self.results); it.setFlags(Qt.NoItemFlags)
            it.setData(ROLE_KIND, "empty")

    def _result_open(self, it):
        if it is None or it.data(ROLE_KIND) != "result":
            return
        self.open_page(it.data(ROLE_KEY), it.data(ROLE_HINT) if it.data(ROLE_HINT) is not None else "")

    # ---------------------------------------------------------------- reveal + flash
    def find_widget(self, key, hint):
        root = self.built.get(key)
        if root is None or hint == "":
            return None
        if isinstance(hint, QWidget):
            return hint if shiboken_valid(hint) and root.isAncestorOf(hint) else None
        h = clean_text(str(hint)).lower()
        if key == "store" and hasattr(self, "store_search") and not any(
                h == clean_text(x.text()).lower() for x in root.findChildren(QLabel, "cardTitle")):
            self.store_search.setText(str(hint))  # the store only shows one category: search it there
        best = None
        for w in root.findChildren(QWidget):
            if isinstance(w, (QLabel, QAbstractButton)):
                t = clean_text(w.text()).lower()
            elif isinstance(w, QGroupBox):
                t = clean_text(w.title()).lower()
            else:
                continue
            if not t or not explicitly_shown(w, root):
                continue
            if t == h:
                return w
            if best is None and h in t:
                best = w
        return best

    def reveal(self, key, hint):
        w = self.find_widget(key, hint)
        if w is None:
            return
        target = card_of(w, self.built[key]) or w
        a = target  # switch tabs / inner stacks that hide the widget
        while a is not None and a is not self.built[key]:
            par = a.parentWidget()
            if isinstance(par, QStackedWidget) and par is not self.stack:
                tabs = par.parentWidget()
                if isinstance(tabs, QTabWidget):
                    tabs.setCurrentWidget(a)
                else:
                    par.setCurrentWidget(a)
            a = par
        a = target.parentWidget()
        while a is not None and not isinstance(a, QScrollArea):
            a = a.parentWidget()
        if a is not None and a.widget() is not None:
            y = target.mapTo(a.widget(), QPoint(0, 0)).y()
            a.verticalScrollBar().setValue(max(0, y - 24))
        QTimer.singleShot(40, lambda: Flash(target, self.acc))

    # ---------------------------------------------------------------- pages
    def p_welcome(self):
        w, lay = page(f"Welcome to PhoenixGe, {os.environ.get('USER', '')}!", "Rise from the ashes. A few things to set up - each takes one click.")
        grid = FlowGrid(340, 3)
        steps = [("Pick your look", "12 themes made from the PhoenixGe designs.", "themes"),
                 ("Graphics driver", "NVIDIA cards get their driver automatically - check it here.", "drivers"),
                 ("Phoenix Store", "Games, coding tools (VS Code…), Android and iOS dev, design, learning.", "store"),
                 ("Gaming", "Game Mode session, FPS counter, GE-Proton.", "gaming"),
                 ("Safety net", "Automatic system snapshots - undo any bad change.", "backups"),
                 ("Phone", "Files, notifications and clipboard with your phone.", "phone")]
        steps = [s for s in steps if s[2] in self.page_by_key]
        if not Path("/run/live").exists():
            prof = (Path("/var/lib/phoenixge/profile").read_text().strip() if Path("/var/lib/phoenixge/profile").exists() else "everything")
            names = {"games": "Steam, Heroic, Discord, Minecraft", "replay": "Instant Replay", "rgb": "RGB", "gpu": "GPU control",
                     "gamemode": "Game Mode", "devpack": "developer tools", "devapps": "VS Code, Android Studio",
                     "backups": "daily backups", "android": "Android apps"}
            steps_for = {"gaming": "games replay rgb gpu gamemode backups android", "developer": "devpack devapps backups android",
                         "minimal": "backups"}.get(prof, "games replay rgb gpu gamemode devpack devapps backups android").split()
            left = [names[k] for k in steps_for if not Path(f"/var/lib/phoenixge/fb-{k}.done").exists()]
            lay.addWidget(Card(f"Profile: {prof.capitalize()} - " + ("everything is ready ✓" if not left else "setting up in the background…"),
                               ("Installed: " + ", ".join(names[k] for k in steps_for) + ".") if not left else
                               "Installing: " + ", ".join(left) + ". Keep the internet on - it continues by itself, even after a restart."))
        for i, (t, d, target) in enumerate(steps):
            c = Card(t, d)
            b = QPushButton("Open"); b.clicked.connect(lambda _=False, k=target: self.open_page(k))
            c.lay.addWidget(b, 0, Qt.AlignLeft)
            grid.add(c)
        lay.addWidget(grid)
        auto = QCheckBox("Show this window at login"); auto.setChecked(not (CFG / "welcome-done").exists())
        auto.toggled.connect(lambda on: (CFG.mkdir(parents=True, exist_ok=True),
                                         (CFG / "welcome-done").unlink(missing_ok=True) if on else (CFG / "welcome-done").write_text("1")))
        lay.addWidget(auto); lay.addStretch()
        return w

    def p_themes(self):
        w, lay = page("Themes", "Every theme changes the whole desktop: taskbar, start menu, widgets, windows, colors and fonts.")
        current = kread("kdeglobals", "KDE", "LookAndFeelPackage")
        grid = FlowGrid(240, 6)
        self.theme_buttons = []
        tl = themes()
        for i, t in enumerate(tl):
            b = QToolButton(); b.setObjectName("theme"); b.setCheckable(True); b.setChecked(t["id"] == current)
            b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
            b.setIcon(QIcon(t["preview"])); b.setIconSize(QSize(200, 112)); b.setText(t["name"])
            b.setToolTip(t["desc"]); b.setFixedSize(224, 150); b.setAutoRaise(True)
            b.clicked.connect(lambda _=False, tid=t["id"], btn=b: self.apply_theme(tid, btn))
            self.theme_buttons.append(b)
            grid.add(b)
        lay.addWidget(grid)
        # automatic day / night
        c = Card("Automatic day / night", "Switch to a light theme in the day and a dark one at night.")
        conf = self.autotheme_conf()
        row = QHBoxLayout()
        en = QCheckBox("Enabled"); en.setChecked(conf.get("enabled") == "1")
        day, night = QComboBox(), QComboBox()
        for t in tl:
            day.addItem(t["name"], t["id"]); night.addItem(t["name"], t["id"])
        day.setCurrentIndex(max(0, day.findData(conf.get("day", "org.phoenixge.ash"))))
        night.setCurrentIndex(max(0, night.findData(conf.get("night", "org.phoenixge.ember"))))
        save = QPushButton("Save"); save.setObjectName("primary")
        save.clicked.connect(lambda: self.save_autotheme(en.isChecked(), day.currentData(), night.currentData()))
        for x in (en, QLabel("Day (07:00):"), day, QLabel("Night (19:00):"), night, save):
            row.addWidget(x)
        row.addStretch(); c.lay.addLayout(row); lay.addWidget(c)
        lv = Card("Live fire wallpaper", "Embers rise from the bottom of your wallpaper and the glow breathes slowly. Uses the "
                                         "graphics card, very light.")
        live = QCheckBox("Live wallpaper on")
        live.setChecked("org.phoenixge.fire" in sh("grep -h '^wallpaperplugin=' ~/.config/plasma-org.kde.plasma.desktop-appletsrc"))
        live.toggled.connect(self.set_live)
        lv.lay.addWidget(live); lay.addWidget(lv); lay.addStretch()
        return w

    def set_live(self, on):
        if on:
            js = ('desktops().forEach(function (d) { d.currentConfigGroup = ["Wallpaper", "org.kde.image", "General"];'
                  ' var img = d.readConfig("Image"); d.wallpaperPlugin = "org.phoenixge.fire";'
                  ' d.currentConfigGroup = ["Wallpaper", "org.phoenixge.fire", "General"];'
                  f' d.writeConfig("Image", img); d.writeConfig("Color", "{accent()}"); }});')
        else:
            js = 'desktops().forEach(function (d) { d.wallpaperPlugin = "org.kde.image"; });'
        sh(["gdbus", "call", "--session", "--dest", "org.kde.plasmashell", "--object-path", "/PlasmaShell",
            "--method", "org.kde.PlasmaShell.evaluateScript", js])

    def apply_theme(self, tid, btn):
        for b in self.theme_buttons:
            b.setChecked(b is btn)
        self.runner.run("sh", ["-c", f"plasma-apply-lookandfeel -a {tid} --resetLayout && plasma-apply-desktoptheme phoenixge-{tid.split('.')[-1]}"])

    def autotheme_conf(self):
        f = CFG / "autotheme.conf"
        try:
            return dict(l.split("=", 1) for l in f.read_text().split() if "=" in l)
        except OSError:
            return {}

    def save_autotheme(self, on, day, night):
        CFG.mkdir(parents=True, exist_ok=True)
        (CFG / "autotheme.conf").write_text(f"enabled={'1' if on else '0'}\nday={day}\nnight={night}\nday_start=07\nnight_start=19\n")
        sh("systemctl --user start phoenixge-autotheme.service")
        QMessageBox.information(self, "PhoenixGe", "Saved." + (" The theme switches automatically at 07:00 and 19:00." if on else ""))

    def p_drivers(self):
        w, lay = page("Drivers", "PhoenixGe installs the NVIDIA driver by itself on the first boot of an installed system (internet needed).")
        gpus = sh("lspci -nn | grep -Ei 'vga|3d|display' | sed 's/^[^ ]* //'") or "unknown"
        c = Card("Graphics", gpus); lay.addWidget(c)
        nv = "nvidia" in sh("lsmod")
        has_nv = "10de" in sh("lspci -nn | grep -Ei 'vga|3d'")
        if not has_nv:
            status = "No NVIDIA card - the built-in open driver (Mesa) is used, nothing to install."
        elif nv:
            status = "NVIDIA driver is running. " + sh("nvidia-smi --query-gpu=name,driver_version --format=csv,noheader")
        elif Path("/var/lib/phoenixge/nvidia-reboot-needed").exists():
            status = "NVIDIA driver installed - restart the computer to use it."
        else:
            status = "NVIDIA card found but the driver is not installed yet."
        s = Card("Status", status); lay.addWidget(s)
        if has_nv and not nv:
            b = QPushButton("Install NVIDIA driver now"); b.setObjectName("primary")
            b.clicked.connect(lambda: self.runner.root("/usr/lib/phoenixge/firstboot-nvidia.sh"))
            s.lay.addWidget(b, 0, Qt.AlignLeft)
        lay.addStretch()
        return w

    def p_store(self):
        w, lay = page("Phoenix Store", "Hand-picked apps by category. Flathub apps are sandboxed and update by themselves; "
                                       "everything else is in Discover.")
        top = QHBoxLayout()
        self.store_search = QLineEdit(); self.store_search.setPlaceholderText("Search the store…")
        self.store_search.textChanged.connect(lambda _t: self.fill_store())
        top.addWidget(self.store_search, 1)
        more = QPushButton("Open Discover"); more.clicked.connect(lambda: QProcess.startDetached("plasma-discover", []))
        top.addWidget(more); lay.addLayout(top)
        chips = QHBoxLayout(); chips.setSpacing(6)
        self.store_cat = CATEGORIES[0]
        self.cat_buttons = []
        for c in CATEGORIES:
            b = QPushButton(c.replace("&", "&&")); b.setCheckable(True); b.setChecked(c == self.store_cat); b.setProperty("cat", c)
            b.clicked.connect(lambda _=False, cc=c: self.pick_cat(cc))
            self.cat_buttons.append(b); chips.addWidget(b)
        chips.addStretch(); lay.addLayout(chips)
        self.store_grid = FlowGrid(300, 5)
        lay.addWidget(self.store_grid); lay.addStretch()
        self.installed = self.flatpaks()
        self.debs = set(l.split()[0] for l in sh("dpkg-query -W -f='${Package} ${db:Status-Status}\\n'", 20).splitlines()
                        if l.endswith(" installed"))
        self.fill_store()
        return w

    def pick_cat(self, c):
        self.store_cat = c
        for b in self.cat_buttons:
            b.setChecked(b.property("cat") == c)
        self.store_search.clear()
        self.fill_store()

    def fill_store(self):
        cards = []
        q = self.store_search.text().strip().lower()
        items = [x for x in STORE if (q and (q in x[3].lower() or q in x[4].lower())) or (not q and x[0] == self.store_cat)]
        seen = set()
        for i, (cat, kind, ident, name, what) in enumerate(items):
            if (kind, ident, name) in seen:
                continue
            seen.add((kind, ident, name))
            c = Card(name, what)
            if kind != "info":
                done = ((kind == "flatpak" and ident in self.installed) or
                        (kind in ("apt", "aptbpo") and set(ident.split()) <= self.debs))
                b = QPushButton("Installed" if done else ("Set up" if kind == "script" else "Install"))
                b.setEnabled(not done)
                if not done:
                    b.setObjectName("primary")
                    b.clicked.connect(lambda _=False, k=kind, ii=ident, btn=b: self.store_install(k, ii, btn))
                tag = QLabel({"flatpak": "Flathub", "apt": "Debian", "aptbpo": "Debian backports", "script": "official installer"}[kind])
                tag.setObjectName("dim")
                row = QHBoxLayout(); row.addWidget(b); row.addWidget(tag); row.addStretch(); c.lay.addLayout(row)
            cards.append(c)
        self.store_grid.set_items(cards)

    def store_install(self, kind, ident, btn):
        btn.setEnabled(False); btn.setText("Installing…")

        def done(code):
            btn.setText("Installed" if code == 0 else "Retry"); btn.setEnabled(code != 0)
            if code == 0 and kind == "flatpak":
                self.installed.add(ident)
            elif code == 0:
                self.debs.update(ident.split())
        if kind == "flatpak":
            self.runner.run("flatpak", ["install", "-y", "--noninteractive", "flathub", ident], done)
        elif kind in ("apt", "aptbpo"):
            self.runner.root("/usr/lib/phoenixge/apt-install.sh", (["-b"] if kind == "aptbpo" else []) + ident.split(), done)
        elif kind == "script":
            self.runner.run("sh", [f"/usr/lib/phoenixge/dev/{ident}"], done)

    def p_android(self):
        w, lay = page("Android", "Android apps in normal windows next to your other apps (Waydroid - a real Android in a container). "
                                 "Install apps from F-Droid, an APK file, or Google Play.")
        have = shutil.which("waydroid") is not None
        st = sh("waydroid status 2>/dev/null | grep -E 'Session|Container' | tr '\n' ' '") if have else ""
        nv_only = ("10de" in sh("lspci -nn | grep -Ei 'vga|3d'")) and not re.search(r"8086|1002", sh("lspci -nn | grep -Ei 'vga|3d'"))
        c = Card("Status", ("Installed. " + st) if have else "Not installed yet.")
        lay.addWidget(c)
        if nv_only:
            lay.addWidget(Card("NVIDIA note", "Waydroid can't use NVIDIA graphics, so Android draws with the CPU: normal apps are "
                                              "fine, heavy 3D Android games will be slow."))
        s1 = Card("1. Install Android", "Downloads Android (LineageOS, ~1 GB). With Google Play you must register the device once (step 4).")
        row = QHBoxLayout()
        b1 = QPushButton("Install (free apps / F-Droid)"); b1.setObjectName("primary")
        b1.clicked.connect(lambda: self.runner.root("/usr/lib/phoenixge/android-setup.sh"))
        b2 = QPushButton("Install with Google Play")
        b2.clicked.connect(lambda: self.runner.root("/usr/lib/phoenixge/android-setup.sh", ["gapps"]))
        row.addWidget(b1); row.addWidget(b2); row.addStretch(); s1.lay.addLayout(row); lay.addWidget(s1)
        s2 = Card("2. Start", "Starts Android, puts its apps in the start menu as separate windows and installs F-Droid.")
        row = QHBoxLayout()
        b3 = QPushButton("Start Android"); b3.setObjectName("primary")
        b3.clicked.connect(lambda: self.runner.run("sh", ["/usr/lib/phoenixge/android-user.sh"]))
        b4 = QPushButton("Full Android screen"); b4.clicked.connect(lambda: QProcess.startDetached("waydroid", ["show-full-ui"]))
        b5 = QPushButton("Install APK file…"); b5.clicked.connect(self.install_apk)
        b6 = QPushButton("Restart Android")
        b6.clicked.connect(lambda: self.runner.run("sh", ["-c", "waydroid session stop; sleep 2; sh /usr/lib/phoenixge/android-user.sh"]))
        for b in (b3, b4, b5, b6):
            b.setEnabled(have); row.addWidget(b)
        row.addStretch(); s2.lay.addLayout(row); lay.addWidget(s2)
        s3 = Card("3. ARM support", "Many Play Store apps and games are built only for phone (ARM) processors. This adds a translator "
                                    "(libndk on AMD, libhoudini on Intel).")
        b7 = QPushButton("Add ARM support"); b7.setEnabled(have)
        b7.clicked.connect(lambda: self.runner.root("/usr/lib/phoenixge/android-arm.sh"))
        s3.lay.addWidget(b7, 0, Qt.AlignLeft); lay.addWidget(s3)
        s4 = Card("4. Google Play registration", "Only for the Google Play version: get the device ID, paste it at "
                                                 "google.com/android/uncertified, wait ~10 minutes, restart Android.")
        row = QHBoxLayout()
        b8 = QPushButton("Show device ID"); b8.setEnabled(have)
        b8.clicked.connect(lambda: self.runner.root("/usr/lib/phoenixge/android-certify.sh"))
        b9 = QPushButton("Open registration page")
        b9.clicked.connect(lambda: QProcess.startDetached("xdg-open", ["https://www.google.com/android/uncertified"]))
        row.addWidget(b8); row.addWidget(b9); row.addStretch(); s4.lay.addLayout(row); lay.addWidget(s4)
        lay.addWidget(Card("Won't work", "Banking apps and games with anti-cheat (PUBG Mobile, Free Fire…) usually detect that this "
                                         "is not a real phone and refuse to start."))
        lay.addStretch()
        return w

    def install_apk(self):
        f, _ = QFileDialog.getOpenFileName(self, "Android app (.apk)", str(HOME / "Downloads"), "Android apps (*.apk)")
        if f:
            self.runner.run("waydroid", ["app", "install", f])

    def p_gaming(self):
        w, lay = page("Gaming", "Settings that make games run and look better.")
        lib = Card("Phoenix Games", "All your games in one library: Steam, Epic, GOG, Amazon (Heroic), Lutris, Minecraft "
                                    "and Android games, with covers and play time.")
        lb = QPushButton("Open Phoenix Games"); lb.setObjectName("primary")
        lb.clicked.connect(lambda: QProcess.startDetached("phoenixge-games", []))
        lib.lay.addWidget(lb, 0, Qt.AlignLeft); lay.addWidget(lib)
        envd = HOME / ".config/environment.d"
        mh = QCheckBox("Show FPS counter (MangoHud) in every game  - takes effect after logging in again")
        mh.setChecked((envd / "phoenixge-mangohud.conf").exists())
        mh.toggled.connect(lambda on: (envd.mkdir(parents=True, exist_ok=True),
                                       (envd / "phoenixge-mangohud.conf").write_text("MANGOHUD=1\n") if on
                                       else (envd / "phoenixge-mangohud.conf").unlink(missing_ok=True),
                                       QProcess.startDetached("python3", ["/usr/lib/phoenixge/gaming/flatpak_mangohud.py"])))
        auto = HOME / ".config/autostart/phoenixge-bigpicture.desktop"
        bp = QCheckBox("Start Steam Big Picture at login (console mode)")
        bp.setChecked(auto.exists())
        bp.toggled.connect(lambda on: self.bigpicture(on, auto))
        gs = Card("PhoenixGe Game Mode (like SteamOS)",
                  "On the login screen pick \"PhoenixGe Game Mode\" (session menu, bottom left): Steam's console interface starts "
                  "full screen inside gamescope - controller friendly, no desktop in the way. Quit Steam to come back.")
        ready = shutil.which("gamescope") is not None
        gb = QPushButton("Game Mode is ready ✓" if ready else "Set up Game Mode (gamescope + Steam)")
        gb.setEnabled(not ready); gb.setObjectName("primary")
        gb.clicked.connect(lambda: self.runner.run("sh", ["-c", "pkexec /bin/sh /usr/lib/phoenixge/apt-install.sh -b gamescope && "
                                                          "(flatpak info com.valvesoftware.Steam >/dev/null 2>&1 || "
                                                          "flatpak install -y --noninteractive flathub com.valvesoftware.Steam)"]))
        gs.lay.addWidget(gb, 0, Qt.AlignLeft); lay.addWidget(gs)
        # automatic game profile (GameMode start/end hooks -> /usr/lib/phoenixge/gaming/session.py)
        try:
            sys.path.insert(0, "/usr/lib/phoenixge/gaming")
            import settings as gset
            gconf = gset.load()
        except Exception:
            gset = None
        if gset:
            ap = Card("Automatic game profile", "While a game runs, PhoenixGe switches to maximum performance and keeps "
                      "everything else quiet. When you quit the game, everything goes back as it was.")
            for key, text in [("power_profile", "Performance power mode while playing"),
                              ("do_not_disturb", "Do Not Disturb (no notifications) while playing"),
                              ("pause_updates", "Pause updates and background maintenance while playing"),
                              ("fps_log", "Record FPS and temperatures (shown in Phoenix Games)"),
                              ("discord", "Show \"Playing ...\" in Discord")]:
                cb = QCheckBox(text); cb.setChecked(bool(gconf.get(key, True)))

                def toggled(on, k=key):
                    cf = gset.load(); cf[k] = on; gset.save(cf)
                    if k == "fps_log":  # Flatpak launchers (Heroic, Steam) get MangoHud via overrides
                        QProcess.startDetached("python3", ["/usr/lib/phoenixge/gaming/flatpak_mangohud.py"])
                cb.toggled.connect(toggled); ap.lay.addWidget(cb)
            lay.addWidget(ap)
        ov = Card("PhoenixGe Overlay (Meta+G)", "A game bar over your game: live FPS and temperatures, per-app volume, "
                  "music controls, screenshots and Instant Replay. Press Meta+G (or Esc) again to close it.")
        ov_auto = HOME / ".config/autostart/phoenixge-overlay.desktop"
        mrow = QHBoxLayout(); mrow.addWidget(QLabel("Overlay works:"))
        oc = QComboBox()
        oc.addItem("Only while a game is running", "game")
        oc.addItem("Always (Meta+G anywhere)", "always")
        always_now = gset.overlay_always() if gset else ov_auto.exists()
        oc.setCurrentIndex(1 if always_now else 0)

        def overlay_mode(_i):
            mode = oc.currentData()
            if gset:
                cf = gset.load(); cf["overlay_mode"] = mode; gset.save(cf)
            if mode == "always":   # resident from login on, opens instantly
                ov_auto.parent.mkdir(parents=True, exist_ok=True)
                ov_auto.write_text("[Desktop Entry]\nType=Application\nName=PhoenixGe Overlay\n"
                                   "Exec=phoenixge-overlay --daemon\nNoDisplay=true\nX-KDE-autostart-phase=2\n")
                QProcess.startDetached("phoenixge-overlay", ["--daemon"])
            else:                  # started with each game, quits after it
                ov_auto.unlink(missing_ok=True)
        oc.currentIndexChanged.connect(overlay_mode)
        mrow.addWidget(oc); mrow.addStretch(1); ov.lay.addLayout(mrow)
        orow = QHBoxLayout()
        ob1 = QPushButton("Open overlay"); ob1.setObjectName("primary")
        ob1.clicked.connect(lambda: QProcess.startDetached("phoenixge-overlay", ["--show"]))
        ob2 = QPushButton("Change shortcut…")
        ob2.clicked.connect(lambda: QProcess.startDetached("systemsettings", ["kcm_keys"]))
        orow.addWidget(ob1); orow.addWidget(ob2); orow.addStretch(1); ov.lay.addLayout(orow)
        onote = QLabel("Works over windowed and borderless games. Not over exclusive-fullscreen games or the Game Mode "
                       "session - Steam's own overlay works there. If Meta+G opens the window grid instead, set the "
                       "shortcut with \"Change shortcut…\"."); onote.setWordWrap(True); onote.setObjectName("dim")
        ov.lay.addWidget(onote); lay.addWidget(ov)
        c = Card("Performance"); c.lay.addWidget(mh); c.lay.addWidget(bp)
        gm = QLabel("GameMode is always on for Windows programs started with PhoenixGe (phoenix-run) and for Steam games "
                    "with the launch option  gamemoderun %command%"); gm.setWordWrap(True); gm.setObjectName("dim")
        c.lay.addWidget(gm); lay.addWidget(c)
        p = Card("GE-Proton", "A community Proton build with extra fixes for Windows games. ProtonUp-Qt installs and updates it "
                              "for Steam, Heroic, Lutris and Bottles.")
        b = QPushButton("Install / open ProtonUp-Qt"); b.setObjectName("primary")
        b.clicked.connect(lambda: self.runner.run(
            "sh", ["-c", "flatpak info net.davidotek.pupgui2 >/dev/null 2>&1 || "
                         "flatpak install -y --noninteractive flathub net.davidotek.pupgui2"],
            lambda code: code == 0 and QProcess.startDetached("flatpak", ["run", "net.davidotek.pupgui2"])))
        p.lay.addWidget(b, 0, Qt.AlignLeft); lay.addWidget(p)
        kver = sh("uname -r")
        has_ntsync = Path("/dev/ntsync").exists()
        k = Card("Gaming kernel (ntsync)",
                 f"Current kernel: {kver} - ntsync {'available ✓' if has_ntsync else 'not available'}.\n"
                 "The newest Debian kernel (backports, 7.x) has ntsync, which makes many Windows games run smoother with "
                 "Proton/Wine. NVIDIA driver is updated to match. The old kernel stays in the boot menu as a fallback.")
        kb = QPushButton("Install gaming kernel"); kb.setEnabled(not has_ntsync)
        kb.clicked.connect(lambda: self.runner.root("/usr/lib/phoenixge/gaming-kernel.sh"))
        k.lay.addWidget(kb, 0, Qt.AlignLeft); lay.addWidget(k)
        ir = Card("Instant Replay (like NVIDIA ShadowPlay)",
                  "GPU Screen Recorder keeps the last 30-60 seconds of your game in memory; press its hotkey to save the clip. "
                  "Uses the graphics card's video encoder, so games don't slow down.")
        self.flatpak_button(ir, "com.dec05eba.gpu_screen_recorder", "Open Instant Replay"); lay.addWidget(ir)
        nv = "10de" in sh("lspci -nn | grep -Ei 'vga|3d'")
        gc = Card("Graphics card control (LACT)", "Fans, temperature, clocks and power limit for NVIDIA and AMD cards - like MSI "
                  "Afterburner. The first time it opens, LACT asks for your password once to set up its background service."
                  + (" NVIDIA: install the driver on the Drivers page first." if nv else ""))
        self.flatpak_button(gc, "io.github.ilya_zlobintsev.LACT", "Open LACT")
        lay.addWidget(gc)
        rgb = Card("RGB lighting", "OpenRGB controls keyboards, mice, RAM and graphics card lights from almost every brand. "
                                   "With 'follow theme' on, the lights take the color of the PhoenixGe theme.")
        self.flatpak_button(rgb, "org.openrgb.OpenRGB", "Open OpenRGB")
        fol = QCheckBox("RGB follows the theme color"); fol.setChecked(not (CFG / "rgb-off").exists())
        fol.toggled.connect(lambda on: (CFG.mkdir(parents=True, exist_ok=True),
                                        (CFG / "rgb-off").unlink(missing_ok=True) if on else (CFG / "rgb-off").write_text("1")))
        rgb.lay.addWidget(fol); lay.addWidget(rgb)
        ct = Card("Controllers", "Xbox, PlayStation (DualShock 4 / DualSense), Switch Pro and Steam controllers work over USB and "
                                 "Bluetooth. Bluetooth: hold the pair button on the controller, then pair it here.")
        b = QPushButton("Pair a Bluetooth controller"); b.clicked.connect(lambda: QProcess.startDetached("systemsettings", ["kcm_bluetooth"]))
        ct.lay.addWidget(b, 0, Qt.AlignLeft); lay.addWidget(ct)
        ac = Card("Anti-cheat", "Games with kernel anti-cheat (Valorant, FACEIT, Fortnite…) do not run on Linux at all. "
                                "Check a game on areweanticheatyet.com before buying.")
        lay.addWidget(ac); lay.addStretch()
        return w

    def bigpicture(self, on, auto):
        if on:
            auto.parent.mkdir(parents=True, exist_ok=True)
            cmd = "flatpak run com.valvesoftware.Steam -gamepadui" if "com.valvesoftware.Steam" in self.flatpaks() else "steam -gamepadui"
            auto.write_text(f"[Desktop Entry]\nType=Application\nName=Steam Big Picture\nExec={cmd}\nIcon=steam\n")
        else:
            auto.unlink(missing_ok=True)

    def flatpak_button(self, card, fid, label):
        have = fid in self.flatpaks()
        b = QPushButton(label if have else "Install")
        state = {"have": have}

        def finished(code):  # after a successful install the button opens the app instead of installing again
            state["have"] = code == 0
            b.setText(label if code == 0 else "Retry"); b.setEnabled(True)

        def clicked():
            if state["have"]:
                QProcess.startDetached("flatpak", ["run", fid])
            else:
                b.setEnabled(False); b.setText("Installing…")
                self.runner.run("flatpak", ["install", "-y", "--noninteractive", "flathub", fid], finished)
        if not have:
            b.setObjectName("primary")
        b.clicked.connect(clicked)
        card.lay.addWidget(b, 0, Qt.AlignLeft)

    def flatpaks(self):
        if getattr(self, "_flatpaks", None) is None:
            self._flatpaks = set(sh("flatpak list --app --columns=application", 20).split())
        return self._flatpaks

    def p_security(self):
        w, lay = page("Security", "Firewall, VPN, passwords, an encrypted folder and fingerprint login.")
        fw_on = Path("/etc/ufw/ufw.conf").exists() and "ENABLED=yes" in Path("/etc/ufw/ufw.conf").read_text(errors="ignore")
        c = Card("Firewall", "Blocks incoming connections from the network; apps can still go out. "
                             + ("Status: ON ✓" if fw_on else "Status: off"))
        row = QHBoxLayout()
        b1 = QPushButton("Turn firewall off" if fw_on else "Turn firewall on"); b1.setObjectName("" if fw_on else "primary")
        fw = {"on": fw_on}

        def fw_done(code):
            if code == 0:
                fw["on"] = not fw["on"]
                b1.setText("Turn firewall off" if fw["on"] else "Turn firewall on")
        b1.clicked.connect(lambda: self.runner.run("pkexec", ["/bin/sh", "-c", "ufw disable" if fw["on"] else
                                                              "ufw default deny incoming; ufw default allow outgoing; ufw allow 1714:1764/udp; "
                                                              "ufw allow 1714:1764/tcp; ufw --force enable"], fw_done))
        b2 = QPushButton("Advanced rules"); b2.clicked.connect(lambda: QProcess.startDetached("systemsettings", ["kcm_firewall"]))
        row.addWidget(b1); row.addWidget(b2); row.addStretch(); c.lay.addLayout(row)
        n = QLabel("KDE Connect (phone) stays allowed."); n.setObjectName("dim"); c.lay.addWidget(n); lay.addWidget(c)
        v = Card("VPN (WireGuard)", "Got a .conf file from your VPN provider (Proton VPN, Mullvad, your own server)? Import it - "
                                    "it then shows up in the network icon in the system tray.")
        b3 = QPushButton("Import WireGuard file…"); b3.setObjectName("primary"); b3.clicked.connect(self.import_vpn)
        v.lay.addWidget(b3, 0, Qt.AlignLeft); lay.addWidget(v)
        k = Card("Password manager", "KeePassXC keeps all passwords in one encrypted file, fills them in the browser, makes strong ones.")
        b4 = QPushButton("Open KeePassXC"); b4.clicked.connect(lambda: QProcess.startDetached("keepassxc", []))
        k.lay.addWidget(b4, 0, Qt.AlignLeft); lay.addWidget(k)
        vt = Card("Encrypted folder (Plasma Vault)", "A folder that is locked with a password - only open when you unlock it from the "
                                                     "system tray (lock icon). Good for documents and photos.")
        b5 = QPushButton("Create a vault"); b5.clicked.connect(lambda: QProcess.startDetached("gdbus", ["call", "--session", "--dest", "org.kde.kded6", "--object-path",
                                                                    "/modules/plasmavault", "--method", "org.kde.plasmavault.requestNewVault"]))
        vt.lay.addWidget(b5, 0, Qt.AlignLeft); lay.addWidget(vt)
        has_fp = bool(sh("lsusb 2>/dev/null | grep -Ei 'fingerprint|synaptics|goodix|elan|validity'"))
        f = Card("Fingerprint login", ("Fingerprint reader found. " if has_fp else "No fingerprint reader detected on this computer. ")
                 + "Add your finger in Settings > Users; then log in, unlock and approve admin prompts with it. "
                 "(Face login like Windows Hello needs an IR camera and is not available for Debian yet.)")
        b6 = QPushButton("Set up fingerprint"); b6.setEnabled(has_fp)
        b6.clicked.connect(lambda: self.runner.run("pkexec", ["/bin/sh", "-c", "DEBIAN_FRONTEND=noninteractive pam-auth-update --enable fprintd"],
                                                   lambda _c: QProcess.startDetached("systemsettings", ["kcm_users"])))
        f.lay.addWidget(b6, 0, Qt.AlignLeft); lay.addWidget(f)
        lay.addStretch()
        return w

    def import_vpn(self):
        f, _ = QFileDialog.getOpenFileName(self, "WireGuard config", str(HOME / "Downloads"), "WireGuard (*.conf)")
        if f:
            self.runner.run("nmcli", ["connection", "import", "type", "wireguard", "file", f])

    def p_devices(self):
        w, lay = page("Devices", "Battery, TV and screens.")
        prof = sh("powerprofilesctl get")
        c = Card("Power mode", f"Current: {prof or 'unknown'}. Battery saver gives the longest battery life, Performance the most FPS.")
        row = QHBoxLayout()
        for key, label in [("power-saver", "🔋 Battery saver"), ("balanced", "⚖ Balanced"), ("performance", "🚀 Performance")]:
            b = QPushButton(label + ("  ✓" if prof == key else ""))
            if prof == key:
                b.setObjectName("primary")
            b.clicked.connect(lambda _=False, k=key: self.runner.run("powerprofilesctl", ["set", k]))
            row.addWidget(b)
        row.addStretch(); c.lay.addLayout(row); lay.addWidget(c)
        try:  # laptop: smart battery, battery protection, graphics mode (hidden on desktops)
            import laptop
            lay.addWidget(laptop.build(self))
        except Exception as e:
            print("laptop section:", e, file=sys.stderr)
            bat = sh("upower -i $(upower -e | grep -m1 BAT) 2>/dev/null | grep -E 'percentage|state|time to' | sed 's/^ *//'")
            if bat:
                lay.addWidget(Card("Battery", bat))
        t = Card("Show on a TV", "Miracast (most smart TVs, Windows-style 'Cast') and Chromecast: the screen appears on the TV "
                                 "over Wi-Fi. TV and computer on the same network; on the TV enable 'Screen mirroring'.")
        b = QPushButton("Cast to TV"); b.setObjectName("primary")
        b.clicked.connect(lambda: QProcess.startDetached("gnome-network-displays", []))
        t.lay.addWidget(b, 0, Qt.AlignLeft); lay.addWidget(t)
        d = Card("Screens", "Resolution, refresh rate (144 Hz), scaling, multiple monitors.")
        b2 = QPushButton("Display settings"); b2.clicked.connect(lambda: QProcess.startDetached("systemsettings", ["kcm_kscreen"]))
        d.lay.addWidget(b2, 0, Qt.AlignLeft); lay.addWidget(d)
        lay.addStretch()
        return w

    def p_migrate(self):
        w, lay = page("Move from Windows", "Copy your games (Epic → Heroic, Steam), find Linux versions of your Windows "
                                           "programs, bring files, bookmarks and wallpaper over. Windows is only read, never changed.")
        c = Card("Move from Windows", "Opens the Windows drive read-only and lets you pick what to bring over. Tip: in Windows run "
                 "'powercfg /h off' once (turns off Fast Startup), otherwise the Windows drive may be locked.")
        row = QHBoxLayout()
        for label, pg in (("Start", ""), ("Games", "games"), ("Programs", "programs"), ("Files & settings", "files")):
            b = QPushButton(label)
            if not pg:
                b.setObjectName("primary")
            b.clicked.connect(lambda _=False, p=pg: QProcess.startDetached("phoenixge-migrate", ["--page", p] if p else []))
            row.addWidget(b)
        row.addStretch(); c.lay.addLayout(row); lay.addWidget(c); lay.addStretch()
        return w

    def p_backups(self):
        w, lay = page("Backups", "Timeshift keeps snapshots of the system (not your personal files). If an update or a change breaks "
                                 "something, restore yesterday's system in a few clicks.")
        have = shutil.which("timeshift") is not None
        conf = Path("/etc/timeshift/timeshift.json")
        state = "not installed" if not have else ("automatic daily snapshots are ON" if conf.exists() and '"schedule_daily" : "true"' in conf.read_text(errors="ignore") else "automatic snapshots are off")
        c = Card("Status", f"Timeshift: {state}"); lay.addWidget(c)
        st = c.findChild(QLabel, "dim")
        row = QHBoxLayout()
        b1 = QPushButton("Turn on daily snapshots (keep 5)"); b1.setObjectName("primary")
        b1.clicked.connect(lambda: self.runner.root("/usr/lib/phoenixge/timeshift-auto.sh"))
        b2 = QPushButton("Make a snapshot now")
        b2.clicked.connect(lambda: self.runner.run("pkexec", ["/usr/bin/timeshift", "--create", "--comments", "PhoenixGe Center", "--yes"]))
        b3 = QPushButton("Open Timeshift (restore)"); b3.clicked.connect(lambda: QProcess.startDetached("timeshift-launcher", []))
        for b in (b1, b2, b3):
            b.setEnabled(have); row.addWidget(b)
        if not have:  # Timeshift is only a Recommends of phoenixge-desktop
            bi = QPushButton("Install Timeshift"); bi.setObjectName("primary")

            def installed(code):
                if code == 0:
                    bi.hide(); st.setText("Timeshift: installed - turn on daily snapshots")
                    for b in (b1, b2, b3):
                        b.setEnabled(True)
            bi.clicked.connect(lambda: self.runner.root("/usr/lib/phoenixge/apt-install.sh", ["timeshift"], installed))
            row.insertWidget(0, bi)
        row.addStretch(); c.lay.addLayout(row)
        # safe updates: a snapshot before every update + "restore previous state" in the boot menu
        optout = Path("/var/lib/phoenixge/no-pre-update-snapshot")
        btrfs = sh("findmnt -no FSTYPE /").strip() == "btrfs"
        booted = sh("/usr/bin/phoenixge-rollback --status").strip()
        su = Card("Safe updates", "Before every update the system state is saved (the last 5 are kept). If the computer doesn't "
                  "start properly after an update, pick \"PhoenixGe - restore previous state\" in the boot menu. "
                  + ("Snapshots start directly from the boot menu (btrfs)." if btrfs else
                     "The boot menu opens a restore tool (ext4 - snapshots can't be started directly)."))
        pre = QCheckBox("Save the system state before every update"); pre.setChecked(not optout.exists()); pre.setEnabled(have)
        pre.toggled.connect(lambda on: self.runner.run("pkexec", ["/bin/sh", "-c", f"rm -f {optout}" if on else
                                                                     f"mkdir -p {optout.parent} && touch {optout}"]))
        su.lay.addWidget(pre)
        r2 = QHBoxLayout()
        rb = QPushButton("Restore a previous state…")
        rb.clicked.connect(lambda: QProcess.startDetached("konsole", ["-e", "sudo", "/usr/bin/phoenixge-rollback"]))
        rb.setEnabled(have); r2.addWidget(rb)
        if booted.startswith("snapshot"):
            mp = QPushButton("You're running a saved state - make it permanent"); mp.setObjectName("primary")
            mp.clicked.connect(lambda: QProcess.startDetached("/usr/lib/phoenixge/snapshot-notice.sh", []))
            r2.addWidget(mp)
        r2.addStretch(); su.lay.addLayout(r2); lay.addWidget(su); lay.addStretch()
        return w

    def p_updates(self):
        ver = VERSION.read_text().strip() if VERSION.exists() else "?"
        w, lay = page("Updates", f"PhoenixGe {ver}. New themes, fixes and tools arrive as normal updates - no reinstall needed.")
        c = Card("Update now", "Updates PhoenixGe and all system packages (asks for your password).")
        b = QPushButton("Check and install updates"); b.setObjectName("primary")
        b.clicked.connect(lambda: self.runner.run("phoenixge-update", []))
        c.lay.addWidget(b, 0, Qt.AlignLeft); lay.addWidget(c)
        d = Card("Automatic", "Discover also shows PhoenixGe updates in the system tray.")
        o = QPushButton("Open Discover updates"); o.clicked.connect(lambda: QProcess.startDetached("plasma-discover", ["--mode", "update"]))
        d.lay.addWidget(o, 0, Qt.AlignLeft); lay.addWidget(d); lay.addStretch()
        return w

    def p_language(self):
        w, lay = page("Language", "Language of menus and apps. Log out and in again to apply.")
        cur = kread("plasma-localerc", "Translations", "LANGUAGE")
        c = Card("Display language")
        row = QHBoxLayout()
        for code, label in [("en_US", "English"), ("ka:en_US", "ქართული (Georgian)")]:
            b = QPushButton(label + ("  ✓" if cur == code or (not cur and code == "en_US") else ""))
            b.clicked.connect(lambda _=False, cd=code: (sh(["kwriteconfig6", "--file", "plasma-localerc", "--group", "Translations", "--key", "LANGUAGE", cd]),
                                                     QMessageBox.information(self, "PhoenixGe", "Saved - log out and in again.")))
            row.addWidget(b)
        row.addStretch(); c.lay.addLayout(row)
        kb = QLabel("Keyboard: English + Georgian, switch with Alt+Shift."); kb.setObjectName("dim"); c.lay.addWidget(kb)
        lay.addWidget(c); lay.addStretch()
        return w

    def p_phone(self):
        w, lay = page("Phone", "KDE Connect links your Android phone (or iPhone with limited features): send files, see notifications, "
                               "share the clipboard, use the phone as a remote.")
        c = Card("1. Install the app on the phone", "Google Play / F-Droid: \"KDE Connect\". iPhone: App Store \"KDE Connect\".")
        lay.addWidget(c)
        d = Card("2. Pair", "Phone and computer on the same Wi-Fi, then pair here.")
        b = QPushButton("Open KDE Connect"); b.setObjectName("primary")
        b.clicked.connect(lambda: QProcess.startDetached("kdeconnect-app", []))
        d.lay.addWidget(b, 0, Qt.AlignLeft); lay.addWidget(d); lay.addStretch()
        return w

    def p_system(self):
        w, lay = page("System")
        info = [("PhoenixGe", VERSION.read_text().strip() if VERSION.exists() else "?"),
                ("Base", sh(". /etc/os-release; echo $PRETTY_NAME")), ("Kernel", sh("uname -r")),
                ("CPU", sh("grep -m1 'model name' /proc/cpuinfo | cut -d: -f2")),
                ("Memory", sh("free -h | awk '/^Mem/{print $2}'")), ("Disk /", sh("df -h / | awk 'NR==2{print $4\" free of \"$2}'")),
                ("Graphics", sh("lspci | grep -Ei 'vga|3d' | cut -d: -f3"))]
        c = Card("This computer")
        g = QGridLayout()
        for i, (k, v) in enumerate(info):
            a = QLabel(k); a.setObjectName("dim"); g.addWidget(a, i, 0)
            b = QLabel(v.strip() or "-"); b.setTextInteractionFlags(Qt.TextSelectableByMouse); g.addWidget(b, i, 1)
        c.lay.addLayout(g); lay.addWidget(c)
        t = Card("Tools")
        row = QHBoxLayout()
        for label, prog in [("Kali Toolbox", "phoenix-toolbox"), ("System Monitor", "plasma-systemmonitor"), ("Settings", "systemsettings")]:
            b = QPushButton(label); b.clicked.connect(lambda _=False, p=prog: QProcess.startDetached(p, [])); row.addWidget(b)
        row.addStretch(); t.lay.addLayout(row); lay.addWidget(t); lay.addStretch()
        return w


def main():
    welcome = "--welcome" in sys.argv
    if welcome and (CFG / "welcome-done").exists():
        return 0
    app = QApplication(sys.argv)
    app.setApplicationName("PhoenixGe Center")
    app.setDesktopFileName("phoenixge-center")
    want = None
    if "--page" in sys.argv:  # --page <key> (keys/aliases in PAGES; old page titles work too)
        i = sys.argv.index("--page")
        want = sys.argv[i + 1] if len(sys.argv) > i + 1 else None
    else:
        want = next((a.split("=", 1)[1] for a in sys.argv if a.startswith("--page=")), None)
    if "--list-pages" in sys.argv:
        for p in PAGES:
            print(f"{p['key']:12} {p['group']:8} {p['title']}" + ("" if page_available(p) else "   (module missing)"))
        return 0
    w = Center(welcome, want)
    w.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
