#!/bin/sh
# Put PhoenixGe shortcuts on the user's desktop at login (each one only once,
# so a shortcut the user deleted stays deleted). Order/look follow design/Main.dc.html:
# Home, Games, Windows Apps, Trash (+ Kali Tools, ChatlaxiAI).
DESK=$(xdg-user-dir DESKTOP 2>/dev/null)
[ -n "$DESK" ] || DESK="$HOME/Desktop"
DONE="$HOME/.local/share/phoenixge/desktop-icons.done"
mkdir -p "$DESK" "$(dirname "$DONE")" "$HOME/Games" "$HOME/Windows Apps"

N=0
link() {  # id name url icon  (folder view sorts by date: old fixed mtimes keep the design order)
  N=$((N + 1))
  grep -qx "$1" "$DONE" 2>/dev/null && return
  printf '[Desktop Entry]\nType=Link\nName=%s\nURL=%s\nIcon=%s\n' "$2" "$3" "$4" > "$DESK/$1.desktop"
  chmod +x "$DESK/$1.desktop"
  touch -d "2000-01-01 00:00:$(printf %02d $N)" "$DESK/$1.desktop"
  echo "$1" >> "$DONE"
}
link 01-home "Home" "file://$HOME" phoenixge-home
link 02-games "Games" "file://$HOME/Games" phoenixge-games
link 03-windows-apps "Windows Apps" "file://$HOME/Windows Apps" phoenixge-winapps
link 04-trash "Trash" "trash:/" phoenixge-trash

# owner: the desktop shows the APPS we have (Center pages like Store/Themes stay inside PhoenixGe Center).
# Shortcuts from an earlier version that pointed at Center pages are removed once.
for old in 06-store 07-android 08-themes 09-gamemode 05-center; do
  f="$DESK/$old.desktop"
  [ -f "$f" ] && grep -q '^Exec=phoenixge-center' "$f" && rm -f "$f"
done

# apps: system ones and Flatpak ones (Steam/Heroic/Discord/Minecraft appear here once they are installed)
for app in phoenixge-center phoenix-toolbox ge.chatlaxi.ai firefox-esr net.lutris.Lutris            com.valvesoftware.Steam com.heroicgameslauncher.hgl com.discordapp.Discord org.prismlauncher.PrismLauncher; do
  N=$((N + 1))
  src=""
  for d in /usr/share/applications /var/lib/flatpak/exports/share/applications "$HOME/.local/share/flatpak/exports/share/applications"; do
    [ -f "$d/$app.desktop" ] && { src="$d/$app.desktop"; break; }
  done
  [ -n "$src" ] || continue
  grep -qx "$app" "$DONE" 2>/dev/null && continue
  cp "$src" "$DESK/$app.desktop"
  chmod +x "$DESK/$app.desktop"
  gio set "$DESK/$app.desktop" metadata::trusted true 2>/dev/null || true
  touch -d "2000-01-01 00:00:$(printf %02d $N)" "$DESK/$app.desktop"
  echo "$app" >> "$DONE"
done
