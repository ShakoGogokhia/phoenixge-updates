#!/bin/sh
# PhoenixGe: on the INSTALLED system, set up everything PhoenixGe offers, once (needs internet).
# Each step has its own stamp, so a step that failed (no internet) is retried on the next boot / every 5 min.
#   apps     Steam, Heroic (Epic/GOG: Rocket League), Discord, Prism Launcher (Minecraft), Bottles, ProtonUp-Qt (GE-Proton)
#   gamemode gamescope from Debian backports -> "PhoenixGe Game Mode" session on the login screen
#   backups  Timeshift daily system snapshots (keep 5) + first snapshot
#   android  Waydroid (Android apps in windows), Android image downloaded and ready
[ -d /run/live ] && exit 0                       # skip in the live session
D=/var/lib/phoenixge; mkdir -p "$D"
LOG=/var/log/phoenixge-firstboot.log
exec >>"$LOG" 2>&1
echo "=== $(date) first-boot setup"
for i in $(seq 1 30); do getent hosts dl.flathub.org >/dev/null && break; sleep 10; done
step() { [ -f "$D/fb-$1.done" ] && return 0; echo "--- $1"; if "$2"; then touch "$D/fb-$1.done"; else echo "!!! $1 failed, retry later"; FAIL=1; fi; }
FAIL=0

apps() {
  flatpak remote-add --if-not-exists --system flathub https://dl.flathub.org/repo/flathub.flatpakrepo &&
  flatpak install --system --noninteractive -y flathub com.valvesoftware.Steam com.heroicgameslauncher.hgl \
    com.discordapp.Discord org.prismlauncher.PrismLauncher com.usebottles.bottles net.davidotek.pupgui2
}
gamemode() { sh /usr/lib/phoenixge/apt-install.sh -b gamescope; }
backups() { command -v timeshift >/dev/null && sh /usr/lib/phoenixge/timeshift-auto.sh; }
android() { sh /usr/lib/phoenixge/android-setup.sh; }

step apps apps
step gamemode gamemode
step backups backups
step android android
[ "$FAIL" = 0 ] && touch "$D/firstboot-v2.done"
echo "=== done (fail=$FAIL)"
exit 0
