/*
    PhoenixGe Launcher - the start menu from design/<Theme>-Start.dc.html
    (category rail, search, pinned grid, all apps, user card, power buttons).
    SPDX-License-Identifier: GPL-2.0-or-later
*/
pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Layouts
import QtQuick.Effects
import QtQuick.Shapes
import QtQuick.Window
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.kirigami as Kirigami
import org.kde.plasma.private.kicker as Kicker
import org.kde.plasma.private.sessions as Sessions
import org.kde.coreaddons as KCoreAddons

import "code/styles.js" as Styles

PlasmoidItem {
    id: root

    readonly property var s: Styles.get(Plasmoid.configuration.theme)
    readonly property bool railRight: s.layout === "right"   // design: categories on the right (Ash, Inferno, Cyber, Glass)
    readonly property bool chips: s.layout === "chips"       // design: categories as chips under the search (Kolkhi, Pastel, Forest)
    readonly property bool run: s.layout === "run"           // design: Mono run launcher (prompt + result list, no rail)
    readonly property bool library: s.layout === "library"   // design: Game Mode library (cover cards, filters, apps row)
    readonly property bool classic: !run && !library
    property int category: 0              // row in rootModel (0 = all applications)
    readonly property bool searching: searchText.length > 0
    property string searchText: ""

    Plasmoid.icon: Plasmoid.configuration.icon
    preferredRepresentation: compactRepresentation
    activationTogglesExpanded: true

    onExpandedChanged: {
        if (expanded) {
            rootModel.refresh();
            category = library ? gamesRow() : 0;
            searchText = "";
        }
    }

    // row of the "Games" category in rootModel (Game Mode library opens on it), 0 = all apps if there is none
    function gamesRow() {
        for (var i = 1; i < rootModel.count; ++i) {
            var n = String(rootModel.data(rootModel.index(i, 0), Qt.DisplayRole) || "").toLowerCase();
            if (n === "games" || n === "game" || n === "თამაშები") return i;
        }
        return 0;
    }

    // short category tag for the Mono run launcher grid ("game", "web", "sys" ...)
    function categoryTag(name) {
        var tags = { "development": "dev", "games": "game", "graphics": "gfx", "internet": "web", "multimedia": "media",
                     "office": "office", "settings": "set", "system": "sys", "utilities": "util", "education": "edu",
                     "science & math": "sci", "lost & found": "misc" };
        var n = String(name || "").toLowerCase();
        return tags[n] || n.substring(0, 5);
    }

    function categoryName(row) {
        if (row <= 0) return "All";
        return String(rootModel.data(rootModel.index(row, 0), Qt.DisplayRole) || "");
    }

    // ------------------------------------------------------------ models
    Kicker.RootModel {
        id: rootModel
        autoPopulate: false
        appletInterface: root
        flat: true
        sorted: true
        showSeparators: false
        showTopLevelItems: false
        showAllApps: true
        showAllAppsCategorized: false
        showRecentApps: false
        showRecentDocs: false
        showPowerSession: false
        showFavoritesPlaceholder: false

        Component.onCompleted: {
            favoritesModel.initForClient("org.phoenixge.launcher.favorites.instance-" + Plasmoid.id);
            refresh();
            if (!Plasmoid.configuration.favoritesPorted) {
                seedFavorites.start();
            }
        }
    }

    Instantiator {
        id: favIds
        model: rootModel.favoritesModel
        delegate: QtObject {
            required property var model
            readonly property string fid: model.favoriteId || ""
        }
    }

    // first run: pin exactly the apps from the design (KAStats loads asynchronously, so wait a moment)
    Timer {
        id: seedFavorites
        interval: 1500
        onTriggered: {
            var fav = rootModel.favoritesModel;
            var want = Plasmoid.configuration.favorites;
            var have = [];
            for (var k = 0; k < favIds.count; ++k) {
                if (favIds.objectAt(k)) have.push(favIds.objectAt(k).fid);
            }
            for (var i = 0; i < have.length; ++i) {
                if (want.indexOf(have[i]) < 0) fav.removeFavorite(have[i]);
            }
            addFavorites.start();
        }
    }
    Timer {  // second step: removals of preferred:// defaults are async, add the design apps afterwards
        id: addFavorites
        interval: 800
        onTriggered: {
            var fav = rootModel.favoritesModel;
            var want = Plasmoid.configuration.favorites;
            for (var j = 0; j < want.length; ++j) {
                if (!fav.isFavorite(want[j])) fav.addFavorite(want[j], -1);
            }
            Plasmoid.configuration.favoritesPorted = true;
        }
    }

    Kicker.RunnerModel {
        id: runnerModel
        appletInterface: root
        mergeResults: true
        favoritesModel: rootModel.favoritesModel
        query: root.searchText
    }

    Sessions.SessionManagement { id: session }
    KCoreAddons.KUser { id: kuser }

    // results lag a little behind the typed text: Enter during that time launches when they are there
    property var pendingLaunch: null
    Timer {
        id: settle
        interval: 350
        onTriggered: if (root.pendingLaunch) { var f = root.pendingLaunch; root.pendingLaunch = null; f(); }
    }
    onSearchTextChanged: settle.restart()
    function launchFirst(view) {
        var go = function() { if (view.count > 0) root.launch(view.model, Math.max(0, view.currentIndex)); };
        if (settle.running) root.pendingLaunch = go; else go();
    }

    function launch(model, row) {
        if (model && model.trigger(row, "", null)) {
            root.expanded = false;
        }
    }

    // ------------------------------------------------------------ start button
    compactRepresentation: MouseArea {
        id: button
        // design start buttons: icon tile (default), "text" = Cyber slanted START tab, "label" = Inferno logo + name pill.
        // Vertical panels always get the icon tile.
        readonly property string startStyle: root.s.startStyle
        readonly property bool iconOnly: startStyle === "icon" || Plasmoid.formFactor === PlasmaCore.Types.Vertical
        hoverEnabled: true
        Layout.minimumWidth: iconOnly ? height : tab.width + 4
        Layout.preferredWidth: Layout.minimumWidth
        onClicked: root.expanded = !root.expanded

        Item {
            id: tab
            visible: !button.iconOnly
            readonly property bool isText: button.startStyle === "text"
            readonly property int pad: Math.round(height * 0.38)
            x: 2
            anchors.verticalCenter: parent.verticalCenter
            height: Math.max(0, button.height - 8)
            width: (isText ? tabText.implicitWidth + root.s.startSlant : tabRow.implicitWidth) + 2 * pad
            opacity: (root.expanded || button.containsMouse) ? 1 : 0.9

            // Cyber: parallelogram tab, the right edge slanted (clip-path polygon in design/Cyber.dc.html)
            Shape {
                visible: tab.isText
                anchors.fill: parent
                layer.enabled: true
                layer.samples: 4
                ShapePath {
                    strokeWidth: -1
                    fillColor: root.s.startFill
                    startX: 0; startY: 0
                    PathLine { x: tab.width; y: 0 }
                    PathLine { x: tab.width - root.s.startSlant; y: tab.height }
                    PathLine { x: 0; y: tab.height }
                    PathLine { x: 0; y: 0 }
                }
            }
            Text {
                id: tabText
                visible: tab.isText
                anchors.verticalCenter: parent.verticalCenter
                anchors.horizontalCenter: parent.horizontalCenter
                anchors.horizontalCenterOffset: -root.s.startSlant / 2
                text: root.s.startText
                font.family: root.s.font; font.pixelSize: Math.max(10, Math.round(tab.height * 0.4))
                font.weight: Font.Bold; font.letterSpacing: 2
                color: root.s.startInk
            }

            // Inferno: gradient pill with the logo and the name
            Rectangle {
                visible: !tab.isText
                anchors.fill: parent
                radius: Math.min(12, height / 2)
                gradient: Gradient {
                    orientation: Gradient.Horizontal
                    GradientStop { position: 0; color: root.s.startFill }
                    GradientStop { position: 1; color: root.s.startFill2 }
                }
            }
            RowLayout {
                id: tabRow
                visible: !tab.isText
                anchors.centerIn: parent
                spacing: 8
                Kirigami.Icon {
                    Layout.preferredWidth: Math.round(tab.height * 0.6)
                    Layout.preferredHeight: Layout.preferredWidth
                    source: Plasmoid.configuration.icon
                }
                Text {
                    text: root.s.startText
                    font.family: root.s.font; font.pixelSize: Math.max(10, Math.round(tab.height * 0.34))
                    font.weight: Font.Bold
                    color: root.s.startInk
                }
            }
        }

        Rectangle {
            visible: button.iconOnly
            anchors.centerIn: parent
            width: Math.min(parent.width, parent.height) - 4
            height: width
            radius: root.s.startRadius
            color: (root.expanded || button.containsMouse) ? root.s.startBg : Qt.rgba(root.s.startBg.r, root.s.startBg.g, root.s.startBg.b, root.s.startBg.a * 0.7)
            border.color: root.s.startBorder
            border.width: 1

            Kirigami.Icon {
                anchors.centerIn: parent
                width: Math.round(parent.width * 0.7)
                height: width
                source: Plasmoid.configuration.icon
            }
        }
    }

    // ------------------------------------------------------------ menu
    fullRepresentation: Rectangle {
        id: menu
        // never larger than the screen (the Game Mode library is big)
        readonly property int popupW: Screen.desktopAvailableWidth > 0 ? Math.min(root.s.width, Screen.desktopAvailableWidth - 48) : root.s.width
        readonly property int popupH: Screen.desktopAvailableHeight > 0 ? Math.min(root.s.height, Screen.desktopAvailableHeight - 96) : root.s.height
        Layout.preferredWidth: popupW
        Layout.preferredHeight: popupH
        Layout.minimumWidth: popupW
        Layout.minimumHeight: popupH
        Layout.maximumWidth: popupW
        Layout.maximumHeight: popupH
        color: root.s.panelBg
        radius: root.s.radius
        border.color: root.s.panelBorder
        border.width: 1

        function focusSearch() {
            if (root.run) runInput.forceActiveFocus();
            else if (root.library) libInput.forceActiveFocus();
            else searchInput.forceActiveFocus();
        }

        // the category rail is flush with the popup frame (like the design): reach under the frame padding
        readonly property int pad: 8
        Item {
            visible: root.classic && !root.chips
            x: root.railRight ? menu.width - root.s.railWidth : -menu.pad; y: -menu.pad
            width: root.s.railWidth + menu.pad
            height: menu.height + 2 * menu.pad
            clip: true
            Rectangle { x: root.railRight ? -20 : 0; width: parent.width + 20; height: parent.height; radius: 18; color: root.s.railBg }
            Rectangle { x: root.railRight ? 0 : parent.width - 1; anchors { top: parent.top; bottom: parent.bottom } width: 1; color: root.s.railBorder }
        }

        Keys.onEscapePressed: root.expanded = false
        Component.onCompleted: menu.focusSearch()
        Connections {
            target: root
            function onExpandedChanged() {
                if (root.expanded) {
                    searchInput.text = "";
                    runInput.text = "";
                    libInput.text = "";
                    runList.currentIndex = 0;
                    coverList.currentIndex = 0;
                    menu.focusSearch();
                }
            }
        }

        RowLayout {
            visible: root.classic
            anchors.fill: parent
            anchors.margins: 1
            spacing: 0
            layoutDirection: root.railRight ? Qt.RightToLeft : Qt.LeftToRight

            // ---------------- categories rail
            Rectangle {
                visible: !root.chips
                Layout.fillHeight: true
                Layout.preferredWidth: root.s.railWidth
                color: "transparent"

                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 14
                    anchors.topMargin: 24
                    spacing: 4

                    Text {
                        text: "CATEGORIES"
                        font.family: root.s.font; font.pixelSize: 11; font.letterSpacing: 2
                        color: root.s.dim
                        leftPadding: 12; bottomPadding: 10
                    }

                    ListView {
                        id: catList
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        clip: true
                        spacing: 4
                        model: rootModel
                        boundsBehavior: Flickable.StopAtBounds
                        delegate: Rectangle {
                            id: cat
                            required property int index
                            required property var model
                            readonly property bool sel: root.category === index && !root.searching
                            width: ListView.view.width
                            height: 38
                            radius: 10
                            color: sel ? root.s.selBg : (catMouse.containsMouse ? root.s.hoverBg : "transparent")

                            Text {
                                anchors { left: parent.left; leftMargin: 12; right: countText.left; verticalCenter: parent.verticalCenter }
                                text: cat.index === 0 ? "All" : cat.model.display
                                elide: Text.ElideRight
                                font.family: root.s.font; font.pixelSize: 13
                                color: cat.sel ? root.s.accentFg : root.s.fg
                            }
                            Text {
                                id: countText
                                anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                                text: { var m = rootModel.modelForRow(cat.index); return m ? m.count : ""; }
                                font.family: root.s.font; font.pixelSize: 11
                                color: root.s.dim
                            }
                            MouseArea {
                                id: catMouse
                                anchors.fill: parent
                                hoverEnabled: true
                                onClicked: { root.searchText = ""; searchInput.text = ""; root.category = cat.index; }
                            }
                        }
                    }

                    // user card
                    Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 60
                        radius: 12
                        color: root.s.userBg
                        RowLayout {
                            anchors.fill: parent
                            anchors.margins: 12
                            spacing: 10
                            Rectangle {
                                Layout.preferredWidth: 36; Layout.preferredHeight: 36
                                radius: 18
                                gradient: Gradient {
                                    orientation: Gradient.Horizontal
                                    GradientStop { position: 0; color: root.s.avatarA }
                                    GradientStop { position: 1; color: root.s.avatarB }
                                }
                                Text {
                                    anchors.centerIn: parent
                                    text: (kuser.loginName || "?").charAt(0).toUpperCase()
                                    font.family: root.s.font; font.pixelSize: 14; font.weight: Font.Bold
                                    color: "#ffffff"
                                }
                            }
                            ColumnLayout {
                                spacing: 0
                                Text { text: kuser.loginName; font.family: root.s.font; font.pixelSize: 13; font.weight: Font.DemiBold; color: root.s.fg }
                                Text { text: "Administrator"; font.family: root.s.font; font.pixelSize: 11; color: root.s.dim }
                            }
                        }
                        MouseArea { anchors.fill: parent; onClicked: { Qt.openUrlExternally("file://" + kuser.homeDir); root.expanded = false; } }
                    }
                }
            }

            // ---------------- main area
            ColumnLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.margins: 24
                Layout.leftMargin: 28
                Layout.rightMargin: 28
                spacing: 20

                // search
                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 46
                    radius: root.s.searchRadius
                    color: root.s.searchBg
                    border.color: root.s.searchBorder
                    border.width: 1
                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: 18
                        anchors.rightMargin: 14
                        spacing: 10
                        Glyph { name: "search"; tint: root.s.accentFg; Layout.preferredWidth: 18; Layout.preferredHeight: 18 }
                        TextInput {
                            id: searchInput
                            Layout.fillWidth: true
                            font.family: root.s.font; font.pixelSize: 14
                            color: root.s.fg
                            selectionColor: root.s.accent
                            clip: true
                            onTextChanged: root.searchText = text
                            Keys.onReturnPressed: if (root.searching) { results.currentIndex = 0; root.launchFirst(results); }
                            Keys.onEnterPressed: if (root.searching) { results.currentIndex = 0; root.launchFirst(results); }
                            Keys.onDownPressed: if (root.searching) { results.forceActiveFocus(); results.currentIndex = 0; }
                            Text {
                                anchors.verticalCenter: parent.verticalCenter
                                visible: !searchInput.text
                                text: "Search apps, files, games"
                                font: searchInput.font
                                color: root.s.dim
                            }
                        }
                        Rectangle {
                            Layout.preferredHeight: 22
                            Layout.preferredWidth: metaText.implicitWidth + 16
                            radius: 6
                            color: "transparent"
                            border.color: root.s.badgeBorder
                            Text { id: metaText; anchors.centerIn: parent; text: "Meta"; font.family: root.s.font; font.pixelSize: 11; color: root.s.dim }
                        }
                    }
                }

                // ---- categories as chips (Kolkhi / Pastel / Forest designs)
                Flow {
                    visible: root.chips && !root.searching
                    Layout.fillWidth: true
                    spacing: 8
                    Repeater {
                        model: rootModel
                        Rectangle {
                            id: chip
                            required property int index
                            required property var model
                            readonly property bool sel: root.category === index
                            height: 30; width: chipLabel.implicitWidth + 28; radius: 15
                            color: sel ? root.s.accent : root.s.btnBg
                            Text {
                                id: chipLabel
                                anchors.centerIn: parent
                                text: chip.index === 0 ? "All" : chip.model.display
                                font.family: root.s.font; font.pixelSize: 12; font.weight: chip.sel ? Font.DemiBold : Font.Normal
                                color: chip.sel ? root.s.onAccent : root.s.fg
                            }
                            MouseArea { anchors.fill: parent; onClicked: { root.searchText = ""; searchInput.text = ""; root.category = chip.index; } }
                        }
                    }
                }

                // ---- search results
                ListView {
                    id: results
                    visible: root.searching
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    clip: true
                    spacing: 4
                    model: runnerModel.count > 0 ? runnerModel.modelForRow(0) : null
                    highlightFollowsCurrentItem: true
                    keyNavigationEnabled: true
                    Keys.onReturnPressed: root.launch(model, currentIndex)
                    Keys.onEnterPressed: root.launch(model, currentIndex)
                    delegate: Item {
                        id: hit
                        required property int index
                        required property var model
                        width: ListView.view.width
                        height: 44
                        AppRow {
                            anchors { fill: parent; bottomMargin: 4 }
                            index: hit.index
                            model: hit.model
                            highlighted: hit.ListView.isCurrentItem
                            onClicked: root.launch(results.model, hit.index)
                        }
                    }
                }

                // ---- pinned
                RowLayout {
                    visible: !root.searching && root.category === 0
                    Layout.fillWidth: true
                    Text { text: "Pinned"; font.family: root.s.font; font.pixelSize: 15; font.weight: Font.DemiBold; color: root.s.fg; Layout.fillWidth: true }
                    Text {
                        text: "Edit"; font.family: root.s.font; font.pixelSize: 12; color: root.s.accentFg
                        MouseArea { anchors.fill: parent; onClicked: { Plasmoid.internalAction("configure").trigger(); } }
                    }
                }
                GridView {
                    id: pinned
                    visible: !root.searching && root.category === 0
                    Layout.fillWidth: true
                    Layout.preferredHeight: Math.min(2, Math.ceil(count / root.s.pinnedCols)) * cellHeight
                    interactive: false
                    cellWidth: width / root.s.pinnedCols
                    cellHeight: root.s.tile + 40
                    model: rootModel.favoritesModel
                    delegate: Item {
                        id: tile
                        required property int index
                        required property var model
                        width: GridView.view.cellWidth
                        height: GridView.view.cellHeight
                        Column {
                            anchors.horizontalCenter: parent.horizontalCenter
                            spacing: 8
                            Kirigami.Icon {
                                anchors.horizontalCenter: parent.horizontalCenter
                                width: root.s.tile; height: root.s.tile
                                source: tile.model.decoration
                                scale: tileMouse.containsMouse ? 1.06 : 1
                                Behavior on scale { NumberAnimation { duration: 120 } }
                            }
                            Text {
                                anchors.horizontalCenter: parent.horizontalCenter
                                width: tile.width - 8
                                horizontalAlignment: Text.AlignHCenter
                                text: tile.model.display
                                elide: Text.ElideRight
                                font.family: root.s.font; font.pixelSize: 12
                                color: root.s.fg
                            }
                        }
                        MouseArea { id: tileMouse; anchors.fill: parent; hoverEnabled: true; onClicked: root.launch(rootModel.favoritesModel, tile.index) }
                    }
                }

                Rectangle { visible: !root.searching && root.category === 0; Layout.fillWidth: true; Layout.preferredHeight: 1; color: root.s.divider }

                // ---- all apps / category
                RowLayout {
                    visible: !root.searching
                    Layout.fillWidth: true
                    Text {
                        Layout.fillWidth: true
                        text: root.category === 0 ? "All apps" : (allApps.model ? allApps.model.description || "" : "")
                        font.family: root.s.font; font.pixelSize: 15; font.weight: Font.DemiBold; color: root.s.fg
                    }
                    Text { text: "A–Z"; font.family: root.s.font; font.pixelSize: 12; color: root.s.dim }
                }
                GridView {
                    id: allApps
                    visible: !root.searching
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    clip: true
                    boundsBehavior: Flickable.StopAtBounds
                    cellWidth: width / 2
                    cellHeight: 44
                    model: rootModel.count > 0 ? rootModel.modelForRow(root.category) : null
                    delegate: Item {
                        id: cell
                        required property int index
                        required property var model
                        width: GridView.view.cellWidth
                        height: GridView.view.cellHeight
                        AppRow {
                            anchors { fill: parent; rightMargin: 16; bottomMargin: 4 }
                            index: cell.index
                            model: cell.model
                            onClicked: root.launch(allApps.model, cell.index)
                        }
                    }
                }

                // ---- power
                RowLayout {
                    Layout.alignment: Qt.AlignRight
                    spacing: 8
                    PowerButton { glyph: "sleep"; tip: "Sleep"; onClicked: session.suspend() }
                    PowerButton { glyph: "lock"; tip: "Lock"; onClicked: session.lock() }
                    PowerButton { glyph: "restart"; tip: "Restart"; onClicked: session.requestReboot() }
                    PowerButton { glyph: "power"; tip: "Shut down"; primary: true; onClicked: session.requestShutdown() }
                }
            }
        }

        // ================================================================ Mono: run launcher (design/Mono-Start.dc.html)
        ColumnLayout {
            id: runView
            visible: root.run
            anchors.fill: parent
            anchors.margins: 1
            spacing: 0

            // header line
            RowLayout {
                Layout.fillWidth: true
                Layout.preferredHeight: 28
                Layout.leftMargin: 12
                Layout.rightMargin: 12
                Text { Layout.fillWidth: true; text: "launcher — drun"; font.family: root.s.font; font.pixelSize: 12; color: root.s.dim }
                Text { text: "meta"; font.family: root.s.font; font.pixelSize: 12; color: root.s.dim }
            }
            Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 1; color: root.s.divider }

            // prompt
            RowLayout {
                Layout.fillWidth: true
                Layout.preferredHeight: 58
                Layout.leftMargin: 16
                Layout.rightMargin: 16
                spacing: 10
                Text { text: "run ›"; font.family: root.s.font; font.pixelSize: 18; font.weight: Font.DemiBold; color: root.s.accent }
                TextInput {
                    id: runInput
                    Layout.fillWidth: true
                    font.family: root.s.font; font.pixelSize: 18
                    color: root.s.fg
                    selectionColor: root.s.accent
                    clip: true
                    onTextChanged: { root.searchText = text; runList.currentIndex = 0; }
                    Keys.onUpPressed: runList.currentIndex = Math.max(0, runList.currentIndex - 1)
                    Keys.onDownPressed: runList.currentIndex = Math.min(runList.count - 1, runList.currentIndex + 1)
                    Keys.onReturnPressed: root.launchFirst(runList)
                    Keys.onEnterPressed: root.launchFirst(runList)
                    Keys.onTabPressed: root.category = (root.category + 1) % Math.max(1, rootModel.count)
                    Keys.onBacktabPressed: root.category = (root.category + Math.max(1, rootModel.count) - 1) % Math.max(1, rootModel.count)
                    Keys.onPressed: (event) => {
                        if (!(event.modifiers & Qt.AltModifier)) return;
                        if (event.key >= Qt.Key_1 && event.key <= Qt.Key_9) {
                            var i = event.key - Qt.Key_1;
                            if (i < runList.count) root.launch(runList.model, i);
                        } else if (event.key === Qt.Key_L) { root.expanded = false; session.lock(); }
                        else if (event.key === Qt.Key_S) { root.expanded = false; session.suspend(); }
                        else if (event.key === Qt.Key_R) { root.expanded = false; session.requestReboot(); }
                        else if (event.key === Qt.Key_P) { root.expanded = false; session.requestShutdown(); }
                        else return;
                        event.accepted = true;
                    }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        visible: !runInput.text
                        text: "type an app, file or command"
                        font: runInput.font
                        color: root.s.dim
                        opacity: 0.6
                    }
                }
                Text {
                    text: (runList.count > 0 ? runList.currentIndex + 1 : 0) + " / " + runList.count
                    font.family: root.s.font; font.pixelSize: 12; color: root.s.dim
                }
            }
            Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 1; color: root.s.divider }

            // mode tabs = categories (Tab / Shift+Tab cycles)
            ListView {
                id: runTabs
                visible: !root.searching
                Layout.fillWidth: true
                Layout.preferredHeight: 24
                Layout.topMargin: 8
                Layout.leftMargin: 16
                Layout.rightMargin: 16
                orientation: ListView.Horizontal
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                model: root.run ? rootModel : null
                currentIndex: root.category
                highlightFollowsCurrentItem: false
                onCurrentIndexChanged: positionViewAtIndex(currentIndex, ListView.Contain)
                delegate: Rectangle {
                    id: rtab
                    required property int index
                    required property var model
                    readonly property bool sel: root.category === index
                    height: 24
                    width: rtabLabel.implicitWidth + 20
                    color: sel ? root.s.fg : "transparent"
                    Text {
                        id: rtabLabel
                        anchors.centerIn: parent
                        text: String(rtab.index === 0 ? "all" : rtab.model.display).toLowerCase()
                        font.family: root.s.font; font.pixelSize: 12; font.weight: rtab.sel ? Font.DemiBold : Font.Normal
                        color: rtab.sel ? root.s.viewBg : root.s.dim
                    }
                    MouseArea { anchors.fill: parent; onClicked: { root.category = rtab.index; runInput.forceActiveFocus(); } }
                }
            }

            // results (search) / pinned apps (empty prompt)
            ListView {
                id: runList
                Layout.fillWidth: true
                Layout.fillHeight: root.searching
                Layout.preferredHeight: root.searching ? -1 : Math.min(count, 5) * 38 + 16
                topMargin: 8
                bottomMargin: 8
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                model: !root.run ? null : (root.searching ? (runnerModel.count > 0 ? runnerModel.modelForRow(0) : null) : rootModel.favoritesModel)
                onCurrentIndexChanged: positionViewAtIndex(currentIndex, ListView.Contain)
                delegate: Rectangle {
                    id: rr
                    required property int index
                    required property var model
                    readonly property bool cur: ListView.isCurrentItem
                    width: ListView.view.width
                    height: 38
                    color: cur ? root.s.hoverBg : "transparent"
                    Rectangle { width: 3; height: parent.height; color: root.s.accent; visible: rr.cur }
                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: 16
                        anchors.rightMargin: 16
                        spacing: 14
                        Kirigami.Icon { source: rr.model.decoration; Layout.preferredWidth: 18; Layout.preferredHeight: 18 }
                        Text {
                            Layout.preferredWidth: 170
                            text: rr.model.display || ""
                            elide: Text.ElideRight
                            font.family: root.s.font; font.pixelSize: 14; font.weight: Font.DemiBold
                            color: rr.cur ? root.s.fg : root.s.dim
                        }
                        Text {
                            Layout.fillWidth: true
                            text: rr.model.description || ""
                            elide: Text.ElideRight
                            font.family: root.s.uiFont; font.pixelSize: 12
                            color: root.s.dim
                        }
                        Text {
                            text: rr.cur ? "enter" : (rr.index < 9 ? "alt+" + (rr.index + 1) : "")
                            font.family: root.s.font; font.pixelSize: 11
                            color: root.s.dim
                            opacity: 0.7
                        }
                    }
                    MouseArea {
                        anchors.fill: parent
                        hoverEnabled: true
                        onEntered: runList.currentIndex = rr.index
                        onClicked: root.launch(runList.model, rr.index)
                    }
                }
            }

            // all apps of the current category, 3 columns: "<tag> <name>"
            Rectangle { visible: !root.searching; Layout.fillWidth: true; Layout.preferredHeight: 1; color: root.s.divider }
            Text {
                visible: !root.searching
                Layout.leftMargin: 16
                Layout.topMargin: 12
                Layout.bottomMargin: 6
                text: root.categoryName(root.category).toLowerCase() + " · a–z"
                font.family: root.s.font; font.pixelSize: 11; color: root.s.dim
            }
            GridView {
                id: runGrid
                visible: !root.searching
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.leftMargin: 16
                Layout.rightMargin: 16
                Layout.bottomMargin: 8
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                cellWidth: Math.floor(width / 3)
                cellHeight: 24
                model: root.run && !root.searching && rootModel.count > 0 ? rootModel.modelForRow(root.category) : null
                delegate: Item {
                    id: rg
                    required property int index
                    required property var model
                    width: GridView.view.cellWidth
                    height: GridView.view.cellHeight
                    Row {
                        anchors.verticalCenter: parent.verticalCenter
                        spacing: 8
                        Text {
                            visible: root.category > 0
                            width: 44
                            text: root.categoryTag(root.categoryName(root.category))
                            font.family: root.s.font; font.pixelSize: 12; color: root.s.dim
                            opacity: 0.7
                        }
                        Text {
                            width: rg.width - (root.category > 0 ? 60 : 8)
                            text: rg.model.display || ""
                            elide: Text.ElideRight
                            font.family: root.s.font; font.pixelSize: 12
                            color: rgMouse.containsMouse ? root.s.accent : root.s.fg
                            opacity: rgMouse.containsMouse ? 1 : 0.8
                        }
                    }
                    MouseArea { id: rgMouse; anchors.fill: parent; hoverEnabled: true; onClicked: root.launch(runGrid.model, rg.index) }
                }
            }

            // footer: user@host, [l] [s] [r] [p]
            Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 1; color: root.s.divider }
            RowLayout {
                Layout.fillWidth: true
                Layout.preferredHeight: 40
                Layout.leftMargin: 16
                Layout.rightMargin: 16
                spacing: 6
                Text {
                    Layout.fillWidth: true
                    textFormat: Text.StyledText
                    text: "<font color='" + root.s.accent + "'>" + kuser.loginName + "</font><font color='" + root.s.dim + "'>@phoenixge</font>"
                    font.family: root.s.font; font.pixelSize: 12
                }
                TermButton { label: "[l] lock"; onClicked: session.lock() }
                TermButton { label: "[s] sleep"; onClicked: session.suspend() }
                TermButton { label: "[r] restart"; onClicked: session.requestReboot() }
                TermButton { label: "[p] power"; primary: true; onClicked: session.requestShutdown() }
            }
            Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 1; color: root.s.divider }
            Text {
                Layout.fillWidth: true
                Layout.preferredHeight: 26
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
                textFormat: Text.StyledText
                font.family: root.s.font; font.pixelSize: 11; color: root.s.dim
                readonly property string k: "<font color='" + root.s.fg + "'>"
                text: k + "↑↓</font> select&nbsp;&nbsp;&nbsp;" + k + "enter</font> run&nbsp;&nbsp;&nbsp;" + k + "tab</font> mode&nbsp;&nbsp;&nbsp;"
                      + k + "alt+1‑9</font> quick&nbsp;&nbsp;&nbsp;" + k + "alt+l/s/r/p</font> session&nbsp;&nbsp;&nbsp;" + k + "esc</font> close"
            }
        }

        // ================================================================ Game Mode: library (design/GameMode-Start.dc.html)
        ColumnLayout {
            id: libView
            visible: root.library
            anchors.fill: parent
            anchors.margins: 24
            anchors.leftMargin: 32
            anchors.rightMargin: 32
            spacing: 14

            // top bar: logo, Library / All apps, clock, avatar
            RowLayout {
                Layout.fillWidth: true
                spacing: 30
                Kirigami.Icon { source: Plasmoid.configuration.icon; Layout.preferredWidth: 38; Layout.preferredHeight: 38 }
                Repeater {
                    model: ["Library", "All apps"]
                    Text {
                        id: nav
                        required property int index
                        required property string modelData
                        readonly property bool sel: index === 0 ? root.category !== 0 : root.category === 0
                        text: modelData
                        font.family: root.s.font; font.pixelSize: 18; font.weight: sel ? Font.ExtraBold : Font.Normal
                        color: sel ? root.s.fg : root.s.dim
                        bottomPadding: 6
                        Rectangle { visible: nav.sel; anchors.bottom: parent.bottom; width: parent.width; height: 3; color: root.s.accent }
                        MouseArea {
                            anchors.fill: parent
                            onClicked: { root.category = nav.index === 0 ? root.gamesRow() : 0; libInput.forceActiveFocus(); }
                        }
                    }
                }
                Item { Layout.fillWidth: true }
                Text {
                    id: libClock
                    font.family: root.s.font; font.pixelSize: 16; font.weight: Font.DemiBold
                    color: root.s.fg
                    Timer {
                        running: root.expanded && root.library
                        interval: 10000
                        repeat: true
                        triggeredOnStart: true
                        onTriggered: libClock.text = Qt.formatTime(new Date(), "HH:mm")
                    }
                }
                Rectangle {
                    Layout.preferredWidth: 40; Layout.preferredHeight: 40
                    radius: 20
                    gradient: Gradient {
                        orientation: Gradient.Horizontal
                        GradientStop { position: 0; color: root.s.avatarA }
                        GradientStop { position: 1; color: root.s.avatarB }
                    }
                    Text {
                        anchors.centerIn: parent
                        text: (kuser.loginName || "?").charAt(0).toUpperCase()
                        font.family: root.s.font; font.pixelSize: 15; font.weight: Font.Bold
                        color: "#ffffff"
                    }
                }
            }

            // search + filters
            RowLayout {
                Layout.fillWidth: true
                Layout.topMargin: 6
                spacing: 14
                Rectangle {
                    Layout.preferredWidth: 380
                    Layout.preferredHeight: 48
                    radius: 24
                    color: root.s.btnBg
                    border.width: 2
                    border.color: libInput.activeFocus ? root.s.searchBorder : root.s.badgeBorder
                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: 18
                        anchors.rightMargin: 18
                        spacing: 12
                        Glyph { name: "search"; tint: root.s.fg; Layout.preferredWidth: 18; Layout.preferredHeight: 18 }
                        TextInput {
                            id: libInput
                            Layout.fillWidth: true
                            font.family: root.s.font; font.pixelSize: 15
                            color: root.s.fg
                            selectionColor: root.s.accent
                            clip: true
                            onTextChanged: { root.searchText = text; coverList.currentIndex = 0; }
                            Keys.onLeftPressed: (event) => { if (libInput.text.length === 0) coverList.decrementCurrentIndex(); else event.accepted = false; }
                            Keys.onRightPressed: (event) => { if (libInput.text.length === 0) coverList.incrementCurrentIndex(); else event.accepted = false; }
                            Keys.onReturnPressed: if (coverList.count > 0) root.launch(coverList.model, coverList.currentIndex)
                            Keys.onEnterPressed: if (coverList.count > 0) root.launch(coverList.model, coverList.currentIndex)
                            Keys.onTabPressed: root.category = (root.category + 1) % Math.max(1, rootModel.count)
                            Keys.onBacktabPressed: root.category = (root.category + Math.max(1, rootModel.count) - 1) % Math.max(1, rootModel.count)
                            Text {
                                anchors.verticalCenter: parent.verticalCenter
                                visible: !libInput.text
                                text: "Search games or apps"
                                font: libInput.font
                                color: root.s.dim
                            }
                        }
                    }
                }
                ListView {
                    id: libFilters
                    visible: !root.searching
                    Layout.fillWidth: true
                    Layout.preferredHeight: 40
                    orientation: ListView.Horizontal
                    spacing: 10
                    clip: true
                    boundsBehavior: Flickable.StopAtBounds
                    model: root.library ? rootModel : null
                    currentIndex: root.category
                    highlightFollowsCurrentItem: false
                    onCurrentIndexChanged: positionViewAtIndex(currentIndex, ListView.Contain)
                    delegate: Rectangle {
                        id: lf
                        required property int index
                        required property var model
                        readonly property bool sel: root.category === index
                        height: 40
                        width: lfLabel.implicitWidth + 36
                        radius: 20
                        color: sel ? root.s.accent : root.s.btnBg
                        Text {
                            id: lfLabel
                            anchors.centerIn: parent
                            text: lf.index === 0 ? "All" : (lf.model.display || "")
                            font.family: root.s.font; font.pixelSize: 14; font.weight: Font.DemiBold
                            color: lf.sel ? root.s.onAccent : root.s.fg
                        }
                        MouseArea { anchors.fill: parent; onClicked: { root.category = lf.index; libInput.forceActiveFocus(); } }
                    }
                }
                Item { visible: root.searching; Layout.fillWidth: true }
            }

            // library: cover cards (the selected one bigger, accent border + glow)
            Text {
                Layout.topMargin: 4
                textFormat: Text.StyledText
                text: (root.searching ? "Results" : root.categoryName(root.category))
                      + " <font color='" + root.s.dim + "'>· " + coverList.count + (coverList.count === 1 ? " app" : " apps") + "</font>"
                font.family: root.s.font; font.pixelSize: 18; font.weight: Font.DemiBold
                color: root.s.fg
            }
            ListView {
                id: coverList
                // design cover gradients (160deg in the design; vertical here)
                readonly property var coverColors: [["#2a9d8f", "#1d3557"], ["#f4a261", "#3d405b"], ["#bc6c25", "#283618"],
                                                    ["#588157", "#344e41"], ["#e63946", "#1d1d3b"], ["#7b2cbf", "#240046"]]
                readonly property int bigH: Math.max(120, height - 34)
                readonly property int smallH: Math.round(bigH * 0.83)
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.minimumHeight: 200
                orientation: ListView.Horizontal
                spacing: 20
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                model: !root.library ? null : (root.searching ? (runnerModel.count > 0 ? runnerModel.modelForRow(0) : null)
                                                              : (rootModel.count > 0 ? rootModel.modelForRow(root.category) : null))
                onCurrentIndexChanged: positionViewAtIndex(currentIndex, ListView.Contain)
                delegate: Item {
                    id: cover
                    required property int index
                    required property var model
                    readonly property bool cur: ListView.isCurrentItem
                    readonly property var pal: coverList.coverColors[index % coverList.coverColors.length]
                    width: card.width
                    height: ListView.view.height
                    Rectangle {
                        id: card
                        anchors.bottom: caption.top
                        anchors.bottomMargin: 8
                        height: cover.cur ? coverList.bigH : coverList.smallH
                        width: Math.round(height * 0.71)
                        Behavior on height { NumberAnimation { duration: 120 } }
                        radius: 14
                        border.width: cover.cur ? 3 : 0
                        border.color: root.s.accent
                        gradient: Gradient {
                            GradientStop { position: 0; color: cover.pal[0] }
                            GradientStop { position: 1; color: cover.pal[1] }
                        }
                        layer.enabled: cover.cur
                        layer.effect: MultiEffect {
                            shadowEnabled: true
                            shadowColor: root.s.accent
                            shadowBlur: 1.0
                            shadowOpacity: 0.45
                        }
                        Kirigami.Icon {
                            anchors.centerIn: parent
                            anchors.verticalCenterOffset: -Math.round(card.height * 0.1)
                            width: Math.round(card.width * 0.46)
                            height: width
                            source: cover.model.decoration
                        }
                        Text {
                            anchors { left: parent.left; right: parent.right; bottom: parent.bottom; leftMargin: 14; rightMargin: 14; bottomMargin: 12 }
                            text: cover.model.display || ""
                            wrapMode: Text.Wrap
                            maximumLineCount: 2
                            elide: Text.ElideRight
                            font.family: root.s.font; font.pixelSize: 15; font.weight: Font.ExtraBold
                            color: "#ffffff"
                        }
                    }
                    Text {
                        id: caption
                        anchors.bottom: parent.bottom
                        width: card.width
                        height: 18
                        text: cover.model.description || ""
                        elide: Text.ElideRight
                        font.family: root.s.font; font.pixelSize: 12
                        color: root.s.dim
                    }
                    MouseArea {
                        anchors.fill: card
                        hoverEnabled: true
                        onEntered: coverList.currentIndex = cover.index
                        onClicked: root.launch(coverList.model, cover.index)
                    }
                }
                Text {
                    anchors.centerIn: parent
                    visible: coverList.count === 0
                    text: root.searching ? "Nothing found" : "No games yet — get some from Steam, Heroic, Lutris or Discover"
                    font.family: root.s.font; font.pixelSize: 15
                    color: root.s.dim
                }
            }

            // apps and tools = pinned apps
            Text {
                visible: !root.searching
                text: "Apps and tools"
                font.family: root.s.font; font.pixelSize: 18; font.weight: Font.DemiBold
                color: root.s.fg
            }
            ListView {
                id: appsRow
                visible: !root.searching
                Layout.fillWidth: true
                Layout.preferredHeight: 104
                orientation: ListView.Horizontal
                spacing: 14
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                model: root.library ? rootModel.favoritesModel : null
                delegate: Rectangle {
                    id: app
                    required property int index
                    required property var model
                    width: 148
                    height: 104
                    radius: 14
                    color: appMouse.containsMouse ? root.s.selBg : root.s.btnBg
                    border.width: 1
                    border.color: root.s.divider
                    Column {
                        anchors.centerIn: parent
                        spacing: 10
                        Kirigami.Icon { anchors.horizontalCenter: parent.horizontalCenter; width: 40; height: 40; source: app.model.decoration }
                        Text {
                            anchors.horizontalCenter: parent.horizontalCenter
                            width: app.width - 16
                            horizontalAlignment: Text.AlignHCenter
                            text: app.model.display || ""
                            elide: Text.ElideRight
                            font.family: root.s.font; font.pixelSize: 13; font.weight: Font.DemiBold
                            color: root.s.fg
                        }
                    }
                    MouseArea { id: appMouse; anchors.fill: parent; hoverEnabled: true; onClicked: root.launch(rootModel.favoritesModel, app.index) }
                }
            }

            // user + power + back to desktop, controller-style hints
            RowLayout {
                Layout.fillWidth: true
                Layout.topMargin: 4
                spacing: 14
                Rectangle {
                    Layout.preferredWidth: 36; Layout.preferredHeight: 36
                    radius: 18
                    gradient: Gradient {
                        orientation: Gradient.Horizontal
                        GradientStop { position: 0; color: root.s.avatarA }
                        GradientStop { position: 1; color: root.s.avatarB }
                    }
                }
                Text { text: kuser.loginName; font.family: root.s.font; font.pixelSize: 15; font.weight: Font.DemiBold; color: root.s.fg }
                Text { text: "online"; font.family: root.s.font; font.pixelSize: 13; color: "#4ade80" }
                PillButton { glyph: "power"; tint: "#f87171"; label: "Power"; onClicked: session.requestShutdown() }
                PillButton { label: "Back to desktop" }
                Item { Layout.fillWidth: true }
                Text {
                    textFormat: Text.StyledText
                    font.family: root.s.font; font.pixelSize: 13
                    color: root.s.dim
                    text: "<b><font color='#4ade80'>Enter</font></b> play&nbsp;&nbsp;&nbsp;&nbsp;<b><font color='#f87171'>Esc</font></b> back&nbsp;&nbsp;&nbsp;&nbsp;"
                          + "<b><font color='#60a5fa'>← →</font></b> choose&nbsp;&nbsp;&nbsp;&nbsp;<b><font color='#ffd166'>Tab</font></b> filter"
                }
            }
        }
    }

    // ------------------------------------------------------------ pieces
    component AppRow: Rectangle {
        id: row
        property int index
        property var model
        property bool highlighted: false
        signal clicked()
        height: 40
        radius: 10
        color: (highlighted || rowMouse.containsMouse) ? root.s.hoverBg : "transparent"
        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 10
            anchors.rightMargin: 10
            spacing: 12
            Kirigami.Icon { source: row.model ? row.model.decoration : ""; Layout.preferredWidth: root.s.listIcon; Layout.preferredHeight: root.s.listIcon }
            ColumnLayout {
                spacing: 0
                Layout.fillWidth: true
                Text { Layout.fillWidth: true; text: row.model ? row.model.display : ""; elide: Text.ElideRight; font.family: root.s.font; font.pixelSize: 13; color: root.s.fg }
                Text {
                    Layout.fillWidth: true
                    visible: text.length > 0
                    text: row.model && row.model.description ? row.model.description : ""
                    elide: Text.ElideRight
                    font.family: root.s.font; font.pixelSize: 11; color: root.s.dim
                }
            }
        }
        MouseArea { id: rowMouse; anchors.fill: parent; hoverEnabled: true; onClicked: row.clicked() }
    }

    component PowerButton: Rectangle {
        id: pb
        property string glyph
        property string tip
        property bool primary: false
        signal clicked()
        Layout.preferredWidth: 38
        Layout.preferredHeight: 38
        radius: 10
        color: primary ? root.s.accent : (pbMouse.containsMouse ? root.s.hoverBg : root.s.btnBg)
        Glyph {
            anchors.centerIn: parent
            width: 18; height: 18
            name: pb.glyph
            tint: pb.primary ? root.s.onAccent : root.s.fg
        }
        MouseArea { id: pbMouse; anchors.fill: parent; hoverEnabled: true; onClicked: { root.expanded = false; pb.clicked(); } }
    }

    // Mono run launcher footer button: "[l] lock"
    component TermButton: Rectangle {
        id: tb
        property string label
        property bool primary: false
        signal clicked()
        Layout.preferredHeight: 24
        Layout.preferredWidth: tbText.implicitWidth + 16
        color: tbMouse.containsMouse ? root.s.hoverBg : "transparent"
        border.width: 1
        border.color: primary ? root.s.accent : root.s.badgeBorder
        Text {
            id: tbText
            anchors.centerIn: parent
            text: tb.label
            font.family: root.s.font; font.pixelSize: 11
            color: tb.primary ? root.s.accent : root.s.fg
            opacity: tb.primary ? 1 : 0.8
        }
        MouseArea { id: tbMouse; anchors.fill: parent; hoverEnabled: true; onClicked: { root.expanded = false; tb.clicked(); } }
    }

    // Game Mode library bottom bar button (rounded pill, optional glyph)
    component PillButton: Rectangle {
        id: pill
        property string label
        property string glyph: ""
        property color tint: root.s.fg
        signal clicked()
        Layout.preferredHeight: 36
        Layout.preferredWidth: pillRow.implicitWidth + 32
        radius: 18
        color: pillMouse.containsMouse ? root.s.hoverBg : root.s.btnBg
        border.width: 1
        border.color: root.s.badgeBorder
        RowLayout {
            id: pillRow
            anchors.centerIn: parent
            spacing: 8
            Glyph { visible: pill.glyph.length > 0; name: pill.glyph || "power"; tint: pill.tint; Layout.preferredWidth: 14; Layout.preferredHeight: 14 }
            Text { text: pill.label; font.family: root.s.font; font.pixelSize: 13; color: root.s.fg }
        }
        MouseArea { id: pillMouse; anchors.fill: parent; hoverEnabled: true; onClicked: { root.expanded = false; pill.clicked(); } }
    }

    // line icon (stroke-only SVG) recolored without filling its shapes (Kirigami isMask fills closed paths)
    component Glyph: Item {
        id: gl
        property string name
        property color tint
        Image { id: gimg; anchors.fill: parent; source: Qt.resolvedUrl("icons/" + gl.name + ".svg"); sourceSize: Qt.size(64, 64); visible: false }
        MultiEffect { anchors.fill: parent; source: gimg; colorization: 1.0; colorizationColor: gl.tint }
    }
}
