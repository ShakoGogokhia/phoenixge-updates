"""PhoenixGe "Remove beard" for DeepFaceLive (called by the patched FaceMerger before the swapped face is merged).

A swapped beardless face (e.g. a woman's face model) leaves the user's beard visible around the jaw, chin and neck.
Here, per frame and face:
  1. region  = the face below the nose (mustache, chin, cheeks) + a thin band past the jawline, without the lips
               (468 FaceMesh points)
  2. beard   = pixels in that region clearly darker than the user's own skin (median of the cheeks)
  3. paint   = the beard pixels are replaced by the skin around them (normalized convolution = smooth skin colour
               and shading from the neighbouring non-beard pixels) plus a little grain so it doesn't look plastic.
strength 0..100: how dark a pixel must be to count as beard (higher = removes more, also lighter stubble).
Runs on the CPU on a crop around the lower face (~2-4 ms at 640x480).
"""
import cv2
import numpy as np

# MediaPipe FaceMesh (468) indices
LIPS = [61, 146, 91, 181, 84, 17, 314, 405, 321, 375, 291, 409, 270, 269, 267, 0, 37, 39, 40, 185]
NOSE_BASE = [98, 97, 2, 326, 327]          # under the nose: the beard region starts a little below
CHEEKS = [50, 280, 117, 346, 205, 425]     # skin reference (above the usual beard line)
EYE_LINE = [33, 263]


def _poly(pts, idx):
    return np.array([pts[i] for i in idx], np.float32)


def shave(frame, lmrks_px, strength=50, debug=None):
    """frame: HxWx3 uint8 or float32 0..1 (BGR). lmrks_px: (N,2) landmarks in frame pixels. Returns the same dtype."""
    if lmrks_px is None or len(lmrks_px) < 468:
        return frame
    H, W = frame.shape[:2]
    pts = np.asarray(lmrks_px, np.float32)
    is_float = frame.dtype != np.uint8
    chin = pts[152]
    eye_c = _poly(pts, EYE_LINE).mean(0)
    face_h = float(np.linalg.norm(chin - eye_c)) + 1e-3
    nose_y = _poly(pts, NOSE_BASE)[:, 1].mean()

    # region: the face below the nose (convex hull of all points), grown by a thin band past the jaw (beard edge)
    hull = cv2.convexHull(pts.astype(np.float32)).reshape(-1, 2)
    grow = face_h * 0.07
    x0, y0 = np.floor(hull.min(0) - grow * 2.5).astype(int)     # room for the soft edge inside the crop
    x1, y1 = np.ceil(hull.max(0) + grow * 2.5).astype(int)
    y0 = int(nose_y - face_h * 0.02)
    x0, y0 = max(0, x0), max(0, y0)
    x1, y1 = min(W, x1), min(H, y1)
    if x1 - x0 < 16 or y1 - y0 < 16:
        return frame
    crop = frame[y0:y1, x0:x1]
    crop8 = (np.clip(crop, 0, 1) * 255).astype(np.uint8) if is_float else crop
    ch, cw = crop8.shape[:2]
    off = np.array([x0, y0], np.float32)

    face = np.zeros((ch, cw), np.uint8)
    cv2.fillPoly(face, [np.round(hull - off).astype(np.int32)], 255)
    g = max(1, int(grow))
    reg = cv2.dilate(face, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * g + 1, 2 * g + 1)))
    lips = np.zeros_like(reg)
    cv2.fillPoly(lips, [np.round(_poly(pts, LIPS) - off).astype(np.int32)], 255)
    lips = cv2.erode(lips, np.ones((3, 3), np.uint8))          # the lip line itself stays; the mustache above goes
    reg[lips > 0] = 0

    # skin reference from the cheeks (full frame coordinates)
    samples = []
    r = max(3, int(face_h * 0.05))
    for i in CHEEKS:
        cx, cy = int(pts[i][0]), int(pts[i][1])
        patch = frame[max(0, cy - r):cy + r, max(0, cx - r):cx + r]
        if patch.size:
            p8 = (np.clip(patch, 0, 1) * 255).astype(np.uint8) if is_float else patch
            samples.append(cv2.cvtColor(p8, cv2.COLOR_BGR2LAB).reshape(-1, 3))
    if not samples:
        return frame
    ref = np.median(np.concatenate(samples), axis=0).astype(np.float32)

    lab = cv2.cvtColor(crop8, cv2.COLOR_BGR2LAB).astype(np.float32)
    # darker than the skin by more than t (strength 0 -> 40 L-units, 100 -> 8): beard / stubble
    t = 40.0 - 0.32 * float(np.clip(strength, 0, 100))
    beard = ((lab[..., 0] < ref[0] - t) & (reg > 0)).astype(np.uint8) * 255
    k = max(3, int(face_h / 40) | 1)
    beard = cv2.morphologyEx(beard, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    beard = cv2.morphologyEx(beard, cv2.MORPH_CLOSE, np.ones((k, k), np.uint8))
    # skin showing through a full beard (lighter islands on the chin) belongs to it: close big gaps + fill holes
    big = max(5, int(face_h / 10) | 1)
    beard = cv2.morphologyEx(beard, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (big, big)))
    cnts, _h = cv2.findContours(beard, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts = [c for c in cnts if cv2.contourArea(c) > (face_h * 0.08) ** 2]   # drop small specks (moles, shadows)
    beard = np.zeros_like(beard)
    cv2.drawContours(beard, cnts, -1, 255, thickness=cv2.FILLED)
    beard &= reg
    beard = cv2.dilate(beard, np.ones((3, 3), np.uint8), iterations=1)
    beard[lips > 0] = 0
    m = cv2.GaussianBlur(beard, (0, 0), max(1.5, face_h / 60)).astype(np.float32) / 255.0
    m *= cv2.GaussianBlur(reg, (0, 0), max(2.0, face_h / 25)).astype(np.float32) / 255.0   # soft at the region edge
    # fade in below the nose (no straight line across the cheeks at the top of the crop)
    ys = np.arange(ch, dtype=np.float32)[:, None] + y0
    m *= np.clip((ys - nose_y) / (face_h * 0.12), 0, 1)
    if m.max() < 0.05:
        return frame

    # skin fill: smooth colour + shading from the real skin around (inside the face, not beard, close to the cheeks)
    skin = ((face > 0) & (beard == 0) & (lips == 0) & (np.abs(lab[..., 0] - ref[0]) < 18)
            & (np.abs(lab[..., 1] - ref[1]) < 12) & (np.abs(lab[..., 2] - ref[2]) < 14)).astype(np.float32)
    sig = max(4.0, face_h / 6)
    src = crop8.astype(np.float32)
    # the wide blur at 1/4 size (same look, ~10x faster)
    sm = (max(8, cw // 4), max(8, ch // 4))
    num = cv2.resize(cv2.GaussianBlur(cv2.resize(src * skin[..., None], sm, interpolation=cv2.INTER_AREA), (0, 0), sig / 4),
                     (cw, ch), interpolation=cv2.INTER_LINEAR)
    den = cv2.resize(cv2.GaussianBlur(cv2.resize(skin, sm, interpolation=cv2.INTER_AREA), (0, 0), sig / 4),
                     (cw, ch), interpolation=cv2.INTER_LINEAR)[..., None]
    ref_bgr = cv2.cvtColor(ref.reshape(1, 1, 3).astype(np.uint8), cv2.COLOR_LAB2BGR).reshape(3).astype(np.float32)
    w = np.clip(den / 0.15, 0, 1)
    fill = (num / np.maximum(den, 1e-4)) * w + ref_bgr * (1 - w)
    grain = np.random.default_rng(0).normal(0, 1.8, fill.shape[:2]).astype(np.float32)[..., None]
    fill = fill + grain

    res = src * (1 - m[..., None]) + fill * m[..., None]
    res8 = np.clip(res, 0, 255).astype(np.uint8)
    if debug is not None:
        debug.update(region=reg, beard=beard, mask=m, crop=crop8, result=res8, ref=ref)
    out_frame = frame.copy()
    out_frame[y0:y1, x0:x1] = (res8.astype(np.float32) / 255.0).astype(frame.dtype) if is_float else res8
    return out_frame
