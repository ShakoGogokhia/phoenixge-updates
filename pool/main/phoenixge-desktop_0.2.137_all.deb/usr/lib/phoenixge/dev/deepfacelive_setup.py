"""PhoenixGe tweaks for DeepFaceLive (run with DeepFaceLive's own Python, from its app folder).

  deepfacelive_setup.py patch            stream output -> virtual webcam when $PHOENIXGE_VCAM is set, and the
                                         PhoenixGe menu "Use in…" (record, go live, OBS, Discord…) (idempotent)
  deepfacelive_setup.py fixcam USERDIR   at every start: camera selection back to webcam 0 when DeepFaceLive lost it
                                         (it clears it when the camera was busy, e.g. used by a browser)
  deepfacelive_setup.py preset USERDIR   good starting settings: webcam 0, YoloV5 + FaceMesh + DFM swap on the GPU,
                                         Keanu Reeves model, output = swapped picture, virtual camera on.
                                         Only fills in what is missing/broken; the user's own choices stay.
"""
import sys
from pathlib import Path

APP = Path.cwd()
sys.path.insert(0, str(APP))

STREAMER = APP / "xlib/streamer/FFMPEGStreamer.py"
MARK = "# PhoenixGe: virtual webcam"
MARK_V = MARK + " v2"   # v2: fixed 1280x720 (same as the idle picture), stops phoenixge-vcam-idle
APPWIN = APP / "apps/DeepFaceLive/DeepFaceLiveApp.py"
MERGER = APP / "apps/DeepFaceLive/backend/FaceMerger.py"
QMERGER = APP / "apps/DeepFaceLive/ui/QFaceMerger.py"
BEARD_MARK = "# PhoenixGe: remove beard"
MENU_MARK = "# PhoenixGe: Use in… menu"


def patch():
    patch_streamer()
    patch_menu()
    patch_beard()


def _sub(s, old, new, what):
    if old not in s:
        raise SystemExit(f"{what}: DeepFaceLive changed upstream - 'Remove beard' not added")
    return s.replace(old, new, 1)


def patch_beard():
    """Face merger: "Remove beard" checkbox + strength (dfl_shave.py paints the beard with skin before merging)."""
    s = MERGER.read_text()
    if BEARD_MARK in s:
        return print("beard remover already patched")
    here = str(Path(__file__).resolve().parent)
    s = _sub(s, "        cs.face_opacity.call_on_number(self.on_cs_face_opacity)\n",
             "        cs.face_opacity.call_on_number(self.on_cs_face_opacity)\n"
             "        cs.remove_beard.call_on_flag(self.on_cs_remove_beard)  " + BEARD_MARK + "\n"
             "        cs.beard_strength.call_on_number(self.on_cs_beard_strength)\n", "on_start")
    s = _sub(s, """            cs.face_opacity.set_number(state.face_opacity if state.face_opacity is not None else 1.0)
        else:""", """            cs.face_opacity.set_number(state.face_opacity if state.face_opacity is not None else 1.0)

            cs.remove_beard.enable()
            cs.remove_beard.set_flag(state.remove_beard if state.remove_beard is not None else False)
            cs.beard_strength.enable()
            cs.beard_strength.set_config(lib_csw.Number.Config(min=0, max=100, step=1, decimals=0, allow_instant_update=True))
            cs.beard_strength.set_number(state.beard_strength if state.beard_strength is not None else 50)
        else:""", "on_cs_device")
    s = _sub(s, "    def on_cs_face_opacity(self, face_opacity):", f"""    def on_cs_remove_beard(self, remove_beard):
        state, cs = self.get_state(), self.get_control_sheet()
        state.remove_beard = remove_beard
        self.save_state()
        self.reemit_frame_signal.send()

    def on_cs_beard_strength(self, beard_strength):
        state, cs = self.get_state(), self.get_control_sheet()
        cfg = cs.beard_strength.get_config()
        beard_strength = state.beard_strength = int(np.clip(beard_strength, cfg.min, cfg.max))
        cs.beard_strength.set_number(beard_strength)
        self.save_state()
        self.reemit_frame_signal.send()

    def _phoenixge_shave(self, frame, fsi, frame_width, frame_height):
        import sys as _sys
        for _d in ('/usr/lib/phoenixge/dev', {here!r}):
            if _d not in _sys.path:
                _sys.path.append(_d)
        try:
            import dfl_shave
            ul = fsi.face_ulmrks
            if ul is None:
                return frame
            pts = ul.as_numpy(w_h=(frame_width, frame_height))
            import os as _os, time as _time
            dbg = _os.environ.get('PHOENIXGE_SHAVE_DEBUG')
            if dbg and _time.time() - getattr(self, '_shave_dbg_t', 0) > 2:
                self._shave_dbg_t = _time.time()
                f8 = frame if frame.dtype == np.uint8 else (np.clip(frame, 0, 1) * 255).astype(np.uint8)
                np.savez_compressed(_os.path.join(dbg, f'shave_{{int(_time.time())}}.npz'), frame=f8, lmrks=pts)
            return dfl_shave.shave(frame, pts, self.get_state().beard_strength or 50)
        except Exception as e:
            if not getattr(self, '_shave_err', False):
                self._shave_err = True
                print('PhoenixGe remove beard:', e)
            return frame

    def on_cs_face_opacity(self, face_opacity):""", "methods")
    s = _sub(s, """                                do_color_compression = fsi_id == fsi_list_len-1
""", """                                if state.remove_beard:
                                    merged_frame = self._phoenixge_shave(merged_frame, fsi, frame_width, frame_height)
                                do_color_compression = fsi_id == fsi_list_len-1
""", "on_tick")
    s = _sub(s, """            self.face_opacity = lib_csw.Number.Client()
""", """            self.face_opacity = lib_csw.Number.Client()
            self.remove_beard = lib_csw.Flag.Client()
            self.beard_strength = lib_csw.Number.Client()
""", "Sheet.Host")
    s = _sub(s, """            self.face_opacity = lib_csw.Number.Host()
""", """            self.face_opacity = lib_csw.Number.Host()
            self.remove_beard = lib_csw.Flag.Host()
            self.beard_strength = lib_csw.Number.Host()
""", "Sheet.Worker")
    s = _sub(s, """    face_opacity : float = None
""", """    face_opacity : float = None
    remove_beard : bool = None
    beard_strength : int = None
""", "WorkerState")

    q = QMERGER.read_text()
    q = _sub(q, """        grid_l = qtx.QXGridLayout(spacing=5)""", """        q_remove_beard_label = QLabelPopupInfo(label='Remove beard', popup_info_text='PhoenixGe: paints your beard, '
            'mustache and stubble with your own skin colour before the new face is put on. For beardless face models.')
        q_remove_beard = QCheckBoxCSWFlag(cs.remove_beard, reflect_state_widgets=[q_remove_beard_label])
        q_beard_strength_label = QLabelPopupInfo(label='Beard strength', popup_info_text='Higher = also lighter '
            'stubble is removed. Lower if your skin gets painted too.')
        q_beard_strength = QSliderCSWNumber(cs.beard_strength, reflect_state_widgets=[q_beard_strength_label])

        grid_l = qtx.QXGridLayout(spacing=5)""", "QFaceMerger widgets")
    q = _sub(q, """        grid_l.addWidget(q_face_opacity, row, 1)
        row += 1
""", """        grid_l.addWidget(q_face_opacity, row, 1)
        row += 1
        grid_l.addWidget(q_remove_beard_label, row, 0, alignment=qtx.AlignRight | qtx.AlignVCenter)
        grid_l.addWidget(q_remove_beard, row, 1, alignment=qtx.AlignLeft)
        row += 1
        grid_l.addWidget(q_beard_strength_label, row, 0, alignment=qtx.AlignRight | qtx.AlignVCenter)
        grid_l.addWidget(q_beard_strength, row, 1)
        row += 1
""", "QFaceMerger layout")
    MERGER.write_text(s)
    QMERGER.write_text(q)
    print("beard remover added to Face merger")


def patch_menu():
    """Our menu "Use in…" (dfl_share.py next to this file) between Language and Help."""
    s = APPWIN.read_text()
    if MENU_MARK in s:
        return print("menu already patched")
    old = "        menu_help = menu_bar.addMenu( L('@QDFLAppWindow.help') )"
    if old not in s:
        return print("DeepFaceLiveApp.py changed upstream - PhoenixGe menu not added")
    here = str(Path(__file__).resolve().parent)
    new = f"""        {MENU_MARK}
        try:
            import sys as _sys
            for _d in ('/usr/lib/phoenixge/dev', {here!r}):
                if _d not in _sys.path:
                    _sys.path.append(_d)
            import dfl_share
            dfl_share.add_menu(menu_bar, self, str(self._userdata_path))
        except Exception as _e:
            print('PhoenixGe menu:', _e)
""" + old
    APPWIN.write_text(s.replace(old, new, 1))
    print("PhoenixGe menu added")


def patch_streamer():
    """DeepFaceLive's 'mpegts udp://' output starts ffmpeg; with PHOENIXGE_VCAM=/dev/videoN it writes to that v4l2
    device instead (the virtual camera "PhoenixGe Camera")."""
    s = STREAMER.read_text()
    if MARK_V in s:
        return print("streamer already patched")
    if MARK in s:   # older PhoenixGe patch: start again from the original file
        import subprocess
        subprocess.run(["git", "checkout", "--", str(STREAMER.relative_to(APP))], cwd=APP, check=True)
        s = STREAMER.read_text()
    old = """                '-i', '-',
                '-f', 'mpegts',
                '-q:v', '2',
                f'udp://{self._addr}:{self._port}'
        ]"""
    new = """                '-i', '-',
        ]
        """ + MARK_V + """ (PHOENIXGE_VCAM=/dev/videoN set by the launcher)
        import os
        vcam = os.environ.get('PHOENIXGE_VCAM')
        if vcam and os.path.exists(vcam):
            import subprocess as _sp   # the "open DeepFaceLive" picture stops; the launcher brings it back on exit
            _sp.run(['systemctl', '--user', 'stop', 'phoenixge-vcam-idle'], capture_output=True)
            # always 1280x720: apps keep the camera when the picture size changes (webcam 640x480, phone 1280x720)
            args = [a for a in args if a != '-re'] + [
                '-vf', 'scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,format=yuv420p',
                '-f', 'v4l2', vcam]
        else:
            args += ['-f', 'mpegts', '-q:v', '2', f'udp://{self._addr}:{self._port}']"""
    if old not in s:
        sys.exit("FFMPEGStreamer.py changed upstream - virtual camera patch not applied")
    STREAMER.write_text(s.replace(old, new))
    print("streamer patched for the virtual camera")


def fixcam(userdir):
    f = Path(userdir) / "settings/states.dat"
    if not f.exists():
        return
    import apps.DeepFaceLive.backend  # noqa: F401
    from xlib.db import KeyValueDB
    CS = sys.modules["apps.DeepFaceLive.backend.CameraSource"]
    db = KeyValueDB(f)
    cs = db._data.get("CameraSource_worker_state")
    if cs is not None and cs.device_idx is None:
        cs.device_idx = 0
        if cs.driver is None:
            cs.driver = CS._DriverType.COMPATIBLE
        db._data["CameraSource_worker_state"] = cs
        db._save_data()
        print("camera selection restored: webcam 0")


def preset(userdir):
    import apps.DeepFaceLive.backend  # noqa: F401  (imports every backend module)
    from modelhub import DFLive
    from xlib import onnxruntime as lib_ort
    from xlib.db import KeyValueDB
    M = lambda n: sys.modules["apps.DeepFaceLive.backend." + n]  # noqa: E731

    settings = Path(userdir) / "settings"
    settings.mkdir(parents=True, exist_ok=True)
    db = KeyValueDB(settings / "states.dat")
    d = db._data
    devs = lib_ort.get_available_devices_info()
    gpu = next((x for x in devs if "CUDA" in str(x)), devs[0] if devs else None)
    print("device:", gpu)

    # one chain: camera -> detect -> landmarks -> align -> DFM swap -> merge -> output
    for k, on in {"FileSource": False, "CameraSource": True, "FaceDetector": True, "FaceMarker": True,
                  "FaceAligner": True, "FaceAnimator": False, "FaceSwapInsight": False, "FaceSwapDFM": True,
                  "FrameAdjuster": True, "FaceMerger": True, "StreamOutput": True}.items():
        d[f"{k}_host_onoff"] = on

    CS = M("CameraSource")
    cs = d.get("CameraSource_worker_state") or CS.WorkerState()
    if cs.driver not in (CS._DriverType.COMPATIBLE, CS._DriverType.GSTREAMER):  # DirectShow/MSMF are Windows-only
        cs.driver = CS._DriverType.COMPATIBLE
    if cs.device_idx is None:
        cs.device_idx = 0
    d["CameraSource_worker_state"] = cs

    FD = M("FaceDetector")
    fd = d.get("FaceDetector_worker_state") or FD.WorkerState()
    if fd.detector_type is None:
        fd.detector_type = FD.DetectorType.YOLOV5
    for st in (fd.YoloV5_state, fd.center_face_state, fd.S3FD_state):
        if st.device is None:
            st.device = gpu
    d["FaceDetector_worker_state"] = fd

    FM = M("FaceMarker")
    fm = d.get("FaceMarker_worker_state") or FM.WorkerState()
    if fm.marker_type is None:
        fm.marker_type = FM.MarkerType.GOOGLE_FACEMESH
    for st in (fm.google_facemesh_state, fm.insightface_2d106_state):
        if st.device is None:
            st.device = gpu
    d["FaceMarker_worker_state"] = fm

    SW = M("FaceSwapDFM")
    sw = d.get("FaceSwapDFM_worker_state") or SW.WorkerState()
    if sw.device is None:
        sw.device = gpu
    if sw.model is None:
        models = DFLive.get_available_models_info(Path(userdir) / "dfm_models")
        sw.model = next((m for m in models if m.get_name() == "Keanu Reeves"), None)
    d["FaceSwapDFM_worker_state"] = sw

    SO = M("StreamOutput")
    so = d.get("StreamOutput_worker_state") or SO.WorkerState()
    # what other apps see: the swapped picture, the plain camera picture while no face is found
    so.source_type = SO.SourceType.MERGED_FRAME_OR_SOURCE_FRAME
    so.is_streaming = True
    d["StreamOutput_worker_state"] = so

    db._save_data()
    print("preset written:", settings / "states.dat")


if __name__ == "__main__":
    {"patch": lambda: patch(), "preset": lambda: preset(sys.argv[2]), "fixcam": lambda: fixcam(sys.argv[2])}[sys.argv[1]]()
