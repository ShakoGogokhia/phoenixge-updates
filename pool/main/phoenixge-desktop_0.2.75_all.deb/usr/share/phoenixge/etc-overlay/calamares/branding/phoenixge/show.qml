import QtQuick 2.0;
import calamares.slideshow 1.0;

Presentation
{
    id: presentation
    Timer { interval: 12000; running: true; repeat: true; onTriggered: presentation.goToNextSlide() }
    Rectangle { anchors.fill: parent; color: "#0e0909"; z: -1 }
    Slide { Image { source: "slide1.png"; anchors.fill: parent; fillMode: Image.PreserveAspectFit } }
    Slide { Image { source: "slide2.png"; anchors.fill: parent; fillMode: Image.PreserveAspectFit } }
    Slide { Image { source: "slide3.png"; anchors.fill: parent; fillMode: Image.PreserveAspectFit } }
    Slide { Image { source: "slide4.png"; anchors.fill: parent; fillMode: Image.PreserveAspectFit } }
}
