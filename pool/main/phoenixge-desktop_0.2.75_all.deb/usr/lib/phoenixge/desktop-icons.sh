#!/bin/sh
# Put PhoenixGe shortcuts on the user's desktop at login (each one only once,
# so a shortcut the user deleted stays deleted). Order/look follow design/Main.dc.html:
# Home, Games, Windows Apps, Trash (+ Kali Tools, ChatlaxiAI).
DESK=$(xdg-user-dir DESKTOP 2>/dev/null)
[ -n "$DESK" ] || DESK="$HOME/Desktop"
DONE="$HOME/.local/share/phoenixge/desktop-icons.done"
mkdir -p "$DESK" "$(dirname "$DONE")" "$HOME/Games" "$HOME/Windows Apps"

N=0
link() {  # id name url icon  (folder view sorts by date: old fixed mtimes keep the design order)
  N=$((N + 1))
  grep -qx "$1" "$DONE" 2>/dev/null && return
  printf '[Desktop Entry]\nType=Link\nName=%s\nURL=%s\nIcon=%s\n' "$2" "$3" "$4" > "$DESK/$1.desktop"
  chmod +x "$DESK/$1.desktop"
  touch -d "2000-01-01 00:00:0$N" "$DESK/$1.desktop"
  echo "$1" >> "$DONE"
}
link 01-home "Home" "file://$HOME" phoenixge-home
link 02-games "Games" "file://$HOME/Games" phoenixge-games
link 03-windows-apps "Windows Apps" "file://$HOME/Windows Apps" phoenixge-winapps
link 04-trash "Trash" "trash:/" phoenixge-trash

for app in phoenix-toolbox ge.chatlaxi.ai; do
  src=/usr/share/applications/$app.desktop
  [ -f "$src" ] || continue
  grep -qx "$app" "$DONE" 2>/dev/null && continue
  cp "$src" "$DESK/$app.desktop"
  chmod +x "$DESK/$app.desktop"
  N=$((N + 1)); touch -d "2000-01-01 00:00:0$N" "$DESK/$app.desktop"
  echo "$app" >> "$DONE"
done
