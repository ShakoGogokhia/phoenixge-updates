#!/bin/sh
# Turn on daily Timeshift snapshots (rsync mode, system disk, keep 5 daily + 3 boot). Run as root (pkexec).
set -e
mkdir -p /etc/timeshift
UUID=$(findmnt -no UUID /)
cat > /etc/timeshift/timeshift.json <<J
{
  "backup_device_uuid" : "$UUID",
  "parent_device_uuid" : "",
  "do_first_run" : "false",
  "btrfs_mode" : "false",
  "include_btrfs_home_for_backup" : "false",
  "include_btrfs_home_for_restore" : "false",
  "stop_cron_emails" : "true",
  "schedule_monthly" : "false",
  "schedule_weekly" : "false",
  "schedule_daily" : "true",
  "schedule_hourly" : "false",
  "schedule_boot" : "true",
  "count_monthly" : "2",
  "count_weekly" : "3",
  "count_daily" : "5",
  "count_hourly" : "6",
  "count_boot" : "3",
  "date_format" : "%Y-%m-%d %H:%M:%S",
  "exclude" : [ "/home/**", "/root/**" ],
  "exclude-apps" : []
}
J
timeshift --check >/dev/null 2>&1 || true
echo "Daily snapshots are on (keep 5 daily, 3 at boot). First snapshot is being made now..."
timeshift --create --comments "PhoenixGe first snapshot" --yes
