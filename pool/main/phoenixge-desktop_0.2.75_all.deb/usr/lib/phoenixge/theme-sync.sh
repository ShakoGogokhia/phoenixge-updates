#!/bin/sh
# PhoenixGe theme sync: when a PhoenixGe Global Theme is applied, also switch the parts KDE's
# Global Theme can't: Kvantum widget style, lock screen wallpaper, the Konsole profile and the Plasma style
# (plasma-apply-lookandfeel does not switch the Plasma style, so panels/popups would keep the old shape).
MAP=/usr/share/phoenixge/themes.map
STATE="$HOME/.config/phoenixge/applied-theme"

apply() {
  lnf=$(kreadconfig6 --file kdeglobals --group KDE --key LookAndFeelPackage 2>/dev/null)
  case "$lnf" in org.phoenixge.*) ;; *) return 0 ;; esac
  id=${lnf#org.phoenixge.}
  line=$(grep "^$id " "$MAP") || return 0
  if [ "$(kreadconfig6 --file plasmarc --group Theme --key name 2>/dev/null)" != "phoenixge-$id" ]; then
    plasma-apply-desktoptheme "phoenixge-$id" >/dev/null 2>&1
  fi
  [ "$(cat "$STATE" 2>/dev/null)" = "$id" ] && return 0
  set -- $line
  mkdir -p "$HOME/.config/Kvantum" "$(dirname "$STATE")"
  kwriteconfig6 --file "$HOME/.config/Kvantum/kvantum.kvconfig" --group General --key theme "$2"
  kwriteconfig6 --file kscreenlockerrc --group Greeter --group Wallpaper --group org.kde.image --group General \
                --key Image "file:///usr/share/wallpapers/$3/"
  kwriteconfig6 --file konsolerc --group "Desktop Entry" --key DefaultProfile "PhoenixGe-$id.profile"
  echo "$id" > "$STATE"
}

apply
command -v inotifywait >/dev/null 2>&1 || exit 0
while inotifywait -qq -e close_write -e moved_to "$HOME/.config/" 2>/dev/null; do
  sleep 1; apply
done
