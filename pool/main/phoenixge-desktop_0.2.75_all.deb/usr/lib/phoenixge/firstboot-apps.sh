#!/bin/sh
# PhoenixGe: on the INSTALLED system, install game launchers from Flathub once (needs internet).
# Heroic = Epic/GOG/Amazon games (e.g. Rocket League); Prism Launcher = Minecraft Java; Discord.
set -e
[ -d /run/live ] && exit 0                       # skip in the live session
STAMP=/var/lib/phoenixge/firstboot-apps.done
[ -f "$STAMP" ] && exit 0
flatpak remote-add --if-not-exists --system flathub https://dl.flathub.org/repo/flathub.flatpakrepo
flatpak install --system --noninteractive -y flathub com.heroicgameslauncher.hgl org.prismlauncher.PrismLauncher com.discordapp.Discord
mkdir -p "$(dirname "$STAMP")"; touch "$STAMP"
