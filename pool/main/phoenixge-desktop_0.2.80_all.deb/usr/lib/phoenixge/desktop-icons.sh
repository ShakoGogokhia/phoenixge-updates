#!/bin/sh
# Put PhoenixGe shortcuts on the user's desktop at login (each one only once,
# so a shortcut the user deleted stays deleted). Order/look follow design/Main.dc.html:
# Home, Games, Windows Apps, Trash (+ Kali Tools, ChatlaxiAI).
DESK=$(xdg-user-dir DESKTOP 2>/dev/null)
[ -n "$DESK" ] || DESK="$HOME/Desktop"
DONE="$HOME/.local/share/phoenixge/desktop-icons.done"
mkdir -p "$DESK" "$(dirname "$DONE")" "$HOME/Games" "$HOME/Windows Apps"

N=0
link() {  # id name url icon  (folder view sorts by date: old fixed mtimes keep the design order)
  N=$((N + 1))
  grep -qx "$1" "$DONE" 2>/dev/null && return
  printf '[Desktop Entry]\nType=Link\nName=%s\nURL=%s\nIcon=%s\n' "$2" "$3" "$4" > "$DESK/$1.desktop"
  chmod +x "$DESK/$1.desktop"
  touch -d "2000-01-01 00:00:$(printf %02d $N)" "$DESK/$1.desktop"
  echo "$1" >> "$DONE"
}
link 01-home "Home" "file://$HOME" phoenixge-home
link 02-games "Games" "file://$HOME/Games" phoenixge-games
link 03-windows-apps "Windows Apps" "file://$HOME/Windows Apps" phoenixge-winapps
link 04-trash "Trash" "trash:/" phoenixge-trash

app() {  # id name comment exec icon - feature shortcuts, so a new user sees what PhoenixGe offers
  N=$((N + 1))
  grep -qx "$1" "$DONE" 2>/dev/null && return
  printf '[Desktop Entry]\nType=Application\nName=%s\nComment=%s\nExec=%s\nIcon=%s\n' "$2" "$3" "$4" "$5" > "$DESK/$1.desktop"
  chmod +x "$DESK/$1.desktop"
  # Plasma asks before running an unknown launcher - mark ours as trusted
  gio set "$DESK/$1.desktop" metadata::trusted true 2>/dev/null || true
  touch -d "2000-01-01 00:00:$(printf %02d $N)" "$DESK/$1.desktop"
  echo "$1" >> "$DONE"
}
app 05-center "PhoenixGe Center" "Welcome, themes, drivers, backups, updates" "phoenixge-center" phoenixge-center
app 06-store "Phoenix Store" "Games, coding tools, Android/iOS dev, design" "phoenixge-center --page store" phoenixge-store
app 07-android "Android Apps" "Run Android apps in windows" "phoenixge-center --page android" phoenixge-android
app 08-themes "Themes" "12 PhoenixGe looks" "phoenixge-center --page themes" phoenixge-themes
app 09-gamemode "Game Mode" "Steam console mode, FPS counter, GE-Proton" "phoenixge-center --page gaming" phoenixge-gamemode

for app in phoenix-toolbox ge.chatlaxi.ai; do
  src=/usr/share/applications/$app.desktop
  [ -f "$src" ] || continue
  grep -qx "$app" "$DONE" 2>/dev/null && continue
  cp "$src" "$DESK/$app.desktop"
  chmod +x "$DESK/$app.desktop"
  N=$((N + 1)); touch -d "2000-01-01 00:00:$(printf %02d $N)" "$DESK/$app.desktop"
  echo "$app" >> "$DONE"
done
