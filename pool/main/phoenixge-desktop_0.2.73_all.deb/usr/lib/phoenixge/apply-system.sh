#!/bin/sh
# System-wide PhoenixGe setup. Run by the ISO build (hook 0800) and by the phoenixge-desktop package (postinst),
# so an update brings the same result as a fresh install.
set -e
# /etc defaults travel inside the package under usr/share (dpkg conffile prompts would block GUI updates)
if [ -d /usr/share/phoenixge/etc-overlay ]; then
  cp -r /usr/share/phoenixge/etc-overlay/. /etc/
fi
# start menu: hide apps that only clutter it
for f in org.kde.contactprintthemeeditor org.kde.contactthemeeditor org.kde.headerthemeeditor org.kde.mboximporter \
         org.kde.pimdataexporter org.kde.kmail-refresh-settings org.kde.ktnef org.kde.sieveeditor \
         org.kde.drkonqi.coredump.gui org.kde.kdeconnect.sms org.kde.kdeconnect.nonplasma display-im7.q16 \
         org.kde.kmousetool org.kde.kmouth org.kde.kmag org.kde.sweeper org.rncbc.qsynth vim kvantummanager \
         org.kde.kontrast org.kde.kmenuedit konqbrowser org.kde.akregator; do
  d=/usr/share/applications/$f.desktop
  [ -f "$d" ] || continue
  if grep -q '^NoDisplay=' "$d"; then sed -i 's/^NoDisplay=.*/NoDisplay=true/' "$d"; else sed -i '/^\[Desktop Entry\]/a NoDisplay=true' "$d"; fi
done
# icon themes (design folders + Papirus logos)
python3 /usr/lib/phoenixge/make-tile-icons.py || true
# login screen
mkdir -p /etc/sddm.conf.d
printf '[Theme]\nCurrent=phoenixge\n' > /etc/sddm.conf.d/10-phoenixge.conf
chmod 755 /usr/lib/phoenixge/*.sh /usr/bin/phoenix-* 2>/dev/null || true
if [ -d /run/systemd/system ]; then systemctl daemon-reload || true; fi
exit 0
