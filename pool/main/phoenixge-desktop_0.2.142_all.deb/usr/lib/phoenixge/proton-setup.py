#!/usr/bin/env python3
"""Install / update umu-launcher + GE-Proton for the current user (no root, no apt).

phoenix-run uses them for Windows programs and games (better compatibility than plain Wine:
DXVK/VKD3D, game fixes, Steam Runtime container). Everything lives in the user's home:

  ~/.local/share/phoenixge/umu/umu-run              umu-launcher zipapp (GitHub release, sha256 checked)
  ~/.local/share/Steam/compatibilitytools.d/GE-*    GE-Proton (GitHub release, sha512 checked; Steam/Lutris see it too)
  ~/.local/share/umu/                               Steam Runtime, downloaded by umu itself on the warm-up run

  proton-setup.py            install what is missing, then warm up (idempotent)
  proton-setup.py --update   also replace older versions with the newest release
  proton-setup.py --status   print JSON: {"ready": bool, "umu": path, "proton": path}
  proton-setup.py --notify   desktop notifications for start/finish (used by phoenix-run / Center)
"""
import fcntl
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
import urllib.request
from pathlib import Path

HOME = Path.home()
DATA = Path(os.environ.get("XDG_DATA_HOME", HOME / ".local/share"))
UMU_DIR = DATA / "phoenixge/umu"
UMU_RUN = UMU_DIR / "umu-run"
TOOLS = DATA / "Steam/compatibilitytools.d"
STATE = DATA / "phoenixge/proton.json"
LOCK = DATA / "phoenixge/proton-setup.lock"
UMU_API = "https://api.github.com/repos/Open-Wine-Components/umu-launcher/releases/latest"
GE_API = "https://api.github.com/repos/GloriousEggroll/proton-ge-custom/releases/latest"
UA = {"User-Agent": "phoenixge-proton-setup", "Accept": "application/vnd.github+json"}
NOTIFY = "--notify" in sys.argv


def log(msg):
    print(msg, flush=True)


def notify(title, body):
    if NOTIFY and shutil.which("notify-send"):
        subprocess.Popen(["notify-send", "-a", "PhoenixGe", "-i", "/usr/share/pixmaps/phoenixge.png", title, body])


def api(url):
    with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=30) as r:
        return json.load(r)


def download(url, dest, algo=None, expected=None):
    log(f"downloading {url}")
    h = hashlib.new(algo) if algo else None
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": UA["User-Agent"]}), timeout=60) as r, \
            open(dest, "wb") as f:
        total, done, step = int(r.headers.get("Content-Length") or 0), 0, 0
        while chunk := r.read(1 << 20):
            f.write(chunk)
            if h:
                h.update(chunk)
            done += len(chunk)
            if total and done * 10 // total > step:
                step = done * 10 // total
                log(f"  {step * 10}%  ({done >> 20} / {total >> 20} MB)")
    if h and expected and h.hexdigest() != expected.lower():
        raise RuntimeError(f"checksum mismatch for {url}")


def safe_extract(tar_path, dest):
    dest = dest.resolve()
    with tarfile.open(tar_path) as t:
        for m in t.getmembers():
            if not (dest / m.name).resolve().is_relative_to(dest):
                raise RuntimeError(f"unsafe path in archive: {m.name}")
        t.extractall(dest, filter="tar") if hasattr(tarfile, "data_filter") else t.extractall(dest)


def installed_proton():
    """Newest GE-Proton directory that has a proton script (version-sorted)."""
    if not TOOLS.is_dir():
        return None
    dirs = [d for d in TOOLS.glob("GE-Proton*") if (d / "proton").is_file()]
    key = lambda d: [int(x) if x.isdigit() else 0 for x in d.name.replace("GE-Proton", "").replace("-", ".").split(".")]
    return max(dirs, key=key) if dirs else None


def status():
    proton = installed_proton()
    warm = STATE.is_file() and json.loads(STATE.read_text()).get("warm", False)
    return {"ready": bool(UMU_RUN.is_file() and proton and warm),
            "umu": str(UMU_RUN) if UMU_RUN.is_file() else None,
            "proton": str(proton) if proton else None, "warm": warm}


def install_umu(update):
    if UMU_RUN.is_file() and not update:
        return
    rel = api(UMU_API)
    asset = next(a for a in rel["assets"] if a["name"].endswith("-zipapp.tar"))
    digest = (asset.get("digest") or "").removeprefix("sha256:") or None
    ver_file = UMU_DIR / "VERSION"
    if UMU_RUN.is_file() and ver_file.is_file() and ver_file.read_text().strip() == rel["tag_name"]:
        log(f"umu-launcher {rel['tag_name']} is current")
        return
    with tempfile.TemporaryDirectory() as tmp:
        tar = Path(tmp) / asset["name"]
        download(asset["browser_download_url"], tar, "sha256" if digest else None, digest)
        safe_extract(tar, Path(tmp))
        UMU_DIR.mkdir(parents=True, exist_ok=True)
        shutil.copy2(Path(tmp) / "umu/umu-run", UMU_RUN)
    UMU_RUN.chmod(0o755)
    ver_file.write_text(rel["tag_name"] + "\n")
    log(f"umu-launcher {rel['tag_name']} installed")


def install_proton(update):
    if installed_proton() and not update:
        return
    rel = api(GE_API)
    tag = rel["tag_name"]
    if (TOOLS / tag / "proton").is_file():
        log(f"{tag} is current")
        return
    tar_a = next(a for a in rel["assets"] if a["name"] == f"{tag}-x86_64.tar.gz" or a["name"] == f"{tag}.tar.gz")
    sum_a = next((a for a in rel["assets"] if a["name"].endswith(".sha512sum") and "aarch64" not in a["name"]), None)
    expected = None
    if sum_a:
        with urllib.request.urlopen(urllib.request.Request(sum_a["browser_download_url"], headers=UA), timeout=30) as r:
            expected = r.read().decode().split()[0]
    TOOLS.mkdir(parents=True, exist_ok=True)
    free = shutil.disk_usage(TOOLS).free
    if free < 3 * (1 << 30):
        raise RuntimeError(f"not enough free space ({free >> 30} GB, GE-Proton needs ~3 GB)")
    with tempfile.TemporaryDirectory(dir=TOOLS) as tmp:   # same filesystem -> atomic rename
        tar = Path(tmp) / tar_a["name"]
        download(tar_a["browser_download_url"], tar, "sha512" if expected else None, expected)
        log("unpacking…")
        safe_extract(tar, Path(tmp) / "x")
        src = next((Path(tmp) / "x").iterdir())
        src.rename(TOOLS / tag)
    log(f"{tag} installed")
    STATE.write_text(json.dumps({"warm": False}))


def warm_up():
    """First umu run downloads the Steam Runtime (~600 MB) - do it now, not during the first program's probe."""
    st = status()
    if st["warm"]:
        return
    log("preparing the Steam Runtime (one time)…")
    with tempfile.TemporaryDirectory() as tmp:
        env = dict(os.environ, WINEPREFIX=str(Path(tmp) / "pfx"), GAMEID="umu-default", STORE="none",
                   PROTONPATH=st["proton"], UMU_LOG="1", WINEDEBUG="-all", PROTON_LOG="0")
        r = subprocess.run([str(UMU_RUN), "wineboot", "-u"], env=env, timeout=1800)
    if r.returncode != 0:
        raise RuntimeError(f"umu warm-up failed (exit {r.returncode})")
    STATE.write_text(json.dumps({"warm": True}))
    log("ready")


def main():
    if "--status" in sys.argv:
        print(json.dumps(status()))
        return 0
    update = "--update" in sys.argv
    LOCK.parent.mkdir(parents=True, exist_ok=True)
    with open(LOCK, "w") as lk:
        try:
            fcntl.flock(lk, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            log("already running")
            return 0
        if status()["ready"] and not update:
            log("already installed: " + json.dumps(status()))
            return 0
        notify("PhoenixGe", "GE-Proton is being installed for Windows programs (~1 GB download, one time)…")
        try:
            install_umu(update)
            install_proton(update)
            warm_up()
        except Exception as e:   # network, disk, checksum
            log(f"FAILED: {e}")
            notify("GE-Proton was not installed", f"{e}. Windows programs keep using Wine.")
            return 1
        notify("PhoenixGe", "GE-Proton is ready - Windows programs now start with it.")
        log(json.dumps(status()))
        return 0


if __name__ == "__main__":
    sys.exit(main())
