#!/bin/sh
# System-wide PhoenixGe setup. Run by the ISO build (hook 0800) and by the phoenixge-desktop package (postinst),
# so an update brings the same result as a fresh install.
set -e
# /etc defaults travel inside the package under usr/share (dpkg conffile prompts would block GUI updates)
if [ -d /usr/share/phoenixge/etc-overlay ]; then
  cp -r /usr/share/phoenixge/etc-overlay/. /etc/
fi
# repair: older builds had no VERSION_CODENAME in /etc/os-release -> "Suites: -backports" broke every apt update
B=/etc/apt/sources.list.d/phoenixge-backports.sources
if [ -f "$B" ] && grep -q '^Suites: -backports' "$B"; then sed -i 's/^Suites: -backports/Suites: trixie-backports/' "$B"; fi
# backports already in sources.list (Debian installer) -> our extra file only causes "configured multiple times" warnings
if [ -f "$B" ] && grep -qsE '^[^#]*trixie-backports' /etc/apt/sources.list; then rm -f "$B"; fi
# repair: the NVIDIA first-boot step used to add contrib/non-free to the PhoenixGe repo too (apt warnings)
for f in /etc/apt/sources.list.d/*.sources; do
  [ -f "$f" ] && grep -q '^URIs:.*phoenixge-updates' "$f" && sed -i -E 's/^Components:.*/Components: main/' "$f"
done
# update channel (stable/beta): the overlay just reset the apt source to stable -> re-apply the saved channel
sh /usr/lib/phoenixge/update-channel.sh apply || true
sh /usr/lib/phoenixge/autoupdate-setup.sh || true
# start menu: hide apps that only clutter it
for f in org.kde.contactprintthemeeditor org.kde.contactthemeeditor org.kde.headerthemeeditor org.kde.mboximporter \
         org.kde.pimdataexporter org.kde.kmail-refresh-settings org.kde.ktnef org.kde.sieveeditor \
         org.kde.drkonqi.coredump.gui org.kde.kdeconnect.sms org.kde.kdeconnect.nonplasma display-im7.q16 \
         org.kde.kmousetool org.kde.kmouth org.kde.kmag org.kde.sweeper org.rncbc.qsynth vim kvantummanager \
         org.kde.kontrast org.kde.kmenuedit konqbrowser org.kde.akregator; do
  d=/usr/share/applications/$f.desktop
  [ -f "$d" ] || continue
  if grep -q '^NoDisplay=' "$d"; then sed -i 's/^NoDisplay=.*/NoDisplay=true/' "$d"; else sed -i '/^\[Desktop Entry\]/a NoDisplay=true' "$d"; fi
done
# icon themes (design folders + Papirus logos)
python3 /usr/lib/phoenixge/make-tile-icons.py || true
# login screen
mkdir -p /etc/sddm.conf.d
printf '[Theme]\nCurrent=phoenixge\n' > /etc/sddm.conf.d/10-phoenixge.conf
chmod 755 /usr/lib/phoenixge/*.sh /usr/bin/phoenix-* 2>/dev/null || true
systemctl --global enable phoenixge-autotheme.timer >/dev/null 2>&1 || true
# first-boot setup (apps, Game Mode, backups, Android) - also runs once after an update brings new steps
systemctl enable phoenixge-firstboot-apps.service phoenixge-firstboot-apps.timer >/dev/null 2>&1 || true
chmod 755 /usr/lib/phoenixge/*.sh /usr/lib/phoenixge/dev/*.sh /usr/lib/phoenixge/gaming/*.sh /usr/lib/phoenixge/gaming/*.py 2>/dev/null || true
# safe updates: snapshot before updates + GRUB "restore previous state" menu
sh /usr/lib/phoenixge/safe-updates-setup.sh || true
if [ -d /run/systemd/system ]; then systemctl daemon-reload || true; fi
# NVIDIA: kernel modesetting (Wayland, VRR, HDR) for installs that got the driver before this was added
if [ -d /run/systemd/system ] && [ ! -d /run/live ] && [ ! -f /etc/modprobe.d/phoenixge-nvidia-drm.conf ] && \
   { dpkg -s nvidia-kernel-dkms >/dev/null 2>&1 || dpkg -s nvidia-open-kernel-dkms >/dev/null 2>&1; }; then
  sh /usr/lib/phoenixge/gamedisplay/nvidia-modeset.sh on >/dev/null 2>&1 || true
fi
# NVIDIA driver half-installed because the DKMS build failed on a newer kernel -> patch + finish (no-op otherwise)
if [ -d /run/systemd/system ] && [ ! -d /run/live ] && [ -x /usr/lib/phoenixge/nvidia-dkms-fix.sh ] && ls -d /usr/src/nvidia-current* >/dev/null 2>&1; then
  setsid sh /usr/lib/phoenixge/nvidia-dkms-fix.sh >>/var/log/phoenixge-nvidia-fix.log 2>&1 < /dev/null &   # background: dpkg is still locked by this very postinst
fi
# boot animation: rebuild the initramfs only when the PhoenixGe Plymouth theme changed (installed systems)
T=/usr/share/plymouth/themes/phoenixge
if [ -d /run/systemd/system ] && [ ! -d /run/live ] && [ -d "$T" ] && command -v plymouth-set-default-theme >/dev/null; then
  SUM=$(cat "$T"/* | md5sum | cut -d' ' -f1)
  if [ "$SUM" != "$(cat /var/lib/phoenixge/plymouth.md5 2>/dev/null)" ]; then
    plymouth-set-default-theme phoenixge && update-initramfs -u >/dev/null 2>&1 && mkdir -p /var/lib/phoenixge && echo "$SUM" > /var/lib/phoenixge/plymouth.md5
  fi
fi
exit 0
