#!/bin/sh
# PhoenixGe: on the INSTALLED system, set up what PhoenixGe offers, once (needs internet).
# What gets installed depends on the profile picked in the installer (/var/lib/phoenixge/profile):
#   gaming     game apps, Instant Replay, RGB, GPU control, Game Mode session, Android, backups
#   developer  developer pack, VS Code, Android Studio, Docker, Android, backups
#   everything all of the above (default, also for systems installed before profiles existed)
#   minimal    backups only (everything else stays one click away in PhoenixGe Center)
# Each step has its own stamp: a step that failed (no internet) is retried by the timer every 15 min.
[ -d /run/live ] && exit 0                       # skip in the live session
D=/var/lib/phoenixge; mkdir -p "$D"
PROFILE=$(cat "$D/profile" 2>/dev/null || echo everything)
exec >>/var/log/phoenixge-firstboot.log 2>&1
echo "=== $(date) first-boot setup, profile: $PROFILE"
for i in $(seq 1 30); do getent hosts dl.flathub.org >/dev/null && break; sleep 10; done
FAIL=0
step() { [ -f "$D/fb-$1.done" ] && return 0; echo "--- $1"; if "$1"; then touch "$D/fb-$1.done"; else echo "!!! $1 failed, retry later"; FAIL=1; fi; }
flathub() { flatpak remote-add --if-not-exists --system flathub https://dl.flathub.org/repo/flathub.flatpakrepo &&
            flatpak install --system --noninteractive -y flathub "$@"; }

games() { flathub com.valvesoftware.Steam com.heroicgameslauncher.hgl com.discordapp.Discord org.prismlauncher.PrismLauncher \
                  com.usebottles.bottles net.davidotek.pupgui2; }
replay() { flathub com.dec05eba.gpu_screen_recorder; }        # Instant Replay (ShadowPlay-like)
rgb() {
  flathub org.openrgb.OpenRGB || return 1
  R=/var/lib/flatpak/app/org.openrgb.OpenRGB/current/active/files/lib/udev/rules.d/60-openrgb.rules
  [ -f "$R" ] && cp "$R" /etc/udev/rules.d/60-openrgb.rules && udevadm control --reload-rules && udevadm trigger
  echo i2c-dev > /etc/modules-load.d/phoenixge-rgb.conf; modprobe i2c-dev 2>/dev/null || true
}
gpu() {  # GPU fans/clocks/temps/power limit: LACT (NVIDIA + AMD); its daemon is set up on first start of the app
  if lspci -nn | grep -Ei 'vga|3d' | grep -Eq '10de|1002'; then flathub io.github.ilya_zlobintsev.LACT; fi
}
flatpaknv() { sh /usr/lib/phoenixge/flatpak-nvidia.sh; }   # NVIDIA GPU inside Flatpak games (no-op without NVIDIA)
gamemode() { sh /usr/lib/phoenixge/apt-install.sh -b gamescope; }
devpack() {
  sh /usr/lib/phoenixge/apt-install.sh build-essential git cmake clang gdb python3-pip python3-venv pipx nodejs npm \
     default-jdk golang rustc cargo php composer sqlite3 neovim adb fastboot docker.io docker-compose || return 1
  for u in $(awk -F: '$3>=1000 && $3<60000{print $1}' /etc/passwd); do usermod -aG docker "$u" 2>/dev/null; done
  return 0
}
devapps() { flathub com.visualstudio.code com.google.AndroidStudio io.github.shiftey.Desktop com.getpostman.Postman; }
backups() { { command -v timeshift >/dev/null || sh /usr/lib/phoenixge/apt-install.sh timeshift; } && sh /usr/lib/phoenixge/timeshift-auto.sh; }
android() { sh /usr/lib/phoenixge/android-setup.sh; }

case "$PROFILE" in
  gaming)    STEPS="games flatpaknv replay rgb gpu gamemode backups android" ;;
  developer) STEPS="devpack devapps backups android" ;;
  minimal)   STEPS="backups" ;;
  *)         STEPS="games flatpaknv replay rgb gpu gamemode devpack devapps backups android" ;;
esac
for s in $STEPS; do step "$s"; done
[ "$FAIL" = 0 ] && touch "$D/firstboot-v2.done"
[ "$FAIL" = 0 ] && sh /usr/lib/phoenixge/sysreset-factory-snapshot.sh || true
echo "=== done (fail=$FAIL)"
exit 0
