#!/bin/sh
# PhoenixGe: Flatpak apps (Steam, Heroic, Bottles, ...) only use the NVIDIA GPU when the Flatpak GL extension that
# matches the host driver is installed: org.freedesktop.Platform.GL{,32}.nvidia-<version with dashes>.
# Without it games silently run on the integrated GPU (or fall back to software). Installs the missing ones.
# No-op without NVIDIA driver, without system Flatpak apps, or when the disk is too full (needs ~1 GB).
[ -d /run/live ] && exit 0
command -v flatpak >/dev/null 2>&1 || exit 0
flatpak --system list --app --columns=application 2>/dev/null | grep -q . || exit 0
V=$(cat /sys/module/nvidia/version 2>/dev/null)
[ -n "$V" ] || V=$(dpkg-query -W -f='${Version}' nvidia-driver-libs 2>/dev/null | sed 's/-.*//')
case "$V" in [0-9]*.[0-9]*) ;; *) exit 0 ;; esac
N=nvidia-$(echo "$V" | tr . -)
H=$(flatpak --system list --runtime --columns=application 2>/dev/null)
MISS=""
for e in GL GL32; do echo "$H" | grep -qx "org.freedesktop.Platform.$e.$N" || MISS="$MISS org.freedesktop.Platform.$e.$N"; done
[ -n "$MISS" ] || exit 0
FREE=$(df -Pk /var/lib/flatpak 2>/dev/null | awk 'NR==2{print $4}')
[ "${FREE:-0}" -gt 3000000 ] || { echo "flatpak-nvidia: less than 3 GB free, not installing$MISS"; exit 0; }
echo "flatpak-nvidia: installing$MISS"
flatpak remote-add --if-not-exists --system flathub https://dl.flathub.org/repo/flathub.flatpakrepo &&
  flatpak install --system --noninteractive -y flathub $MISS
