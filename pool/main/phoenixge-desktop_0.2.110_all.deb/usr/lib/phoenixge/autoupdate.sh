#!/bin/sh
# PhoenixGe automatic updates (Center > Auto updates). Settings: /etc/phoenixge/autoupdate.conf, defaults:
# /usr/share/phoenixge/autoupdate.conf.default (MODE=auto: security + PhoenixGe install, the rest is downloaded and
# you get a notification; only on non-metered networks, on AC power and never while a game runs).
#
#   autoupdate.sh run [--timer|--now]   root. --timer (phoenixge-autoupdate.timer, hourly): runs when due, inside the
#                                       time window and when the conditions allow - otherwise postpones (next hour).
#                                       --now ("Update now"): everything that isn't "off" is installed right away.
#   autoupdate.sh shutdown              root, phoenixge-autoupdate-shutdown.service (ExecStop): WHEN=shutdown installs
#                                       what the timer downloaded
#   autoupdate.sh set KEY=VALUE ...     root, writes /etc/phoenixge/autoupdate.conf (values are validated)
#   autoupdate.sh pause SECONDS | resume
#   autoupdate.sh config                print the effective settings (any user)
#   autoupdate.sh user-flatpak [--now]  as the user (systemd --user phoenixge-flatpak-autoupdate.timer): the user's
#                                       own Flatpak apps, same settings and conditions
# Status: /var/lib/phoenixge/autoupdate-status.json (+ ~/.local/state/phoenixge/autoupdate-user.json),
# log: /var/log/phoenixge-autoupdate.log. Snapshots before apt changes come from the apt hook (80phoenixge-snapshot).
set -u
PATH=/usr/sbin:/usr/bin:/sbin:/bin
DEF=/usr/share/phoenixge/autoupdate.conf.default
CONF=/etc/phoenixge/autoupdate.conf
STATE=/var/lib/phoenixge
STATUS=$STATE/autoupdate-status.json
STAMP=$STATE/autoupdate.last-ok
PENDING=$STATE/autoupdate.pending
NOTIFIED=$STATE/autoupdate.notified
LOG=/var/log/phoenixge-autoupdate.log
ICON=system-software-update
KEYS="MODE FREQ SECURITY PHOENIXGE SYSTEM FLATPAK FIRMWARE WHEN WIN_START WIN_END UNMETERED AC NOGAME DL_LIMIT REBOOT_NOTIFY KERNEL_CLEANUP PAUSED_UNTIL"

# ------------------------------------------------------------------ settings
fallback() {
  case "$1" in
    MODE) echo auto ;; FREQ) echo daily ;; SECURITY|PHOENIXGE) echo install ;; SYSTEM|FLATPAK) echo download ;;
    FIRMWARE) echo notify ;; WHEN) echo anytime ;; WIN_START) echo 3 ;; WIN_END) echo 6 ;;
    UNMETERED|AC|NOGAME|REBOOT_NOTIFY|KERNEL_CLEANUP) echo 1 ;; *) echo 0 ;;
  esac
}
valid() {
  case "$1" in
    MODE) case "$2" in auto|manual) return 0 ;; esac ;;
    FREQ) case "$2" in daily|weekly) return 0 ;; esac ;;
    SECURITY|PHOENIXGE|SYSTEM|FLATPAK) case "$2" in install|download|off) return 0 ;; esac ;;
    FIRMWARE) case "$2" in notify|off) return 0 ;; esac ;;
    WHEN) case "$2" in anytime|window|shutdown) return 0 ;; esac ;;
    WIN_START|WIN_END) case "$2" in [0-9]|1[0-9]|2[0-3]) return 0 ;; esac ;;
    UNMETERED|AC|NOGAME|REBOOT_NOTIFY|KERNEL_CLEANUP) case "$2" in 0|1) return 0 ;; esac ;;
    DL_LIMIT|PAUSED_UNTIL) case "$2" in ''|*[!0-9]*) return 1 ;; *) [ ${#2} -le 12 ] && return 0 ;; esac ;;
  esac
  return 1
}
raw() { [ -r "$2" ] && sed -n "s/^$1=\([A-Za-z0-9_.:-]*\).*/\1/p" "$2" | tail -n 1; }
conf() {
  _m=$(raw MODE "$CONF"); valid MODE "$_m" || _m=$(raw MODE "$DEF"); valid MODE "$_m" || _m=auto
  [ "$1" = MODE ] && { echo "$_m"; return; }
  _v=""
  if [ "$_m" = manual ] || [ "$1" = PAUSED_UNTIL ]; then _v=$(raw "$1" "$CONF"); fi
  valid "$1" "$_v" || _v=$(raw "$1" "$DEF")
  valid "$1" "$_v" || _v=$(fallback "$1")
  echo "$_v"
}
load() { for k in $KEYS; do eval "C_$k=\$(conf $k)"; done; }

need_root() { [ "$(id -u)" = 0 ] || { echo "autoupdate.sh: $1 needs root (pkexec)" >&2; exit 1; }; }

write_conf() { # KEY=VALUE ... (already validated)
  mkdir -p /etc/phoenixge
  T=$(mktemp /etc/phoenixge/.autoupdate.XXXXXX) || exit 1
  { echo "# PhoenixGe automatic updates - written by PhoenixGe Center (see $DEF for what each key means)"
    for k in $KEYS; do
      v=""
      for a in "$@"; do [ "${a%%=*}" = "$k" ] && v=${a#*=}; done
      [ -n "$v" ] || v=$(raw "$k" "$CONF")
      valid "$k" "$v" || v=$(raw "$k" "$DEF")
      valid "$k" "$v" || v=$(fallback "$k")
      echo "$k=$v"
    done; } > "$T"
  chmod 644 "$T" && mv "$T" "$CONF"
}

# ------------------------------------------------------------------ helpers
now() { date +%s; }
log() {
  echo "$*"
  [ "$(id -u)" = 0 ] && echo "$(date '+%F %T') $*" >> "$LOG"
  return 0
}
trim_log() {
  [ -f "$LOG" ] || return 0
  if [ "$(wc -c < "$LOG")" -gt 1048576 ]; then tail -n 3000 "$LOG" > "$LOG.tmp" && mv "$LOG.tmp" "$LOG"; fi
  chmod 644 "$LOG" 2>/dev/null
}

user_sessions() { # uid user busdir (logged-in desktop users)
  for d in /run/user/[0-9]*; do
    [ -S "$d/bus" ] || continue
    u=${d##*/}; [ "$u" -ge 1000 ] 2>/dev/null || continue
    n=$(id -nu "$u" 2>/dev/null) || continue
    echo "$u $n $d"
  done
}

notify() { # title body
  if [ "$(id -u)" != 0 ]; then
    notify-send -a "PhoenixGe Updates" -i "$ICON" "$1" "$2" 2>/dev/null; return 0
  fi
  command -v notify-send >/dev/null 2>&1 || return 0
  user_sessions | while read -r uid name dir; do
    timeout 10 runuser -u "$name" -- env DBUS_SESSION_BUS_ADDRESS="unix:path=$dir/bus" XDG_RUNTIME_DIR="$dir" \
      notify-send -a "PhoenixGe Updates" -i "$ICON" "$1" "$2" >/dev/null 2>&1
  done
  return 0
}

on_ac() {
  bat=0
  for s in /sys/class/power_supply/*; do
    [ -r "$s/type" ] || continue
    case "$(cat "$s/type")" in
      Mains|USB|USB_C|USB_PD|USB_PD_DRP) [ "$(cat "$s/online" 2>/dev/null)" = 1 ] && return 0 ;;
      Battery)
        [ "$(cat "$s/scope" 2>/dev/null)" = Device ] && continue   # mouse/keyboard batteries
        bat=1
        case "$(cat "$s/status" 2>/dev/null)" in Charging|Full|"Not charging") return 0 ;; esac ;;
    esac
  done
  [ "$bat" = 0 ]   # no system battery = desktop PC
}

metered() {
  command -v busctl >/dev/null 2>&1 || return 1
  m=$(busctl get-property org.freedesktop.NetworkManager /org/freedesktop/NetworkManager \
      org.freedesktop.NetworkManager Metered 2>/dev/null | awk '{print $2}')
  case "$m" in 1|3) return 0 ;; esac   # NM: 1 = yes, 3 = guess-yes (phone hotspot)
  return 1
}

gaming() {
  [ -f /run/phoenixge/gaming-pause.state ] && return 0
  for f in /run/user/[0-9]*/phoenixge/gaming-session.json; do [ -f "$f" ] && return 0; done
  command -v gamemoded >/dev/null 2>&1 || return 1
  if [ "$(id -u)" != 0 ]; then
    case "$(timeout 5 gamemoded -s 2>/dev/null)" in *" is active"*) return 0 ;; esac
    return 1
  fi
  for line in $(user_sessions | tr ' ' ':'); do
    uid=${line%%:*}; rest=${line#*:}; name=${rest%%:*}; dir=${rest#*:}
    case "$(timeout 5 runuser -u "$name" -- env DBUS_SESSION_BUS_ADDRESS="unix:path=$dir/bus" gamemoded -s 2>/dev/null)" in
      *" is active"*) return 0 ;;
    esac
  done
  return 1
}

in_window() {
  [ "$C_WHEN" = window ] || return 0
  h=$(date +%H | sed 's/^0//'); [ -n "$h" ] || h=0
  s=$C_WIN_START; e=$C_WIN_END
  if [ "$s" -lt "$e" ]; then [ "$h" -ge "$s" ] && [ "$h" -lt "$e" ]
  elif [ "$s" -gt "$e" ]; then [ "$h" -ge "$s" ] || [ "$h" -lt "$e" ]
  else return 0; fi
}

due() { # stampfile
  last=$(cat "$1" 2>/dev/null); case "$last" in ''|*[!0-9]*) last=0 ;; esac
  case "$C_FREQ" in weekly) iv=$((6 * 86400 + 12 * 3600)) ;; *) iv=$((20 * 3600)) ;; esac
  [ $(($(now) - last)) -ge "$iv" ]
}

blocked() { # prints the reason when a condition blocks the run
  [ "$C_AC" = 1 ] && ! on_ac && { echo "on battery power"; return 0; }
  [ "$C_UNMETERED" = 1 ] && metered && { echo "on a metered connection"; return 0; }
  [ "$C_NOGAME" = 1 ] && gaming && { echo "a game is running"; return 0; }
  return 1
}

# status file (Center reads it). Lists are space separated package names.
INSTALLED=""; DOWNLOADED=""; HELD=""; FW=0; FPAK=""; REBOOT=0
status() { # result message [trigger]
  [ "$(id -u)" = 0 ] || return 0
  mkdir -p "$STATE"
  AU_RESULT="$1" AU_MSG="$2" AU_TRIGGER="${3:-timer}" AU_INSTALLED="$INSTALLED" AU_DOWNLOADED="$DOWNLOADED" AU_HELD="$HELD" \
  AU_FW="$FW" AU_FPAK="$FPAK" AU_REBOOT="$REBOOT" AU_OUT="$STATUS" AU_STAMP="$STAMP" python3 - <<'PY' 2>/dev/null
import json, os, time
e = os.environ
try:
    last_ok = int(open(e["AU_STAMP"]).read().strip() or 0)
except Exception:
    last_ok = 0
d = dict(time=int(time.time()), result=e["AU_RESULT"], message=e["AU_MSG"], trigger=e["AU_TRIGGER"], last_ok=last_ok,
         installed=e["AU_INSTALLED"].split(), downloaded=e["AU_DOWNLOADED"].split(), held=e["AU_HELD"].split(),
         firmware=int(e["AU_FW"] or 0), flatpak=e["AU_FPAK"], reboot=e["AU_REBOOT"] == "1" or os.path.exists("/run/reboot-required"))
tmp = e["AU_OUT"] + ".tmp"
with open(tmp, "w") as f:
    json.dump(d, f, indent=1)
os.chmod(tmp, 0o644)
os.replace(tmp, e["AU_OUT"])
PY
}

# ------------------------------------------------------------------ apt
apt_env() {
  export DEBIAN_FRONTEND=noninteractive APT_LISTCHANGES_FRONTEND=none NEEDRESTART_MODE=a LC_ALL=C.UTF-8
  APTO="-q -o DPkg::Lock::Timeout=900 -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold"
  if [ "$C_DL_LIMIT" -gt 0 ] 2>/dev/null; then
    APTO="$APTO -o Acquire::http::Dl-Limit=$C_DL_LIMIT -o Acquire::https::Dl-Limit=$C_DL_LIMIT"
  fi
}

# "security pkg" / "phoenixge pkg" / "system pkg" for every package a full upgrade would install
classify() {
  apt-get -s -o Debug::NoLocking=1 dist-upgrade 2>/dev/null | awk '
    /^Inst / { c = "system"
               if (index($0, "Debian-Security:") || index($0, "-security ") || index($0, "-security,") || index($0, "-security]")) c = "security"
               else if (index($0, " PhoenixGe:") || index($0, ",PhoenixGe:")) c = "phoenixge"
               print c, $2 }'
}

removals() { # apt-get args... -> package names the action would remove
  apt-get -s -o Debug::NoLocking=1 "$@" 2>/dev/null | awk '/^Remv /{print $2}' | tr '\n' ' '
}

reboot_check() { # names of installed packages
  need=""
  for p in $1; do
    case "$p" in linux-image-*|linux-modules-*|systemd|systemd-*|libc6|libc6-*|dbus|dbus-*|libssl3*|nvidia-*|libnvidia-*|firmware-*|*-microcode|libgl1-mesa-dri|mesa-*)
      need="$need $p" ;; esac
  done
  newest=$(ls /boot/vmlinuz-* 2>/dev/null | sed 's|/boot/vmlinuz-||' | sort -V | tail -n 1)
  if [ -n "$newest" ] && [ "$newest" != "$(uname -r)" ]; then need="$need kernel-$newest"; fi
  if [ -n "$need" ]; then
    touch /run/reboot-required
    for p in $need; do echo "$p"; done >> /run/reboot-required.pkgs
    REBOOT=1
  fi
}

# install or download one class of packages. $1 class, $2 policy, $3 extra apt flag (--no-download at shutdown)
do_class() {
  cls=$1; pol=$2; extra=${3:-}
  pk=$(echo "$CLASSES" | awk -v c="$cls" '$1 == c {print $2}' | tr '\n' ' ')
  [ -n "${pk% }" ] || return 0
  [ "$pol" = off ] && { log "$cls: $(echo $pk | wc -w) update(s) available, set to off - skipped"; return 0; }
  rm=$(removals install --only-upgrade $pk)
  if [ -n "$rm" ]; then
    log "$cls: would REMOVE $rm - not done automatically, only downloaded (install it yourself after checking)"
    HELD="$HELD $pk"; pol=download
  fi
  if [ "$pol" = download ]; then
    log "$cls: downloading $(echo $pk | wc -w) update(s): $pk"
    if apt-get $APTO -y -d install --only-upgrade $pk >> "$LOG" 2>&1; then DOWNLOADED="$DOWNLOADED $pk"
    else log "$cls: download failed (see the log)"; FAILED=1; fi
    return 0
  fi
  log "$cls: installing $(echo $pk | wc -w) update(s): $pk"
  if apt-get $APTO -y $extra install --only-upgrade $pk 2>&1 | tee -a "$LOG" | grep -E '^(Setting up|Unpacking|E:|W:)' ; then :; fi
  # what really changed: compare with a new simulation
  left=$(classify | awk -v c="$cls" '$1 == c {print $2}' | tr '\n' ' ')
  for p in $pk; do
    case " $left " in *" $p "*) FAILED=1 ;; *) INSTALLED="$INSTALLED $p" ;; esac
  done
  [ -n "${left% }" ] && log "$cls: not installed: $left"
  return 0
}

kernel_cleanup() {
  [ "$C_KERNEL_CLEANUP" = 1 ] || return 0
  run=$(uname -r)
  old=$(apt-get -s -o Debug::NoLocking=1 autoremove 2>/dev/null | awk '/^Remv /{print $2}' |
        grep -E '^linux-(image|headers|modules|kbuild)-[0-9]' | grep -vF -- "$run" | tr '\n' ' ')
  [ -n "${old% }" ] || return 0
  log "removing old kernels: $old (keeping $run and the newest)"
  apt-get $APTO -y purge $old >> "$LOG" 2>&1 || log "kernel cleanup failed (see the log)"
}

firmware_check() {
  [ "$C_FIRMWARE" = notify ] && command -v fwupdmgr >/dev/null 2>&1 || return 0
  timeout 120 fwupdmgr refresh --assume-yes >/dev/null 2>&1
  FW=$(timeout 120 fwupdmgr get-updates --json 2>/dev/null | python3 -c '
import json, sys
try:
    d = json.load(sys.stdin)
except Exception:
    print(0); raise SystemExit
print(sum(1 for x in d.get("Devices", []) if x.get("Releases")))' 2>/dev/null)
  case "$FW" in ''|*[!0-9]*) FW=0 ;; esac
  [ "$FW" -gt 0 ] && log "firmware: updates for $FW device(s) available (not installed automatically)"
  return 0
}

flatpak_system() { # install|download|deploy
  [ "$C_FLATPAK" != off ] && command -v flatpak >/dev/null 2>&1 || return 0
  flatpak --system list --columns=ref 2>/dev/null | grep -q . || return 0
  case "$1" in
    install) a="" ;; download) a="--no-deploy" ;; deploy) a="--no-pull" ;;
  esac
  log "flatpak (system): $1"
  if flatpak update --system -y --noninteractive $a >> "$LOG" 2>&1; then FPAK="$1"; else FPAK="failed"; log "flatpak update failed"; fi
}

notify_result() {
  n_i=$(echo $INSTALLED | wc -w); n_d=$(echo $DOWNLOADED | wc -w)
  if [ "$n_d" -gt 0 ] || [ -n "${HELD# }" ] || [ "$FW" -gt 0 ]; then
    key=$(echo "$DOWNLOADED $HELD fw$FW" | md5sum | cut -c1-12)
    if [ "$key" != "$(cat "$NOTIFIED" 2>/dev/null)" ]; then
      msg=""
      [ "$n_d" -gt 0 ] && msg="$n_d update(s) are downloaded and ready. Install them: PhoenixGe Center > Auto updates > Update now, or Discover."
      [ -n "${HELD# }" ] && msg="$msg Some updates would remove packages - please review them in Discover."
      [ "$FW" -gt 0 ] && msg="$msg Firmware updates for $FW device(s) are available (Discover > Updates)."
      notify "Updates ready" "$msg"
      echo "$key" > "$NOTIFIED"
    fi
  fi
  if [ "$REBOOT" = 1 ] && [ "$C_REBOOT_NOTIFY" = 1 ]; then
    notify "Restart to finish updating" "$n_i update(s) were installed. Some (kernel, drivers or system libraries) are used after a restart."
  elif [ "$n_i" -gt 0 ]; then
    notify "Updates installed" "$n_i update(s) installed in the background (security and PhoenixGe)."
  fi
}

# ------------------------------------------------------------------ run
cmd_run() {
  need_root run
  trigger=${1:---timer}; trigger=${trigger#--}
  [ -d /run/live ] && { echo "live session - no automatic updates"; exit 0; }
  mkdir -p "$STATE"
  exec 9>/run/phoenixge-autoupdate.lock
  flock -n 9 || { echo "another update run is busy"; exit 0; }
  load; trim_log
  if [ "$trigger" != now ]; then
    if [ "$C_PAUSED_UNTIL" -gt "$(now)" ]; then status paused "Paused until $(date -d "@$C_PAUSED_UNTIL" '+%F %H:%M')" "$trigger"; exit 0; fi
    due "$STAMP" || exit 0
    in_window || { status waiting "Waiting for the time window ($C_WIN_START:00-$C_WIN_END:00)" "$trigger"; exit 0; }
    if r=$(blocked); then log "postponed: $r"; status postponed "Postponed: $r - trying again every hour" "$trigger"; exit 0; fi
  fi
  log "=== update run ($trigger, mode $C_MODE)"
  apt_env; FAILED=0
  if ! apt-get $APTO update >> "$LOG" 2>&1; then log "could not refresh the package lists (offline?)"; status failed "Could not reach the update servers" "$trigger"; exit 1; fi
  CLASSES=$(classify)
  if [ "$trigger" = now ]; then
    for c in SECURITY PHOENIXGE SYSTEM FLATPAK; do eval "[ \"\$C_$c\" = download ] && C_$c=install"; done
    # "Update now" = all system packages that are not switched off
  elif [ "$C_WHEN" = shutdown ]; then
    for c in SECURITY PHOENIXGE SYSTEM FLATPAK; do eval "[ \"\$C_$c\" = install ] && C_$c=download"; done
    echo "$CLASSES" > "$PENDING"
  fi
  do_class security "$C_SECURITY"
  do_class phoenixge "$C_PHOENIXGE"
  do_class system "$C_SYSTEM"
  [ -n "${INSTALLED# }" ] && kernel_cleanup
  [ -n "${INSTALLED# }" ] && reboot_check "$INSTALLED"
  flatpak_system "$C_FLATPAK"
  firmware_check
  [ -z "$(echo "$CLASSES" | tr -d ' \n')" ] && log "system packages are up to date"
  [ "$FAILED" = 0 ] && now > "$STAMP"
  if [ "$FAILED" = 1 ]; then res=partial; msg="Some updates failed - see the log"
  elif [ -n "${INSTALLED# }${DOWNLOADED# }" ]; then res=ok; msg="$(echo $INSTALLED | wc -w) installed, $(echo $DOWNLOADED | wc -w) downloaded"
  else res=ok; msg="Everything is up to date"; fi
  [ "$C_WHEN" = shutdown ] && [ "$trigger" != now ] && [ -n "${DOWNLOADED# }" ] && msg="$msg - installed at the next shutdown"
  if [ "$C_WHEN" = shutdown ] && [ "$trigger" != now ]; then :; else notify_result; fi
  status "$res" "$msg" "$trigger"
  log "=== done: $msg"
}

cmd_shutdown() {
  need_root shutdown
  # only during a real shutdown/reboot, not when someone stops the unit by hand
  case "$(systemctl is-system-running 2>/dev/null)" in stopping) ;; *) exit 0 ;; esac
  load
  [ "$C_MODE" = manual ] && [ "$C_WHEN" = shutdown ] || exit 0
  [ -s "$PENDING" ] || exit 0
  [ "$C_PAUSED_UNTIL" -gt "$(now)" ] && exit 0
  [ "$C_AC" = 1 ] && ! on_ac && { log "shutdown: on battery - updates stay for the next shutdown"; exit 0; }
  exec 9>/run/phoenixge-autoupdate.lock; flock -w 60 9 || exit 0
  log "=== installing downloaded updates at shutdown"
  apt_env; FAILED=0
  # packages must not (re)start services while the system goes down - they start normally at the next boot
  POL=/usr/sbin/policy-rc.d
  if [ ! -e "$POL" ]; then printf '#!/bin/sh\nexit 101\n' > "$POL"; chmod 755 "$POL"; trap 'rm -f "$POL"' EXIT; fi
  CLASSES=$(cat "$PENDING")
  do_class security "$C_SECURITY" --no-download
  do_class phoenixge "$C_PHOENIXGE" --no-download
  do_class system "$C_SYSTEM" --no-download
  [ -n "${INSTALLED# }" ] && kernel_cleanup
  flatpak_system deploy
  rm -f "$PENDING"
  [ "$FAILED" = 0 ] && now > "$STAMP"
  status ok "$(echo $INSTALLED | wc -w) installed at shutdown" shutdown
  log "=== shutdown install done"
}

# ------------------------------------------------------------------ user Flatpak apps (runs as the user)
cmd_user_flatpak() {
  trigger=${1:---timer}; trigger=${trigger#--}
  [ "$(id -u)" = 0 ] && { echo "run as the user" >&2; exit 1; }
  [ -d /run/live ] && exit 0
  command -v flatpak >/dev/null 2>&1 || exit 0
  load
  S=${XDG_STATE_HOME:-$HOME/.local/state}/phoenixge; mkdir -p "$S"
  ULOG=$S/autoupdate-user.log; USTAMP=$S/flatpak-autoupdate.last-ok; UST=$S/autoupdate-user.json
  ulog() { echo "$*"; echo "$(date '+%F %T') $*" >> "$ULOG"; }
  ustatus() { printf '{"time": %s, "result": "%s", "message": "%s"}\n' "$(now)" "$1" "$2" > "$UST"; }
  [ "$C_FLATPAK" = off ] && [ "$trigger" != now ] && exit 0
  flatpak --user list --columns=ref 2>/dev/null | grep -q . || { ustatus ok "No Flatpak apps installed for this user"; exit 0; }
  if [ "$(wc -c < "$ULOG" 2>/dev/null || echo 0)" -gt 262144 ]; then tail -n 500 "$ULOG" > "$ULOG.tmp" && mv "$ULOG.tmp" "$ULOG"; fi
  RT=${XDG_RUNTIME_DIR:-/run/user/$(id -u)}/phoenixge; mkdir -p "$RT"
  # WHEN=shutdown: what was downloaded is put in place at the first check after login (apps aren't running yet)
  if [ "$trigger" != now ] && [ "$C_WHEN" = shutdown ] && [ -f "$S/flatpak-pending" ] && [ ! -f "$RT/flatpak-login-done" ]; then
    ulog "installing downloaded Flatpak updates (login)"
    flatpak update --user -y --noninteractive --no-pull >> "$ULOG" 2>&1 && rm -f "$S/flatpak-pending"
  fi
  touch "$RT/flatpak-login-done"
  if [ "$trigger" != now ]; then
    [ "$C_PAUSED_UNTIL" -gt "$(now)" ] && { ustatus paused "Paused"; exit 0; }
    due "$USTAMP" || exit 0
    in_window || exit 0
    if r=$(blocked); then ulog "postponed: $r"; ustatus postponed "Postponed: $r"; exit 0; fi
  fi
  n=$(flatpak remote-ls --user --updates --columns=application 2>/dev/null | grep -c .)
  pol=$C_FLATPAK; [ "$trigger" = now ] && pol=install
  [ "$C_WHEN" = shutdown ] && [ "$trigger" != now ] && [ "$pol" = install ] && pol=download-login
  if [ "$n" -eq 0 ]; then ulog "Flatpak apps are up to date"; now > "$USTAMP"; ustatus ok "Up to date"; exit 0; fi
  case "$pol" in
    install)
      ulog "updating $n Flatpak app(s)"
      if flatpak update --user -y --noninteractive >> "$ULOG" 2>&1; then
        now > "$USTAMP"; ustatus ok "$n app(s) updated"
        [ "$trigger" = now ] || notify "Apps updated" "$n Flatpak app(s) were updated in the background."
      else ustatus failed "Flatpak update failed"; ulog "failed"; fi ;;
    download|download-login)
      ulog "downloading $n Flatpak app update(s)"
      if flatpak update --user -y --noninteractive --no-deploy >> "$ULOG" 2>&1; then
        now > "$USTAMP"
        if [ "$pol" = download-login ]; then touch "$S/flatpak-pending"; ustatus ok "$n app update(s) downloaded - installed at the next login"
        else
          ustatus ok "$n app update(s) downloaded"
          notify "App updates ready" "$n Flatpak app update(s) are downloaded. Install them in Discover > Updates."
        fi
      else ustatus failed "Flatpak download failed"; fi ;;
  esac
}

# ------------------------------------------------------------------ main
case "${1:-}" in
  run) shift; cmd_run "$@" ;;
  shutdown) cmd_shutdown ;;
  user-flatpak) shift; cmd_user_flatpak "$@" ;;
  config) for k in $KEYS; do echo "$k=$(conf "$k")"; done ;;
  set)
    need_root set; shift
    for a in "$@"; do
      k=${a%%=*}; v=${a#*=}
      case " $KEYS " in *" $k "*) ;; *) echo "unknown setting: $k" >&2; exit 2 ;; esac
      valid "$k" "$v" || { echo "invalid value for $k: $v" >&2; exit 2; }
    done
    write_conf "$@"; log "settings changed: $*" ;;
  pause)
    need_root pause
    case "${2:-}" in ''|*[!0-9]*) echo "usage: $0 pause SECONDS" >&2; exit 2 ;; esac
    u=$(($(now) + $2)); write_conf "PAUSED_UNTIL=$u"
    log "updates paused until $(date -d "@$u" '+%F %H:%M')" ;;
  resume)
    need_root resume
    write_conf PAUSED_UNTIL=0; log "updates resumed - the next check runs within an hour" ;;
  *) sed -n '2,20p' "$0"; exit 2 ;;
esac
