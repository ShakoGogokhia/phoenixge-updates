#!/bin/sh
# PhoenixGe Sound & camera - root helper (run with pkexec from PhoenixGe Center).
#   camera-driver   install v4l2loopback (DKMS) + kernel headers, configure 2 virtual cameras, load the module
#   camera-reload   reload the module with our options (fails if a camera is in use)
#   phone-tools     install scrcpy (Debian backports, contrib) + adb
# Virtual cameras: /dev/video40 "PhoenixGe Camera" (background blur output), /dev/video41 "PhoenixGe Phone Camera".
set -u
PATH=/usr/sbin:/usr/bin:/sbin:/bin
MODCONF=/etc/modprobe.d/phoenixge-v4l2loopback.conf
LOADCONF=/etc/modules-load.d/phoenixge-v4l2loopback.conf
[ "$(id -u)" = 0 ] || { echo "needs root"; exit 1; }

write_conf() {
  cat > "$MODCONF" <<'EOF'
# PhoenixGe virtual cameras (Center > Sound & camera). exclusive_caps=1: Chrome/Discord/Zoom only list them while
# something is sending video, which is what they need to work at all.
options v4l2loopback devices=2 video_nr=40,41 card_label="PhoenixGe Camera","PhoenixGe Phone Camera" exclusive_caps=1,1 max_buffers=2
EOF
  echo v4l2loopback > "$LOADCONF"
}

load_module() {
  if [ -e /dev/video40 ] && [ -e /dev/video41 ]; then echo "Virtual cameras are ready."; return 0; fi
  modprobe -r v4l2loopback 2>/dev/null
  if modprobe v4l2loopback; then
    echo "Virtual cameras are ready: PhoenixGe Camera (/dev/video40), PhoenixGe Phone Camera (/dev/video41)."
    return 0
  fi
  if command -v mokutil >/dev/null 2>&1 && mokutil --sb-state 2>/dev/null | grep -qi enabled; then
    echo "Secure Boot is on and the camera driver is not signed with an enrolled key."
    echo "Either turn Secure Boot off in the firmware setup, or enroll the DKMS key: sudo mokutil --import /var/lib/dkms/mok.pub"
    echo "(choose a one-time password, reboot, pick 'Enroll MOK' in the blue screen)."
  fi
  return 1
}

case "${1:-}" in
  camera-driver)
    export DEBIAN_FRONTEND=noninteractive
    apt-get update
    KV=$(uname -r)
    HDR="linux-headers-$KV"
    apt-cache show "$HDR" >/dev/null 2>&1 || HDR=linux-headers-amd64
    BPO=""
    case "$KV" in *bpo*) BPO="-t $(. /etc/os-release; echo "$VERSION_CODENAME")-backports" ;; esac
    # shellcheck disable=SC2086
    apt-get install -y $BPO "$HDR" || echo "Kernel headers for $KV not found - the driver may not build."
    apt-get install -y v4l2loopback-dkms v4l2loopback-utils v4l-utils || exit 1
    write_conf
    load_module ;;
  camera-reload)
    write_conf
    modprobe -r v4l2loopback || { echo "A virtual camera is in use - stop the phone camera / blur camera first."; exit 1; }
    load_module ;;
  phone-tools)
    sh /usr/lib/phoenixge/apt-install.sh -b scrcpy adb ;;
  *)
    echo "usage: $0 camera-driver|camera-reload|phone-tools"; exit 2 ;;
esac
