#!/usr/bin/env python3
"""Game auto-profile: called by GameMode (see /etc/gamemode.ini [custom] start=/end=) as the logged-in user.

    session.py start    remember the current state, then: performance power profile, Do Not Disturb,
                        pause updates, keep the auto day/night theme, (X11 only, opt-in) suspend compositing
    session.py end      put back exactly what start changed (nothing else)
    session.py status   print the saved state

Every part can be switched off in ~/.config/phoenixge/gaming.conf (settings.py). The state lives in
$XDG_RUNTIME_DIR/phoenixge/gaming-session.json (tmpfs, gone after logout). GameMode kills these scripts after
script_timeout seconds, so everything here is quick or runs in the background.
"""
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import settings  # noqa: E402

HERE = Path(__file__).resolve().parent
RUNTIME = Path(os.environ.get("XDG_RUNTIME_DIR") or f"/run/user/{os.getuid()}") / "phoenixge"
STATE = RUNTIME / "gaming-session.json"
PAUSE_HELPER = "/usr/lib/phoenixge/gaming/updates-pause.sh"
USER_TIMERS = re.compile(r"(flatpak|update|upgrade|phoenixge-autotheme|discover|packagekit)[\w.@-]*\.timer$", re.I)


def run(cmd, timeout=6):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return 1, ""


def log(*a):
    print("phoenixge-gaming:", *a, file=sys.stderr)


def save(state):
    RUNTIME.mkdir(parents=True, exist_ok=True)
    tmp = STATE.with_suffix(".tmp")
    tmp.write_text(json.dumps(state))
    tmp.replace(STATE)


# ------------------------------------------------------------------ parts
def power_on(state):
    if not shutil.which("powerprofilesctl"):
        return
    code, prev = run(["powerprofilesctl", "get"])
    if code != 0 or not prev or prev == "performance":
        return
    code, _ = run(["powerprofilesctl", "set", "performance"])
    if code == 0:
        state["power_profile"] = prev
    else:
        log("performance profile not available on this hardware")


def power_off(state):
    prev = state.get("power_profile")
    if prev:
        run(["powerprofilesctl", "set", prev])


def dnd_on(state):
    try:
        p = subprocess.Popen([sys.executable, str(HERE / "dnd_hold.py")], stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        state["dnd_pid"] = p.pid
    except OSError as e:
        log("do not disturb:", e)


def dnd_off(state):
    pid = state.get("dnd_pid")
    if not pid:
        return
    try:
        if "dnd_hold.py" in Path(f"/proc/{pid}/cmdline").read_bytes().decode(errors="replace"):
            os.kill(pid, 15)
    except (OSError, ValueError):
        pass


def user_timers_on(state, conf):
    code, out = run(["systemctl", "--user", "list-units", "--type=timer", "--state=active", "--plain", "--no-legend"])
    stopped = []
    for line in out.splitlines() if code == 0 else []:
        unit = line.split()[0] if line.split() else ""
        if not USER_TIMERS.search(unit):
            continue
        if "autotheme" in unit and not conf["pause_autotheme"]:
            continue
        if "autotheme" not in unit and not conf["pause_updates"]:
            continue
        if run(["systemctl", "--user", "stop", unit])[0] == 0:
            stopped.append(unit)
    if stopped:
        state["user_timers"] = stopped


def user_timers_off(state):
    for unit in state.get("user_timers", []):
        run(["systemctl", "--user", "start", unit])


def system_pause_on(state):
    if not (shutil.which("pkexec") and os.path.exists(PAUSE_HELPER)):
        return
    code, _ = run(["pkexec", PAUSE_HELPER, "pause"], timeout=12)
    if code == 0:
        state["system_paused"] = True
    else:
        log("could not pause system updates (polkit)")


def system_pause_off(state):
    if state.get("system_paused"):
        run(["pkexec", PAUSE_HELPER, "resume"], timeout=12)


def kwin_compositing_active():
    code, out = run(["busctl", "--user", "get-property", "org.kde.KWin", "/Compositor", "org.kde.kwin.Compositing",
                     "active"])
    return code == 0 and out.strip().endswith("true")


def toggle_compositing():
    return run(["busctl", "--user", "call", "org.kde.kglobalaccel", "/component/kwin", "org.kde.kglobalaccel.Component",
                "invokeShortcut", "s", "Suspend Compositing"])[0] == 0


def compositor_on(state):
    # Wayland: KWin *is* the display server, compositing cannot be suspended (and games get direct scan-out anyway)
    if os.environ.get("XDG_SESSION_TYPE") != "x11":
        return
    if kwin_compositing_active() and toggle_compositing():
        state["compositor_suspended"] = True


def compositor_off(state):
    if state.get("compositor_suspended") and not kwin_compositing_active():
        toggle_compositing()


# ------------------------------------------------------------------ entry points
def start():
    if STATE.exists():
        return 0  # already in a game session; keep the state from *before* the first game
    conf = settings.load()
    state = {"started": time.time()}
    save(state)
    if conf["power_profile"]:
        power_on(state)
    if conf["do_not_disturb"]:
        dnd_on(state)
    save(state)
    if conf["pause_updates"] or conf["pause_autotheme"]:
        user_timers_on(state, conf)
    if conf["suspend_compositor"]:
        compositor_on(state)
    save(state)
    if conf["pause_updates"]:
        system_pause_on(state)
    save(state)
    return 0


def end():
    try:
        state = json.loads(STATE.read_text())
    except (OSError, ValueError):
        return 0
    for fn in (compositor_off, system_pause_off, user_timers_off, dnd_off, power_off):
        try:
            fn(state)
        except Exception as e:  # noqa: BLE001 - always try to restore the rest
            log(fn.__name__, e)
    STATE.unlink(missing_ok=True)
    return 0


def main(argv):
    cmd = argv[1] if len(argv) > 1 else ""
    if cmd == "start":
        return start()
    if cmd == "end":
        return end()
    if cmd == "status":
        print(STATE.read_text() if STATE.exists() else "no game session")
        return 0
    print("usage: session.py start|end|status", file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
