#!/bin/sh
# PhoenixGe: on the INSTALLED system, detect an NVIDIA GPU and install the proprietary driver once.
# RTX 20xx and newer (Turing+) -> open kernel modules (recommended by NVIDIA); older -> classic DKMS module.
# Needs internet; on failure the service retries (e.g. Wi-Fi only comes up after the user logs in).
set -e
[ -d /run/live ] && { echo "Live session: the NVIDIA driver is installed on the installed system, not here."; exit 0; }
STAMP=/var/lib/phoenixge/nvidia.done
[ -f "$STAMP" ] && { echo "NVIDIA setup already done ($STAMP). Restart the computer if the driver is not running yet."; exit 0; }
mkdir -p /var/lib/phoenixge
# PCI class 03xx (display), vendor 10de (NVIDIA)
if ! lspci -n | awk '$2 ~ /^03/ && $3 ~ /^10de:/ {found=1} END {exit !found}'; then
  echo "No NVIDIA graphics card found."; touch "$STAMP"; exit 0
fi
# The driver lives in contrib/non-free; older PhoenixGe installs only had "main non-free-firmware".
fix_components() {
  for f in /etc/apt/sources.list /etc/apt/sources.list.d/*.list; do
    [ -f "$f" ] || continue
    sed -i -E '/^deb(-src)? .*debian/ { / contrib/! s/ main( |$)/ main contrib\1/; / non-free( |$)/! s/ contrib( |$)/ contrib non-free\1/ }' "$f"
  done
  for f in /etc/apt/sources.list.d/*.sources; do
    [ -f "$f" ] || continue
    sed -i -E '/^Components:/ { / contrib/! s/ main/ main contrib/; / non-free( |$)/! s/ contrib/ contrib non-free/ }' "$f"
  done
}
fix_components
MODEL=$(lspci | grep -iE 'vga|3d|display' | grep -i nvidia | head -1)
if echo "$MODEL" | grep -qiE 'RTX|GTX 16|A[0-9]{3,4}|L[0-9]{2}'; then
  KMOD=nvidia-open-kernel-dkms
else
  KMOD=nvidia-kernel-dkms
fi
export DEBIAN_FRONTEND=noninteractive
# wait for internet (up to ~2 min), otherwise fail and let systemd retry later
i=0; until getent hosts deb.debian.org >/dev/null 2>&1; do i=$((i+1)); [ $i -ge 24 ] && { echo "No internet connection - try again later."; exit 1; }; sleep 5; done
apt-get update
apt-get install -y "linux-headers-$(uname -r)" linux-headers-amd64 "$KMOD" nvidia-driver firmware-nvidia-gsp nvidia-settings libcuda1 libnvidia-ml1
touch "$STAMP" /var/lib/phoenixge/nvidia-reboot-needed
echo "NVIDIA driver installed - restart the computer to use it."
