"""PhoenixGe Overlay - data sources. Pure Python (no Qt), every function degrades to None / [] when a tool is missing.

    game_session()        -> {"name", "start", "pid"} of the game phoenix-game-run is watching (or a GameMode session)
    PerfSampler.sample()  -> live FPS/frametime (MangoHud CSV that is still being written) + CPU/GPU/RAM/VRAM
    audio_master() / audio_streams() / set_master_volume() / set_stream_volume() / set_*_mute()   (pactl)
    media_player()        -> now playing via playerctl, fallback MPRIS over D-Bus (python3-dbus)
    replay_status() / replay_save() / replay_start() / screenshot()                          (capture)
    discord_status()      -> {"running", "flatpak", "presence"}
    power_profiles() / set_power_profile()                                                   (powerprofilesctl)
"""
import glob
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

sys.path.insert(0, "/usr/lib/phoenixge/gaming")
try:
    import perf  # MangoHud CSV parser + log locations (PERF_ROOT)
except Exception:  # noqa: BLE001
    perf = None
try:
    import settings as gsettings
except Exception:  # noqa: BLE001
    gsettings = None

HOME = Path.home()
RUNTIME = Path(os.environ.get("XDG_RUNTIME_DIR") or f"/run/user/{os.getuid()}")
PERF_ROOT = perf.PERF_ROOT if perf else HOME / ".local/share/phoenixge/perf"
SHOTS = Path(os.environ.get("XDG_PICTURES_DIR") or HOME / "Pictures") / "Screenshots"
REPLAYS = Path(os.environ.get("XDG_VIDEOS_DIR") or HOME / "Videos") / "Replays"
GSR_FLATPAK = "com.dec05eba.gpu_screen_recorder"


def run(cmd, timeout=3):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout
    except (OSError, subprocess.SubprocessError):
        return 1, ""


def spawn(cmd):
    try:
        subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)
        return True
    except OSError:
        return False


def processes():
    """[(pid, argv)] of every process we can read."""
    out = []
    for d in os.listdir("/proc"):
        if not d.isdigit():
            continue
        try:
            with open(f"/proc/{d}/cmdline", "rb") as f:
                raw = f.read()
        except OSError:
            continue
        if raw:
            out.append((int(d), [a.decode(errors="replace") for a in raw.rstrip(b"\0").split(b"\0")]))
    return out


def proc_start(pid):
    """Process start time (epoch seconds)."""
    try:
        with open(f"/proc/{pid}/stat") as f:
            ticks = int(f.read().rsplit(")", 1)[1].split()[19])
        with open("/proc/stat") as f:
            btime = next(int(l.split()[1]) for l in f if l.startswith("btime"))
        return btime + ticks / os.sysconf("SC_CLK_TCK")
    except (OSError, ValueError, IndexError, StopIteration):
        return None


# ------------------------------------------------------------------ current game
def game_session():
    """The game phoenix-game-run is watching right now: its --name (or GAME_ID) and when it started."""
    best = None
    for pid, argv in processes():
        if not any(a.endswith(("phoenix-game-run", "gamerun.py")) for a in argv[:3]):
            continue
        i = next((k for k, a in enumerate(argv) if a.endswith(("phoenix-game-run", "gamerun.py"))), 0) + 1
        name, gid = None, None
        while i < len(argv):
            a = argv[i]
            if a == "--":
                break
            if a in ("--name", "--match", "--wait") and i + 1 < len(argv):
                if a == "--name":
                    name = argv[i + 1]
                i += 2
                continue
            if a.startswith("--name="):
                name = a.split("=", 1)[1]
            elif not a.startswith("-") and gid is None:
                gid = a
            i += 1
        start = proc_start(pid) or time.time()
        if best is None or start > best["start"]:
            best = {"name": name or gid or "Game", "id": gid, "start": start, "pid": pid}
    if best:
        return best
    # game started outside Phoenix Games but registered with GameMode (session.py writes this)
    try:
        st = json.loads((RUNTIME / "phoenixge/gaming-session.json").read_text())
        return {"name": None, "id": None, "start": float(st.get("started", time.time())), "pid": None}
    except (OSError, ValueError):
        return None


# ------------------------------------------------------------------ performance
class LiveLog:
    """Tails the newest MangoHud CSV under ~/.local/share/phoenixge/perf/** while it is still growing."""

    FRESH = 6.0   # seconds since the last write for the log to count as "live"

    def __init__(self):
        self.path, self.columns, self.pos, self.rows, self.next_scan = None, None, 0, [], 0.0
        self.partial = ""

    def _find(self):
        newest, mt = None, 0.0
        for p in glob.glob(str(PERF_ROOT / "**" / "*.csv"), recursive=True):
            if p.endswith("_summary.csv"):
                continue
            try:
                m = os.stat(p).st_mtime
            except OSError:
                continue
            if m > mt:
                newest, mt = p, m
        return newest if newest and time.time() - mt < self.FRESH else None

    def _header(self, path):
        try:
            with open(path, encoding="utf-8", errors="replace") as f:
                for _ in range(8):
                    line = f.readline()
                    if not line:
                        break
                    if line.startswith("fps,"):
                        return [c.strip() for c in line.split(",")]
        except OSError:
            pass
        return None

    def poll(self):
        """New rows since the last call (dicts column -> float). [] when no live log."""
        now = time.time()
        if self.path is None or now >= self.next_scan:
            self.next_scan = now + 3
            p = self._find()
            if p != self.path:
                self.path, self.columns, self.rows, self.partial = p, None, [], ""
                try:  # start near the end: only the last ~2 s matter
                    self.pos = max(0, os.path.getsize(p) - 4096) if p else 0
                except OSError:
                    self.pos = 0
        if not self.path:
            return []
        if self.columns is None:
            self.columns = self._header(self.path)
            if not self.columns:
                return []
        try:
            with open(self.path, encoding="utf-8", errors="replace") as f:
                f.seek(self.pos)
                data = f.read()
                self.pos = f.tell()
        except OSError:
            self.path = None
            return []
        data = self.partial + data
        lines = data.split("\n")
        self.partial = lines.pop()  # incomplete last line
        new = []
        for line in lines:
            fields = line.strip().split(",")
            if len(fields) != len(self.columns):
                continue
            try:
                row = {k: float(v) for k, v in zip(self.columns, fields) if v not in ("", "nan")}
            except ValueError:
                continue
            if row.get("fps", 0) > 0:
                new.append(row)
        return new


class PerfSampler:
    """Call sample() about once a second (from a worker thread: nvidia-smi / sensors take 50-150 ms)."""

    def __init__(self):
        self.log = LiveLog()
        self.prev_cpu = None
        self.has_nvsmi = bool(shutil.which("nvidia-smi"))
        self.has_sensors = bool(shutil.which("sensors"))

    def cpu_load(self):
        try:
            with open("/proc/stat") as f:
                v = [int(x) for x in f.readline().split()[1:]]
        except (OSError, ValueError):
            return None
        idle, total = v[3] + (v[4] if len(v) > 4 else 0), sum(v[:8])
        prev, self.prev_cpu = self.prev_cpu, (idle, total)
        if not prev or total == prev[1]:
            return None
        return 100.0 * (1 - (idle - prev[0]) / (total - prev[1]))

    @staticmethod
    def ram():
        try:
            m = {}
            with open("/proc/meminfo") as f:
                for line in f:
                    k, v = line.split(":", 1)
                    m[k] = int(v.split()[0])
            return (m["MemTotal"] - m["MemAvailable"]) / 1048576, m["MemTotal"] / 1048576
        except (OSError, KeyError, ValueError):
            return None, None

    def cpu_temp(self):
        if self.has_sensors:
            code, out = run(["sensors", "-j"], 2)
            try:
                data = json.loads(out) if code == 0 else {}
            except ValueError:
                data = {}
            for chip, vals in data.items():
                if not chip.startswith(("k10temp", "coretemp", "zenpower", "cpu_thermal")):
                    continue
                for label in ("Tctl", "Tdie", "Package id 0"):
                    for k, v in vals.get(label, {}).items() if isinstance(vals.get(label), dict) else []:
                        if k.endswith("_input"):
                            return float(v)
        for z in sorted(glob.glob("/sys/class/thermal/thermal_zone*")):
            try:
                if Path(z, "type").read_text().strip() in ("x86_pkg_temp", "cpu-thermal", "acpitz"):
                    return int(Path(z, "temp").read_text()) / 1000
            except (OSError, ValueError):
                pass
        return None

    def gpu(self):
        """{"name", "load", "temp", "vram_used", "vram_total"} (GiB) from nvidia-smi or amdgpu sysfs."""
        if self.has_nvsmi:
            code, out = run(["nvidia-smi", "--query-gpu=name,utilization.gpu,temperature.gpu,memory.used,memory.total",
                             "--format=csv,noheader,nounits"], 3)
            if code == 0 and out.strip():
                f = [x.strip() for x in out.strip().splitlines()[0].split(",")]
                try:
                    return {"name": f[0].replace("NVIDIA GeForce ", ""), "load": float(f[1]), "temp": float(f[2]),
                            "vram_used": float(f[3]) / 1024, "vram_total": float(f[4]) / 1024}
                except (ValueError, IndexError):
                    pass
        for dev in sorted(glob.glob("/sys/class/drm/card[0-9]/device")):
            busy = Path(dev, "gpu_busy_percent")
            if not busy.exists():
                continue
            g = {"name": "AMD GPU" if Path(dev, "mem_info_vram_total").exists() else "GPU"}
            try:
                g["load"] = float(busy.read_text())
                g["vram_used"] = int(Path(dev, "mem_info_vram_used").read_text()) / 2 ** 30
                g["vram_total"] = int(Path(dev, "mem_info_vram_total").read_text()) / 2 ** 30
            except (OSError, ValueError):
                pass
            for t in glob.glob(f"{dev}/hwmon/hwmon*/temp1_input"):
                try:
                    g["temp"] = int(Path(t).read_text()) / 1000
                except (OSError, ValueError):
                    pass
            return g
        return None

    def sample(self):
        rows = self.log.poll()
        s = {"live": bool(self.log.path), "frames": rows, "cpu_load": self.cpu_load(), "cpu_temp": None, "gpu": None}
        s["ram_used"], s["ram_total"] = self.ram()
        last = rows[-1] if rows else {}
        # MangoHud already measures temps/load: only ask the sensors when the log does not have them
        if last.get("cpu_temp"):
            s["cpu_temp"] = last["cpu_temp"]
        else:
            s["cpu_temp"] = self.cpu_temp()
        g = self.gpu() or {}
        for k_log, k in (("gpu_load", "load"), ("gpu_temp", "temp")):
            if last.get(k_log):
                g[k] = last[k_log]
        if last.get("gpu_vram_used"):
            g["vram_used"] = last["gpu_vram_used"]
        s["gpu"] = g or None
        return s


# ------------------------------------------------------------------ audio (pactl, works with PipeWire's pulse server)
def _pactl_json(*args):
    code, out = run(["pactl", "-f", "json", *args], 3)
    try:
        return json.loads(out) if code == 0 and out.strip() else None
    except ValueError:
        return None


def _vol_pct(volume):
    try:
        vals = [int(str(c.get("value_percent", "0")).rstrip("%")) for c in volume.values()]
        return round(sum(vals) / len(vals)) if vals else 0
    except (AttributeError, ValueError):
        return 0


def audio_master():
    if not shutil.which("pactl"):
        return None
    sink = run(["pactl", "get-default-sink"])[1].strip()
    for s in _pactl_json("list", "sinks") or []:
        if s.get("name") == sink:
            return {"name": s.get("description") or sink, "volume": _vol_pct(s.get("volume", {})),
                    "muted": bool(s.get("mute"))}
    code, out = run(["pactl", "get-sink-volume", "@DEFAULT_SINK@"])
    m = re.search(r"(\d+)%", out)
    if code != 0 or not m:
        return {"unavailable": True}
    muted = "yes" in run(["pactl", "get-sink-mute", "@DEFAULT_SINK@"])[1]
    return {"name": "Speakers", "volume": int(m[1]), "muted": muted}


def audio_streams():
    """One entry per application (several streams of one app are merged): {"app", "icon", "ids", "volume", "muted"}."""
    apps = {}
    for s in _pactl_json("list", "sink-inputs") or []:
        p = s.get("properties", {})
        if p.get("media.role") in ("event", "filter") or p.get("application.id") == "org.PulseAudio.pavucontrol":
            continue
        app = (p.get("application.name") or p.get("application.process.binary") or p.get("media.name") or "App").strip()
        if app.lower() in ("wine64-preloader", "wine-preloader", "wine64", "wine"):
            app = p.get("application.process.binary", app)
        key = app.lower()
        e = apps.setdefault(key, {"app": app, "icon": p.get("application.icon_name") or p.get("application.process.binary"),
                                  "ids": [], "volume": 0, "muted": True,
                                  "binary": p.get("application.process.binary", "")})
        e["ids"].append(s.get("index"))
        e["volume"] = max(e["volume"], _vol_pct(s.get("volume", {})))
        e["muted"] = e["muted"] and bool(s.get("mute"))
    return list(apps.values())


def set_master_volume(pct):
    return spawn(["pactl", "set-sink-volume", "@DEFAULT_SINK@", f"{int(pct)}%"])


def set_master_mute(muted):
    return spawn(["pactl", "set-sink-mute", "@DEFAULT_SINK@", "1" if muted else "0"])


def set_stream_volume(ids, pct):
    for i in ids:
        spawn(["pactl", "set-sink-input-volume", str(i), f"{int(pct)}%"])


def set_stream_mute(ids, muted):
    for i in ids:
        spawn(["pactl", "set-sink-input-mute", str(i), "1" if muted else "0"])


# ------------------------------------------------------------------ media (MPRIS via playerctl)
PCTL_FMT = "{{playerName}}\t{{status}}\t{{xesam:title}}\t{{xesam:artist}}\t{{mpris:artUrl}}\t{{mpris:length}}\t{{position}}"


def _media_dbus():
    """Fallback without playerctl: MPRIS over D-Bus with dbus-python (python3-dbus)."""
    try:
        import dbus
        bus = dbus.SessionBus()
    except Exception:  # noqa: BLE001
        return None
    best = None
    for name in bus.list_names():
        if not str(name).startswith("org.mpris.MediaPlayer2."):
            continue
        try:
            props = dbus.Interface(bus.get_object(name, "/org/mpris/MediaPlayer2"), "org.freedesktop.DBus.Properties")
            md = props.Get("org.mpris.MediaPlayer2.Player", "Metadata")
            status = str(props.Get("org.mpris.MediaPlayer2.Player", "PlaybackStatus"))
            try:
                pos = int(props.Get("org.mpris.MediaPlayer2.Player", "Position")) / 1e6
            except Exception:  # noqa: BLE001 - not every player reports a position
                pos = 0
        except Exception:  # noqa: BLE001
            continue
        artist = md.get("xesam:artist", [])
        e = {"player": str(name)[len("org.mpris.MediaPlayer2."):], "status": status,
             "title": str(md.get("xesam:title", "")), "artist": ", ".join(str(a) for a in artist),
             "art": str(md.get("mpris:artUrl", "")), "length": int(md.get("mpris:length", 0)) / 1e6, "pos": pos,
             "bus": str(name)}
        if not (e["title"] or e["artist"]):
            continue
        if best is None or (status == "Playing" and best["status"] != "Playing"):
            best = e
    return best


def media_player():
    """Now playing of the most relevant player (Playing beats Paused). None = no player."""
    if not shutil.which("playerctl"):
        return _media_dbus()
    code, out = run(["playerctl", "-a", "metadata", "--format", PCTL_FMT], 3)
    best = None
    for line in out.splitlines() if code == 0 else []:
        f = line.split("\t")
        if len(f) < 7 or not (f[2] or f[3]):
            continue
        try:
            length, pos = int(f[5] or 0) / 1e6, int(f[6] or 0) / 1e6
        except ValueError:
            length = pos = 0
        e = {"player": f[0], "status": f[1], "title": f[2], "artist": f[3], "art": f[4], "length": length, "pos": pos}
        if best is None or (e["status"] == "Playing" and best["status"] != "Playing"):
            best = e
    return best


def media_command(player, cmd):  # cmd: previous | play-pause | next
    if shutil.which("playerctl"):
        return spawn(["playerctl", "-p", player, cmd] if player else ["playerctl", cmd])
    method = {"previous": "Previous", "play-pause": "PlayPause", "next": "Next"}[cmd]
    try:
        import dbus
        obj = dbus.SessionBus().get_object(f"org.mpris.MediaPlayer2.{player}", "/org/mpris/MediaPlayer2")
        getattr(dbus.Interface(obj, "org.mpris.MediaPlayer2.Player"), method)()
        return True
    except Exception:  # noqa: BLE001
        return False


# ------------------------------------------------------------------ capture
def _game_tag(game):
    name = (game or {}).get("name") or "Desktop"
    return re.sub(r"[^A-Za-z0-9._-]+", "-", name).strip("-")[:40] or "Desktop"


def screenshot(game):
    """Full-screen shot with Spectacle (call it after the overlay is hidden). Returns the path or None."""
    if not shutil.which("spectacle"):
        return None
    SHOTS.mkdir(parents=True, exist_ok=True)
    path = SHOTS / f"{_game_tag(game)}-{datetime.now():%Y-%m-%d_%H-%M-%S}.png"
    return str(path) if spawn(["spectacle", "-b", "-n", "-f", "-o", str(path)]) else None


def replay_procs():
    """GPU Screen Recorder processes in replay mode (-r <seconds>). Flatpak processes are visible from the host."""
    out = []
    for pid, argv in processes():
        if not argv or os.path.basename(argv[0]) != "gpu-screen-recorder" or "-r" not in argv:
            continue
        out.append((pid, argv))
    return out


def replay_status():
    """{"installed", "running", "seconds", "folder"}"""
    procs = replay_procs()
    st = {"installed": bool(shutil.which("gpu-screen-recorder")) or flatpak_installed(GSR_FLATPAK),
          "running": bool(procs), "seconds": None, "folder": str(REPLAYS)}
    if procs:
        argv = procs[0][1]
        for flag, key in (("-r", "seconds"), ("-o", "folder")):
            if flag in argv and argv.index(flag) + 1 < len(argv):
                st[key] = argv[argv.index(flag) + 1]
    return st


def replay_save():
    """SIGUSR1 = save the replay buffer to the -o folder (GPU Screen Recorder's documented interface)."""
    ok = False
    for pid, _ in replay_procs():
        try:
            os.kill(pid, signal.SIGUSR1)
            ok = True
        except OSError:
            pass
    return ok


def replay_start(seconds=30):
    """Start a replay buffer: whole screen through the desktop portal (KDE asks once, then the choice is restored),
    60 fps, default output + mic off, saved to ~/Videos/Replays."""
    REPLAYS.mkdir(parents=True, exist_ok=True)
    args = ["-w", "portal", "-restore-portal-session", "yes", "-f", "60", "-r", str(seconds), "-c", "mp4",
            "-a", "default_output", "-o", str(REPLAYS)]
    if shutil.which("gpu-screen-recorder"):
        return spawn(["gpu-screen-recorder", *args])
    if flatpak_installed(GSR_FLATPAK):
        return spawn(["flatpak", "run", "--command=gpu-screen-recorder", GSR_FLATPAK, *args])
    return False


_fp_cache = {}


def flatpak_installed(app):
    if app not in _fp_cache:
        _fp_cache[app] = any(Path(b, app).is_dir() for b in ("/var/lib/flatpak/app", HOME / ".local/share/flatpak/app"))
    return _fp_cache[app]


def open_path(path):
    Path(path).mkdir(parents=True, exist_ok=True)
    return spawn(["xdg-open", str(path)])


# ------------------------------------------------------------------ Discord
DISCORD_BINS = {"Discord", "discord", "DiscordCanary", "vesktop", "Vesktop", "webcord"}


def discord_status(game=None):
    running, flat = False, False
    for _, argv in processes():
        b = os.path.basename(argv[0]) if argv else ""
        if b in DISCORD_BINS or (b == "bwrap" and any("com.discordapp.Discord" in a for a in argv)):
            running = True
            flat = flat or any("com.discordapp" in a for a in argv)
    conf = gsettings.load() if gsettings else {}
    try:
        import discord_rpc
        has_id = bool(conf.get("discord_client_id") or discord_rpc.CLIENT_ID)
    except Exception:  # noqa: BLE001
        has_id = False
    presence = None
    if running and game and game.get("name") and game.get("pid") and conf.get("discord", True) and has_id:
        presence = f"Playing {game['name']}"
    return {"running": running, "flatpak": flat, "presence": presence, "rpc_configured": has_id}


def discord_raise(flatpak=False):
    if flatpak or (not shutil.which("discord") and flatpak_installed("com.discordapp.Discord")):
        return spawn(["flatpak", "run", "com.discordapp.Discord"])
    return spawn(["discord"]) if shutil.which("discord") else False


# ------------------------------------------------------------------ power profiles
def power_profiles():
    """{"active", "available": [...]} or None without power-profiles-daemon."""
    if not shutil.which("powerprofilesctl"):
        return None
    code, out = run(["powerprofilesctl", "list"], 3)
    if code != 0:
        return None
    avail, active = [], None
    for line in out.splitlines():
        m = re.match(r"^(\*?)\s*([a-z-]+):\s*$", line)
        if m:
            avail.append(m[2])
            if m[1]:
                active = m[2]
    return {"active": active, "available": avail}


def set_power_profile(name):
    return run(["powerprofilesctl", "set", name], 5)[0] == 0
