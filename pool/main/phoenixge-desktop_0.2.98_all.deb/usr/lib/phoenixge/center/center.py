#!/usr/bin/env python3
"""PhoenixGe Center - welcome screen (first login) and control center in one app.

Pages: Welcome, Themes (12 designs + automatic day/night), Drivers (NVIDIA), Apps (one-click Flathub),
Gaming (MangoHud, GameMode, Steam Big Picture at login, GE-Proton), Backups (Timeshift), Updates,
Language, Phone (KDE Connect), System.
  phoenixge-center            open the control center
  phoenixge-center --welcome  first-login welcome (shown once, from autostart)
"""
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

from PySide6.QtCore import QProcess, Qt, QSize, QTimer
from PySide6.QtGui import QColor, QFont, QIcon, QPixmap
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QFileDialog, QFrame, QLineEdit, QGridLayout, QHBoxLayout, QLabel,
                               QListWidget, QListWidgetItem, QMessageBox, QPlainTextEdit, QPushButton, QScrollArea,
                               QStackedWidget, QToolButton, QVBoxLayout, QWidget)

HOME = Path.home()
CFG = HOME / ".config/phoenixge"
LNF = Path("/usr/share/plasma/look-and-feel")
VERSION = Path("/usr/share/phoenixge/version")
LOGO = "/usr/share/pixmaps/phoenixge.png"

sys.path.insert(0, str(Path(__file__).resolve().parent))
from store import CATEGORIES, STORE  # noqa: E402
import health, usbmaker  # noqa: E402


def sh(cmd, timeout=10):
    try:
        return subprocess.run(cmd, shell=isinstance(cmd, str), capture_output=True, text=True, timeout=timeout).stdout.strip()
    except Exception:
        return ""


def kread(file, group, key):
    return sh(["kreadconfig6", "--file", file, "--group", group, "--key", key])


def accent():
    v = kread("kdeglobals", "General", "AccentColor")
    try:
        r, g, b = (int(x) for x in v.split(",")[:3])
        return QColor(r, g, b).name()
    except Exception:
        return "#ff7a2e"


def themes():
    out = []
    for d in sorted(LNF.glob("org.phoenixge.*")):
        try:
            meta = json.loads((d / "metadata.json").read_text(encoding="utf-8"))["KPlugin"]
        except Exception:
            continue
        out.append(dict(id=d.name, name=meta.get("Name", d.name).replace("PhoenixGe ", ""),
                        desc=meta.get("Description", "").split("—")[-1].strip(),
                        preview=str(d / "contents/previews/preview.png")))
    return out


# ------------------------------------------------------------------ widgets
class Card(QFrame):
    def __init__(self, title="", text=""):
        super().__init__()
        self.setObjectName("card")
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(18, 16, 18, 16)
        self.lay.setSpacing(8)
        if title:
            t = QLabel(title); t.setObjectName("cardTitle"); self.lay.addWidget(t)
        if text:
            x = QLabel(text); x.setWordWrap(True); x.setObjectName("dim"); self.lay.addWidget(x)


def page(title, subtitle=""):
    w = QWidget()
    outer = QVBoxLayout(w); outer.setContentsMargins(0, 0, 0, 0)
    scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame)
    inner = QWidget(); lay = QVBoxLayout(inner); lay.setContentsMargins(36, 30, 36, 30); lay.setSpacing(16)
    h = QLabel(title); h.setObjectName("h1"); lay.addWidget(h)
    if subtitle:
        s = QLabel(subtitle); s.setObjectName("dim"); s.setWordWrap(True); lay.addWidget(s)
    scroll.setWidget(inner); outer.addWidget(scroll)
    return w, lay


class FlowGrid(QWidget):
    """Grid that re-flows its cards to the window width (1 column on narrow windows, 4+ when maximized)."""

    def __init__(self, min_w=300, max_cols=5):
        super().__init__()
        self.min_w, self.max_cols, self.items, self.cols = min_w, max_cols, [], 0
        self.grid = QGridLayout(self); self.grid.setContentsMargins(0, 0, 0, 0); self.grid.setSpacing(12)

    def set_items(self, widgets):
        for w in self.items:
            self.grid.removeWidget(w); w.deleteLater()
        self.items, self.cols = list(widgets), 0
        self.reflow()

    def add(self, w):
        self.items.append(w); self.cols = 0; self.reflow()

    def reflow(self):
        cols = max(1, min(self.max_cols, self.width() // self.min_w)) if self.width() > 50 else 3
        if cols == self.cols:
            return
        self.cols = cols
        for w in self.items:
            self.grid.removeWidget(w)
        for i, w in enumerate(self.items):
            self.grid.addWidget(w, i // cols, i % cols)
        for c in range(self.max_cols):
            self.grid.setColumnStretch(c, 1 if c < cols else 0)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self.reflow()


class Runner:
    """Runs commands with QProcess and streams output into a log box."""

    def __init__(self, log: QPlainTextEdit):
        self.log, self.procs = log, []

    def run(self, program, args, done=None):
        p = QProcess()
        p.setProcessChannelMode(QProcess.MergedChannels)
        p.readyReadStandardOutput.connect(lambda: self.log.appendPlainText(bytes(p.readAllStandardOutput()).decode(errors="replace").rstrip()))
        p.finished.connect(lambda code, _s: self._end(p, done, code, f"— finished ({code})"))
        p.errorOccurred.connect(lambda err: err == QProcess.ProcessError.FailedToStart and
                                self._end(p, done, -1, f"— could not start {program} (not installed?)"))
        self.procs.append(p)
        self.log.show()
        self.log.appendPlainText(f"$ {program} {' '.join(args)}")
        p.start(program, args)

    def _end(self, p, done, code, msg):
        if p not in self.procs:
            return
        self.procs.remove(p)
        self.log.appendPlainText(msg)
        if done:
            done(code)

    def root(self, script, args=(), done=None):
        """Run one of our scripts as root. Via /bin/sh so it works even if the file lost its exec bit."""
        self.run("pkexec", ["/bin/sh", script, *args], done)


# ------------------------------------------------------------------ main window
class Center(QWidget):
    def __init__(self, welcome=False):
        super().__init__()
        self.setWindowTitle("PhoenixGe Center")
        self.setWindowIcon(QIcon(LOGO))
        self.resize(1180, 760)
        self.setMinimumSize(760, 520)
        acc = accent()
        self.setStyleSheet(f"""
            QWidget {{ font-size: 13px; }}
            #sidebar {{ background: palette(alternate-base); }}
            #side {{ background: transparent; border: none; padding: 10px; }}
            #side::item {{ padding: 10px 14px; border-radius: 10px; margin: 2px 0; }}
            #side::item:selected {{ background: {acc}33; color: {acc}; }}
            #h1 {{ font-size: 26px; font-weight: 700; }}
            #dim {{ color: palette(placeholder-text); }}
            #card {{ background: palette(alternate-base); border-radius: 14px; border: 1px solid {acc}22; }}
            #cardTitle {{ font-size: 15px; font-weight: 600; }}
            QPushButton {{ padding: 8px 16px; border-radius: 10px; }}
            QPushButton#primary {{ background: {acc}; color: #1a0b06; font-weight: 600; border: none; }}
            QPushButton:checked {{ background: {acc}; color: #1a0b06; }}
            QToolButton#theme {{ border-radius: 14px; padding: 6px; }}
            QToolButton#theme:checked {{ border: 2px solid {acc}; background: {acc}22; }}
        """)
        root = QHBoxLayout(self); root.setContentsMargins(0, 0, 0, 0); root.setSpacing(0)
        side = QVBoxLayout(); side.setContentsMargins(0, 0, 0, 0)
        brand = QLabel(); brand.setPixmap(QPixmap(LOGO).scaled(56, 56, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        brand.setAlignment(Qt.AlignCenter); brand.setContentsMargins(0, 18, 0, 6)
        name = QLabel("PhoenixGe Center"); name.setAlignment(Qt.AlignCenter); name.setStyleSheet("font-weight:700;font-size:15px;")
        self.nav = QListWidget(); self.nav.setObjectName("side"); self.nav.setFixedWidth(230); self.nav.setIconSize(QSize(20, 20))
        side.addWidget(brand); side.addWidget(name); side.addWidget(self.nav)
        sidew = QWidget(); sidew.setLayout(side); sidew.setFixedWidth(230)
        sidew.setObjectName("sidebar"); sidew.setAttribute(Qt.WA_StyledBackground, True)
        self.stack = QStackedWidget()
        right = QVBoxLayout(); right.setContentsMargins(0, 0, 0, 0); right.addWidget(self.stack)
        self.log = QPlainTextEdit(); self.log.setReadOnly(True); self.log.setMaximumHeight(150); self.log.hide()
        right.addWidget(self.log)
        root.addWidget(sidew); root.addLayout(right, 1)
        self.runner = Runner(self.log)
        if welcome:  # before the pages are built, so the "Show this window at login" checkbox shows the real state
            CFG.mkdir(parents=True, exist_ok=True)
            (CFG / "welcome-done").write_text("1")

        for title, icon, build in [("Welcome", "go-home", self.p_welcome), ("Themes", "preferences-desktop-theme", self.p_themes),
                                   ("Drivers", "preferences-system", self.p_drivers), ("Store", "plasmadiscover", self.p_store),
                                   ("Android", "smartphone", self.p_android),
                                   ("Gaming", "applications-games", self.p_gaming), ("Security", "security-high", self.p_security),
                                   ("Devices", "computer-laptop", self.p_devices), ("Backups", "timeshift", self.p_backups),
                                   ("Updates", "system-software-update", self.p_updates), ("Language", "preferences-desktop-locale", self.p_language),
                                   ("Phone", "kdeconnect", self.p_phone),
                                   ("Health", "utilities-system-monitor", lambda: health.build(self)),
                                   ("USB Creator", "drive-removable-media-usb", lambda: usbmaker.build(self)),
                                   ("System", "computer", self.p_system),
                                   ("Move from Windows", "document-import", self.p_migrate)]:
            QListWidgetItem(QIcon.fromTheme(icon), title, self.nav)
            self.stack.addWidget(build())
        self.nav.currentRowChanged.connect(self.stack.setCurrentIndex)
        self.nav.setCurrentRow(0)

    # ---------------------------------------------------------------- pages
    def p_welcome(self):
        w, lay = page(f"Welcome to PhoenixGe, {os.environ.get('USER', '')}!", "Rise from the ashes. A few things to set up - each takes one click.")
        grid = FlowGrid(340, 3)
        steps = [("Pick your look", "12 themes made from the PhoenixGe designs.", 1),
                 ("Graphics driver", "NVIDIA cards get their driver automatically - check it here.", 2),
                 ("Phoenix Store", "Games, coding tools (VS Code…), Android and iOS dev, design, learning.", 3),
                 ("Gaming", "Game Mode session, FPS counter, GE-Proton.", 5),
                 ("Safety net", "Automatic system snapshots - undo any bad change.", 8),
                 ("Phone", "Files, notifications and clipboard with your phone.", 11)]
        if not Path("/run/live").exists():
            prof = (Path("/var/lib/phoenixge/profile").read_text().strip() if Path("/var/lib/phoenixge/profile").exists() else "everything")
            names = {"games": "Steam, Heroic, Discord, Minecraft", "replay": "Instant Replay", "rgb": "RGB", "gpu": "GPU control",
                     "gamemode": "Game Mode", "devpack": "developer tools", "devapps": "VS Code, Android Studio",
                     "backups": "daily backups", "android": "Android apps"}
            steps_for = {"gaming": "games replay rgb gpu gamemode backups android", "developer": "devpack devapps backups android",
                         "minimal": "backups"}.get(prof, "games replay rgb gpu gamemode devpack devapps backups android").split()
            left = [names[k] for k in steps_for if not Path(f"/var/lib/phoenixge/fb-{k}.done").exists()]
            lay.addWidget(Card(f"Profile: {prof.capitalize()} - " + ("everything is ready ✓" if not left else "setting up in the background…"),
                               ("Installed: " + ", ".join(names[k] for k in steps_for) + ".") if not left else
                               "Installing: " + ", ".join(left) + ". Keep the internet on - it continues by itself, even after a restart."))
        for i, (t, d, target) in enumerate(steps):
            c = Card(t, d)
            b = QPushButton("Open"); b.clicked.connect(lambda _=False, r=target: self.nav.setCurrentRow(r))
            c.lay.addWidget(b, 0, Qt.AlignLeft)
            grid.add(c)
        lay.addWidget(grid)
        auto = QCheckBox("Show this window at login"); auto.setChecked(not (CFG / "welcome-done").exists())
        auto.toggled.connect(lambda on: (CFG.mkdir(parents=True, exist_ok=True),
                                         (CFG / "welcome-done").unlink(missing_ok=True) if on else (CFG / "welcome-done").write_text("1")))
        lay.addWidget(auto); lay.addStretch()
        return w

    def p_themes(self):
        w, lay = page("Themes", "Every theme changes the whole desktop: taskbar, start menu, widgets, windows, colors and fonts.")
        current = kread("kdeglobals", "KDE", "LookAndFeelPackage")
        grid = FlowGrid(240, 6)
        self.theme_buttons = []
        tl = themes()
        for i, t in enumerate(tl):
            b = QToolButton(); b.setObjectName("theme"); b.setCheckable(True); b.setChecked(t["id"] == current)
            b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
            b.setIcon(QIcon(t["preview"])); b.setIconSize(QSize(200, 112)); b.setText(t["name"])
            b.setToolTip(t["desc"]); b.setFixedSize(224, 150); b.setAutoRaise(True)
            b.clicked.connect(lambda _=False, tid=t["id"], btn=b: self.apply_theme(tid, btn))
            self.theme_buttons.append(b)
            grid.add(b)
        lay.addWidget(grid)
        # automatic day / night
        c = Card("Automatic day / night", "Switch to a light theme in the day and a dark one at night.")
        conf = self.autotheme_conf()
        row = QHBoxLayout()
        en = QCheckBox("Enabled"); en.setChecked(conf.get("enabled") == "1")
        day, night = QComboBox(), QComboBox()
        for t in tl:
            day.addItem(t["name"], t["id"]); night.addItem(t["name"], t["id"])
        day.setCurrentIndex(max(0, day.findData(conf.get("day", "org.phoenixge.ash"))))
        night.setCurrentIndex(max(0, night.findData(conf.get("night", "org.phoenixge.ember"))))
        save = QPushButton("Save"); save.setObjectName("primary")
        save.clicked.connect(lambda: self.save_autotheme(en.isChecked(), day.currentData(), night.currentData()))
        for x in (en, QLabel("Day (07:00):"), day, QLabel("Night (19:00):"), night, save):
            row.addWidget(x)
        row.addStretch(); c.lay.addLayout(row); lay.addWidget(c)
        lv = Card("Live fire wallpaper", "Embers rise from the bottom of your wallpaper and the glow breathes slowly. Uses the "
                                         "graphics card, very light.")
        live = QCheckBox("Live wallpaper on")
        live.setChecked("org.phoenixge.fire" in sh("grep -h '^wallpaperplugin=' ~/.config/plasma-org.kde.plasma.desktop-appletsrc"))
        live.toggled.connect(self.set_live)
        lv.lay.addWidget(live); lay.addWidget(lv); lay.addStretch()
        return w

    def set_live(self, on):
        if on:
            js = ('desktops().forEach(function (d) { d.currentConfigGroup = ["Wallpaper", "org.kde.image", "General"];'
                  ' var img = d.readConfig("Image"); d.wallpaperPlugin = "org.phoenixge.fire";'
                  ' d.currentConfigGroup = ["Wallpaper", "org.phoenixge.fire", "General"];'
                  f' d.writeConfig("Image", img); d.writeConfig("Color", "{accent()}"); }});')
        else:
            js = 'desktops().forEach(function (d) { d.wallpaperPlugin = "org.kde.image"; });'
        sh(["gdbus", "call", "--session", "--dest", "org.kde.plasmashell", "--object-path", "/PlasmaShell",
            "--method", "org.kde.PlasmaShell.evaluateScript", js])

    def apply_theme(self, tid, btn):
        for b in self.theme_buttons:
            b.setChecked(b is btn)
        self.runner.run("sh", ["-c", f"plasma-apply-lookandfeel -a {tid} --resetLayout && plasma-apply-desktoptheme phoenixge-{tid.split('.')[-1]}"])

    def autotheme_conf(self):
        f = CFG / "autotheme.conf"
        try:
            return dict(l.split("=", 1) for l in f.read_text().split() if "=" in l)
        except OSError:
            return {}

    def save_autotheme(self, on, day, night):
        CFG.mkdir(parents=True, exist_ok=True)
        (CFG / "autotheme.conf").write_text(f"enabled={'1' if on else '0'}\nday={day}\nnight={night}\nday_start=07\nnight_start=19\n")
        sh("systemctl --user start phoenixge-autotheme.service")
        QMessageBox.information(self, "PhoenixGe", "Saved." + (" The theme switches automatically at 07:00 and 19:00." if on else ""))

    def p_drivers(self):
        w, lay = page("Drivers", "PhoenixGe installs the NVIDIA driver by itself on the first boot of an installed system (internet needed).")
        gpus = sh("lspci -nn | grep -Ei 'vga|3d|display' | sed 's/^[^ ]* //'") or "unknown"
        c = Card("Graphics", gpus); lay.addWidget(c)
        nv = "nvidia" in sh("lsmod")
        has_nv = "10de" in sh("lspci -nn | grep -Ei 'vga|3d'")
        if not has_nv:
            status = "No NVIDIA card - the built-in open driver (Mesa) is used, nothing to install."
        elif nv:
            status = "NVIDIA driver is running. " + sh("nvidia-smi --query-gpu=name,driver_version --format=csv,noheader")
        elif Path("/var/lib/phoenixge/nvidia-reboot-needed").exists():
            status = "NVIDIA driver installed - restart the computer to use it."
        else:
            status = "NVIDIA card found but the driver is not installed yet."
        s = Card("Status", status); lay.addWidget(s)
        if has_nv and not nv:
            b = QPushButton("Install NVIDIA driver now"); b.setObjectName("primary")
            b.clicked.connect(lambda: self.runner.root("/usr/lib/phoenixge/firstboot-nvidia.sh"))
            s.lay.addWidget(b, 0, Qt.AlignLeft)
        lay.addStretch()
        return w

    def p_store(self):
        w, lay = page("Phoenix Store", "Hand-picked apps by category. Flathub apps are sandboxed and update by themselves; "
                                       "everything else is in Discover.")
        top = QHBoxLayout()
        self.store_search = QLineEdit(); self.store_search.setPlaceholderText("Search the store…")
        self.store_search.textChanged.connect(lambda _t: self.fill_store())
        top.addWidget(self.store_search, 1)
        more = QPushButton("Open Discover"); more.clicked.connect(lambda: QProcess.startDetached("plasma-discover", []))
        top.addWidget(more); lay.addLayout(top)
        chips = QHBoxLayout(); chips.setSpacing(6)
        self.store_cat = CATEGORIES[0]
        self.cat_buttons = []
        for c in CATEGORIES:
            b = QPushButton(c.replace("&", "&&")); b.setCheckable(True); b.setChecked(c == self.store_cat); b.setProperty("cat", c)
            b.clicked.connect(lambda _=False, cc=c: self.pick_cat(cc))
            self.cat_buttons.append(b); chips.addWidget(b)
        chips.addStretch(); lay.addLayout(chips)
        self.store_grid = FlowGrid(300, 5)
        lay.addWidget(self.store_grid); lay.addStretch()
        self.installed = self.flatpaks()
        self.debs = set(l.split()[0] for l in sh("dpkg-query -W -f='${Package} ${db:Status-Status}\\n'", 20).splitlines()
                        if l.endswith(" installed"))
        self.fill_store()
        return w

    def pick_cat(self, c):
        self.store_cat = c
        for b in self.cat_buttons:
            b.setChecked(b.property("cat") == c)
        self.store_search.clear()
        self.fill_store()

    def fill_store(self):
        cards = []
        q = self.store_search.text().strip().lower()
        items = [x for x in STORE if (q and (q in x[3].lower() or q in x[4].lower())) or (not q and x[0] == self.store_cat)]
        seen = set()
        for i, (cat, kind, ident, name, what) in enumerate(items):
            if (kind, ident, name) in seen:
                continue
            seen.add((kind, ident, name))
            c = Card(name, what)
            if kind != "info":
                done = ((kind == "flatpak" and ident in self.installed) or
                        (kind in ("apt", "aptbpo") and set(ident.split()) <= self.debs))
                b = QPushButton("Installed" if done else ("Set up" if kind == "script" else "Install"))
                b.setEnabled(not done)
                if not done:
                    b.setObjectName("primary")
                    b.clicked.connect(lambda _=False, k=kind, ii=ident, btn=b: self.store_install(k, ii, btn))
                tag = QLabel({"flatpak": "Flathub", "apt": "Debian", "aptbpo": "Debian backports", "script": "official installer"}[kind])
                tag.setObjectName("dim")
                row = QHBoxLayout(); row.addWidget(b); row.addWidget(tag); row.addStretch(); c.lay.addLayout(row)
            cards.append(c)
        self.store_grid.set_items(cards)

    def store_install(self, kind, ident, btn):
        btn.setEnabled(False); btn.setText("Installing…")

        def done(code):
            btn.setText("Installed" if code == 0 else "Retry"); btn.setEnabled(code != 0)
            if code == 0 and kind == "flatpak":
                self.installed.add(ident)
            elif code == 0:
                self.debs.update(ident.split())
        if kind == "flatpak":
            self.runner.run("flatpak", ["install", "-y", "--noninteractive", "flathub", ident], done)
        elif kind in ("apt", "aptbpo"):
            self.runner.root("/usr/lib/phoenixge/apt-install.sh", (["-b"] if kind == "aptbpo" else []) + ident.split(), done)
        elif kind == "script":
            self.runner.run("sh", [f"/usr/lib/phoenixge/dev/{ident}"], done)

    def p_android(self):
        w, lay = page("Android", "Android apps in normal windows next to your other apps (Waydroid - a real Android in a container). "
                                 "Install apps from F-Droid, an APK file, or Google Play.")
        have = shutil.which("waydroid") is not None
        st = sh("waydroid status 2>/dev/null | grep -E 'Session|Container' | tr '\n' ' '") if have else ""
        nv_only = ("10de" in sh("lspci -nn | grep -Ei 'vga|3d'")) and not re.search(r"8086|1002", sh("lspci -nn | grep -Ei 'vga|3d'"))
        c = Card("Status", ("Installed. " + st) if have else "Not installed yet.")
        lay.addWidget(c)
        if nv_only:
            lay.addWidget(Card("NVIDIA note", "Waydroid can't use NVIDIA graphics, so Android draws with the CPU: normal apps are "
                                              "fine, heavy 3D Android games will be slow."))
        s1 = Card("1. Install Android", "Downloads Android (LineageOS, ~1 GB). With Google Play you must register the device once (step 4).")
        row = QHBoxLayout()
        b1 = QPushButton("Install (free apps / F-Droid)"); b1.setObjectName("primary")
        b1.clicked.connect(lambda: self.runner.root("/usr/lib/phoenixge/android-setup.sh"))
        b2 = QPushButton("Install with Google Play")
        b2.clicked.connect(lambda: self.runner.root("/usr/lib/phoenixge/android-setup.sh", ["gapps"]))
        row.addWidget(b1); row.addWidget(b2); row.addStretch(); s1.lay.addLayout(row); lay.addWidget(s1)
        s2 = Card("2. Start", "Starts Android, puts its apps in the start menu as separate windows and installs F-Droid.")
        row = QHBoxLayout()
        b3 = QPushButton("Start Android"); b3.setObjectName("primary")
        b3.clicked.connect(lambda: self.runner.run("sh", ["/usr/lib/phoenixge/android-user.sh"]))
        b4 = QPushButton("Full Android screen"); b4.clicked.connect(lambda: QProcess.startDetached("waydroid", ["show-full-ui"]))
        b5 = QPushButton("Install APK file…"); b5.clicked.connect(self.install_apk)
        b6 = QPushButton("Restart Android")
        b6.clicked.connect(lambda: self.runner.run("sh", ["-c", "waydroid session stop; sleep 2; sh /usr/lib/phoenixge/android-user.sh"]))
        for b in (b3, b4, b5, b6):
            b.setEnabled(have); row.addWidget(b)
        row.addStretch(); s2.lay.addLayout(row); lay.addWidget(s2)
        s3 = Card("3. ARM support", "Many Play Store apps and games are built only for phone (ARM) processors. This adds a translator "
                                    "(libndk on AMD, libhoudini on Intel).")
        b7 = QPushButton("Add ARM support"); b7.setEnabled(have)
        b7.clicked.connect(lambda: self.runner.root("/usr/lib/phoenixge/android-arm.sh"))
        s3.lay.addWidget(b7, 0, Qt.AlignLeft); lay.addWidget(s3)
        s4 = Card("4. Google Play registration", "Only for the Google Play version: get the device ID, paste it at "
                                                 "google.com/android/uncertified, wait ~10 minutes, restart Android.")
        row = QHBoxLayout()
        b8 = QPushButton("Show device ID"); b8.setEnabled(have)
        b8.clicked.connect(lambda: self.runner.root("/usr/lib/phoenixge/android-certify.sh"))
        b9 = QPushButton("Open registration page")
        b9.clicked.connect(lambda: QProcess.startDetached("xdg-open", ["https://www.google.com/android/uncertified"]))
        row.addWidget(b8); row.addWidget(b9); row.addStretch(); s4.lay.addLayout(row); lay.addWidget(s4)
        lay.addWidget(Card("Won't work", "Banking apps and games with anti-cheat (PUBG Mobile, Free Fire…) usually detect that this "
                                         "is not a real phone and refuse to start."))
        lay.addStretch()
        return w

    def install_apk(self):
        f, _ = QFileDialog.getOpenFileName(self, "Android app (.apk)", str(HOME / "Downloads"), "Android apps (*.apk)")
        if f:
            self.runner.run("waydroid", ["app", "install", f])

    def p_gaming(self):
        w, lay = page("Gaming", "Settings that make games run and look better.")
        lib = Card("Phoenix Games", "All your games in one library: Steam, Epic, GOG, Amazon (Heroic), Lutris, Minecraft "
                                    "and Android games, with covers and play time.")
        lb = QPushButton("Open Phoenix Games"); lb.setObjectName("primary")
        lb.clicked.connect(lambda: QProcess.startDetached("phoenixge-games", []))
        lib.lay.addWidget(lb, 0, Qt.AlignLeft); lay.addWidget(lib)
        envd = HOME / ".config/environment.d"
        mh = QCheckBox("Show FPS counter (MangoHud) in every game  - takes effect after logging in again")
        mh.setChecked((envd / "phoenixge-mangohud.conf").exists())
        mh.toggled.connect(lambda on: (envd.mkdir(parents=True, exist_ok=True),
                                       (envd / "phoenixge-mangohud.conf").write_text("MANGOHUD=1\n") if on
                                       else (envd / "phoenixge-mangohud.conf").unlink(missing_ok=True)))
        auto = HOME / ".config/autostart/phoenixge-bigpicture.desktop"
        bp = QCheckBox("Start Steam Big Picture at login (console mode)")
        bp.setChecked(auto.exists())
        bp.toggled.connect(lambda on: self.bigpicture(on, auto))
        gs = Card("PhoenixGe Game Mode (like SteamOS)",
                  "On the login screen pick \"PhoenixGe Game Mode\" (session menu, bottom left): Steam's console interface starts "
                  "full screen inside gamescope - controller friendly, no desktop in the way. Quit Steam to come back.")
        ready = shutil.which("gamescope") is not None
        gb = QPushButton("Game Mode is ready ✓" if ready else "Set up Game Mode (gamescope + Steam)")
        gb.setEnabled(not ready); gb.setObjectName("primary")
        gb.clicked.connect(lambda: self.runner.run("sh", ["-c", "pkexec /bin/sh /usr/lib/phoenixge/apt-install.sh -b gamescope && "
                                                          "(flatpak info com.valvesoftware.Steam >/dev/null 2>&1 || "
                                                          "flatpak install -y --noninteractive flathub com.valvesoftware.Steam)"]))
        gs.lay.addWidget(gb, 0, Qt.AlignLeft); lay.addWidget(gs)
        # automatic game profile (GameMode start/end hooks -> /usr/lib/phoenixge/gaming/session.py)
        try:
            sys.path.insert(0, "/usr/lib/phoenixge/gaming")
            import settings as gset
            gconf = gset.load()
        except Exception:
            gset = None
        if gset:
            ap = Card("Automatic game profile", "While a game runs, PhoenixGe switches to maximum performance and keeps "
                      "everything else quiet. When you quit the game, everything goes back as it was.")
            for key, text in [("power_profile", "Performance power mode while playing"),
                              ("do_not_disturb", "Do Not Disturb (no notifications) while playing"),
                              ("pause_updates", "Pause updates and background maintenance while playing"),
                              ("fps_log", "Record FPS and temperatures (shown in Phoenix Games)"),
                              ("discord", "Show \"Playing ...\" in Discord")]:
                cb = QCheckBox(text); cb.setChecked(bool(gconf.get(key, True)))

                def toggled(on, k=key):
                    cf = gset.load(); cf[k] = on; gset.save(cf)
                cb.toggled.connect(toggled); ap.lay.addWidget(cb)
            lay.addWidget(ap)
        ov = Card("PhoenixGe Overlay (Meta+G)", "A game bar over your game: live FPS and temperatures, per-app volume, "
                  "music controls, screenshots and Instant Replay. Press Meta+G (or Esc) again to close it.")
        ov_auto = HOME / ".config/autostart/phoenixge-overlay.desktop"
        oc = QCheckBox("Keep the overlay ready in the background (opens instantly)")
        oc.setChecked(ov_auto.exists())
        oc.toggled.connect(lambda on: (ov_auto.parent.mkdir(parents=True, exist_ok=True),
                                       ov_auto.write_text("[Desktop Entry]\nType=Application\nName=PhoenixGe Overlay\n"
                                                          "Exec=phoenixge-overlay --daemon\nNoDisplay=true\nX-KDE-autostart-phase=2\n")
                                       if on else ov_auto.unlink(missing_ok=True)))
        ov.lay.addWidget(oc)
        orow = QHBoxLayout()
        ob1 = QPushButton("Open overlay"); ob1.setObjectName("primary")
        ob1.clicked.connect(lambda: QProcess.startDetached("phoenixge-overlay", ["--show"]))
        ob2 = QPushButton("Change shortcut…")
        ob2.clicked.connect(lambda: QProcess.startDetached("systemsettings", ["kcm_keys"]))
        orow.addWidget(ob1); orow.addWidget(ob2); orow.addStretch(1); ov.lay.addLayout(orow)
        onote = QLabel("Works over windowed and borderless games. Not over exclusive-fullscreen games or the Game Mode "
                       "session - Steam's own overlay works there. If Meta+G opens the window grid instead, set the "
                       "shortcut with \"Change shortcut…\"."); onote.setWordWrap(True); onote.setObjectName("dim")
        ov.lay.addWidget(onote); lay.addWidget(ov)
        c = Card("Performance"); c.lay.addWidget(mh); c.lay.addWidget(bp)
        gm = QLabel("GameMode is always on for Windows programs started with PhoenixGe (phoenix-run) and for Steam games "
                    "with the launch option  gamemoderun %command%"); gm.setWordWrap(True); gm.setObjectName("dim")
        c.lay.addWidget(gm); lay.addWidget(c)
        p = Card("GE-Proton", "A community Proton build with extra fixes for Windows games. ProtonUp-Qt installs and updates it "
                              "for Steam, Heroic, Lutris and Bottles.")
        b = QPushButton("Install / open ProtonUp-Qt"); b.setObjectName("primary")
        b.clicked.connect(lambda: self.runner.run(
            "sh", ["-c", "flatpak info net.davidotek.pupgui2 >/dev/null 2>&1 || "
                         "flatpak install -y --noninteractive flathub net.davidotek.pupgui2"],
            lambda code: code == 0 and QProcess.startDetached("flatpak", ["run", "net.davidotek.pupgui2"])))
        p.lay.addWidget(b, 0, Qt.AlignLeft); lay.addWidget(p)
        kver = sh("uname -r")
        has_ntsync = Path("/dev/ntsync").exists()
        k = Card("Gaming kernel (ntsync)",
                 f"Current kernel: {kver} - ntsync {'available ✓' if has_ntsync else 'not available'}.\n"
                 "The newest Debian kernel (backports, 7.x) has ntsync, which makes many Windows games run smoother with "
                 "Proton/Wine. NVIDIA driver is updated to match. The old kernel stays in the boot menu as a fallback.")
        kb = QPushButton("Install gaming kernel"); kb.setEnabled(not has_ntsync)
        kb.clicked.connect(lambda: self.runner.root("/usr/lib/phoenixge/gaming-kernel.sh"))
        k.lay.addWidget(kb, 0, Qt.AlignLeft); lay.addWidget(k)
        ir = Card("Instant Replay (like NVIDIA ShadowPlay)",
                  "GPU Screen Recorder keeps the last 30-60 seconds of your game in memory; press its hotkey to save the clip. "
                  "Uses the graphics card's video encoder, so games don't slow down.")
        self.flatpak_button(ir, "com.dec05eba.gpu_screen_recorder", "Open Instant Replay"); lay.addWidget(ir)
        nv = "10de" in sh("lspci -nn | grep -Ei 'vga|3d'")
        gc = Card("Graphics card control (LACT)", "Fans, temperature, clocks and power limit for NVIDIA and AMD cards - like MSI "
                  "Afterburner. The first time it opens, LACT asks for your password once to set up its background service."
                  + (" NVIDIA: install the driver on the Drivers page first." if nv else ""))
        self.flatpak_button(gc, "io.github.ilya_zlobintsev.LACT", "Open LACT")
        lay.addWidget(gc)
        rgb = Card("RGB lighting", "OpenRGB controls keyboards, mice, RAM and graphics card lights from almost every brand. "
                                   "With 'follow theme' on, the lights take the color of the PhoenixGe theme.")
        self.flatpak_button(rgb, "org.openrgb.OpenRGB", "Open OpenRGB")
        fol = QCheckBox("RGB follows the theme color"); fol.setChecked(not (CFG / "rgb-off").exists())
        fol.toggled.connect(lambda on: (CFG.mkdir(parents=True, exist_ok=True),
                                        (CFG / "rgb-off").unlink(missing_ok=True) if on else (CFG / "rgb-off").write_text("1")))
        rgb.lay.addWidget(fol); lay.addWidget(rgb)
        ct = Card("Controllers", "Xbox, PlayStation (DualShock 4 / DualSense), Switch Pro and Steam controllers work over USB and "
                                 "Bluetooth. Bluetooth: hold the pair button on the controller, then pair it here.")
        b = QPushButton("Pair a Bluetooth controller"); b.clicked.connect(lambda: QProcess.startDetached("systemsettings", ["kcm_bluetooth"]))
        ct.lay.addWidget(b, 0, Qt.AlignLeft); lay.addWidget(ct)
        ac = Card("Anti-cheat", "Games with kernel anti-cheat (Valorant, FACEIT, Fortnite…) do not run on Linux at all. "
                                "Check a game on areweanticheatyet.com before buying.")
        lay.addWidget(ac); lay.addStretch()
        return w

    def bigpicture(self, on, auto):
        if on:
            auto.parent.mkdir(parents=True, exist_ok=True)
            cmd = "flatpak run com.valvesoftware.Steam -gamepadui" if "com.valvesoftware.Steam" in self.flatpaks() else "steam -gamepadui"
            auto.write_text(f"[Desktop Entry]\nType=Application\nName=Steam Big Picture\nExec={cmd}\nIcon=steam\n")
        else:
            auto.unlink(missing_ok=True)

    def flatpak_button(self, card, fid, label):
        have = fid in self.flatpaks()
        b = QPushButton(label if have else "Install")
        state = {"have": have}

        def finished(code):  # after a successful install the button opens the app instead of installing again
            state["have"] = code == 0
            b.setText(label if code == 0 else "Retry"); b.setEnabled(True)

        def clicked():
            if state["have"]:
                QProcess.startDetached("flatpak", ["run", fid])
            else:
                b.setEnabled(False); b.setText("Installing…")
                self.runner.run("flatpak", ["install", "-y", "--noninteractive", "flathub", fid], finished)
        if not have:
            b.setObjectName("primary")
        b.clicked.connect(clicked)
        card.lay.addWidget(b, 0, Qt.AlignLeft)

    def flatpaks(self):
        if getattr(self, "_flatpaks", None) is None:
            self._flatpaks = set(sh("flatpak list --app --columns=application", 20).split())
        return self._flatpaks

    def p_security(self):
        w, lay = page("Security", "Firewall, VPN, passwords, an encrypted folder and fingerprint login.")
        fw_on = Path("/etc/ufw/ufw.conf").exists() and "ENABLED=yes" in Path("/etc/ufw/ufw.conf").read_text(errors="ignore")
        c = Card("Firewall", "Blocks incoming connections from the network; apps can still go out. "
                             + ("Status: ON ✓" if fw_on else "Status: off"))
        row = QHBoxLayout()
        b1 = QPushButton("Turn firewall off" if fw_on else "Turn firewall on"); b1.setObjectName("" if fw_on else "primary")
        fw = {"on": fw_on}

        def fw_done(code):
            if code == 0:
                fw["on"] = not fw["on"]
                b1.setText("Turn firewall off" if fw["on"] else "Turn firewall on")
        b1.clicked.connect(lambda: self.runner.run("pkexec", ["/bin/sh", "-c", "ufw disable" if fw["on"] else
                                                              "ufw default deny incoming; ufw default allow outgoing; ufw allow 1714:1764/udp; "
                                                              "ufw allow 1714:1764/tcp; ufw --force enable"], fw_done))
        b2 = QPushButton("Advanced rules"); b2.clicked.connect(lambda: QProcess.startDetached("systemsettings", ["kcm_firewall"]))
        row.addWidget(b1); row.addWidget(b2); row.addStretch(); c.lay.addLayout(row)
        n = QLabel("KDE Connect (phone) stays allowed."); n.setObjectName("dim"); c.lay.addWidget(n); lay.addWidget(c)
        v = Card("VPN (WireGuard)", "Got a .conf file from your VPN provider (Proton VPN, Mullvad, your own server)? Import it - "
                                    "it then shows up in the network icon in the system tray.")
        b3 = QPushButton("Import WireGuard file…"); b3.setObjectName("primary"); b3.clicked.connect(self.import_vpn)
        v.lay.addWidget(b3, 0, Qt.AlignLeft); lay.addWidget(v)
        k = Card("Password manager", "KeePassXC keeps all passwords in one encrypted file, fills them in the browser, makes strong ones.")
        b4 = QPushButton("Open KeePassXC"); b4.clicked.connect(lambda: QProcess.startDetached("keepassxc", []))
        k.lay.addWidget(b4, 0, Qt.AlignLeft); lay.addWidget(k)
        vt = Card("Encrypted folder (Plasma Vault)", "A folder that is locked with a password - only open when you unlock it from the "
                                                     "system tray (lock icon). Good for documents and photos.")
        b5 = QPushButton("Create a vault"); b5.clicked.connect(lambda: QProcess.startDetached("gdbus", ["call", "--session", "--dest", "org.kde.kded6", "--object-path",
                                                                    "/modules/plasmavault", "--method", "org.kde.plasmavault.requestNewVault"]))
        vt.lay.addWidget(b5, 0, Qt.AlignLeft); lay.addWidget(vt)
        has_fp = bool(sh("lsusb 2>/dev/null | grep -Ei 'fingerprint|synaptics|goodix|elan|validity'"))
        f = Card("Fingerprint login", ("Fingerprint reader found. " if has_fp else "No fingerprint reader detected on this computer. ")
                 + "Add your finger in Settings > Users; then log in, unlock and approve admin prompts with it. "
                 "(Face login like Windows Hello needs an IR camera and is not available for Debian yet.)")
        b6 = QPushButton("Set up fingerprint"); b6.setEnabled(has_fp)
        b6.clicked.connect(lambda: self.runner.run("pkexec", ["/bin/sh", "-c", "DEBIAN_FRONTEND=noninteractive pam-auth-update --enable fprintd"],
                                                   lambda _c: QProcess.startDetached("systemsettings", ["kcm_users"])))
        f.lay.addWidget(b6, 0, Qt.AlignLeft); lay.addWidget(f)
        lay.addStretch()
        return w

    def import_vpn(self):
        f, _ = QFileDialog.getOpenFileName(self, "WireGuard config", str(HOME / "Downloads"), "WireGuard (*.conf)")
        if f:
            self.runner.run("nmcli", ["connection", "import", "type", "wireguard", "file", f])

    def p_devices(self):
        w, lay = page("Devices", "Battery, TV and screens.")
        prof = sh("powerprofilesctl get")
        c = Card("Power mode", f"Current: {prof or 'unknown'}. Battery saver gives the longest battery life, Performance the most FPS.")
        row = QHBoxLayout()
        for key, label in [("power-saver", "🔋 Battery saver"), ("balanced", "⚖ Balanced"), ("performance", "🚀 Performance")]:
            b = QPushButton(label + ("  ✓" if prof == key else ""))
            if prof == key:
                b.setObjectName("primary")
            b.clicked.connect(lambda _=False, k=key: self.runner.run("powerprofilesctl", ["set", k]))
            row.addWidget(b)
        row.addStretch(); c.lay.addLayout(row); lay.addWidget(c)
        try:  # laptop: smart battery, battery protection, graphics mode (hidden on desktops)
            import laptop
            lay.addWidget(laptop.build(self))
        except Exception as e:
            print("laptop section:", e, file=sys.stderr)
            bat = sh("upower -i $(upower -e | grep -m1 BAT) 2>/dev/null | grep -E 'percentage|state|time to' | sed 's/^ *//'")
            if bat:
                lay.addWidget(Card("Battery", bat))
        t = Card("Show on a TV", "Miracast (most smart TVs, Windows-style 'Cast') and Chromecast: the screen appears on the TV "
                                 "over Wi-Fi. TV and computer on the same network; on the TV enable 'Screen mirroring'.")
        b = QPushButton("Cast to TV"); b.setObjectName("primary")
        b.clicked.connect(lambda: QProcess.startDetached("gnome-network-displays", []))
        t.lay.addWidget(b, 0, Qt.AlignLeft); lay.addWidget(t)
        d = Card("Screens", "Resolution, refresh rate (144 Hz), scaling, multiple monitors.")
        b2 = QPushButton("Display settings"); b2.clicked.connect(lambda: QProcess.startDetached("systemsettings", ["kcm_kscreen"]))
        d.lay.addWidget(b2, 0, Qt.AlignLeft); lay.addWidget(d)
        lay.addStretch()
        return w

    def p_migrate(self):
        w, lay = page("Move from Windows", "Copy your games (Epic → Heroic, Steam), find Linux versions of your Windows "
                                           "programs, bring files, bookmarks and wallpaper over. Windows is only read, never changed.")
        c = Card("Move from Windows", "Opens the Windows drive read-only and lets you pick what to bring over. Tip: in Windows run "
                 "'powercfg /h off' once (turns off Fast Startup), otherwise the Windows drive may be locked.")
        row = QHBoxLayout()
        for label, pg in (("Start", ""), ("Games", "games"), ("Programs", "programs"), ("Files & settings", "files")):
            b = QPushButton(label)
            if not pg:
                b.setObjectName("primary")
            b.clicked.connect(lambda _=False, p=pg: QProcess.startDetached("phoenixge-migrate", ["--page", p] if p else []))
            row.addWidget(b)
        row.addStretch(); c.lay.addLayout(row); lay.addWidget(c); lay.addStretch()
        return w

    def p_backups(self):
        w, lay = page("Backups", "Timeshift keeps snapshots of the system (not your personal files). If an update or a change breaks "
                                 "something, restore yesterday's system in a few clicks.")
        have = shutil.which("timeshift") is not None
        conf = Path("/etc/timeshift/timeshift.json")
        state = "not installed" if not have else ("automatic daily snapshots are ON" if conf.exists() and '"schedule_daily" : "true"' in conf.read_text(errors="ignore") else "automatic snapshots are off")
        c = Card("Status", f"Timeshift: {state}"); lay.addWidget(c)
        st = c.findChild(QLabel, "dim")
        row = QHBoxLayout()
        b1 = QPushButton("Turn on daily snapshots (keep 5)"); b1.setObjectName("primary")
        b1.clicked.connect(lambda: self.runner.root("/usr/lib/phoenixge/timeshift-auto.sh"))
        b2 = QPushButton("Make a snapshot now")
        b2.clicked.connect(lambda: self.runner.run("pkexec", ["/usr/bin/timeshift", "--create", "--comments", "PhoenixGe Center", "--yes"]))
        b3 = QPushButton("Open Timeshift (restore)"); b3.clicked.connect(lambda: QProcess.startDetached("timeshift-launcher", []))
        for b in (b1, b2, b3):
            b.setEnabled(have); row.addWidget(b)
        if not have:  # Timeshift is only a Recommends of phoenixge-desktop
            bi = QPushButton("Install Timeshift"); bi.setObjectName("primary")

            def installed(code):
                if code == 0:
                    bi.hide(); st.setText("Timeshift: installed - turn on daily snapshots")
                    for b in (b1, b2, b3):
                        b.setEnabled(True)
            bi.clicked.connect(lambda: self.runner.root("/usr/lib/phoenixge/apt-install.sh", ["timeshift"], installed))
            row.insertWidget(0, bi)
        row.addStretch(); c.lay.addLayout(row)
        # safe updates: a snapshot before every update + "restore previous state" in the boot menu
        optout = Path("/var/lib/phoenixge/no-pre-update-snapshot")
        btrfs = sh("findmnt -no FSTYPE /").strip() == "btrfs"
        booted = sh("/usr/bin/phoenixge-rollback --status").strip()
        su = Card("Safe updates", "Before every update the system state is saved (the last 5 are kept). If the computer doesn't "
                  "start properly after an update, pick \"PhoenixGe - restore previous state\" in the boot menu. "
                  + ("Snapshots start directly from the boot menu (btrfs)." if btrfs else
                     "The boot menu opens a restore tool (ext4 - snapshots can't be started directly)."))
        pre = QCheckBox("Save the system state before every update"); pre.setChecked(not optout.exists()); pre.setEnabled(have)
        pre.toggled.connect(lambda on: self.runner.run("pkexec", ["/bin/sh", "-c", f"rm -f {optout}" if on else
                                                                     f"mkdir -p {optout.parent} && touch {optout}"]))
        su.lay.addWidget(pre)
        r2 = QHBoxLayout()
        rb = QPushButton("Restore a previous state…")
        rb.clicked.connect(lambda: QProcess.startDetached("konsole", ["-e", "sudo", "/usr/bin/phoenixge-rollback"]))
        rb.setEnabled(have); r2.addWidget(rb)
        if booted.startswith("snapshot"):
            mp = QPushButton("You're running a saved state - make it permanent"); mp.setObjectName("primary")
            mp.clicked.connect(lambda: QProcess.startDetached("/usr/lib/phoenixge/snapshot-notice.sh", []))
            r2.addWidget(mp)
        r2.addStretch(); su.lay.addLayout(r2); lay.addWidget(su); lay.addStretch()
        return w

    def p_updates(self):
        ver = VERSION.read_text().strip() if VERSION.exists() else "?"
        w, lay = page("Updates", f"PhoenixGe {ver}. New themes, fixes and tools arrive as normal updates - no reinstall needed.")
        c = Card("Update now", "Updates PhoenixGe and all system packages (asks for your password).")
        b = QPushButton("Check and install updates"); b.setObjectName("primary")
        b.clicked.connect(lambda: self.runner.run("phoenixge-update", []))
        c.lay.addWidget(b, 0, Qt.AlignLeft); lay.addWidget(c)
        d = Card("Automatic", "Discover also shows PhoenixGe updates in the system tray.")
        o = QPushButton("Open Discover updates"); o.clicked.connect(lambda: QProcess.startDetached("plasma-discover", ["--mode", "update"]))
        d.lay.addWidget(o, 0, Qt.AlignLeft); lay.addWidget(d); lay.addStretch()
        return w

    def p_language(self):
        w, lay = page("Language", "Language of menus and apps. Log out and in again to apply.")
        cur = kread("plasma-localerc", "Translations", "LANGUAGE")
        c = Card("Display language")
        row = QHBoxLayout()
        for code, label in [("en_US", "English"), ("ka:en_US", "ქართული (Georgian)")]:
            b = QPushButton(label + ("  ✓" if cur == code or (not cur and code == "en_US") else ""))
            b.clicked.connect(lambda _=False, cd=code: (sh(["kwriteconfig6", "--file", "plasma-localerc", "--group", "Translations", "--key", "LANGUAGE", cd]),
                                                     QMessageBox.information(self, "PhoenixGe", "Saved - log out and in again.")))
            row.addWidget(b)
        row.addStretch(); c.lay.addLayout(row)
        kb = QLabel("Keyboard: English + Georgian, switch with Alt+Shift."); kb.setObjectName("dim"); c.lay.addWidget(kb)
        lay.addWidget(c); lay.addStretch()
        return w

    def p_phone(self):
        w, lay = page("Phone", "KDE Connect links your Android phone (or iPhone with limited features): send files, see notifications, "
                               "share the clipboard, use the phone as a remote.")
        c = Card("1. Install the app on the phone", "Google Play / F-Droid: \"KDE Connect\". iPhone: App Store \"KDE Connect\".")
        lay.addWidget(c)
        d = Card("2. Pair", "Phone and computer on the same Wi-Fi, then pair here.")
        b = QPushButton("Open KDE Connect"); b.setObjectName("primary")
        b.clicked.connect(lambda: QProcess.startDetached("kdeconnect-app", []))
        d.lay.addWidget(b, 0, Qt.AlignLeft); lay.addWidget(d); lay.addStretch()
        return w

    def p_system(self):
        w, lay = page("System")
        info = [("PhoenixGe", VERSION.read_text().strip() if VERSION.exists() else "?"),
                ("Base", sh(". /etc/os-release; echo $PRETTY_NAME")), ("Kernel", sh("uname -r")),
                ("CPU", sh("grep -m1 'model name' /proc/cpuinfo | cut -d: -f2")),
                ("Memory", sh("free -h | awk '/^Mem/{print $2}'")), ("Disk /", sh("df -h / | awk 'NR==2{print $4\" free of \"$2}'")),
                ("Graphics", sh("lspci | grep -Ei 'vga|3d' | cut -d: -f3"))]
        c = Card("This computer")
        g = QGridLayout()
        for i, (k, v) in enumerate(info):
            a = QLabel(k); a.setObjectName("dim"); g.addWidget(a, i, 0)
            b = QLabel(v.strip() or "-"); b.setTextInteractionFlags(Qt.TextSelectableByMouse); g.addWidget(b, i, 1)
        c.lay.addLayout(g); lay.addWidget(c)
        t = Card("Tools")
        row = QHBoxLayout()
        for label, prog in [("Kali Toolbox", "phoenix-toolbox"), ("System Monitor", "plasma-systemmonitor"), ("Settings", "systemsettings")]:
            b = QPushButton(label); b.clicked.connect(lambda _=False, p=prog: QProcess.startDetached(p, [])); row.addWidget(b)
        row.addStretch(); t.lay.addLayout(row); lay.addWidget(t); lay.addStretch()
        return w


def main():
    welcome = "--welcome" in sys.argv
    if welcome and (CFG / "welcome-done").exists():
        return 0
    app = QApplication(sys.argv)
    app.setApplicationName("PhoenixGe Center")
    app.setDesktopFileName("phoenixge-center")
    w = Center(welcome)
    if "--page" in sys.argv:
        want = sys.argv[sys.argv.index("--page") + 1].lower() if len(sys.argv) > sys.argv.index("--page") + 1 else ""
        for r in range(w.nav.count()):
            if w.nav.item(r).text().lower() == want:
                w.nav.setCurrentRow(r)
    w.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
