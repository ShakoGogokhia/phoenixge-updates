#!/bin/sh
# System-wide PhoenixGe setup. Run by the ISO build (hook 0800) and by the phoenixge-desktop package (postinst),
# so an update brings the same result as a fresh install.
set -e
# /etc defaults travel inside the package under usr/share (dpkg conffile prompts would block GUI updates)
if [ -d /usr/share/phoenixge/etc-overlay ]; then
  cp -r /usr/share/phoenixge/etc-overlay/. /etc/
fi
# repair: older builds had no VERSION_CODENAME in /etc/os-release -> "Suites: -backports" broke every apt update
B=/etc/apt/sources.list.d/phoenixge-backports.sources
if [ -f "$B" ] && grep -q '^Suites: -backports' "$B"; then sed -i 's/^Suites: -backports/Suites: trixie-backports/' "$B"; fi
# backports already in sources.list (Debian installer) -> our extra file only causes "configured multiple times" warnings
if [ -f "$B" ] && grep -qsE '^[^#]*trixie-backports' /etc/apt/sources.list; then rm -f "$B"; fi
# repair: the NVIDIA first-boot step used to add contrib/non-free to the PhoenixGe repo too (apt warnings)
for f in /etc/apt/sources.list.d/*.sources; do
  [ -f "$f" ] && grep -q '^URIs:.*phoenixge-updates' "$f" && sed -i -E 's/^Components:.*/Components: main/' "$f"
done
# update channel (stable/beta): the overlay just reset the apt source to stable -> re-apply the saved channel
sh /usr/lib/phoenixge/update-channel.sh apply || true
sh /usr/lib/phoenixge/autoupdate-setup.sh || true
# start menu: hide apps that only clutter it
for f in org.kde.contactprintthemeeditor org.kde.contactthemeeditor org.kde.headerthemeeditor org.kde.mboximporter \
         org.kde.pimdataexporter org.kde.kmail-refresh-settings org.kde.ktnef org.kde.sieveeditor \
         org.kde.drkonqi.coredump.gui org.kde.kdeconnect.sms org.kde.kdeconnect.nonplasma display-im7.q16 \
         org.kde.kmousetool org.kde.kmouth org.kde.kmag org.kde.sweeper org.rncbc.qsynth vim kvantummanager \
         org.kde.kontrast org.kde.kmenuedit konqbrowser org.kde.akregator; do
  d=/usr/share/applications/$f.desktop
  [ -f "$d" ] || continue
  if grep -q '^NoDisplay=' "$d"; then sed -i 's/^NoDisplay=.*/NoDisplay=true/' "$d"; else sed -i '/^\[Desktop Entry\]/a NoDisplay=true' "$d"; fi
done
# icon themes (design folders + Papirus logos)
python3 /usr/lib/phoenixge/make-tile-icons.py || true
# login screen
mkdir -p /etc/sddm.conf.d
printf '[Theme]\nCurrent=phoenixge\n' > /etc/sddm.conf.d/10-phoenixge.conf
chmod 755 /usr/lib/phoenixge/*.sh /usr/bin/phoenix-* 2>/dev/null || true
systemctl --global enable phoenixge-autotheme.timer >/dev/null 2>&1 || true
# first-boot setup (apps, Game Mode, backups, Android) - also runs once after an update brings new steps
systemctl enable phoenixge-firstboot-apps.service phoenixge-firstboot-apps.timer >/dev/null 2>&1 || true
chmod 755 /usr/lib/phoenixge/*.sh /usr/lib/phoenixge/dev/*.sh /usr/lib/phoenixge/gaming/*.sh /usr/lib/phoenixge/gaming/*.py 2>/dev/null || true
# safe updates: snapshot before updates + GRUB "restore previous state" menu
sh /usr/lib/phoenixge/safe-updates-setup.sh || true
if [ -d /run/systemd/system ]; then systemctl daemon-reload || true; fi
# NVIDIA: kernel modesetting (Wayland, VRR, HDR) for installs that got the driver before this was added
if [ -d /run/systemd/system ] && [ ! -d /run/live ] && [ ! -f /etc/modprobe.d/phoenixge-nvidia-drm.conf ] && \
   { dpkg -s nvidia-kernel-dkms >/dev/null 2>&1 || dpkg -s nvidia-open-kernel-dkms >/dev/null 2>&1; }; then
  sh /usr/lib/phoenixge/gamedisplay/nvidia-modeset.sh on >/dev/null 2>&1 || true
fi
# NVIDIA driver half-installed because the DKMS build failed on a newer kernel -> patch + finish (no-op otherwise)
if [ -d /run/systemd/system ] && [ ! -d /run/live ] && [ -x /usr/lib/phoenixge/nvidia-dkms-fix.sh ] && ls -d /usr/src/nvidia-current* >/dev/null 2>&1; then
  setsid sh /usr/lib/phoenixge/nvidia-dkms-fix.sh >>/var/log/phoenixge-nvidia-fix.log 2>&1 < /dev/null &   # background: dpkg is still locked by this very postinst
fi
# clock (installed systems): dual-boot with Windows -> Windows keeps the hardware clock in LOCAL time; Linux read it as
# UTC -> clock 4 h ahead in Tbilisi (broke TLS, signing keys, logs). Use local RTC once when Windows is on the disk,
# and always keep internet time sync on.
if [ -d /run/systemd/system ] && [ ! -d /run/live ]; then
  if [ -d /boot/efi/EFI/Microsoft ] && [ ! -f /var/lib/phoenixge/rtc-local.done ]; then
    timedatectl set-local-rtc 1 >/dev/null 2>&1 && mkdir -p /var/lib/phoenixge && touch /var/lib/phoenixge/rtc-local.done
  fi
  systemctl enable --now systemd-timesyncd >/dev/null 2>&1 && timedatectl set-ntp true >/dev/null 2>&1 || true
  # local RTC is never written back by Linux -> save the synced time now and at every shutdown
  if [ -f /var/lib/phoenixge/rtc-local.done ]; then
    systemctl daemon-reload >/dev/null 2>&1 || true; systemctl enable --now phoenixge-rtc-save.service >/dev/null 2>&1 || true
    timedatectl show -p NTPSynchronized --value 2>/dev/null | grep -qx yes && timedatectl set-local-rtc 0 >/dev/null 2>&1 && timedatectl set-local-rtc 1 >/dev/null 2>&1 || true
  fi
fi
# NVIDIA: open kernel module installed but the "nvidia" alternative points to the closed one (nvidia-current, not
# built) -> the driver never loads at boot. Point it at current-open.
if [ -d /run/systemd/system ] && [ ! -d /run/live ] && dpkg -s nvidia-open-kernel-dkms >/dev/null 2>&1 && \
   [ -d /usr/lib/nvidia/current-open ] && [ "$(readlink -f /etc/alternatives/nvidia)" != /usr/lib/nvidia/current-open ]; then
  update-alternatives --set nvidia /usr/lib/nvidia/current-open >/dev/null 2>&1 && \
    touch /var/lib/phoenixge/nvidia-reboot-needed || true
fi
# Flatpak games: NVIDIA GL extension + MangoHud layer (background: needs internet, dpkg is locked by this postinst)
if [ -d /run/systemd/system ] && [ ! -d /run/live ] && [ -x /usr/lib/phoenixge/flatpak-gaming.sh ]; then
  setsid sh /usr/lib/phoenixge/flatpak-gaming.sh >>/var/log/phoenixge-flatpak-gaming.log 2>&1 < /dev/null &
fi
# boot animation: rebuild the initramfs only when the PhoenixGe Plymouth theme changed (installed systems)
T=/usr/share/plymouth/themes/phoenixge
if [ -d /run/systemd/system ] && [ ! -d /run/live ] && [ -d "$T" ] && command -v plymouth-set-default-theme >/dev/null; then
  SUM=$(cat "$T"/* | md5sum | cut -d' ' -f1)
  if [ "$SUM" != "$(cat /var/lib/phoenixge/plymouth.md5 2>/dev/null)" ]; then
    plymouth-set-default-theme phoenixge && update-initramfs -u >/dev/null 2>&1 && mkdir -p /var/lib/phoenixge && echo "$SUM" > /var/lib/phoenixge/plymouth.md5
  fi
fi
# Timeshift rsync mode (non-btrfs): older setups copied Flatpak apps/caches and made a full copy at every boot on the
# same disk -> filled small Linux partitions. Exclude the reinstallable parts and stop boot snapshots in rsync mode.
if [ -f /etc/timeshift/timeshift.json ] && command -v python3 >/dev/null; then
  python3 - <<'PY' || true
import json
p = "/etc/timeshift/timeshift.json"
c = json.load(open(p))
ex = c.setdefault("exclude", [])
add = ["/var/lib/flatpak/**", "/var/lib/waydroid/**", "/var/cache/**", "/var/tmp/**", "/swapfile"]
changed = [e for e in add if e not in ex]
ex += changed
if c.get("btrfs_mode") != "true" and c.get("schedule_boot") == "true":
    c["schedule_boot"] = "false"; changed.append("boot")
if changed:
    json.dump(c, open(p, "w"), indent=2)
if c.get("schedule_boot") == "false":
    import os
    try:
        os.remove("/etc/cron.d/timeshift-boot")  # Timeshift only rewrites its cron files when its settings are saved
    except FileNotFoundError:
        pass
PY
fi
# ChatlaxiAI: start through chatlaxi-run.sh (uses the NVIDIA GPU instead of the Intel iGPU on hybrid laptops)
D=/usr/share/applications/ge.chatlaxi.ai.desktop
[ -f "$D" ] && sed -i 's#^Exec=/opt/chatlaxi-ai/chatlaxi_ai#Exec=/usr/lib/phoenixge/chatlaxi-run.sh#' "$D" || true
# FluidSynth (pulled in by Lutris) starts a per-user MIDI daemon that may open the speaker directly through ALSA before
# PipeWire does -> the only output left is "Dummy Output" (no sound at all). Nothing needs the daemon (Lutris starts
# its own synth), so keep it off for every user.
if [ -f /usr/lib/systemd/user/fluidsynth.service ]; then
  systemctl --global disable fluidsynth.service >/dev/null 2>&1 || true
  rm -f /etc/systemd/user/default.target.wants/fluidsynth.service
fi
# PhoenixGe Camera stays visible to apps while DeepFaceLive is closed (placeholder picture; no-op without /dev/video10)
systemctl --global enable phoenixge-vcam-idle.service >/dev/null 2>&1 || true

exit 0
