"""PhoenixGe tweaks for DeepFaceLive (run with DeepFaceLive's own Python, from its app folder).

  deepfacelive_setup.py patch            stream output -> virtual webcam when $PHOENIXGE_VCAM is set, and the
                                         PhoenixGe menu "Use in…" (record, go live, OBS, Discord…) (idempotent)
  deepfacelive_setup.py preset USERDIR   good starting settings: webcam 0, YoloV5 + FaceMesh + DFM swap on the GPU,
                                         Keanu Reeves model, output = swapped picture, virtual camera on.
                                         Only fills in what is missing/broken; the user's own choices stay.
"""
import sys
from pathlib import Path

APP = Path.cwd()
sys.path.insert(0, str(APP))

STREAMER = APP / "xlib/streamer/FFMPEGStreamer.py"
MARK = "# PhoenixGe: virtual webcam"
MARK_V = MARK + " v2"   # v2: fixed 1280x720 (same as the idle picture), stops phoenixge-vcam-idle
APPWIN = APP / "apps/DeepFaceLive/DeepFaceLiveApp.py"
MENU_MARK = "# PhoenixGe: Use in… menu"


def patch():
    patch_streamer()
    patch_menu()


def patch_menu():
    """Our menu "Use in…" (dfl_share.py next to this file) between Language and Help."""
    s = APPWIN.read_text()
    if MENU_MARK in s:
        return print("menu already patched")
    old = "        menu_help = menu_bar.addMenu( L('@QDFLAppWindow.help') )"
    if old not in s:
        return print("DeepFaceLiveApp.py changed upstream - PhoenixGe menu not added")
    here = str(Path(__file__).resolve().parent)
    new = f"""        {MENU_MARK}
        try:
            import sys as _sys
            for _d in ('/usr/lib/phoenixge/dev', {here!r}):
                if _d not in _sys.path:
                    _sys.path.append(_d)
            import dfl_share
            dfl_share.add_menu(menu_bar, self, str(self._userdata_path))
        except Exception as _e:
            print('PhoenixGe menu:', _e)
""" + old
    APPWIN.write_text(s.replace(old, new, 1))
    print("PhoenixGe menu added")


def patch_streamer():
    """DeepFaceLive's 'mpegts udp://' output starts ffmpeg; with PHOENIXGE_VCAM=/dev/videoN it writes to that v4l2
    device instead (the virtual camera "PhoenixGe Camera")."""
    s = STREAMER.read_text()
    if MARK_V in s:
        return print("streamer already patched")
    if MARK in s:   # older PhoenixGe patch: start again from the original file
        import subprocess
        subprocess.run(["git", "checkout", "--", str(STREAMER.relative_to(APP))], cwd=APP, check=True)
        s = STREAMER.read_text()
    old = """                '-i', '-',
                '-f', 'mpegts',
                '-q:v', '2',
                f'udp://{self._addr}:{self._port}'
        ]"""
    new = """                '-i', '-',
        ]
        """ + MARK_V + """ (PHOENIXGE_VCAM=/dev/videoN set by the launcher)
        import os
        vcam = os.environ.get('PHOENIXGE_VCAM')
        if vcam and os.path.exists(vcam):
            import subprocess as _sp   # the "open DeepFaceLive" picture stops; the launcher brings it back on exit
            _sp.run(['systemctl', '--user', 'stop', 'phoenixge-vcam-idle'], capture_output=True)
            # always 1280x720: apps keep the camera when the picture size changes (webcam 640x480, phone 1280x720)
            args = [a for a in args if a != '-re'] + [
                '-vf', 'scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,format=yuv420p',
                '-f', 'v4l2', vcam]
        else:
            args += ['-f', 'mpegts', '-q:v', '2', f'udp://{self._addr}:{self._port}']"""
    if old not in s:
        sys.exit("FFMPEGStreamer.py changed upstream - virtual camera patch not applied")
    STREAMER.write_text(s.replace(old, new))
    print("streamer patched for the virtual camera")


def preset(userdir):
    import apps.DeepFaceLive.backend  # noqa: F401  (imports every backend module)
    from modelhub import DFLive
    from xlib import onnxruntime as lib_ort
    from xlib.db import KeyValueDB
    M = lambda n: sys.modules["apps.DeepFaceLive.backend." + n]  # noqa: E731

    settings = Path(userdir) / "settings"
    settings.mkdir(parents=True, exist_ok=True)
    db = KeyValueDB(settings / "states.dat")
    d = db._data
    devs = lib_ort.get_available_devices_info()
    gpu = next((x for x in devs if "CUDA" in str(x)), devs[0] if devs else None)
    print("device:", gpu)

    # one chain: camera -> detect -> landmarks -> align -> DFM swap -> merge -> output
    for k, on in {"FileSource": False, "CameraSource": True, "FaceDetector": True, "FaceMarker": True,
                  "FaceAligner": True, "FaceAnimator": False, "FaceSwapInsight": False, "FaceSwapDFM": True,
                  "FrameAdjuster": True, "FaceMerger": True, "StreamOutput": True}.items():
        d[f"{k}_host_onoff"] = on

    CS = M("CameraSource")
    cs = d.get("CameraSource_worker_state") or CS.WorkerState()
    if cs.driver not in (CS._DriverType.COMPATIBLE, CS._DriverType.GSTREAMER):  # DirectShow/MSMF are Windows-only
        cs.driver = CS._DriverType.COMPATIBLE
    if cs.device_idx is None:
        cs.device_idx = 0
    d["CameraSource_worker_state"] = cs

    FD = M("FaceDetector")
    fd = d.get("FaceDetector_worker_state") or FD.WorkerState()
    if fd.detector_type is None:
        fd.detector_type = FD.DetectorType.YOLOV5
    for st in (fd.YoloV5_state, fd.center_face_state, fd.S3FD_state):
        if st.device is None:
            st.device = gpu
    d["FaceDetector_worker_state"] = fd

    FM = M("FaceMarker")
    fm = d.get("FaceMarker_worker_state") or FM.WorkerState()
    if fm.marker_type is None:
        fm.marker_type = FM.MarkerType.GOOGLE_FACEMESH
    for st in (fm.google_facemesh_state, fm.insightface_2d106_state):
        if st.device is None:
            st.device = gpu
    d["FaceMarker_worker_state"] = fm

    SW = M("FaceSwapDFM")
    sw = d.get("FaceSwapDFM_worker_state") or SW.WorkerState()
    if sw.device is None:
        sw.device = gpu
    if sw.model is None:
        models = DFLive.get_available_models_info(Path(userdir) / "dfm_models")
        sw.model = next((m for m in models if m.get_name() == "Keanu Reeves"), None)
    d["FaceSwapDFM_worker_state"] = sw

    SO = M("StreamOutput")
    so = d.get("StreamOutput_worker_state") or SO.WorkerState()
    # what other apps see: the swapped picture, the plain camera picture while no face is found
    so.source_type = SO.SourceType.MERGED_FRAME_OR_SOURCE_FRAME
    so.is_streaming = True
    d["StreamOutput_worker_state"] = so

    db._save_data()
    print("preset written:", settings / "states.dat")


if __name__ == "__main__":
    {"patch": lambda: patch(), "preset": lambda: preset(sys.argv[2])}[sys.argv[1]]()
