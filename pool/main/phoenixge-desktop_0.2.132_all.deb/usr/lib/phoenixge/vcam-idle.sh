#!/bin/sh
# Keeps the virtual webcam "PhoenixGe Camera" (/dev/video10) alive while DeepFaceLive is closed: a still picture at 5 fps.
# Why: a v4l2loopback camera only counts as a camera while something writes into it - without this, Discord, browsers
# and PipeWire don't list it (or keep an old list), and a call can't be started before DeepFaceLive runs.
# DeepFaceLive stops this service when its stream starts and the launcher starts it again when DeepFaceLive closes.
# Same format as DeepFaceLive's stream (1280x720 yuv420p), so apps keep the camera when the picture switches.
V=/dev/video10
IMG=/usr/share/phoenixge/vcam-idle.png
[ -w "$V" ] || exit 0
command -v ffmpeg >/dev/null || exit 0
# take the format from our writer (1280x720 yuv420p), then keep it so readers survive the switch to DeepFaceLive
v4l2-ctl -d "$V" -c keep_format=0 >/dev/null 2>&1 || true
# the picture converted once to a raw frame: sending it is then only a memory copy (~1 % CPU)
RAW="${XDG_RUNTIME_DIR:-/tmp}/phoenixge-vcam-idle.yuv"
[ -s "$RAW" ] || ffmpeg -hide_banner -loglevel error -i "$IMG" -vf "scale=1280:720,format=yuv420p" -frames:v 1 \
  -f rawvideo -y "$RAW" || exit 1
ffmpeg -hide_banner -loglevel error -re -stream_loop -1 -f rawvideo -pix_fmt yuv420p -s 1280x720 -framerate 10 -i "$RAW" \
  -c:v copy -f v4l2 "$V" &
PID=$!
trap 'kill $PID 2>/dev/null; exit 0' TERM INT
sleep 2
v4l2-ctl -d "$V" -c keep_format=1,sustain_framerate=1,timeout=3000 >/dev/null 2>&1 || true
# PipeWire (Discord, browsers via the camera portal) scanned the cameras before we wrote anything: rescan once
( sleep 2; wpctl status 2>/dev/null | grep -q "PhoenixGe Camera (V4L2)" || systemctl --user restart wireplumber ) &
wait $PID
