#!/bin/sh
# initramfs-tools hook: tools + settings for grow-root-premount.sh (only while a grow is pending)
PREREQ=""
prereqs() { echo "$PREREQ"; }
case "$1" in prereqs) prereqs; exit 0 ;; esac
. /usr/share/initramfs-tools/hook-functions
[ -f /etc/phoenixge-grow.conf ] || exit 0
for b in /usr/sbin/sfdisk /usr/sbin/e2fsck /usr/sbin/resize2fs /usr/bin/partx /usr/sbin/blockdev; do
  [ -x "$b" ] && copy_exec "$b" /sbin
done
mkdir -p "$DESTDIR/etc" && cp /etc/phoenixge-grow.conf "$DESTDIR/etc/"
