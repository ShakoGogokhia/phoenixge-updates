#!/bin/sh
# After the boot that grew the root partition: remove the pending-grow settings and rebuild the initramfs without them.
. /etc/phoenixge-grow.conf 2>/dev/null || exit 0
case "$DISK" in *nvme*|*mmcblk*|*loop*) DEV="${DISK}p$PART" ;; *) DEV="$DISK$PART" ;; esac
[ "$(cat /sys/class/block/$(basename "$DEV")/start 2>/dev/null)" = "$OLD_START" ] && exit 0   # not done yet
rm -f /etc/phoenixge-grow.conf
update-initramfs -u >/dev/null 2>&1 || true
systemctl disable phoenixge-grow-cleanup.service >/dev/null 2>&1 || true
echo "PhoenixGe: root partition grown, cleanup done: $(df -h / | awk 'NR==2{print $2}')"
