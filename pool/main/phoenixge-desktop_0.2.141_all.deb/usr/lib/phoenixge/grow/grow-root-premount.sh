#!/bin/sh
# PhoenixGe: grow the Linux root partition into free space directly BEFORE it (e.g. space taken from Windows).
# Runs in the initramfs (local-premount) before the root file system is mounted - the only time the partition start
# can move. Does nothing unless /etc/phoenixge-grow.conf (copied into the initramfs) describes a pending grow AND the
# partition still starts where that file says (so it can never run twice).
#   DISK=/dev/nvme0n1  PART=6  OLD_START=<sector>  NEW_START=<sector>
PREREQ=""
prereqs() { echo "$PREREQ"; }
case "$1" in prereqs) prereqs; exit 0 ;; esac

CONF=${PHOENIXGE_GROW_CONF:-/etc/phoenixge-grow.conf}
[ -f "$CONF" ] || exit 0
. "$CONF"
[ -n "$DISK" ] && [ -n "$PART" ] && [ -n "$OLD_START" ] && [ -n "$NEW_START" ] || exit 0
case "$DISK" in *nvme*|*mmcblk*|*loop*) DEV="${DISK}p$PART" ;; *) DEV="$DISK$PART" ;; esac
NAME=$(basename "$DEV")
[ -b "$DEV" ] || exit 0
START=$(cat /sys/class/block/$NAME/start 2>/dev/null)
SIZE=$(cat /sys/class/block/$NAME/size 2>/dev/null)
[ "$START" = "$OLD_START" ] || exit 0             # already done (or the disk changed): never touch it
[ "$NEW_START" -lt "$OLD_START" ] || exit 0
END=$((START + SIZE - 1))
NEW_SIZE=$((END - NEW_START + 1))

say() { echo "PhoenixGe: $*"; [ -x /bin/plymouth ] && plymouth display-message --text="$*" 2>/dev/null; }
say "Making the Linux disk bigger - a few minutes, do not switch off the computer."
e2fsck -f -p "$DEV"; rc=$?
if [ $rc -gt 1 ]; then say "Disk check failed ($rc) - not resizing."; exit 0; fi
# move the partition (and its data) to the new start, keep its end: sfdisk copies the data safely even when overlapping
if echo "$NEW_START,$NEW_SIZE" | sfdisk --no-tell-kernel --move-data=/run/phoenixge-grow-move.log -N "$PART" "$DISK"; then
  partx -u "$DISK" 2>/dev/null || blockdev --rereadpt "$DISK" 2>/dev/null
  sleep 1
  e2fsck -f -y "$DEV"
  resize2fs "$DEV"
  say "Linux disk is bigger now."
else
  say "Moving the partition failed - nothing changed was committed."
fi
exit 0
