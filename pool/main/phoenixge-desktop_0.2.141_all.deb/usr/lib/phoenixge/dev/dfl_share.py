"""PhoenixGe menu "Use in…" inside DeepFaceLive (runs in DeepFaceLive's own Python 3.8 + PyQt6).

Pick where the swapped face should go and it is set up by itself:
  Record video          ~/Videos/DeepFaceLive/*.mp4 (picture from "PhoenixGe Camera" + your microphone)
  Go live               YouTube / Twitch / Kick / any RTMP server (stream key asked once)
  OBS Studio            ready scene "DeepFaceLive" (camera + microphone), installs OBS when missing
  Discord, Telegram,…   opens the app (installs it when missing) + shows where to pick "PhoenixGe Camera" (once)
  Phone as camera       Android phone camera (USB or Wi-Fi adb) via scrcpy, or iPhone via the free app IP Camera Lite
                        (MJPEG over Wi-Fi, or USB through iproxy) -> "PhoenixGe Phone" (/dev/video11), and
                        DeepFaceLive's Camera source switches to it by itself (back when stopped)
Hooked into DeepFaceLiveApp.py by deepfacelive_setup.py patch (add_menu).
"""
import json
import os
import re
import shutil
import subprocess
import time
import uuid
from pathlib import Path
from urllib.parse import quote

from PyQt6.QtCore import QProcess, QTimer, QUrl
from PyQt6.QtGui import QDesktopServices
from PyQt6.QtWidgets import QInputDialog, QLineEdit, QMessageBox

VCAM = "/dev/video10"
PHONE_NR = 11
PHONE = f"/dev/video{PHONE_NR}"
IPROXY_PORT = 18081   # iPhone over USB: iproxy forwards the app's port 8081 here
HOME = Path.home()
CFG = HOME / ".config/phoenixge/deepfacelive-share.json"
VIDEOS = HOME / "Videos/DeepFaceLive"
OBS_ID = "com.obsproject.Studio"

LIVE = {  # name: (rtmp url, where to find the key)
    "YouTube": ("rtmp://a.rtmp.youtube.com/live2", "https://studio.youtube.com -> Go live -> Stream -> Stream key"),
    "Twitch": ("rtmp://live.twitch.tv/app", "https://dashboard.twitch.tv/settings/stream -> Primary stream key"),
    "Kick": ("rtmps://fa723fc1b171.global-contribute.live-video.net/app",
             "https://kick.com/dashboard/settings/stream -> Stream URL + Stream key"),
    "Facebook": ("rtmps://live-api-s.facebook.com:443/rtmp", "https://facebook.com/live/producer -> Stream key"),
}

APPS = [  # name, flatpak id, native command, web url, where to pick the camera
    ("Discord", "com.discordapp.Discord", "discord", None,
     "Discord: ⚙ User Settings → Voice & Video → Camera → PhoenixGe Camera.\n"
     "Video Background must be 'None' there: Discord's backgrounds/blur don't work on Linux and then Discord says "
     "'Something went wrong' and turns the camera off."),
    ("Telegram", "org.telegram.desktop", "telegram-desktop", None,
     "Telegram: ☰ → Settings → Advanced → Call settings → Camera → PhoenixGe Camera"),
    ("Zoom", "us.zoom.Zoom", "zoom", None, "Zoom: ⚙ Settings → Video → Camera → PhoenixGe Camera"),
    ("Google Meet", None, None, "https://meet.google.com",
     "Google Meet: ⋮ → Settings → Video → Camera → PhoenixGe Camera (the browser asks once for camera access)"),
    ("Microsoft Teams", None, None, "https://teams.microsoft.com",
     "Teams: ⋯ → Settings → Devices → Camera → PhoenixGe Camera"),
    ("Skype / browser video call", None, None, "https://web.skype.com",
     "In the call: camera settings → PhoenixGe Camera"),
]


def local_ip():
    import socket
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as so:
            so.connect(("192.0.2.1", 9))     # no packet is sent; just picks the LAN address
            return so.getsockname()[0]
    except OSError:
        return "127.0.0.1"


def iphone_on_usb():
    if not shutil.which("idevice_id") or not shutil.which("iproxy"):
        return False
    try:
        return bool(subprocess.run(["idevice_id", "-l"], capture_output=True, text=True, timeout=5).stdout.strip())
    except (OSError, subprocess.TimeoutExpired):
        return False


def qr_pixmap(text, box=6):
    try:
        import qrcode
        from PyQt6.QtGui import QColor, QPainter, QPixmap
    except ImportError:
        return None
    q = qrcode.QRCode(border=2)
    q.add_data(text)
    q.make(fit=True)
    m = q.get_matrix()
    n = len(m)
    pm = QPixmap(n * box, n * box)
    pm.fill(QColor("white"))
    p = QPainter(pm)
    for y, row in enumerate(m):
        for x, on in enumerate(row):
            if on:
                p.fillRect(x * box, y * box, box, box, QColor("black"))
    p.end()
    return pm


def load():
    try:
        return json.loads(CFG.read_text())
    except (OSError, ValueError):
        return {}


def save(c):
    CFG.parent.mkdir(parents=True, exist_ok=True)
    CFG.write_text(json.dumps(c, indent=2))
    os.chmod(CFG, 0o600)   # stream keys


def target_delay_s(userdir):
    """Stream output delays the picture by "Target delay" (default 500 ms) - the microphone gets the same delay."""
    try:
        import pickle
        d = pickle.loads((Path(userdir) / "settings/states.dat").read_bytes())
        st = d.get("StreamOutput_worker_state")
        st = pickle.loads(st) if isinstance(st, bytes) else st
        return max(0.0, (getattr(st, "target_delay", None) or 500) / 1000.0)
    except Exception:  # noqa: BLE001
        return 0.5


def flatpak_has(app_id):
    return subprocess.run(["flatpak", "info", app_id], capture_output=True).returncode == 0


_ENC = []


def encoder():
    """NVIDIA's hardware encoder when it works (no CPU load), else x264."""
    if _ENC:
        return _ENC[0]
    _ENC.append(["-c:v", "libx264", "-preset", "veryfast", "-crf", "21"])
    try:
        r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", "color=s=256x256:d=0.1",
                            "-c:v", "h264_nvenc", "-f", "null", "-"], capture_output=True, timeout=20)
        if r.returncode == 0:
            _ENC[0] = ["-c:v", "h264_nvenc", "-preset", "p4", "-b:v", "6M"]
    except (OSError, subprocess.TimeoutExpired):
        pass
    return _ENC[0]


class Share:
    def __init__(self, menu_bar, window, userdir):
        self.win = window
        self.userdir = userdir
        self.proc = None          # running ffmpeg (record or live)
        self.phone = None         # running scrcpy (phone camera)
        self.phone_prev_idx = None
        self.what = ""
        self.started = 0
        self.menu = menu_bar.addMenu("🔥 Use in…")
        self.menu.aboutToShow.connect(self.build)
        self.timer = QTimer()
        self.timer.timeout.connect(self.tick)

    # ---------------------------------------------------------------- menu
    def build(self):
        m = self.menu
        m.clear()
        if not os.path.exists(VCAM):
            m.addAction("⚠ Set up the virtual camera (PhoenixGe Camera)…", self.setup_vcam)
            m.addSeparator()
        if self.proc:
            m.addAction(f"■ Stop {self.what} ({self.elapsed()})", self.stop)
            m.addSeparator()
        else:
            m.addAction("⏺ Record video (with microphone)", self.record)
            live = m.addMenu("📡 Go live")
            for name in LIVE:
                live.addAction(name, lambda n=name: self.go_live(n))
            live.addAction("Other RTMP server…", lambda: self.go_live(None))
            live.addSeparator()
            live.addAction("Forget saved stream keys", self.forget_keys)
        if self.phone:
            m.addAction("📱 Stop the phone camera (back to the webcam)", self.phone_stop)
        else:
            ph = m.addMenu("📱 Phone as camera")
            ph.addAction("Android: back camera (best quality)", lambda: self.phone_start("back"))
            ph.addAction("Android: front camera (selfie)", lambda: self.phone_start("front"))
            ph.addSeparator()
            ph.addAction("iPhone (free app IP Camera Lite)…", self.iphone_start)
        m.addAction("🎬 OBS Studio (ready scene)", self.obs)
        m.addSeparator()
        for name, fp, cmd, url, tip in APPS:
            m.addAction(f"💬 {name}", lambda a=(name, fp, cmd, url, tip): self.open_app(*a))
        m.addSeparator()
        m.addAction("📂 Open my recordings", lambda: (VIDEOS.mkdir(parents=True, exist_ok=True),
                                                     QDesktopServices.openUrl(QUrl.fromLocalFile(str(VIDEOS)))))

    def info(self, title, text):
        QMessageBox.information(self.win, title, text)

    def need_vcam(self):
        if os.path.exists(VCAM):
            return True
        if QMessageBox.question(self.win, "PhoenixGe Camera", "The virtual camera isn't set up yet. Set it up now? "
                                "(asks for your password, then restart DeepFaceLive)") == QMessageBox.StandardButton.Yes:
            self.setup_vcam()
        return False

    def setup_vcam(self):
        QProcess.startDetached("pkexec", ["sh", "/usr/lib/phoenixge/vcam-setup.sh"])
        self.info("PhoenixGe Camera", "When the password window is done, restart DeepFaceLive (File → Quit, open it again).")

    # ---------------------------------------------------------------- record / live (ffmpeg from the virtual camera)
    def ffmpeg(self, what, out_args):
        if not self.need_vcam() or not shutil.which("ffmpeg"):
            return
        delay = target_delay_s(self.userdir)
        args = ["-hide_banner", "-loglevel", "error", "-thread_queue_size", "512",
                "-f", "v4l2", "-framerate", "30", "-i", VCAM,
                "-thread_queue_size", "512", "-f", "pulse", "-i", "default",
                "-af", f"adelay={int(delay * 1000)}:all=1,aresample=async=1",
                "-pix_fmt", "yuv420p", "-g", "60"] + encoder() + ["-c:a", "aac", "-b:a", "160k"] + out_args
        p = QProcess()
        p.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
        p.finished.connect(lambda *_a: self.ended(p))
        p.start("ffmpeg", args)
        if not p.waitForStarted(5000):
            return self.info("DeepFaceLive", "ffmpeg could not start.")
        self.proc, self.what, self.started = p, what, time.time()
        self.timer.start(1000)
        self.menu.setTitle(f"🔴 {what}")

    def record(self):
        VIDEOS.mkdir(parents=True, exist_ok=True)
        self.file = VIDEOS / time.strftime("DeepFaceLive %Y-%m-%d %H-%M-%S.mp4")
        self.ffmpeg("recording", ["-movflags", "+faststart", "-y", str(self.file)])

    def go_live(self, name):
        c = load()
        keys = c.setdefault("keys", {})
        if name is None:
            url, ok = QInputDialog.getText(self.win, "Go live", "RTMP server address (rtmp://…):",
                                           text=c.get("custom_url", ""))
            if not ok or not url.strip().startswith(("rtmp://", "rtmps://")):
                return
            c["custom_url"] = url = url.strip().rstrip("/")
            name = "custom"
            where = "your streaming service's settings"
        else:
            url, where = LIVE[name]
        key = keys.get(name)
        if not key:
            key, ok = QInputDialog.getText(self.win, f"Go live on {name.title()}",
                                           f"Stream key (saved on this computer only):\n{where}", QLineEdit.EchoMode.Password)
            if not ok or not key.strip():
                return
            keys[name] = key = key.strip()
        save(c)
        self.live_target = name
        self.ffmpeg(f"live on {name.title()}", ["-f", "flv", f"{url}/{key}"])

    def forget_keys(self):
        c = load(); c.pop("keys", None); save(c)
        self.info("Go live", "Saved stream keys removed.")

    def stop(self):
        if self.proc:
            self.proc.write(b"q")         # ffmpeg finishes the file properly
            self.proc.closeWriteChannel()
            QTimer.singleShot(5000, lambda p=self.proc: p and p.state() != QProcess.ProcessState.NotRunning and p.kill())

    def ended(self, p):
        out = bytes(p.readAll()).decode(errors="replace").strip()
        what = self.what
        self.proc, self.what = None, ""
        self.timer.stop()
        self.menu.setTitle("🔥 Use in…")
        secs = int(time.time() - self.started)
        if what == "recording":
            f = getattr(self, "file", None)
            if f and f.exists() and f.stat().st_size > 10000:
                if QMessageBox.question(self.win, "Recording saved", f"{f.name}\n{secs // 60}:{secs % 60:02d}, "
                                        f"{f.stat().st_size >> 20} MB\n\nOpen the folder?") == QMessageBox.StandardButton.Yes:
                    QDesktopServices.openUrl(QUrl.fromLocalFile(str(VIDEOS)))
            else:
                self.info("Recording", "Nothing was recorded.\n" + out[-600:])
        elif secs < 15 and out:
            if re.search(r"Input/output error|Connection refused|401|403|404|I/O error", out) and getattr(self, "live_target", None):
                c = load(); c.get("keys", {}).pop(self.live_target, None); save(c)
                out += "\n\nThe saved stream key was removed - check it and try again."
            self.info("Live stream stopped", out[-800:])

    def elapsed(self):
        s = int(time.time() - self.started)
        return f"{s // 60}:{s % 60:02d}"

    def tick(self):
        if self.proc:
            self.menu.setTitle(f"🔴 {self.what} {self.elapsed()}")

    # ---------------------------------------------------------------- phone camera (scrcpy -> v4l2loopback)
    def phone_start(self, facing):
        self.phone_is_ios = False
        if not self._phone_device():
            return
        ver = subprocess.run(["scrcpy", "--version"], capture_output=True, text=True).stdout if shutil.which("scrcpy") else ""
        m = re.search(r"scrcpy (\d+)\.(\d+)", ver)
        if not m or (int(m.group(1)), int(m.group(2))) < (2, 2):
            if QMessageBox.question(self.win, "Phone as camera", "This needs scrcpy 2.2 or newer. Install it now? "
                                    "(asks for your password)") == QMessageBox.StandardButton.Yes:
                p = QProcess(self.win)
                p.finished.connect(lambda code, _s: code == 0 and self.phone_start(facing))
                p.start("pkexec", ["sh", "/usr/lib/phoenixge/apt-install.sh", "-b", "scrcpy", "adb"])
            return
        devs = [l.split()[0] for l in subprocess.run(["adb", "devices"], capture_output=True, text=True,
                                                       timeout=20).stdout.splitlines()[1:] if l.endswith("\tdevice")]
        if not devs:
            return self.info("Phone as camera", "No phone found.\n\n1. Phone: Settings → About phone → tap 'Build number' 7 "
                             "times.\n2. Settings → Developer options → USB debugging ON.\n3. Connect it with USB and "
                             "allow 'USB debugging' on the phone.\n\nWithout a cable: PhoenixGe Center → Developer → "
                             "Android phone over Wi-Fi.\n\nAndroid 12 or newer is needed for the camera.")
        serial = next((d for d in devs if ":" not in d), devs[0])   # USB first (faster than Wi-Fi)
        p = QProcess()
        p.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
        p.readyReadStandardOutput.connect(lambda: self.phone_read(p))
        p.finished.connect(lambda *_a: self.phone_ended(p))
        self.phone_log, self.phone_ok = "", False
        p.start("scrcpy", ["-s", serial, "--video-source=camera", f"--camera-facing={facing}", "--max-size=1280",
                           "--camera-fps=30", "--no-audio", "--no-window", "--no-control",
                           f"--v4l2-sink={PHONE}", "--v4l2-buffer=0"])
        self.phone = p
        self.menu.setTitle("📱 starting the phone camera…")

    def _phone_device(self):
        if not os.path.exists(PHONE):
            subprocess.run(["v4l2loopback-ctl", "add", "-n", "PhoenixGe Phone", "-x", "1", str(PHONE_NR)],
                           capture_output=True, timeout=15)
        if os.path.exists(PHONE) and os.access(PHONE, os.W_OK):
            return True
        QProcess.startDetached("pkexec", ["sh", "/usr/lib/phoenixge/vcam-setup.sh"])
        self.info("Phone as camera", "Setting up the phone camera device (password window). Then restart DeepFaceLive "
                  "and choose the phone again.")
        return False

    def iphone_start(self):
        """iPhone: the free app IP Camera Lite serves the camera as MJPEG on port 8081 (Wi-Fi, or USB through iproxy);
        ffmpeg puts it into "PhoenixGe Phone". (Larix Broadcaster's free version stamps "TEST STREAM" on the picture.)"""
        if not self._phone_device():
            return
        from PyQt6.QtCore import Qt
        from PyQt6.QtWidgets import QComboBox, QDialog, QDialogButtonBox, QFormLayout, QLabel, QLineEdit, QVBoxLayout
        c = load()
        usb = iphone_on_usb()
        d = QDialog(self.win)
        d.setWindowTitle("iPhone as camera")
        lay = QVBoxLayout(d)
        t = QLabel("<b>1.</b> On the iPhone install <b>IP Camera Lite</b> (free, App Store) and open it.<br>"
                   "<b>2.</b> Tap <b>Turn on IP Camera Server</b> (allow camera and 'Local Network').<br>"
                   "<b>3.</b> " + ("<b>iPhone found on USB</b> - nothing to type, press Connect."
                                   if usb else "Type the address the app shows (http://192.168.…:8081), press Connect. "
                                   "Or connect the iPhone with its cable (tap 'Trust') - then no address is needed.")
                   + "<br><br>Front/back camera: switch it in the app. The iPhone and this computer must be on the "
                     "same Wi-Fi (not needed with the cable).")
        t.setWordWrap(True); t.setMinimumWidth(460); lay.addWidget(t)
        f = QFormLayout()
        addr = QLineEdit(c.get("iphone_addr", "")); addr.setPlaceholderText("http://192.168.1.23:8081")
        addr.setEnabled(not usb)
        user = QLineEdit(c.get("iphone_user", "admin")); pw = QLineEdit(c.get("iphone_pass", "admin"))
        rot = QComboBox()
        for label, vf in (("as it comes", ""), ("turn right 90°", "transpose=1"), ("turn left 90°", "transpose=2"),
                          ("upside down", "transpose=1,transpose=1")):
            rot.addItem(label, vf)
        rot.setCurrentIndex(max(0, rot.findData(c.get("iphone_rotate", ""))))
        f.addRow("Address", addr); f.addRow("User / password", user); f.addRow("", pw); f.addRow("Picture", rot)
        lay.addLayout(f)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.button(QDialogButtonBox.StandardButton.Ok).setText("Connect")
        bb.accepted.connect(d.accept); bb.rejected.connect(d.reject); lay.addWidget(bb)
        if d.exec() != QDialog.DialogCode.Accepted:
            return
        a = addr.text().strip().rstrip("/")
        if not usb and not a:
            return self.info("iPhone as camera", "Type the address the app shows, or connect the iPhone with its cable.")
        if a and not a.startswith("http"):
            a = "http://" + a
        if a and not re.search(r":\d+$", a):
            a += ":8081"
        c.update(iphone_addr=a, iphone_user=user.text().strip(), iphone_pass=pw.text(), iphone_rotate=rot.currentData())
        save(c)
        self.iproxy = None
        if usb:
            self.iproxy = QProcess()
            self.iproxy.start("iproxy", [str(IPROXY_PORT), "8081"])
            host = f"http://127.0.0.1:{IPROXY_PORT}"
        else:
            host = a
        u = quote(c["iphone_user"], safe=""); pwd = quote(c["iphone_pass"], safe="")
        src = host.replace("://", f"://{u}:{pwd}@", 1) + "/video"
        vf = (c["iphone_rotate"] + "," if c["iphone_rotate"] else "") + \
            "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,format=yuv420p"
        p = QProcess()
        p.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
        p.readyReadStandardOutput.connect(lambda: self.phone_read(p))
        p.finished.connect(lambda *_a: self.phone_ended(p))
        self.phone_log, self.phone_ok, self.phone_is_ios = "", False, True
        p.start("ffmpeg", ["-hide_banner", "-loglevel", "info", "-nostats",   # "Output #0" = the picture arrives
                           "-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_on_network_error", "1",
                           "-reconnect_delay_max", "4", "-i", src, "-vf", vf, "-f", "v4l2", PHONE])
        self.phone = p
        self.menu.setTitle("📱 connecting to the iPhone…")

    def phone_read(self, p):
        out = bytes(p.readAllStandardOutput()).decode(errors="replace")
        self.phone_log += out
        try:   # for support: what the phone camera process said
            with open(HOME / ".cache/phoenixge/dfl-phone.log", "a") as f:
                f.write(out)
        except OSError:
            pass
        started = ("v4l2 sink started" in self.phone_log.lower() or "Texture:" in self.phone_log
                   or "Device: " in self.phone_log or "Output #0, video4linux2" in self.phone_log)
        if not self.phone_ok and started:
            self.phone_ok = True
            QTimer.singleShot(2500, lambda: self.phone is not None and self.phone_switch_dfl())

    def camera_index_combo(self):
        """DeepFaceLive's Camera source > Device index combo box (choices 0..15)."""
        from PyQt6.QtWidgets import QComboBox
        try:
            from apps.DeepFaceLive.ui.QCameraSource import QCameraSource
        except Exception:  # noqa: BLE001
            return None
        for panel in self.win.findChildren(QCameraSource):
            for cb in panel.findChildren(QComboBox):
                items = [cb.itemText(i) for i in range(cb.count())]
                if "11" in items and "15" in items and hasattr(cb, "_csw_switch"):
                    return cb
        return None

    def phone_switch_dfl(self, back=False):
        cb = self.camera_index_combo()
        if cb is None:
            return self.info("Phone as camera", f"The phone camera runs. In 'Camera source' choose Device index {PHONE_NR}.")
        if back:
            idx = self.phone_prev_idx if self.phone_prev_idx not in (None, PHONE_NR) else 0
        else:
            cur = cb.currentText()
            self.phone_prev_idx = int(cur) if cur.isdigit() else 0
            idx = PHONE_NR
        cb._csw_switch.select(idx)
        if not back:
            self.menu.setTitle("📱 phone camera")

    def phone_stop(self):
        if self.phone:
            self.phone.terminate()

    def phone_ended(self, p):
        was_ok = self.phone_ok
        self.phone = None
        self.menu.setTitle("🔥 Use in…")
        if was_ok:
            self.phone_switch_dfl(back=True)
        if getattr(self, "iproxy", None) is not None:
            self.iproxy.kill(); self.iproxy = None
        if was_ok:
            pass
        elif getattr(self, "phone_is_ios", False):
            log = self.phone_log
            why = ("Wrong user/password (the app's settings: Login and password)." if "401" in log else
                   "No answer from the iPhone: is 'IP Camera Server' on in the app, the address right and the iPhone "
                   "on the same Wi-Fi? (Or use the USB cable.)")
            self.info("iPhone as camera", "The iPhone camera stopped.\n\n" + why + "\n\n" + log.strip()[-500:])
        else:
            log = self.phone_log.strip()
            hint = ""
            if "camera" in log.lower() and ("api" in log.lower() or "android 12" in log.lower() or "not supported" in log.lower()):
                hint = "\n\nThe phone camera needs Android 12 or newer."
            self.info("Phone as camera", "The phone camera stopped.\n\n" + log[-900:] + hint)

    # ---------------------------------------------------------------- OBS
    def obs(self):
        if not self.need_vcam():
            return
        if not flatpak_has(OBS_ID) and not shutil.which("obs"):
            if QMessageBox.question(self.win, "OBS Studio", "OBS Studio isn't installed. Install it now (Flathub, ~400 MB)?") \
                    != QMessageBox.StandardButton.Yes:
                return
            p = QProcess(self.win)
            p.finished.connect(lambda code, _s: code == 0 and self.obs())
            p.start("flatpak", ["install", "-y", "--noninteractive", "flathub", OBS_ID])
            self.info("OBS Studio", "Installing OBS in the background - it opens by itself when done.")
            return
        native = shutil.which("obs") and not flatpak_has(OBS_ID)
        base = (HOME / ".config/obs-studio") if native else (HOME / ".var/app" / OBS_ID / "config/obs-studio")
        scenes = base / "basic/scenes"
        scenes.mkdir(parents=True, exist_ok=True)
        f = scenes / "DeepFaceLive.json"
        if not f.exists():
            f.write_text(json.dumps(obs_collection(), indent=1))
        args = ["--collection", "DeepFaceLive", "--scene", "DeepFaceLive"]
        if native:
            QProcess.startDetached("obs", args)
        else:
            QProcess.startDetached("flatpak", ["run", OBS_ID] + args)

    # ---------------------------------------------------------------- video-call apps
    def open_app(self, name, fp, cmd, url, tip):
        if not self.need_vcam():
            return
        c = load()
        shown = c.setdefault("tips", [])
        if url:
            QDesktopServices.openUrl(QUrl(url))
        elif fp and flatpak_has(fp):
            QProcess.startDetached("flatpak", ["run", fp])
        elif cmd and shutil.which(cmd):
            QProcess.startDetached(cmd, [])
        elif fp:
            if QMessageBox.question(self.win, name, f"{name} isn't installed. Install it now (Flathub)?") \
                    != QMessageBox.StandardButton.Yes:
                return
            p = QProcess(self.win)
            p.finished.connect(lambda code, _s: code == 0 and QProcess.startDetached("flatpak", ["run", fp]))
            p.start("flatpak", ["install", "-y", "--noninteractive", "flathub", fp])
            self.info(name, f"Installing {name} in the background - it opens by itself when done.\n\n{tip}")
            shown.append(name); save(c)
            return
        if name not in shown:
            self.info(name, f"{tip}\n\nOnly once: {name} remembers the camera. Keep DeepFaceLive open during the call.")
            shown.append(name); save(c)


def obs_collection():
    cam, mic, scene = str(uuid.uuid4()), str(uuid.uuid4()), str(uuid.uuid4())
    return {
        "name": "DeepFaceLive",
        "current_scene": "DeepFaceLive", "current_program_scene": "DeepFaceLive",
        "scene_order": [{"name": "DeepFaceLive"}],
        "sources": [
            {"id": "v4l2_input", "versioned_id": "v4l2_input", "name": "PhoenixGe Camera", "uuid": cam,
             "settings": {"device_id": VCAM, "input": 0, "auto_reset": True}, "enabled": True, "flags": 0,
             "mixers": 0, "volume": 1.0, "muted": False},
            {"id": "pulse_input_capture", "versioned_id": "pulse_input_capture", "name": "Microphone", "uuid": mic,
             "settings": {"device_id": "default"}, "enabled": True, "flags": 0, "mixers": 255, "volume": 1.0,
             "muted": False},
            {"id": "scene", "versioned_id": "scene", "name": "DeepFaceLive", "uuid": scene, "enabled": True, "flags": 0,
             "mixers": 0, "volume": 1.0, "muted": False,
             "settings": {"id_counter": 2, "custom_size": False, "items": [
                 {"name": "PhoenixGe Camera", "source_uuid": cam, "visible": True, "locked": False, "id": 1,
                  "pos": {"x": 0.0, "y": 0.0}, "rot": 0.0, "scale": {"x": 1.0, "y": 1.0}, "align": 5,
                  "bounds_type": 2, "bounds_align": 0, "bounds": {"x": 1920.0, "y": 1080.0}},
                 {"name": "Microphone", "source_uuid": mic, "visible": True, "locked": False, "id": 2,
                  "pos": {"x": 0.0, "y": 0.0}, "rot": 0.0, "scale": {"x": 1.0, "y": 1.0}, "align": 5,
                  "bounds_type": 0, "bounds_align": 0, "bounds": {"x": 0.0, "y": 0.0}}]}},
        ],
        "transitions": [], "current_transition": "Fade", "transition_duration": 300,
    }


_share = None


def add_menu(menu_bar, window, userdir=None):
    global _share
    _share = Share(menu_bar, window, userdir or str(HOME / "DeepFaceLive"))
    return _share
