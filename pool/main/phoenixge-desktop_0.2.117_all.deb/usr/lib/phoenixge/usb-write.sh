#!/bin/sh
# PhoenixGe Center > USB Creator: write an ISO to a USB stick, then verify it (run with pkexec).
#   usb-write.sh /path/to/file.iso /dev/sdX
# Safety (all checked here as root, whatever the GUI said): whole USB disk only (/dev/sdX, TRAN=usb, TYPE=disk, not
# read-only), never a disk that holds /, /boot, /home, swap, the live medium or the ISO file itself; open LUKS/LVM -> refuse;
# the file must be a real ISO 9660 image that fits. Mounted partitions of the stick are unmounted first.
# Output for the GUI: "PHX-STAGE <hash|write|verify> [bytes]", dd progress lines, "PHX-ERROR <text>", "PHX-RESULT ok|fail".
set -u
export LC_ALL=C
die() { echo "PHX-ERROR $*"; exit 1; }

[ "$#" -eq 2 ] || die "usage: usb-write.sh ISO /dev/sdX"
ISO=$1
DEV=$2
case "$DEV" in
  /dev/sd[a-z]|/dev/sd[a-z][a-z]) ;;
  *) die "$DEV is not a USB disk name (/dev/sdX)" ;;
esac
NAME=${DEV#/dev/}
[ -b "$DEV" ] || die "$DEV is not a block device"
[ -f "$ISO" ] && [ -r "$ISO" ] || die "cannot read $ISO"
[ "$(lsblk -dno TYPE "$DEV" | tr -d ' ')" = disk ] || die "$DEV is not a whole disk"
[ "$(lsblk -dno TRAN "$DEV" | tr -d ' ')" = usb ] || die "$DEV is not connected by USB"
[ "$(lsblk -dno RO "$DEV" | tr -d ' ')" = 0 ] || die "$DEV is read-only (write-protect switch?)"

# top-level disks a device sits on (follows partitions, LUKS, LVM, RAID)
parent_disks() { lsblk -nsro NAME,TYPE "$1" 2>/dev/null | awk '$2 == "disk" {print $1}'; }
on_target() { parent_disks "$1" | grep -qxF "$NAME"; }

for m in / /boot /boot/efi /efi /usr /var /home /run/live/medium /lib/live/mount/medium /run/initramfs/live; do
  src=$(findmnt -nvo SOURCE --mountpoint "$m" 2>/dev/null | head -n1)
  [ -n "$src" ] && [ -b "$src" ] && on_target "$src" && die "$DEV holds the running system ($m) - refusing"
done
for s in $(swapon --noheadings --show=NAME 2>/dev/null); do
  [ -b "$s" ] && on_target "$s" && die "$DEV holds active swap - refusing"
done
isosrc=$(findmnt -nvo SOURCE --target "$ISO" 2>/dev/null | head -n1)
[ -n "$isosrc" ] && [ -b "$isosrc" ] && on_target "$isosrc" && die "the ISO file is stored on $DEV - copy it to your computer first"
lsblk -nro TYPE "$DEV" | grep -qvxE 'disk|part' && die "$DEV has open encrypted/LVM/RAID volumes - close them first"

[ "$(dd if="$ISO" bs=1 skip=32769 count=5 2>/dev/null)" = CD001 ] || die "$ISO is not an ISO image"
iso_size=$(stat -c %s "$ISO")
dev_size=$(blockdev --getsize64 "$DEV")
[ "$iso_size" -gt 0 ] && [ "$iso_size" -le "$dev_size" ] || die "the stick is too small ($dev_size bytes, need $iso_size)"

# unmount whatever of the stick is mounted (e.g. auto-mounted by Dolphin)
for part in $(lsblk -nrpo NAME "$DEV"); do
  i=0
  while findmnt -rno TARGET --source "$part" >/dev/null 2>&1; do
    umount "$part" 2>/dev/null || true
    i=$((i + 1))
    [ "$i" -ge 5 ] && die "could not unmount $part - close files that are open on the stick"
  done
done

echo "PHX-STAGE hash $iso_size"
iso_sum=$(sha256sum "$ISO" | cut -d' ' -f1) || die "cannot read $ISO"
[ -n "$iso_sum" ] || die "cannot read $ISO"

echo "PHX-STAGE write $iso_size"
wipefs -a -q "$DEV" 2>/dev/null || echo "note: wipefs failed, continuing"
dd if="$ISO" of="$DEV" bs=4M oflag=direct status=progress conv=fsync || die "writing failed - was the stick removed?"
sync

echo "PHX-STAGE verify $iso_size"
blockdev --flushbufs "$DEV" 2>/dev/null || true   # read back from the stick, not from memory
dev_sum=$(dd if="$DEV" bs=4M iflag=count_bytes count="$iso_size" status=progress | sha256sum | cut -d' ' -f1)
blockdev --rereadpt "$DEV" 2>/dev/null || true
if [ "$dev_sum" = "$iso_sum" ]; then
  echo "sha256 $iso_sum"
  echo "PHX-RESULT ok"
else
  echo "ISO   sha256 $iso_sum"
  echo "stick sha256 $dev_sum"
  echo "PHX-RESULT fail"
  exit 1
fi
