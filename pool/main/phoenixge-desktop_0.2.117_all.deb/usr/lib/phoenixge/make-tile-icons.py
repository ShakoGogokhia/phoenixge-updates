#!/usr/bin/env python3
"""Generate the PhoenixGe icon themes: Papirus app logos + the design folders (accent folder with phoenix)
and the desktop tiles (Home / Games / Windows Apps / Trash) from the design boards.

  make-tile-icons.py            scan installed apps (system + flatpak) and (re)write the themes
Themes written to /usr/share/icons:
  PhoenixGe-Tiles   solid color tile, white label   (Ember, Kolkhi, Obsidian, Inferno, Borjgali, Forest, ...)
  PhoenixGe-Pastel  light tile, colored label       (Pastel, Ash, Glass)
  PhoenixGe-Outline dark tile, colored border+label  (Cyber, Mono)
Run as root; safe to re-run (first-boot runs it again after Flatpak apps are installed).
"""
import configparser
import hashlib
import os
import shutil
import sys
from pathlib import Path

ICONS = Path(os.environ.get("PHOENIX_ICON_ROOT", "/usr/share/icons"))
APP_DIRS = [Path("/usr/share/applications"), Path("/var/lib/flatpak/exports/share/applications")]

# icon name -> (label, color) taken from the designs
KNOWN = {
    "firefox-esr": ("Fx", "#e8590c"), "firefox": ("Fx", "#e8590c"), "org.mozilla.firefox": ("Fx", "#e8590c"),
    "org.kde.dolphin": ("Fi", "#5c3d2e"), "system-file-manager": ("Fi", "#5c3d2e"),
    "steam": ("St", "#1b2838"), "com.valvesoftware.Steam": ("St", "#1b2838"),
    "com.usebottles.bottles": ("Bo", "#7b2cbf"),
    "net.lutris.Lutris": ("Lu", "#c77d00"), "lutris": ("Lu", "#c77d00"),
    "com.heroicgameslauncher.hgl": ("He", "#2f4858"),
    "plasmadiscover": ("Di", "#1d6fa5"), "org.kde.discover": ("Di", "#1d6fa5"),
    "ge.chatlaxi.ai": ("Ch", "#b23a48"),
    "phoenix-toolbox": ("KT", "#264653"),
    "vlc": ("VL", "#f77f00"),
    "utilities-terminal": (">_", "#2d2d2d"), "org.kde.konsole": (">_", "#2d2d2d"),
    "preferences-system": ("Se", "#6c757d"), "systemsettings": ("Se", "#6c757d"),
    "supertuxkart": ("TK", "#2b9348"),
    "luanti": ("Lu", "#3a7d44"), "minetest": ("Lu", "#3a7d44"),
    "winetricks": ("Wi", "#0f5c8c"), "phoenix-run": ("Wi", "#0f5c8c"),
    "org.kde.kate": ("Ka", "#3d6ee0"), "kate": ("Ka", "#3d6ee0"), "kwrite": ("Kw", "#3d6ee0"),
    "com.discordapp.Discord": ("Dc", "#5865f2"), "discord": ("Dc", "#5865f2"),
    "org.prismlauncher.PrismLauncher": ("Mc", "#3c8527"),
    "gimp": ("Gi", "#5c5543"), "okular": ("Ok", "#c0392b"), "gwenview": ("Gw", "#8e44ad"),
    "ark": ("Ar", "#7f6a3a"), "spectacle": ("Sp", "#2980b9"), "org.kde.spectacle": ("Sp", "#2980b9"),
    "accessories-calculator": ("Ca", "#34495e"), "utilities-system-monitor": ("Sy", "#16a085"),
    "partitionmanager": ("Pa", "#2c3e50"), "dragonplayer": ("Dp", "#1b4f72"), "juk": ("Ju", "#6c3483"),
    "kmail": ("Ma", "#2471a3"), "korganizer": ("Ca", "#b03a2e"), "kaddressbook": ("Co", "#117864"),
    "help-browser": ("He", "#5d6d7e"), "kdeconnect": ("Kc", "#1e8449"), "kvantum": ("Kv", "#7d3c98"),
    "start-here-kde-plasma": ("Pg", "#c2410c"), "konqueror": ("Kq", "#2e86c1"),
    "akregator": ("Ak", "#d35400"), "kfind": ("Fd", "#5c3d2e"), "gvim": ("Vi", "#1e8449"),
}
PALETTE = ["#e8590c", "#5c3d2e", "#1d6fa5", "#7b2cbf", "#c77d00", "#2f4858", "#b23a48", "#264653",
           "#2b9348", "#0f5c8c", "#6c757d", "#8e44ad", "#16a085", "#c0392b"]
PASTEL = "#fff4ee"


def label_for(name):
    words = [w for w in name.replace("-", " ").split() if w[:1].isalnum()]
    if not words:
        return "?"
    if len(words) >= 2 and len(words[0]) <= 3:
        return (words[0][0] + words[1][0]).upper()
    w = words[0]
    return (w[0].upper() + (w[1].lower() if len(w) > 1 else ""))


def mix(hex_a, hex_b, t):
    a = [int(hex_a[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(hex_b[i:i + 2], 16) for i in (1, 3, 5)]
    return "#%02x%02x%02x" % tuple(round(x + (y - x) * t) for x, y in zip(a, b))


def svg(label, color, style):
    size = 21 if len(label) <= 2 else 17
    if style == "pastel":
        bg, fg, stroke = mix(color, "#ffffff", 0.82), mix(color, "#000000", 0.15), ""
    elif style == "outline":
        bg, fg, stroke = "#0b0f14", color, f' stroke="{color}" stroke-width="2"'
    else:
        bg, fg, stroke = color, "#ffffff", ""
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">'
            f'<rect x="2" y="2" width="60" height="60" rx="15" fill="{bg}"{stroke}/>'
            f'<text x="32" y="{32 + size * 0.36:.1f}" text-anchor="middle" font-family="Sora, Inter, sans-serif" '
            f'font-weight="700" font-size="{size}" fill="{fg}">{label.replace(">", "&gt;").replace("<", "&lt;")}</text></svg>\n')


# desktop tiles (Home / Games / Windows Apps / Trash on the Ember board): dark tile + accent line glyph
GLYPHS = {
    "phoenixge-home": '<path d="M18 27v-3a3 3 0 0 1 3-3h7l3 4h12a3 3 0 0 1 3 3v12a3 3 0 0 1-3 3H21a3 3 0 0 1-3-3z"/>',
    "phoenixge-games": '<rect x="16" y="24" width="32" height="16" rx="8"/><circle cx="25" cy="32" r="2"/>',
    "phoenixge-winapps": '<rect x="19" y="19" width="11" height="11" rx="1.5"/><rect x="34" y="19" width="11" height="11" rx="1.5"/>'
                         '<rect x="19" y="34" width="11" height="11" rx="1.5"/><rect x="34" y="34" width="11" height="11" rx="1.5"/>',
    "phoenixge-trash": '<path d="M21 24h22M28 24v-3h8v3M24 24l1.5 19h13L40 24"/>',
    "phoenixge-store": '<path d="M20 26h24l-2 17H22z"/><path d="M27 26v-3a5 5 0 0 1 10 0v3"/>',
    "phoenixge-android": '<path d="M21 36a11 11 0 0 1 22 0v6H21z"/><path d="M24 26l-3-4M40 26l3-4"/>'
                         '<circle cx="27.5" cy="33" r="1.2"/><circle cx="36.5" cy="33" r="1.2"/>',
    "phoenixge-themes": '<path d="M32 19a13 13 0 1 0 0 26c2 0 3-1.5 2-3.5s0-4.5 3-4.5h3a5 5 0 0 0 5-5c0-7-6-13-13-13z"/>'
                        '<circle cx="25" cy="31" r="1.6"/><circle cx="29" cy="25" r="1.6"/><circle cx="36" cy="25" r="1.6"/>',
    "phoenixge-gamemode": '<rect x="16" y="24" width="32" height="16" rx="8"/><path d="M24 29v6M21 32h6"/>'
                          '<circle cx="38" cy="30" r="1.4"/><circle cx="41" cy="34" r="1.4"/>',
}


def place_svg(glyph, tile, accent):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">'
            f'<rect x="2" y="2" width="60" height="60" rx="15" fill="{tile}"/>'
            f'<g fill="none" stroke="{accent}" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">{glyph}</g></svg>\n')


PHOENIX = ("M32 50 C22 44 10 40 4 24 C14 30 22 30 28 34 C24 26 22 18 26 8 C30 18 32 26 32 34 "
           "C32 26 34 18 38 8 C42 18 40 26 36 34 C42 30 50 30 60 24 C54 40 42 44 32 50 Z")
FOLDERS = ["folder", "folder-documents", "folder-download", "folder-downloads", "folder-music", "folder-pictures",
           "folder-images", "folder-videos", "folder-video", "folder-desktop", "user-desktop", "folder-templates",
           "folder-publicshare", "folder-public", "folder-games", "folder-development", "folder-open", "inode-directory"]


def folder_svg(color):
    """Design folder (Ember Files board): flat accent folder with a darker phoenix mark."""
    back, front, mark = mix(color, "#000000", 0.18), color, mix(color, "#000000", 0.35)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">'
            f'<path d="M6 16a4 4 0 0 1 4-4h14l5 5h25a4 4 0 0 1 4 4v4H6z" fill="{back}"/>'
            f'<rect x="6" y="21" width="52" height="33" rx="4" fill="{front}"/>'
            f'<g transform="translate(23.5 26) scale(0.27)"><path d="{PHOENIX}" fill="{mark}"/></g></svg>\n')


THEMES = {"PhoenixGe-Tiles": ("solid", "#2a1712", "#ff8a3d"),
          "PhoenixGe-Pastel": ("pastel", "#ffffff", "#e8590c"),
          "PhoenixGe-Outline": ("outline", "#0b0f14", "#22d3ee")}


def apps():
    found = {}
    for d in APP_DIRS:
        if not d.is_dir():
            continue
        for f in sorted(d.glob("*.desktop")):
            cp = configparser.RawConfigParser(strict=False, interpolation=None)
            try:
                cp.read(f, encoding="utf-8")
                e = cp["Desktop Entry"]
            except Exception:
                continue
            icon, name = e.get("Icon", ""), e.get("Name", f.stem)
            if icon and "/" not in icon and e.get("NoDisplay", "false").lower() != "true":
                found.setdefault(icon, name)
    return found


def main():
    # App icons are the real logos (Papirus, owner: "I want good logos, not names"); this theme only adds the
    # design folders, the desktop tiles and the PhoenixGe apps' own logo on top of Papirus.
    logo = Path("/usr/share/pixmaps/phoenixge.png")
    for theme, (style, tile, accent) in THEMES.items():
        root = ICONS / theme
        shutil.rmtree(root / "scalable/apps", ignore_errors=True)
        (root / "scalable/apps").mkdir(parents=True, exist_ok=True)
        (root / "scalable/places").mkdir(parents=True, exist_ok=True)
        (root / "scalable/mimetypes").mkdir(parents=True, exist_ok=True)
        if logo.exists():
            for own in OWN_APPS:
                shutil.copy(logo, root / f"scalable/apps/{own}.png")
        fcolor = {"solid": "#ff7a2e", "pastel": "#f08aa8", "outline": "#22d3ee"}[style]
        for f in FOLDERS:
            sub = "mimetypes" if f == "inode-directory" else "places"
            (root / f"scalable/{sub}/{f}.svg").write_text(folder_svg(fcolor), encoding="utf-8")
        for icon, glyph in GLYPHS.items():
            (root / f"scalable/places/{icon}.svg").write_text(place_svg(glyph, tile, accent), encoding="utf-8")
        base = "Papirus" if style == "pastel" else "Papirus-Dark"
        (root / "index.theme").write_text(INDEX.format(theme=theme, base=base), encoding="utf-8")
    if os.access(str(ICONS), os.W_OK):
        for theme in THEMES:
            os.system(f"gtk-update-icon-cache -q -f '{ICONS / theme}' 2>/dev/null")
    print(f"PhoenixGe icon themes: {len(THEMES)}")


OWN_APPS = []  # PhoenixGe app icons come from hicolor in every size (scripts/make-branding.py)
INDEX = """[Icon Theme]
Name={theme}
Comment=PhoenixGe: Papirus app logos + design folders
Inherits={base},breeze-dark,breeze,hicolor
Directories=scalable/apps,scalable/places,scalable/mimetypes

[scalable/apps]
Size=64
MinSize=8
MaxSize=512
Type=Scalable
Context=Applications

[scalable/places]
Size=64
MinSize=8
MaxSize=512
Type=Scalable
Context=Places

[scalable/mimetypes]
Size=64
MinSize=8
MaxSize=512
Type=Scalable
Context=MimeTypes
"""


if __name__ == "__main__":
    sys.exit(main())
