#!/bin/sh
# Safe updates setup (root). Run by hook 0850 (ISO build) and by apply-system.sh (phoenixge-desktop updates).
#  - /etc/grub.d/42_phoenixge-restore  -> GRUB submenu "PhoenixGe - restore previous state"
#  - phoenixge-snapshot-menu.service    -> refreshes that menu at boot when the btrfs snapshot list changed
#  - /etc/apt/apt.conf.d/80phoenixge-snapshot (from the etc overlay) -> snapshot before dpkg runs
set +e
L=/usr/lib/phoenixge
chmod 755 /usr/bin/phoenixge-rollback /usr/bin/phoenixge-update "$L"/pre-update-snapshot.sh "$L"/grub-restore-menu.sh \
  "$L"/snapshot-menu-refresh.sh "$L"/snapshot-notice.sh "$L"/timeshift-auto.sh 2>/dev/null
G=/etc/grub.d/42_phoenixge-restore
if [ -d /etc/grub.d ] && [ -f "$L/grub-restore-menu.sh" ]; then
  if ! cmp -s "$L/grub-restore-menu.sh" "$G" || [ ! -x "$G" ]; then
    install -m 755 "$L/grub-restore-menu.sh" "$G"
    CHANGED=1
  fi
fi
systemctl enable phoenixge-snapshot-menu.service >/dev/null 2>&1
# Installed system only (not the ISO build chroot, not the live session, not a booted snapshot):
# rebuild grub.cfg once so the new menu appears.
if [ "$CHANGED" = 1 ] && [ -d /run/systemd/system ] && [ ! -d /run/live ] && ! grep -q 'phoenixge.snapshot=' /proc/cmdline 2>/dev/null \
   && [ -f /boot/grub/grub.cfg ] && command -v update-grub >/dev/null 2>&1; then
  systemctl daemon-reload >/dev/null 2>&1
  update-grub >/dev/null 2>&1 || echo "PhoenixGe: update-grub failed (restore menu not added yet)" >&2
fi
exit 0
