#!/bin/sh
# PhoenixGe: make the Debian NVIDIA 550 driver build on newer Debian kernels (run as root).
# Debian's 6.12.116+ kernel backported a 4th argument to pci_resize_resource() (exclude_bars);
# nvidia 550.163.01 still calls it with 3 -> "too few arguments" -> DKMS build fails -> no NVIDIA driver.
# We add the argument when the installed kernel headers need it, then let dpkg finish the install.
# Safe to run many times; does nothing when no patch is needed.
changed=0
for src in /usr/src/nvidia-current-open-* /usr/src/nvidia-current-*; do
  f="$src/nvidia/nv-pci.c"
  [ -f "$f" ] || continue
  grep -q 'pci_resize_resource(pci_dev, NV_GPU_BAR1, requested_size);' "$f" || continue
  need=0
  for h in /usr/src/linux-headers-*/include/linux/pci.h; do
    grep -A1 'pci_resize_resource(struct pci_dev' "$h" 2>/dev/null | grep -q exclude_bars && need=1
  done
  [ $need = 1 ] || continue
  sed -i 's/pci_resize_resource(pci_dev, NV_GPU_BAR1, requested_size);/pci_resize_resource(pci_dev, NV_GPU_BAR1, requested_size, 0);/' "$f"
  echo "patched $f (pci_resize_resource exclude_bars)"; changed=1
done
# called from a package postinst (in the background): wait until that dpkg/apt run has finished (max ~20 min)
i=0; while pgrep -x dpkg >/dev/null || pgrep -x apt-get >/dev/null || pgrep -x apt >/dev/null; do
  i=$((i+1)); [ $i -ge 240 ] && break; sleep 5
done
if [ $changed = 1 ] || dpkg -l 'nvidia-*' 2>/dev/null | grep -qE '^iF|^iU'; then
  DEBIAN_FRONTEND=noninteractive dpkg --configure -a
fi
exit 0
