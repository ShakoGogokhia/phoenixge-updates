#!/bin/bash
# PhoenixGe Toolbox backend: Kali tools live in a distrobox container, never on the host.
#   backend.sh ensure                 create the Kali container if missing
#   backend.sh installed              list installed tool packages (one per line)
#   backend.sh simulate PKG...        apt-get -s install (conflict check, nothing changes)
#   backend.sh install PKG...         install + export binaries/apps to the host
#   backend.sh export PKG...          (re)export already-installed packages to the host
#   backend.sh remove PKG...          unexport + remove
#   backend.sh remove-all             delete the whole container
#   backend.sh bins PKG               commands a package ships (one per line)
#   backend.sh apps PKG               .desktop apps a package ships (basenames)
set -euo pipefail
BOX=phoenix-kali
IMAGE=docker.io/kalilinux/kali-rolling:latest
BIN_DIR="$HOME/.local/bin"

in_box() { distrobox enter "$BOX" -- "$@"; }

exists() { distrobox list --no-color 2>/dev/null | awk -F'|' '{gsub(/ /,"",$2); print $2}' | grep -qx "$BOX"; }

ensure() {
  if ! exists; then
    echo "PHOENIX: creating Kali container (first time only)..."
    distrobox create --yes --name "$BOX" --image "$IMAGE"
  fi
  in_box sudo apt-get update -q
}

export_pkg() {  # export every binary and desktop app a package ships
  local pkg=$1
  mkdir -p "$BIN_DIR"
  for f in $(in_box dpkg -L "$pkg" 2>/dev/null | grep -E '^/usr/s?bin/[^/]+$' || true); do
    in_box distrobox-export --bin "$f" --export-path "$BIN_DIR" >/dev/null 2>&1 || true
  done
  if in_box dpkg -L "$pkg" 2>/dev/null | grep -q '^/usr/share/applications/.*\.desktop$'; then
    in_box distrobox-export --app "$pkg" >/dev/null 2>&1 || true
  fi
}

unexport_pkg() {
  local pkg=$1
  for f in $(in_box dpkg -L "$pkg" 2>/dev/null | grep -E '^/usr/s?bin/[^/]+$' || true); do
    in_box distrobox-export --bin "$f" --export-path "$BIN_DIR" --delete >/dev/null 2>&1 || true
  done
  in_box distrobox-export --app "$pkg" --delete >/dev/null 2>&1 || true
}

cmd=${1:-}; shift || true
case "$cmd" in
  ensure)    ensure ;;
  installed) exists || exit 0
             in_box dpkg-query -W -f='${db:Status-Abbrev} ${Package}\n' 2>/dev/null | awk '$1 ~ /^ii/ {print $2}' ;;
  simulate)  ensure; in_box sudo apt-get -s install -y "$@" ;;
  install)   ensure
             in_box sudo env DEBIAN_FRONTEND=noninteractive apt-get install -y "$@"
             for p in "$@"; do echo "PHOENIX: exporting $p"; export_pkg "$p"; done
             echo "PHOENIX: done" ;;
  export)    for p in "$@"; do echo "PHOENIX: exporting $p"; export_pkg "$p"; done; echo "PHOENIX: done" ;;
  remove)    exists || exit 0
             for p in "$@"; do unexport_pkg "$p"; done
             in_box sudo apt-get remove -y "$@"; in_box sudo apt-get autoremove -y
             echo "PHOENIX: done" ;;
  remove-all) distrobox rm --force "$BOX"; echo "PHOENIX: done" ;;
  bins)      in_box dpkg -L "$1" 2>/dev/null | grep -E '^/usr/s?bin/[^/]+$' | xargs -r -n1 basename ;;
  apps)      in_box dpkg -L "$1" 2>/dev/null | grep -E '^/usr/share/applications/[^/]+\.desktop$' | xargs -r -n1 basename ;;
  *) sed -n '2,11p' "$0"; exit 2 ;;
esac
