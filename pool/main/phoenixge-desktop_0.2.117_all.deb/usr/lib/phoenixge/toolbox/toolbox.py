#!/usr/bin/env python3
"""PhoenixGe Toolbox — browse and install Kali tools (in an isolated distrobox container)."""
import json
import os
import shutil
import sys
from pathlib import Path

from PySide6.QtCore import QProcess, QSortFilterProxyModel, Qt
from PySide6.QtGui import QIcon, QStandardItem, QStandardItemModel
from PySide6.QtWidgets import (QApplication, QCheckBox, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
                               QListWidget, QListWidgetItem, QMainWindow, QMessageBox, QPlainTextEdit,
                               QPushButton, QSplitter, QTreeView, QVBoxLayout, QWidget)

HERE = Path(__file__).resolve().parent
CATALOG = Path(os.environ.get("PHOENIX_TOOLBOX_CATALOG", "/usr/share/phoenixge/toolbox/catalog.json"))
BACKEND = os.environ.get("PHOENIX_TOOLBOX_BACKEND", str(HERE / "backend.sh"))
MIN_FREE_FOR_EVERYTHING = 80 * 1024 ** 3
ALL = "__all__"
COL_NAME, COL_SUMMARY, COL_SIZE, COL_STATE = range(4)


def human(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit in ("B", "KB") else f"{n:.1f} {unit}"
        n /= 1024


class ToolFilter(QSortFilterProxyModel):
    def __init__(self):
        super().__init__()
        self.category = ALL
        self.text = ""
        self.hide_hw = False

    def filterAcceptsRow(self, row, parent):
        item = self.sourceModel().item(row, COL_NAME)
        tool = item.data(Qt.UserRole)
        if self.category != ALL and self.category not in tool["categories"]:
            return False
        if self.hide_hw and tool["hw"]:
            return False
        if self.text:
            t = self.text.lower()
            return t in tool["name"].lower() or t in tool["summary"].lower() or t in tool["description"].lower()
        return True


class Toolbox(QMainWindow):
    def __init__(self, catalog):
        super().__init__()
        self.catalog = catalog
        self.tools = catalog["tools"]
        self.installed = set()
        self.proc = None
        self.setWindowTitle("PhoenixGe Toolbox — Kali tools")
        self.setWindowIcon(QIcon("/usr/share/pixmaps/phoenixge.png"))
        self.resize(1200, 760)

        # --- top bar
        self.search = QLineEdit(placeholderText="Search by name or description…")
        self.search.textChanged.connect(self.on_search)
        self.hw_box = QCheckBox("Hide hardware-only tools")
        self.hw_box.toggled.connect(self.on_hw)
        sel_all = QPushButton("Select all")
        sel_all.clicked.connect(lambda: self.set_all(True))
        clear = QPushButton("Clear")
        clear.clicked.connect(lambda: self.set_all(False))
        top = QHBoxLayout()
        for w in (self.search, self.hw_box, sel_all, clear):
            top.addWidget(w)

        # --- categories
        self.cats = QListWidget()
        self.cats.setMaximumWidth(260)
        all_item = QListWidgetItem(f"All  ({len(self.tools)})")
        all_item.setData(Qt.UserRole, ALL)
        self.cats.addItem(all_item)
        for c in catalog["categories"]:
            it = QListWidgetItem(f"{c['title']}  ({len(c['packages'])})")
            it.setData(Qt.UserRole, c["id"])
            it.setToolTip(c["summary"])
            self.cats.addItem(it)
        self.cats.currentItemChanged.connect(self.on_category)

        # --- tool list
        self.model = QStandardItemModel(0, 4)
        self.model.setHorizontalHeaderLabels(["Tool", "Description", "Size", "Status"])
        for name, t in self.tools.items():
            n = QStandardItem(("⚙ " if t["hw"] else "") + name)
            n.setCheckable(True)
            n.setData(t, Qt.UserRole)
            n.setToolTip(t["description"] + ("\n\n⚙ Needs real hardware (Wi-Fi/SDR/GPU…)" if t["hw"] else ""))
            s = QStandardItem(t["summary"])
            z = QStandardItem(human(t["size"]))
            z.setData(t["size"], Qt.UserRole)
            st = QStandardItem("")
            for i in (s, z, st):
                i.setEditable(False)
            n.setEditable(False)
            self.model.appendRow([n, s, z, st])
        self.model.itemChanged.connect(self.update_totals)
        self.proxy = ToolFilter()
        self.proxy.setSourceModel(self.model)
        self.view = QTreeView()
        self.view.setModel(self.proxy)
        self.view.setRootIsDecorated(False)
        self.view.setAlternatingRowColors(True)
        self.view.setSortingEnabled(True)
        self.view.sortByColumn(COL_NAME, Qt.AscendingOrder)
        self.view.doubleClicked.connect(lambda _i: self.open_tool())
        hdr = self.view.header()
        hdr.setSectionResizeMode(COL_SUMMARY, QHeaderView.Stretch)
        hdr.resizeSection(COL_NAME, 240)

        # --- log
        self.log = QPlainTextEdit(readOnly=True)
        self.log.setMaximumBlockCount(5000)
        self.log.setPlaceholderText("Install progress appears here…")

        split = QSplitter(Qt.Vertical)
        split.addWidget(self.view)
        split.addWidget(self.log)
        split.setSizes([560, 160])
        mid = QSplitter()
        mid.addWidget(self.cats)
        mid.addWidget(split)
        mid.setSizes([240, 960])

        # --- bottom bar
        self.totals = QLabel()
        self.btn_check = QPushButton("Check conflicts")
        self.btn_check.clicked.connect(self.simulate)
        self.btn_remove = QPushButton("Remove selected")
        self.btn_remove.clicked.connect(self.remove)
        self.btn_open = QPushButton("▶ Open")
        self.btn_open.setToolTip("Launch the installed tool (or double-click it in the list)")
        self.btn_open.clicked.connect(self.open_tool)
        self.btn_install = QPushButton("Install")
        self.btn_install.setDefault(True)
        self.btn_install.clicked.connect(self.install)
        bottom = QHBoxLayout()
        bottom.addWidget(self.totals, 1)
        for b in (self.btn_check, self.btn_remove, self.btn_open, self.btn_install):
            bottom.addWidget(b)

        root = QVBoxLayout()
        root.addLayout(top)
        root.addWidget(mid, 1)
        root.addLayout(bottom)
        w = QWidget()
        w.setLayout(root)
        self.setCentralWidget(w)
        self.cats.setCurrentRow(0)
        self.update_totals()
        self.refresh_installed()

    # ---------- selection
    def rows(self):
        for r in range(self.model.rowCount()):
            yield self.model.item(r, COL_NAME)

    def selected(self):
        return [i.data(Qt.UserRole)["name"] for i in self.rows() if i.checkState() == Qt.Checked]

    def set_all(self, on):
        self.model.blockSignals(True)
        visible = {self.proxy.mapToSource(self.proxy.index(r, 0)).row() for r in range(self.proxy.rowCount())}
        for r in visible:
            self.model.item(r, COL_NAME).setCheckState(Qt.Checked if on else Qt.Unchecked)
        self.model.blockSignals(False)
        self.view.viewport().update()
        self.update_totals()

    def is_everything(self, names):
        return len(names) == len(self.tools)

    def update_totals(self, *_):
        names = self.selected()
        new = [n for n in names if n not in self.installed]
        dl = sum(self.tools[n]["size"] for n in new)
        disk = sum(self.tools[n]["installed_size"] for n in new)
        extra = "  •  full set: kali-linux-everything" if self.is_everything(names) else ""
        self.totals.setText(f"{len(names)} selected  •  ~{human(dl)} download  •  ~{human(disk)} on disk{extra}")

    # ---------- filters
    def on_search(self, text):
        self.proxy.text = text.strip()
        self.proxy.invalidateFilter()

    def on_hw(self, on):
        self.proxy.hide_hw = on
        self.proxy.invalidateFilter()

    def on_category(self, cur, _prev):
        if cur:
            self.proxy.category = cur.data(Qt.UserRole)
            self.proxy.invalidateFilter()

    # ---------- backend
    def run(self, args, done=None):
        if self.proc:
            QMessageBox.information(self, "Toolbox", "Another operation is still running.")
            return
        self.set_busy(True)
        self.log.appendPlainText("$ toolbox " + " ".join(args[:6]) + (" …" if len(args) > 6 else ""))
        self.proc = QProcess(self)
        self.proc.setProcessChannelMode(QProcess.MergedChannels)
        self.proc.readyReadStandardOutput.connect(
            lambda: self.log.appendPlainText(bytes(self.proc.readAllStandardOutput()).decode(errors="replace").rstrip()))

        def finished(code, _status):
            out = self.log.toPlainText()
            self.proc = None
            self.set_busy(False)
            if done:
                done(code, out)
        self.proc.finished.connect(finished)
        self.proc.start("/bin/bash", [BACKEND] + args)

    def set_busy(self, busy):
        for b in (self.btn_check, self.btn_install, self.btn_remove, self.btn_open):
            b.setEnabled(not busy)

    def refresh_installed(self):
        if not os.path.exists(BACKEND) or not shutil.which("distrobox"):
            return
        self._iproc = QProcess(self)  # keep a reference: the slot reads it after it finishes
        self._iproc.finished.connect(self._on_installed_finished)
        self._iproc.start("/bin/bash", [BACKEND, "installed"])

    def _on_installed_finished(self, *_):
        proc, self._iproc = self._iproc, None
        if proc is not None:
            self._installed_done(bytes(proc.readAllStandardOutput()).decode())
            proc.deleteLater()

    def _installed_done(self, text):
        self.installed = set(text.split())
        for r in range(self.model.rowCount()):
            name = self.model.item(r, COL_NAME).data(Qt.UserRole)["name"]
            self.model.item(r, COL_STATE).setText("✔ Installed" if name in self.installed else "")
        self.update_totals()

    def simulate(self):
        names = self.selected()
        if not names:
            return
        pkgs = [self.catalog["everything_metapackage"]] if self.is_everything(names) else names
        self.run(["simulate"] + pkgs, self._simulate_done)

    def _simulate_done(self, code, out):
        problems = [l for l in out.splitlines() if l.startswith(("E:", " ")) and ("Depends" in l or "Conflicts" in l or "E:" in l)]
        if code == 0:
            QMessageBox.information(self, "Check", "No conflicts — you can install.")
        else:
            culprits = sorted({l.split(":")[0].strip() for l in problems if ":" in l and not l.startswith("E:")})
            msg = "These packages conflict:\n\n" + "\n".join(culprits[:30]) if culprits else "\n".join(problems[:15])
            QMessageBox.warning(self, "Conflict", msg + "\n\nUntick them and try again.")

    def install(self):
        names = [n for n in self.selected() if n not in self.installed]
        if not names:
            QMessageBox.information(self, "Toolbox", "Select one or more tools.")
            return
        free = shutil.disk_usage(Path.home()).free
        if self.is_everything(self.selected()):
            if free < MIN_FREE_FOR_EVERYTHING:
                QMessageBox.critical(self, "Not enough space",
                                     f"The full set needs at least 80 GB free. Free now: {human(free)}.")
                return
            if QMessageBox.question(self, "Full set",
                                    "Installing every Kali tool takes ~40–90 minutes (depends on your connection). Continue?") \
                    != QMessageBox.Yes:
                return
            meta = self.catalog["everything_metapackage"]
            self.run(["install", meta], lambda c, o: self.run(["export"] + list(self.tools), self._after_change) if c == 0
                     else self._after_change(c, o))
        else:
            self.run(["install"] + names, self._after_change)

    def remove(self):
        names = [n for n in self.selected() if n in self.installed]
        if not names:
            QMessageBox.information(self, "Toolbox", "None of the selected tools are installed.")
            return
        if QMessageBox.question(self, "Remove", f"Remove {len(names)} tool(s)?") == QMessageBox.Yes:
            self.run(["remove"] + names, self._after_change)

    # ---------- open an installed tool
    def current_tool(self):
        idx = self.view.currentIndex()
        if not idx.isValid():
            return None
        src = self.proxy.mapToSource(idx)
        return self.model.item(src.row(), COL_NAME).data(Qt.UserRole)["name"]

    def backend_lines(self, *args):
        p = QProcess(self)
        p.start("/bin/bash", [BACKEND, *args])
        p.waitForFinished(60000)
        return bytes(p.readAllStandardOutput()).decode(errors="replace").split()

    def open_tool(self):
        name = self.current_tool()
        if not name:
            QMessageBox.information(self, "Toolbox", "Select an installed tool in the list.")
            return
        if name not in self.installed:
            QMessageBox.information(self, "Toolbox", f"{name} is not installed yet — tick it and press Install.")
            return
        apps_dir = Path.home() / ".local/share/applications"
        for app in self.backend_lines("apps", name):
            exported = apps_dir / f"phoenix-kali-{app}"
            if exported.exists():
                QProcess.startDetached("kioclient", ["exec", str(exported)])
                return
        bins = self.backend_lines("bins", name) or [name]
        intro = (f"echo '{name} — commands: {' '.join(bins)}'; echo; "
                 f"echo 'Example: {bins[0]} --help'; echo; ")
        cmd = f"export PATH=$HOME/.local/bin:$PATH; {intro}exec bash -i"
        QProcess.startDetached("konsole", ["--workdir", str(Path.home()), "-e", "bash", "-c", cmd])

    def _after_change(self, code, _out):
        self.refresh_installed()
        if code == 0:
            QMessageBox.information(self, "Toolbox", "Done. Tools appear in the Start menu and in the terminal.")
        else:
            QMessageBox.warning(self, "Toolbox", "Something failed — details are in the log below.")


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("PhoenixGe Toolbox")
    app.setDesktopFileName("phoenix-toolbox")
    app.setWindowIcon(QIcon("/usr/share/pixmaps/phoenixge.png"))
    catalog = json.loads(CATALOG.read_text(encoding="utf-8"))
    w = Toolbox(catalog)
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
