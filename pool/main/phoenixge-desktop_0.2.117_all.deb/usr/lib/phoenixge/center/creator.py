"""PhoenixGe Center > Streaming & clips: one-click OBS Studio setup for Twitch / YouTube / Kick + the Clips app.

build(center) -> QWidget   (center = the PhoenixGe Center main window: uses center.runner)
Run alone for testing:  python3 creator.py [--demo]

What "Set up OBS" writes (Flatpak config dir ~/.var/app/com.obsproject.Studio/config/obs-studio/):
  basic/profiles/PhoenixGe-<Service>/basic.ini        video 1080p60 (or 720p60), advanced output, 3 audio tracks
  basic/profiles/PhoenixGe-<Service>/streamEncoder.json   NVENC / VA-API / x264, CBR, 2 s keyframes
  basic/profiles/PhoenixGe-<Service>/service.json     server + stream key (mode 600, nowhere else)
  basic/scenes/PhoenixGe.json                         scenes Game (screen + webcam), Starting soon, Be right back;
                                                      desktop audio + mic with RNNoise suppression, gate, compressor
  global.ini / user.ini                               skip the first-run wizard, open PhoenixGe-<Service> by default
Anything that already exists is backed up next to it (*.bak-<date>) before it is replaced.
"""
import configparser
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path

from PySide6.QtCore import QProcess, QSize, Qt, QTimer
from PySide6.QtGui import QColor, QGuiApplication, QIcon, QPainter, QPainterPath, QPixmap
from PySide6.QtWidgets import (QButtonGroup, QCheckBox, QComboBox, QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit,
                               QMessageBox, QPushButton, QScrollArea, QSpinBox, QVBoxLayout, QWidget)

HOME = Path.home()
OBS_ID = "com.obsproject.Studio"
OBS_CFG = HOME / ".var/app" / OBS_ID / "config/obs-studio"
COLLECTION = "PhoenixGe"
DEMO = "--demo" in sys.argv
sys.path.insert(0, "/usr/lib/phoenixge/clips")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "clips"))
try:
    import media
except Exception:  # noqa: BLE001 - Clips not installed: the card says so
    media = None

SERVICES = {
    "Twitch": dict(type="rtmp_common", service="Twitch", server="auto", kbps=6000, kbps720=4500,
                   key_url="https://dashboard.twitch.tv/settings/stream",
                   help="Twitch ▸ Creator Dashboard ▸ Settings ▸ Stream ▸ <b>Primary Stream key</b> ▸ Copy."),
    "YouTube": dict(type="rtmp_common", service="YouTube - RTMPS", server="rtmps://a.rtmps.youtube.com:443/live2",
                    kbps=9000, kbps720=6000, key_url="https://www.youtube.com/live_dashboard",
                    help="YouTube Studio ▸ <b>Create ▸ Go live</b> ▸ Stream ▸ <b>Stream key</b> ▸ Copy. "
                         "The very first time, YouTube can take up to 24 hours to switch live streaming on."),
    "Kick": dict(type="rtmp_custom", server="rtmps://fa723fc1b171.global-contribute.live-video.net/app",
                 kbps=8000, kbps720=4500, key_url="https://kick.com/dashboard/settings/stream",
                 help="Kick ▸ Creator dashboard ▸ Settings ▸ <b>Stream URL &amp; Key</b>. Copy the key, and the URL "
                      "too if it differs from the one below."),
}
ENC_LABEL = {"nvenc": "NVIDIA NVENC", "vaapi": "VA-API (AMD / Intel)", "x264": "Software x264 (CPU)"}


def sh(cmd, timeout=8):
    try:
        return subprocess.run(cmd, shell=isinstance(cmd, str), capture_output=True, text=True, timeout=timeout).stdout.strip()
    except Exception:  # noqa: BLE001
        return ""


# ------------------------------------------------------------------ detection
def obs_installed():
    if DEMO:
        return True
    return any(Path(b, OBS_ID).is_dir() for b in ("/var/lib/flatpak/app", HOME / ".local/share/flatpak/app"))


def obs_version():
    """(major, minor) of the OBS Flatpak, (0, 0) when unknown."""
    if DEMO:
        return (31, 1)
    m = re.search(r"Version:\s*(\d+)\.(\d+)", sh(["flatpak", "info", OBS_ID]))
    return (int(m[1]), int(m[2])) if m else (0, 0)


def obs_running():
    for d in os.listdir("/proc"):
        if d.isdigit():
            try:
                if Path(f"/proc/{d}/comm").read_text().strip() == "obs":
                    return True
            except OSError:
                pass
    return False


def gpu_info():
    """{"vendor": nvidia|amd|intel|None, "name", "driver": bool (NVIDIA kernel driver loaded)}"""
    if DEMO:
        return {"vendor": "nvidia", "name": "GeForce RTX 4060 Laptop GPU", "driver": True}
    lines = sh("lspci -nn | grep -Ei 'vga|3d|display'").splitlines()
    pick = next((l for l in lines if "[10de:" in l), None) or next((l for l in lines if "[1002:" in l), None) or \
        (lines[0] if lines else "")
    vendor = "nvidia" if "[10de:" in pick else "amd" if "[1002:" in pick else "intel" if "[8086:" in pick else None
    name = re.sub(r"^.*?: ", "", pick)
    name = re.sub(r"\s*\[[0-9a-f]{4}:[0-9a-f]{4}\].*$", "", name)
    m = re.search(r"\[([^\]]+)\]\s*$", name)
    return {"vendor": vendor, "name": (m[1] if m else name)[:60] or "unknown GPU",
            "driver": Path("/proc/driver/nvidia/version").exists()}


def auto_encoder(gpu):
    if gpu["vendor"] == "nvidia" and gpu["driver"]:
        return "nvenc"
    if os.path.exists("/dev/dri/renderD128") and gpu["vendor"] in ("amd", "intel", "nvidia"):
        return "vaapi" if gpu["vendor"] != "nvidia" else "x264"
    return "x264"


def nvidia_flatpak_gl_missing():
    """NVENC inside a Flatpak needs org.freedesktop.Platform.GL.nvidia-<driver version> (Flatpak installs it on update)."""
    if DEMO:
        return False
    return "org.freedesktop.Platform.GL.nvidia" not in sh(["flatpak", "list", "--runtime", "--columns=application"], 20)


def webcams():
    """[(device, name)] of real capture devices (index 0 of each camera, skips metadata nodes)."""
    if DEMO:
        return [("/dev/video0", "Integrated Camera")]
    out = []
    for d in sorted(Path("/sys/class/video4linux").glob("video*")):
        try:
            if (d / "index").read_text().strip() != "0":
                continue
            out.append((f"/dev/{d.name}", (d / "name").read_text().strip()))
        except OSError:
            continue
    return out


def screen_size():
    s = QGuiApplication.primaryScreen()
    if not s:
        return 1920, 1080
    g, r = s.geometry(), s.devicePixelRatio()
    return int(g.width() * r), int(g.height() * r)


def saved_key(service):
    try:
        return bool(json.loads((OBS_CFG / f"basic/profiles/PhoenixGe-{service}/service.json").read_text())
                    .get("settings", {}).get("key"))
    except (OSError, ValueError):
        return False


# ------------------------------------------------------------------ OBS files
def _source(sid, name, settings, mixers=0, filters=None, volume=1.0):
    s = {"prev_ver": 503447555, "name": name, "uuid": str(uuid.uuid4()), "id": sid, "versioned_id": sid,
         "settings": settings, "mixers": mixers, "sync": 0, "flags": 0, "volume": volume, "balance": 0.5,
         "enabled": True, "muted": False, "push-to-mute": False, "push-to-mute-delay": 0, "push-to-talk": False,
         "push-to-talk-delay": 0, "hotkeys": {}, "deinterlace_mode": 0, "deinterlace_field_order": 0,
         "monitoring_type": 0, "private_settings": {}}
    if filters:
        s["filters"] = [dict(_source(fid, fname, fset), versioned_id=fid) for fid, fname, fset in filters]
    return s


def _item(src, n, x, y, bw, bh, visible=True, align_bounds=0):
    return {"name": src["name"], "source_uuid": src["uuid"], "visible": visible, "locked": False, "rot": 0.0,
            "pos": {"x": float(x), "y": float(y)}, "scale": {"x": 1.0, "y": 1.0}, "align": 5, "bounds_type": 2,
            "bounds_align": align_bounds, "bounds_crop": False, "bounds": {"x": float(bw), "y": float(bh)},
            "crop_left": 0, "crop_top": 0, "crop_right": 0, "crop_bottom": 0, "id": n, "group_item_backup": False,
            "scale_filter": "disable", "blend_method": "default", "blend_type": "normal",
            "show_transition": {"duration": 0}, "hide_transition": {"duration": 0}, "private_settings": {}}


def _scene(name, items):
    return _source("scene", name, {"id_counter": len(items), "custom_size": False, "items": items})


def _abgr(hex_rgb):
    r, g, b = int(hex_rgb[1:3], 16), int(hex_rgb[3:5], 16), int(hex_rgb[5:7], 16)
    return 0xFF000000 | (b << 16) | (g << 8) | r


def scene_collection(o):
    """OBS scene collection: 'Game' (screen capture + optional webcam), 'Starting soon', 'Be right back'."""
    W, H = 1920, 1080
    sources, scenes = [], []
    game = _source("pipewire-screen-capture-source", "Game capture", {"ShowCursor": True})
    sources.append(game)
    items = [_item(game, 1, 0, 0, W, H)]
    if o.get("webcam"):
        cam = _source("v4l2_input", "Webcam", {"device_id": o["webcam"], "auto_reset": True, "buffering": False})
        sources.append(cam)
        cw, ch, m = 420, 236, 28
        x = m if o.get("cam_corner", "br").endswith("l") else W - cw - m
        y = m if o.get("cam_corner", "br").startswith("t") else H - ch - m
        items.append(_item(cam, 2, x, y, cw, ch))
    scenes.append(_scene("Game", items))
    font = {"face": "Inter", "size": 128, "style": "Bold", "flags": 1}
    for title, sub in (("Starting soon", "Grab a drink - we start in a minute"), ("Be right back", "Don't go anywhere")):
        bg = _source("color_source_v3", f"{title} - background", {"color": _abgr("#151116"), "width": W, "height": H})
        t1 = _source("text_ft2_source_v2", f"{title} - title", {"text": title.upper(), "font": font,
                                                                "color1": _abgr("#ff7a2e"), "color2": _abgr("#ff3d1f"),
                                                                "drop_shadow": True})
        t2 = _source("text_ft2_source_v2", f"{title} - subtitle", {"text": sub, "font": dict(font, size=44, style="Regular", flags=0),
                                                                   "color1": _abgr("#f3ece6"), "color2": _abgr("#f3ece6")})
        sources += [bg, t1, t2]
        scenes.append(_scene(title, [_item(bg, 1, 0, 0, W, H), _item(t1, 2, 160, 400, W - 320, 170),
                                     _item(t2, 3, 160, 590, W - 320, 70)]))
    desk = _source("pulse_output_capture", "Desktop Audio", {"device_id": "default"}, mixers=0b011)   # tracks 1 + 2
    mic = _source("pulse_input_capture", "Mic/Aux", {"device_id": "default"}, mixers=0b101,             # tracks 1 + 3
                  filters=[("noise_suppress_filter_v2", "Noise Suppression", {"method": "rnnoise"}),
                           ("noise_gate_filter", "Noise Gate", {"open_threshold": -26.0, "close_threshold": -32.0}),
                           ("compressor_filter", "Compressor", {"ratio": 4.0, "threshold": -18.0, "output_gain": 2.0})])
    if not o.get("desktop_audio", True):
        desk["enabled"] = False; desk["muted"] = True
    if not o.get("mic", True):
        mic["muted"] = True
    coll = {"name": COLLECTION, "current_scene": "Game", "current_program_scene": "Game",
            "scene_order": [{"name": s["name"]} for s in scenes], "sources": scenes + sources, "groups": [],
            "DesktopAudioDevice1": desk, "AuxAudioDevice1": mic, "current_transition": "Fade",
            "transition_duration": 300, "transitions": [], "quick_transitions": [], "saved_projectors": [],
            "preview_locked": False, "scaling_enabled": False, "modules": {}}
    return coll


def encoder_config(enc, kbps, version):
    """(OBS encoder id, streamEncoder.json settings)"""
    base = {"rate_control": "CBR", "bitrate": kbps, "keyint_sec": 2}
    if enc == "nvenc":
        eid = "obs_nvenc_h264_tex" if version >= (31, 0) else "ffmpeg_nvenc"   # OBS 31 has native NVENC on Linux
        return eid, dict(base, preset="p5", preset2="p5", tune="hq", multipass="qres", profile="high", bf=2)
    if enc == "vaapi":
        eid = "ffmpeg_vaapi_tex" if version >= (30, 0) else "ffmpeg_vaapi"
        return eid, dict(base, vaapi_device="/dev/dri/renderD128", profile=100, level=-99, bf=0)
    return "obs_x264", dict(base, preset="veryfast", profile="high", tune="")


def profile_ini(name, o, enc_id):
    out_w, out_h = (1920, 1080) if o["res"] == 1080 else (1280, 720)
    rec = str(media.VIDEOS if media else HOME / "Videos")
    return f"""[General]
Name={name}

[Video]
BaseCX=1920
BaseCY=1080
OutputCX={out_w}
OutputCY={out_h}
FPSType=0
FPSCommon={o['fps']}
ScaleType=lanczos
ColorFormat=NV12
ColorSpace=709
ColorRange=Partial

[Audio]
SampleRate=48000
ChannelSetup=Stereo

[Output]
Mode=Advanced

[AdvOut]
TrackIndex=1
Encoder={enc_id}
ApplyServiceSettings=true
RecType=Standard
RecFilePath={rec}
RecFormat=mkv
RecFormat2=mkv
RecEncoder=none
RecTracks=7
Track1Bitrate=160
Track2Bitrate=160
Track3Bitrate=160
Track1Name=Everything
Track2Name=Game and desktop
Track3Name=Microphone

[SimpleOutput]
FilePath={rec}
RecFormat2=mkv
VBitrate={o['kbps']}
ABitrate=160
"""


def _backup(path):
    if path.exists():
        dst = path.with_name(path.name + time.strftime(".bak-%Y%m%d-%H%M%S"))
        (shutil.copytree if path.is_dir() else shutil.copy2)(path, dst)


def _ini_merge(path, values):
    """Set [section] keys in an OBS ini without touching the rest."""
    cp = configparser.ConfigParser(interpolation=None, strict=False)
    cp.optionxform = str
    try:
        cp.read(path, encoding="utf-8-sig")
    except configparser.Error:
        pass
    for sec, kv in values.items():
        if not cp.has_section(sec):
            cp.add_section(sec)
        for k, v in kv.items():
            cp.set(sec, k, str(v))
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        cp.write(f, space_around_delimiters=False)


def write_obs(service, key, server, o, cfg=None):
    """Write profile + scene collection. o: res, fps, kbps, encoder, webcam, cam_corner, mic, desktop_audio.
    Returns the list of written files."""
    cfg = Path(cfg or OBS_CFG)
    svc = SERVICES[service]
    name = f"PhoenixGe-{service}"
    prof = cfg / "basic/profiles" / name
    scenes = cfg / "basic/scenes" / f"{COLLECTION}.json"
    old_key = None
    try:
        old_key = json.loads((prof / "service.json").read_text()).get("settings", {}).get("key")
    except (OSError, ValueError):
        pass
    _backup(prof); _backup(scenes)
    prof.mkdir(parents=True, exist_ok=True); scenes.parent.mkdir(parents=True, exist_ok=True)
    enc_id, enc_settings = encoder_config(o["encoder"], o["kbps"], o.get("version", (0, 0)))
    (prof / "basic.ini").write_text(profile_ini(name, o, enc_id))
    (prof / "streamEncoder.json").write_text(json.dumps(enc_settings, indent=1))
    settings = {"server": server or svc["server"], "bwtest": False}
    if svc["type"] == "rtmp_common":
        settings["service"] = svc["service"]
    else:
        settings["use_auth"] = False
    if key or old_key:
        settings["key"] = key or old_key
    fd = os.open(prof / "service.json", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)   # the stream key lives only here
    with os.fdopen(fd, "w") as f:
        json.dump({"type": svc["type"], "settings": settings}, f, indent=1)
    os.chmod(prof / "service.json", 0o600)
    scenes.write_text(json.dumps(scene_collection(o), indent=1))
    defaults = {"General": {"FirstRun": "true"},
                "Basic": {"Profile": name, "ProfileDir": name, "SceneCollection": COLLECTION,
                          "SceneCollectionFile": COLLECTION}}
    for ini in ("global.ini", "user.ini"):      # OBS <= 30 reads global.ini, OBS 31+ user.ini
        _ini_merge(cfg / ini, defaults)
    return [prof / "basic.ini", prof / "streamEncoder.json", prof / "service.json", scenes]


def start_obs(service):
    return QProcess.startDetached("flatpak", ["run", OBS_ID, "--profile", f"PhoenixGe-{service}",
                                              "--collection", COLLECTION])


# ------------------------------------------------------------------ UI
def _ui():
    main = sys.modules.get("__main__")
    if hasattr(main, "Card") and hasattr(main, "page"):
        return main.Card, main.page

    class Card(QFrame):
        def __init__(self, title="", text=""):
            super().__init__()
            self.setObjectName("card")
            self.lay = QVBoxLayout(self); self.lay.setContentsMargins(18, 16, 18, 16); self.lay.setSpacing(8)
            if title:
                t = QLabel(title); t.setObjectName("cardTitle"); self.lay.addWidget(t)
            if text:
                x = QLabel(text); x.setWordWrap(True); x.setObjectName("dim"); self.lay.addWidget(x)

    def page(title, subtitle=""):
        w = QWidget(); outer = QVBoxLayout(w); outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame)
        inner = QWidget(); lay = QVBoxLayout(inner); lay.setContentsMargins(36, 30, 36, 30); lay.setSpacing(16)
        h = QLabel(title); h.setObjectName("h1"); lay.addWidget(h)
        if subtitle:
            s = QLabel(subtitle); s.setObjectName("dim"); s.setWordWrap(True); lay.addWidget(s)
        scroll.setWidget(inner); outer.addWidget(scroll)
        return w, lay
    return Card, page


def rounded(pix, w, h, radius=10):
    out = QPixmap(w, h); out.fill(Qt.transparent)
    p = QPainter(out); p.setRenderHint(QPainter.Antialiasing)
    path = QPainterPath(); path.addRoundedRect(0, 0, w, h, radius, radius); p.setClipPath(path)
    if pix.isNull():
        p.fillPath(path, QColor(255, 255, 255, 18))
    else:
        sc = pix.scaled(w, h, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
        p.drawPixmap(-(sc.width() - w) // 2, -(sc.height() - h) // 2, sc)
    p.end()
    return out


def dim(text):
    lbl = QLabel(text); lbl.setObjectName("dim"); lbl.setWordWrap(True); lbl.setTextFormat(Qt.RichText)
    lbl.setOpenExternalLinks(True)
    return lbl


class StreamPage:
    def __init__(self, center):
        self.center = center
        Card, page = _ui()
        self.w, lay = page("Streaming & clips", "Go live on Twitch, YouTube or Kick with OBS Studio - set up in one click, "
                                                "with good settings for your PC. Your clips and Instant Replays live here too.")
        self.w._page = self                                  # keep this object alive with the widget
        self.gpu, self.cams = gpu_info(), webcams()
        self.auto_enc = auto_encoder(self.gpu)
        self.kbps_touched = False

        # ---- OBS status
        self.obs_card = Card("OBS Studio")
        row = QHBoxLayout()
        self.obs_status = dim(""); row.addWidget(self.obs_status, 1)
        self.obs_btn = QPushButton(); self.obs_btn.clicked.connect(self.install_or_open); row.addWidget(self.obs_btn)
        self.obs_card.lay.addLayout(row)
        self.gl_warn = QWidget(); gw = QHBoxLayout(self.gl_warn); gw.setContentsMargins(0, 0, 0, 0)
        gw.addWidget(dim("⚠ NVENC inside Flatpak apps needs the matching NVIDIA driver extension. "
                         "Updating Flatpak apps installs it."), 1)
        b = QPushButton("Install it"); b.clicked.connect(self.install_gl); gw.addWidget(b)
        self.gl_warn.hide(); self.obs_card.lay.addWidget(self.gl_warn)
        lay.addWidget(self.obs_card)

        # ---- 1. service + key
        c = Card("1  ·  Where do you stream?")
        seg = QHBoxLayout(); self.svc_group = QButtonGroup(self.w)
        for i, s in enumerate(SERVICES):
            b = QPushButton(s); b.setCheckable(True); b.setMinimumWidth(110); b.setChecked(i == 0)
            self.svc_group.addButton(b, i); seg.addWidget(b)
        seg.addStretch(); c.lay.addLayout(seg)
        g = QGridLayout(); g.setHorizontalSpacing(10); g.setVerticalSpacing(8)
        g.addWidget(QLabel("Stream key"), 0, 0)
        self.key = QLineEdit(); self.key.setEchoMode(QLineEdit.Password); g.addWidget(self.key, 0, 1)
        show = QPushButton("Show"); show.setCheckable(True)
        show.toggled.connect(lambda on: self.key.setEchoMode(QLineEdit.Normal if on else QLineEdit.Password))
        g.addWidget(show, 0, 2)
        self.get_key = QPushButton("Get my key ↗"); self.get_key.clicked.connect(
            lambda: QProcess.startDetached("xdg-open", [SERVICES[self.service()]["key_url"]]))
        g.addWidget(self.get_key, 0, 3)
        self.server_lbl = QLabel("Server"); self.server = QLineEdit()
        g.addWidget(self.server_lbl, 1, 0); g.addWidget(self.server, 1, 1, 1, 3)
        g.setColumnStretch(1, 1)
        c.lay.addLayout(g)
        self.key_help = dim(""); c.lay.addWidget(self.key_help)
        c.lay.addWidget(dim("Your key is a password: it is saved only in OBS's own settings file "
                            "(<i>service.json</i>, readable only by you) and never leaves this PC except to the "
                            "streaming site. You can also leave it empty and paste it in OBS later."))
        lay.addWidget(c)

        # ---- 2. quality
        c = Card("2  ·  Quality")
        self.auto_lbl = QLabel(); self.auto_lbl.setObjectName("cardTitle"); self.auto_lbl.setStyleSheet("font-size:13px;")
        c.lay.addWidget(self.auto_lbl)
        row = QHBoxLayout(); row.setSpacing(10)
        self.res = QComboBox()
        for label, data in (("1080p · 60 fps", (1080, 60)), ("1080p · 30 fps", (1080, 30)), ("720p · 60 fps", (720, 60)),
                            ("720p · 30 fps", (720, 30))):
            self.res.addItem(label, data)
        self.kbps = QSpinBox(); self.kbps.setRange(1000, 20000); self.kbps.setSingleStep(500); self.kbps.setSuffix(" kbps")
        self.enc = QComboBox()
        self.enc.addItem(f"Automatic - {ENC_LABEL[self.auto_enc]}", self.auto_enc)
        for k, v in ENC_LABEL.items():
            self.enc.addItem(v, k)
        for lbl, w in (("Video", self.res), ("Bitrate", self.kbps), ("Encoder", self.enc)):
            row.addWidget(QLabel(lbl)); row.addWidget(w)
        row.addStretch(); c.lay.addLayout(row)
        self.slow = QCheckBox("Slow upload or older PC - use 720p60 (smoother than a stuttering 1080p)")
        c.lay.addWidget(self.slow)
        self.upload_hint = dim(""); c.lay.addWidget(self.upload_hint)
        lay.addWidget(c)

        # ---- 3. scene + audio
        c = Card("3  ·  Scene and sound")
        self.cb_game = QCheckBox("Game capture - the whole screen through PipeWire (KDE asks once which screen to share)")
        self.cb_game.setChecked(True); self.cb_game.setEnabled(False)
        c.lay.addWidget(self.cb_game)
        cam_row = QHBoxLayout()
        self.cb_cam = QCheckBox("Webcam" + (f" - {self.cams[0][1]}" if self.cams else " (none found - plug one in and reopen)"))
        self.cb_cam.setChecked(bool(self.cams)); self.cb_cam.setEnabled(bool(self.cams))
        self.cam_dev = QComboBox()
        for dev, name in self.cams:
            self.cam_dev.addItem(name, dev)
        self.cam_dev.setVisible(len(self.cams) > 1)
        self.corner = QComboBox()
        for label, k in (("bottom right", "br"), ("bottom left", "bl"), ("top right", "tr"), ("top left", "tl")):
            self.corner.addItem(label, k)
        self.corner.setEnabled(bool(self.cams))
        cam_row.addWidget(self.cb_cam); cam_row.addWidget(self.cam_dev); cam_row.addWidget(QLabel("corner")); cam_row.addWidget(self.corner)
        cam_row.addStretch(); c.lay.addLayout(cam_row)
        self.cb_mic = QCheckBox("Microphone - with noise suppression (RNNoise), noise gate and compressor")
        self.cb_mic.setChecked(True); c.lay.addWidget(self.cb_mic)
        self.cb_desk = QCheckBox("Game and desktop sound"); self.cb_desk.setChecked(True); c.lay.addWidget(self.cb_desk)
        c.lay.addWidget(dim("Also adds <b>Starting soon</b> and <b>Be right back</b> scenes. Recordings get 3 audio tracks "
                            "(1 everything · 2 game only · 3 mic only) so you can fix the mix when editing."))
        lay.addWidget(c)

        # ---- go
        go = QHBoxLayout()
        self.setup_btn = QPushButton(); self.setup_btn.setObjectName("primary"); self.setup_btn.clicked.connect(self.setup)
        self.start_btn = QPushButton(); self.start_btn.clicked.connect(self.start)
        go.addWidget(self.setup_btn); go.addWidget(self.start_btn); go.addStretch()
        lay.addLayout(go)
        self.result = dim(""); lay.addWidget(self.result)

        # ---- clips
        self.clips_card = Card("Clips and Instant Replays")
        self.clips_row = QHBoxLayout(); self.clips_row.setSpacing(10)
        self.clips_card.lay.addLayout(self.clips_row)
        self.clips_txt = dim(""); self.clips_card.lay.addWidget(self.clips_txt)
        row = QHBoxLayout()
        b = QPushButton("Open Clips"); b.setObjectName("primary")
        b.clicked.connect(lambda: QProcess.startDetached("phoenixge-clips", [])); row.addWidget(b)
        b = QPushButton("Replays folder")
        b.clicked.connect(lambda: media and (media.REPLAYS.mkdir(parents=True, exist_ok=True),
                                            QProcess.startDetached("xdg-open", [str(media.REPLAYS)])))
        row.addWidget(b); row.addStretch()
        self.clips_card.lay.addLayout(row)
        lay.addWidget(self.clips_card)
        lay.addStretch()

        self.svc_group.idClicked.connect(lambda _i: self.on_service())
        self.res.currentIndexChanged.connect(lambda _i: self.on_quality(reset_kbps=True))
        self.enc.currentIndexChanged.connect(lambda _i: self.on_quality())
        self.kbps.valueChanged.connect(self.on_kbps)
        self.slow.toggled.connect(lambda on: self.res.setCurrentIndex(2 if on else 0))
        self.cb_cam.toggled.connect(self.corner.setEnabled)
        self.refresh_obs(); self.on_service(); self.refresh_clips()

    # ---------------------------------------------------------- state
    def service(self):
        return list(SERVICES)[max(0, self.svc_group.checkedId())]

    def options(self):
        res, fps = self.res.currentData()
        return dict(res=res, fps=fps, kbps=self.kbps.value(), encoder=self.enc.currentData(),
                    webcam=self.cam_dev.currentData() if self.cb_cam.isChecked() and self.cams else None,
                    cam_corner=self.corner.currentData(), mic=self.cb_mic.isChecked(),
                    desktop_audio=self.cb_desk.isChecked(), version=obs_version())

    def on_service(self):
        s = self.service(); svc = SERVICES[s]
        self.key_help.setText("Where is my key? " + svc["help"])
        self.key.clear()
        self.key.setPlaceholderText("Saved ✓ - paste a new one to replace it" if saved_key(s) else f"Paste your {s} stream key")
        custom = svc["type"] == "rtmp_custom"
        self.server_lbl.setVisible(custom); self.server.setVisible(custom); self.server.setText(svc["server"])
        self.setup_btn.setText(f"Set up OBS for {s}")
        self.start_btn.setText(f"▶  Start OBS with PhoenixGe-{s}")
        self.on_quality(reset_kbps=True)

    def on_quality(self, reset_kbps=False):
        svc = SERVICES[self.service()]
        res, fps = self.res.currentData()
        if reset_kbps or not self.kbps_touched:
            k = svc["kbps"] if res == 1080 else svc["kbps720"]
            if fps == 30:
                k = int(k * 0.7 / 500) * 500
            self.kbps.blockSignals(True); self.kbps.setValue(k); self.kbps.blockSignals(False)
            self.kbps_touched = False
        self.slow.blockSignals(True); self.slow.setChecked(res == 720); self.slow.blockSignals(False)
        enc = self.enc.currentData()
        gpu = self.gpu["name"] if enc in ("nvenc", "vaapi") else "your CPU"
        self.auto_lbl.setText(f"{'Recommended' if not self.kbps_touched and self.enc.currentIndex() == 0 else 'Your choice'}: "
                              f"{res}p{fps}  ·  {self.kbps.value()} kbps  ·  {ENC_LABEL[enc]} on {gpu}")
        need = int(self.kbps.value() * 1.4 / 1000 + 0.5)
        warn = ""
        if enc == "nvenc" and not self.gpu["driver"]:
            warn = " ⚠ The NVIDIA driver is not running - pick Automatic or x264 until it is (Center ▸ Drivers)."
        if enc == "x264" and res == 1080 and fps == 60:
            warn = " ⚠ x264 at 1080p60 needs a strong CPU while gaming - 720p60 is safer."
        self.upload_hint.setText(f"Needs about {need} Mbit/s of upload. Test yours at speed.cloudflare.com.{warn}")

    def on_kbps(self, _v):
        self.kbps_touched = True
        self.on_quality()

    def refresh_obs(self):
        """flatpak info / list take a few hundred ms: ask in a thread so the Center opens instantly."""
        def work():
            inst = obs_installed()
            v = obs_version() if inst else (0, 0)
            gl = inst and self.gpu["vendor"] == "nvidia" and self.gpu["driver"] and nvidia_flatpak_gl_missing()
            QTimer.singleShot(0, self.obs_btn, lambda: self._show_obs(inst, v, gl))
        threading.Thread(target=work, daemon=True).start()

    def _show_obs(self, inst, v, gl_missing):
        if inst:
            self.obs_status.setText(f"✓ Installed from Flathub{f' - version {v[0]}.{v[1]}' if v != (0, 0) else ''}. "
                                    "The button below makes a PhoenixGe-Twitch / -YouTube / -Kick profile in it.")
            self.obs_btn.setText("Open OBS")
        else:
            self.obs_status.setText("Not installed yet. One click installs it from Flathub (about 400 MB).")
            self.obs_btn.setText("Install OBS Studio")
        self.gl_warn.setVisible(bool(gl_missing))
        self.start_btn.setEnabled(inst)

    def refresh_clips(self):
        if media is None:
            self.clips_txt.setText("The Clips app is not installed."); return

        def work():
            items = media.scan()
            replay = None
            try:
                sys.path.insert(0, "/usr/lib/phoenixge/overlay")
                import sources
                replay = sources.replay_status()["running"]
            except Exception:  # noqa: BLE001
                pass
            thumbs = [(it, it["path"] if it["kind"] == "image" else media.thumbnail(it["path"])) for it in items[:5]]
            QTimer.singleShot(0, self.clips_txt, lambda: self._show_clips(items, replay, thumbs))
        threading.Thread(target=work, daemon=True).start()

    def _show_clips(self, items, replay, thumbs):
        while self.clips_row.count():
            it = self.clips_row.takeAt(0)
            if it.widget():
                it.widget().hide(); it.widget().deleteLater()
        week = [i for i in items if i["mtime"] > time.time() - 7 * 86400]
        vids = sum(1 for i in week if i["kind"] == "video")
        shots = len(week) - vids
        txt = (f"This week: <b>{vids}</b> clip{'s' * (vids != 1)} and <b>{shots}</b> screenshot{'s' * (shots != 1)}"
               if week else "No clips this week.")
        if items:
            txt += f" · newest {self.ago(items[0]['mtime'])} ({items[0]['game']})"
        if replay is not None:
            txt += ("<br>Instant Replay is <b>on</b> - press Save in the overlay (Meta+G)." if replay else
                    "<br>Instant Replay is off - switch it on in Center ▸ Gaming or the overlay (Meta+G).")
        self.clips_txt.setText(txt)
        for it, src in thumbs:
            b = QPushButton(); b.setFixedSize(176, 99); b.setIconSize(QSize(168, 95)); b.setFlat(True)
            b.setToolTip(f"{it['game']} - {it['name']}"); b.setCursor(Qt.PointingHandCursor)
            b.setStyleSheet("QPushButton { padding: 0; border: none; background: transparent; border-radius: 12px; }"
                            "QPushButton:hover { background: rgba(255,255,255,0.10); }")
            pm = QPixmap(src) if src else QPixmap()
            b.setIcon(QIcon(rounded(pm, 168, 95)))
            b.clicked.connect(lambda _=False, path=it["path"]: QProcess.startDetached("phoenixge-clips", [path]))
            self.clips_row.addWidget(b)
        self.clips_row.addStretch()

    @staticmethod
    def ago(ts):
        s = time.time() - ts
        return "just now" if s < 90 else f"{int(s // 60)} min ago" if s < 3600 else \
            f"{int(s // 3600)} h ago" if s < 86400 else f"{int(s // 86400)} days ago"

    # ---------------------------------------------------------- actions
    def install_or_open(self):
        if obs_installed():
            QProcess.startDetached("flatpak", ["run", OBS_ID]); return
        self.obs_btn.setEnabled(False); self.obs_btn.setText("Installing…")
        self.center.runner.run("flatpak", ["install", "-y", "--noninteractive", "flathub", OBS_ID],
                               lambda code: (self.obs_btn.setEnabled(True), self.refresh_obs()))

    def install_gl(self):
        self.center.runner.run("flatpak", ["update", "-y", "--noninteractive"], lambda _c: self.refresh_obs())

    def setup(self):
        s = self.service()
        if obs_running():
            QMessageBox.information(self.w, "OBS Studio", "Close OBS first - it overwrites its settings when it quits.")
            return
        key = re.sub(r"\s+", "", self.key.text())
        try:
            files = write_obs(s, key, self.server.text().strip() if SERVICES[s]["type"] == "rtmp_custom" else None,
                              self.options())
        except OSError as e:
            self.result.setText(f"✗ Could not write the OBS settings: {e}"); return
        self.key.clear(); self.on_service()
        o = self.options()
        self.result.setText(f"✓ OBS is set up for <b>{s}</b>: {o['res']}p{o['fps']}, {o['kbps']} kbps, "
                            f"{ENC_LABEL[o['encoder']]}. Profile <i>PhoenixGe-{s}</i>, scene collection <i>PhoenixGe</i>."
                            + ("" if saved_key(s) else " No stream key yet - paste it above or in OBS ▸ Settings ▸ Stream.")
                            + "<br>First start: KDE asks which screen to share - pick it and tick <i>Allow restoring</i>.")
        log = getattr(self.center, "log", None)
        if log is not None:
            log.show(); log.appendPlainText("OBS files written:\n  " + "\n  ".join(str(f) for f in files))
        if not obs_installed():
            self.result.setText(self.result.text() + "<br>Now install OBS Studio (button at the top).")

    def start(self):
        s = self.service()
        if not (OBS_CFG / f"basic/profiles/PhoenixGe-{s}/basic.ini").exists():
            self.setup()
        if obs_installed() and not obs_running():
            start_obs(s)
        elif obs_running():
            QMessageBox.information(self.w, "OBS Studio", "OBS is already open. Pick the profile in OBS ▸ Profile.")


def build(center):
    return StreamPage(center).w


# ------------------------------------------------------------------ standalone test
if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication, QPlainTextEdit
    app = QApplication(sys.argv[:1])
    if DEMO and media:
        import tempfile
        media.make_demo(tempfile.mkdtemp(prefix="phoenixge-creator-demo-"))
        OBS_CFG = Path(tempfile.mkdtemp(prefix="obs-demo-"))

    class FakeCenter(QWidget):
        def __init__(self):
            super().__init__()
            lay = QVBoxLayout(self); lay.setContentsMargins(0, 0, 0, 0)
            self.log = QPlainTextEdit(); self.log.hide()

            class R:
                def run(_s, prog, args, done=None):
                    self.log.show(); self.log.appendPlainText(f"$ {prog} {' '.join(args)}")
            self.runner = R()
            lay.addWidget(build(self)); lay.addWidget(self.log)
            self.resize(1180, 900)

    win = FakeCenter(); win.show()
    sys.exit(app.exec())
