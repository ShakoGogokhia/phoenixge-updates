"""PhoenixGe Center > Controllers & keys.

  * Controllers: what is connected (Xbox / PlayStation / Switch Pro / 8BitDo / generic), connection, battery,
    live test view (buttons, sticks, triggers) and a Learn wizard for pads with unusual button order.
  * Xbox mode: any controller looks like an Xbox 360 pad to games (own small evdev -> uinput mapper,
    /usr/lib/phoenixge/inputmap/xpad.py). Steam games: Steam Input does it already.
  * Keyboard & mouse: input-remapper quick presets (side buttons, Caps = Esc, push-to-talk, no Windows key) + its editor.
  * Per-game profiles: Xbox mode and remap presets switched automatically when phoenix-game-run starts the game.

build(center) -> QWidget        python3 inputmap.py [--demo]   (alone, for testing)
"""
import select
import sys
import threading
import time
from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QFont, QPainter, QPen
from PySide6.QtWidgets import (QCheckBox, QComboBox, QGridLayout, QHBoxLayout, QLabel, QMessageBox, QPushButton,
                               QSlider, QVBoxLayout, QWidget)

sys.path.insert(0, str(Path(__file__).resolve().parent))
from systools_ui import DEMO, GREEN, GREY, YELLOW, Bridge, accent, dim, dot, ui  # noqa: E402

LIB = Path("/usr/lib/phoenixge/inputmap")
if not LIB.exists():  # running from the source tree
    LIB = Path(__file__).resolve().parent.parent / "inputmap"
sys.path.insert(0, str(LIB))
import inputctl  # noqa: E402
import inputdevices as devs  # noqa: E402
import inputprofiles as profiles  # noqa: E402
import remapper  # noqa: E402
import xpad  # noqa: E402

KIND_TEXT = {"xbox": "Works in every game (Xbox controller)",
             "playstation": "Works natively - Steam and SDL games know it, Proton shows it as a controller",
             "nintendo": "Works natively in Steam and SDL games",
             "steam": "Steam controller - best used through Steam Input",
             "8bitdo": "8BitDo - switch it to X-input mode (hold X while turning on) for best results",
             "generic": "Generic pad - games may mix up buttons. Turn on Xbox mode, check with Test, fix with Learn."}


# ------------------------------------------------------------------ live test view
class PadView(QWidget):
    """Draws an Xbox-layout pad from a logical state dict (xpad.Translator.state())."""

    def __init__(self, color):
        super().__init__()
        self.color = QColor(color)
        self.st = {}
        self.setMinimumSize(460, 230)

    def set_state(self, st):
        self.st = st
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        pal = self.palette()
        fg = pal.color(pal.ColorRole.WindowText)
        off = QColor(fg); off.setAlpha(40)
        line = QColor(fg); line.setAlpha(90)
        s = min(self.width() / 600.0, self.height() / 300.0)
        p.translate((self.width() - 600 * s) / 2, (self.height() - 300 * s) / 2); p.scale(s, s)
        st, acc = self.st, self.color
        f = QFont(self.font()); f.setPointSizeF(9); f.setBold(True); p.setFont(f)

        def fill(on):
            return acc if on else off

        # body
        p.setPen(QPen(line, 2)); p.setBrush(Qt.NoBrush)
        p.drawRoundedRect(QRectF(40, 50, 520, 230), 110, 110)
        # triggers (bars) + bumpers
        for x, lg, bl in ((70, "lt", "lb"), (390, "rt", "rb")):
            p.setPen(Qt.NoPen); p.setBrush(off); p.drawRoundedRect(QRectF(x, 4, 140, 14), 7, 7)
            v = float(st.get(lg, 0) or 0)
            if v > 0.01:
                p.setBrush(acc); p.drawRoundedRect(QRectF(x, 4, 140 * v, 14), 7, 7)
            p.setPen(fg); p.drawText(QRectF(x, 4, 140, 14), Qt.AlignCenter, lg.upper())
            p.setPen(Qt.NoPen); p.setBrush(fill(st.get(bl))); p.drawRoundedRect(QRectF(x, 26, 140, 18), 9, 9)
            p.setPen(fg); p.drawText(QRectF(x, 26, 140, 18), Qt.AlignCenter, bl.upper())

        def stick(cx, cy, lx, ly, click):
            p.setPen(QPen(line, 2)); p.setBrush(fill(st.get(click)))
            p.drawEllipse(QPointF(cx, cy), 38, 38)
            x, y = float(st.get(lx, 0) or 0), float(st.get(ly, 0) or 0)
            p.setPen(Qt.NoPen); p.setBrush(acc if (abs(x) > 0.05 or abs(y) > 0.05) else fg)
            p.drawEllipse(QPointF(cx + x * 26, cy + y * 26), 11, 11)
        stick(150, 120, "lx", "ly", "ls")
        stick(380, 205, "rx", "ry", "rs")
        # d-pad
        cx, cy = 225, 205
        p.setPen(Qt.NoPen)
        for lg, r in (("up", QRectF(cx - 12, cy - 40, 24, 28)), ("down", QRectF(cx - 12, cy + 12, 24, 28)),
                      ("left", QRectF(cx - 40, cy - 12, 28, 24)), ("right", QRectF(cx + 12, cy - 12, 28, 24))):
            p.setBrush(fill(st.get(lg))); p.drawRoundedRect(r, 5, 5)
        # face buttons
        for lg, (x, y) in (("y", (455, 82)), ("x", (420, 117)), ("b", (490, 117)), ("a", (455, 152))):
            p.setPen(Qt.NoPen); p.setBrush(fill(st.get(lg))); p.drawEllipse(QPointF(x, y), 17, 17)
            p.setPen(fg); p.drawText(QRectF(x - 17, y - 17, 34, 34), Qt.AlignCenter, lg.upper())
        # back / guide / start
        for lg, x, r, t in (("back", 262, 10, "⧉"), ("guide", 300, 16, "⌂"), ("start", 338, 10, "≡")):
            p.setPen(Qt.NoPen); p.setBrush(fill(st.get(lg))); p.drawEllipse(QPointF(x, 112), r, r)
            p.setPen(fg); p.drawText(QRectF(x - r, 112 - r, 2 * r, 2 * r), Qt.AlignCenter, t)
        p.end()


class PadReader(threading.Thread):
    """Reads raw events from one controller (no grab - games keep working) and hands them to the UI thread."""

    def __init__(self, path, bridge):
        super().__init__(daemon=True)
        self.path, self.bridge, self.stop = path, bridge, False
        self.absinfo, self.keys, self.error = {}, set(), ""

    def open(self):
        import evdev
        self.dev = evdev.InputDevice(self.path)
        self.keys, self.absinfo = xpad.device_info(self.dev)

    def run(self):
        try:
            while not self.stop:
                r, _w, _x = select.select([self.dev.fd], [], [], 0.2)
                if not r:
                    continue
                batch = [(ev.type, ev.code, ev.value) for ev in self.dev.read() if ev.type in (1, 3)]
                if batch:
                    self.bridge.result.emit(batch)
        except OSError:
            self.bridge.result.emit(None)      # unplugged
        finally:
            try:
                self.dev.close()
            except Exception:  # noqa: BLE001
                pass


# ------------------------------------------------------------------ page
class InputPage(QWidget):
    def __init__(self, center):
        super().__init__()
        self.center = center
        self.acc = accent()
        Card, page, FlowGrid = ui(center)
        self.Card = Card
        w, lay = page("Controllers & keys", "Game controllers, Xbox mode for any pad, mouse buttons and keyboard "
                                            "keys - and profiles that switch by themselves when a game starts.")
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0); outer.addWidget(w)

        # ---- controllers
        self.ccard = Card("Controllers")
        top = QHBoxLayout(); self.csum = QLabel("Looking…"); self.csum.setStyleSheet("font-weight:600;")
        rb = QPushButton("Refresh"); rb.clicked.connect(self.refresh)
        top.addWidget(self.csum, 1); top.addWidget(rb)
        self.ccard.lay.addLayout(top)
        self.cbox = QVBoxLayout(); self.cbox.setSpacing(10); self.ccard.lay.addLayout(self.cbox)
        lay.addWidget(self.ccard)

        # ---- test view
        self.tcard = Card("Test")
        self.ttitle = dim("")
        self.view = PadView(self.acc)
        self.traw = QLabel(""); self.traw.setObjectName("dim")
        self.learn_lbl = QLabel(""); self.learn_lbl.setStyleSheet(f"font-size:15px;font-weight:600;color:{self.acc};")
        self.learn_lbl.hide()
        tb = QHBoxLayout()
        self.learn_btn = QPushButton("Learn buttons…"); self.learn_btn.clicked.connect(self.learn_start)
        self.skip_btn = QPushButton("Skip"); self.skip_btn.clicked.connect(lambda: self.learn_next(None)); self.skip_btn.hide()
        self.cancel_btn = QPushButton("Cancel"); self.cancel_btn.clicked.connect(self.learn_cancel); self.cancel_btn.hide()
        self.reset_btn = QPushButton("Reset to automatic"); self.reset_btn.clicked.connect(self.reset_mapping)
        close = QPushButton("Close test"); close.clicked.connect(self.stop_test)
        for b in (self.learn_btn, self.skip_btn, self.cancel_btn, self.reset_btn):
            tb.addWidget(b)
        tb.addStretch(); tb.addWidget(close)
        opts = QHBoxLayout()
        self.swap_ab = QCheckBox("Swap A/B"); self.swap_xy = QCheckBox("Swap X/Y")
        self.swap_ab.setToolTip("Nintendo-style labels: A on the right")
        self.dz = QSlider(Qt.Horizontal); self.dz.setRange(0, 30); self.dz.setFixedWidth(160)
        self.dzl = QLabel("")
        for x in (self.swap_ab, self.swap_xy):
            x.toggled.connect(self.save_opts)
        self.dz.valueChanged.connect(self.save_opts)
        opts.addWidget(self.swap_ab); opts.addWidget(self.swap_xy); opts.addSpacing(20)
        opts.addWidget(QLabel("Stick dead zone")); opts.addWidget(self.dz); opts.addWidget(self.dzl); opts.addStretch()
        for x in (self.ttitle, self.learn_lbl, self.view, self.traw):
            self.tcard.lay.addWidget(x)
        self.tcard.lay.addLayout(opts); self.tcard.lay.addLayout(tb)
        self.tcard.lay.addWidget(dim("The test shows the controller the way games will see it in Xbox mode. "
                                     "Settings here are used by Xbox mode (turn it off and on again to apply)."))
        self.tcard.hide()
        lay.addWidget(self.tcard)

        # ---- how it works (honest)
        how = Card("Make any controller work like an Xbox controller")
        how.lay.addWidget(dim(
            "<b>Steam games:</b> Steam Input already translates every controller (PlayStation, Switch, 8BitDo, generic) "
            "- nothing to do; Steam > Settings > Controller.<br>"
            "<b>Everything else</b> (Heroic, Lutris, Minecraft, emulators, native games): Xbox mode makes the controller "
            "appear as an Xbox 360 pad and hides the original, so games show Xbox buttons and nothing is pressed twice. "
            "<b>Auto</b> (default) uses it only for pads games don't know, and never for Steam games.<br>"
            "Not passed through in Xbox mode: rumble, motion sensors, touchpad and lights. PlayStation and Switch pads "
            "usually work better without it."))
        lay.addWidget(how)

        # ---- keyboard & mouse
        self.kcard = Card("Keyboard & mouse", "Remap keys and mouse buttons, extra mouse buttons, macros. "
                                              "Pick a device, then a quick setup - or open the full editor.")
        self.kstatus = QHBoxLayout(); self.kdot = dot(GREY); self.ktext = QLabel("")
        self.ktext.setWordWrap(True)
        self.kfix = QPushButton("Start remapping service"); self.kfix.clicked.connect(self.start_service); self.kfix.hide()
        self.kstatus.addWidget(self.kdot); self.kstatus.addWidget(self.ktext, 1); self.kstatus.addWidget(self.kfix)
        self.kcard.lay.addLayout(self.kstatus)
        drow = QHBoxLayout()
        self.kdev = QComboBox(); self.kdev.setMinimumWidth(320); self.kdev.currentIndexChanged.connect(self.show_device)
        self.kactive = QLabel(""); self.kactive.setObjectName("dim")
        drow.addWidget(QLabel("Device")); drow.addWidget(self.kdev); drow.addWidget(self.kactive, 1)
        self.kcard.lay.addLayout(drow)
        self.qgrid = FlowGrid(300, 3) if FlowGrid else None
        self.qbox = QVBoxLayout()
        self.kcard.lay.addWidget(self.qgrid) if self.qgrid else self.kcard.lay.addLayout(self.qbox)
        brow = QHBoxLayout()
        self.koff = QPushButton("Turn remapping off for this device"); self.koff.clicked.connect(self.remap_off)
        self.kedit = QPushButton("Full editor (any key, macros)…"); self.kedit.clicked.connect(self.open_editor)
        brow.addWidget(self.koff); brow.addStretch(); brow.addWidget(self.kedit)
        self.kcard.lay.addLayout(brow)
        lay.addWidget(self.kcard)

        # ---- per-game profiles
        self.gcard = Card("Per-game profiles", "Chosen automatically when a game is started from Phoenix Games "
                                                "(phoenix-game-run) and undone when it closes.")
        g = QGridLayout(); g.setHorizontalSpacing(12); g.setVerticalSpacing(8)
        self.ggame = QComboBox(); self.ggame.setMinimumWidth(320); self.ggame.addItem("Loading your games…", "")
        self.ggame.currentIndexChanged.connect(self.show_game)
        self.gxbox = QComboBox()
        for v, t in (("auto", "Auto (only pads games don't know, never in Steam games)"), ("on", "On for every non-Xbox pad"),
                     ("off", "Off")):
            self.gxbox.addItem(t, v)
        g.addWidget(QLabel("Game"), 0, 0); g.addWidget(self.ggame, 0, 1)
        g.addWidget(QLabel("Xbox mode"), 1, 0); g.addWidget(self.gxbox, 1, 1)
        g.setColumnStretch(1, 1)
        self.gcard.lay.addLayout(g)
        self.gremap = QGridLayout(); self.gremap.setHorizontalSpacing(12); self.gcard.lay.addLayout(self.gremap)
        sv = QHBoxLayout(); self.gsave = QPushButton("Save profile"); self.gsave.setObjectName("primary")
        self.gsave.clicked.connect(self.save_game)
        self.gmsg = QLabel(""); self.gmsg.setObjectName("dim")
        sv.addWidget(self.gsave); sv.addWidget(self.gmsg, 1)
        self.gcard.lay.addLayout(sv)
        self.glist = QVBoxLayout(); self.gcard.lay.addLayout(self.glist)
        lay.addWidget(self.gcard)
        lay.addStretch()

        self.ctrls, self.rdevs, self.games, self.combos = [], [], [], {}
        self.reader, self.test_ctrl, self.tr = None, None, None
        self.learning, self.learn_i, self.learn_map, self.learn_base, self.learn_quiet = False, 0, {}, {}, 0.0
        self.bridge = Bridge(); self.bridge.result.connect(self.on_events)
        self.gbridge = Bridge(); self.gbridge.result.connect(self.on_games)
        self.timer = QTimer(self); self.timer.setInterval(4000); self.timer.timeout.connect(self.refresh_controllers)
        self.demo_t = QTimer(self); self.demo_t.setInterval(60); self.demo_t.timeout.connect(self.demo_tick)
        self.shown = False

    # pages are built when the Center starts - work only when opened
    def showEvent(self, e):
        super().showEvent(e)
        self.timer.start()
        if not self.shown:
            self.shown = True
            self.refresh()
            threading.Thread(target=self.load_games, daemon=True).start()

    def hideEvent(self, e):
        super().hideEvent(e)
        self.timer.stop()
        self.stop_test()

    def refresh(self):
        self.refresh_controllers(force=True)
        self.refresh_remap()

    # ---------------------------------------------------------------- controllers
    def refresh_controllers(self, force=False):
        ctrls = devs.DEMO_CONTROLLERS if DEMO else devs.controllers()
        sig = [(c["event"], (c["battery"] or {}).get("percent")) for c in ctrls]
        running = {"/dev/input/event25": 1} if DEMO else inputctl.xbox_running()
        if not force and sig == getattr(self, "_sig", None) and running == getattr(self, "_run", None):
            return
        self._sig, self._run = sig, running
        self.ctrls = ctrls
        while self.cbox.count():
            it = self.cbox.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        if not ctrls:
            self.csum.setText("No controller connected")
            self.cbox.addWidget(dim("Plug it in with a cable, or pair it in System Settings > Bluetooth "
                                    "(PlayStation: hold Share + PS until the light flashes; Xbox: hold the pair button; "
                                    "Switch Pro: hold the sync button)."))
            return
        self.csum.setText(f"{len(ctrls)} controller{'s' if len(ctrls) > 1 else ''} connected")
        data = profiles.load()
        for c in ctrls:
            self.cbox.addWidget(self.ctrl_row(c, c["event"] in running, profiles.device(data, c["dkey"])))

    def ctrl_row(self, c, xbox_on, prof):
        w = QWidget(); g = QGridLayout(w); g.setContentsMargins(0, 4, 0, 4); g.setHorizontalSpacing(10); g.setVerticalSpacing(2)
        state = GREEN if c["native"] or xbox_on else YELLOW
        g.addWidget(dot(state), 0, 0, Qt.AlignVCenter)
        t = QLabel(f"<b>{c['label']}</b>  <span style='color:gray'>{c['name']}</span>"); t.setTextInteractionFlags(Qt.TextSelectableByMouse)
        g.addWidget(t, 0, 1)
        bat = devs.battery_text(c["battery"])
        info = " · ".join(x for x in (c["bus"], f"Battery {bat}" if bat else "", f"driver {c['driver']}") if x)
        g.addWidget(dim(info), 0, 2, Qt.AlignRight)
        txt = KIND_TEXT.get(c["kind"], KIND_TEXT["generic"])
        if xbox_on:
            txt = "Xbox mode is on - games see an Xbox 360 controller."
        g.addWidget(dim(txt), 1, 1, 1, 2)
        row = QHBoxLayout()
        test = QPushButton("Test"); test.clicked.connect(lambda _=False, cc=c: self.start_test(cc))
        xb = QPushButton("Turn Xbox mode off" if xbox_on else "Xbox mode on now")
        xb.setEnabled(c["kind"] != "xbox")
        xb.clicked.connect(lambda _=False, cc=c, on=xbox_on: self.toggle_xbox(cc, on))
        al = QCheckBox("Always (every game, every login)"); al.setChecked(bool(prof["always_xbox"]))
        al.setEnabled(c["kind"] != "xbox")
        al.toggled.connect(lambda v, cc=c: self.set_always(cc, v))
        row.addWidget(test); row.addWidget(xb); row.addWidget(al); row.addStretch()
        g.addLayout(row, 2, 1, 1, 2)
        g.setColumnStretch(1, 1)
        return w

    def toggle_xbox(self, c, on):
        if DEMO:
            return
        if on:
            inputctl.xbox_stop(c["event"])
        else:
            ok, msg = inputctl.xbox_start(c["event"], c["dkey"])
            if not ok:
                QMessageBox.warning(self, "Xbox mode", f"Xbox mode could not start: {msg}")
        QTimer.singleShot(600, lambda: self.refresh_controllers(force=True))

    def set_always(self, c, v):
        if DEMO:
            return
        profiles.set_device(c["dkey"], name=c["name"], always_xbox=bool(v))
        if v:
            inputctl.xbox_start(c["event"], c["dkey"])
            inputctl.ensure_watch()
        QTimer.singleShot(600, lambda: self.refresh_controllers(force=True))

    # ---------------------------------------------------------------- test view + learn
    def start_test(self, c):
        self.stop_test()
        self.test_ctrl = c
        prof = profiles.device(profiles.load(), c["dkey"])
        for x, v in ((self.swap_ab, prof["swap_ab"]), (self.swap_xy, prof["swap_xy"])):
            x.blockSignals(True); x.setChecked(bool(v)); x.blockSignals(False)
        self.dz.blockSignals(True); self.dz.setValue(int(prof["deadzone"])); self.dz.blockSignals(False)
        self.dzl.setText(f"{self.dz.value()}%")
        self.ttitle.setText(f"{c['label']} - press buttons and move the sticks.")
        self.tcard.show()
        if DEMO:
            self.keys, self.absinfo = set(), {}
            self.demo_n = 0
            self.demo_t.start()
            return
        r = PadReader(c["event"], self.bridge)
        try:
            r.open()
        except Exception as e:  # noqa: BLE001
            self.ttitle.setText(f"Can't read {c['event']}: {e}. Log out and back in once if it was just set up.")
            return
        self.keys, self.absinfo = r.keys, r.absinfo
        self.make_translator(prof)
        self.reader = r
        r.start()

    def make_translator(self, prof=None):
        c = self.test_ctrl
        prof = prof or profiles.device(profiles.load(), c["dkey"])
        m = prof["mapping"] or xpad.default_mapping(self.keys, set(self.absinfo), c["standard"])
        m = xpad.apply_swaps(m, prof["swap_ab"], prof["swap_xy"])
        old = self.tr
        self.tr = xpad.Translator(m, self.absinfo, prof["deadzone"])
        if old:
            self.tr.raw_key, self.tr.raw_abs = old.raw_key, old.raw_abs

    def stop_test(self):
        self.demo_t.stop()
        if self.reader:
            self.reader.stop = True
            self.reader = None
        self.learning = False
        self.tcard.hide()

    def save_opts(self):
        self.dzl.setText(f"{self.dz.value()}%")
        if not self.test_ctrl or DEMO:
            return
        profiles.set_device(self.test_ctrl["dkey"], name=self.test_ctrl["name"], swap_ab=self.swap_ab.isChecked(),
                            swap_xy=self.swap_xy.isChecked(), deadzone=self.dz.value())
        self.make_translator()

    def reset_mapping(self):
        if self.test_ctrl and not DEMO:
            profiles.set_device(self.test_ctrl["dkey"], mapping=None)
            self.make_translator()

    def on_events(self, batch):
        if batch is None:
            self.ttitle.setText("The controller was disconnected.")
            self.reader = None
            return
        if not self.tr:
            return
        for t, c, v in batch:
            self.tr.feed(t, c, v)
            if self.learning:
                self.learn_event(t, c, v)
        last = batch[-1]
        try:
            from evdev import ecodes as e
            names = e.KEY if last[0] == 1 else e.ABS
            nm = names.get(last[1], last[1])
            nm = nm[0] if isinstance(nm, (list, tuple)) else nm
        except Exception:  # noqa: BLE001
            nm = last[1]
        self.traw.setText(f"Last event: {nm} = {last[2]}")
        self.view.set_state(self.tr.state())

    def learn_start(self):
        if not self.tr and not DEMO:
            return
        self.learning, self.learn_i, self.learn_map = True, 0, {}
        for b in (self.skip_btn, self.cancel_btn):
            b.show()
        self.learn_btn.hide(); self.learn_lbl.show()
        self.learn_prompt()

    def learn_prompt(self):
        lg = xpad.LOGICAL[self.learn_i]
        self.learn_lbl.setText(f"Step {self.learn_i + 1}/{len(xpad.LOGICAL)}: press  {xpad.LABELS[lg]}")
        self.learn_base = dict(self.tr.raw_abs) if self.tr else {}
        self.learn_quiet = time.time() + 0.45
        self.view.set_state({lg: 1.0 if lg in ("lt", "rt") else (0.8 if lg in ("lx", "ly", "rx", "ry") else True)})

    def learn_event(self, t, c, v):
        if time.time() < self.learn_quiet:
            return
        lg = xpad.LOGICAL[self.learn_i]
        src = None
        if t == 1 and v == 1:
            src = {"t": "key", "c": c}
        elif t == 3:
            lo, hi = self.absinfo.get(c, (-1, 1))
            rng = max(1, hi - lo)
            base = self.learn_base.get(c, (lo + hi) / 2 if lo < 0 else lo)
            delta = (v - base) / rng
            if 16 <= c <= 23 and v:
                src = {"t": "hat", "c": c, "v": 1 if v > 0 else -1}
            elif abs(delta) > 0.4:
                src = {"t": "abs", "c": c, "inv": delta < 0}
        if src:
            self.learn_next(src)

    def learn_next(self, src):
        lg = xpad.LOGICAL[self.learn_i]
        if src:
            self.learn_map[lg] = [src]
        self.learn_i += 1
        if self.learn_i >= len(xpad.LOGICAL):
            self.learning = False
            if not DEMO and self.test_ctrl:
                profiles.set_device(self.test_ctrl["dkey"], name=self.test_ctrl["name"], mapping=self.learn_map,
                                    swap_ab=False, swap_xy=False)
                self.swap_ab.setChecked(False); self.swap_xy.setChecked(False)
                self.make_translator()
            self.learn_cancel(done=True)
            return
        self.learn_prompt()

    def learn_cancel(self, done=False):
        self.learning = False
        for b in (self.skip_btn, self.cancel_btn):
            b.hide()
        self.learn_btn.show()
        self.learn_lbl.setText("Saved - Xbox mode now uses these buttons." if done is True else "")
        self.learn_lbl.setVisible(done is True)

    def demo_tick(self):
        import math
        self.demo_n += 1
        t = self.demo_n / 16.0
        st = {k: False for k in xpad.OUT_BTN}
        st.update(lx=math.cos(t) * 0.8, ly=math.sin(t) * 0.8, rx=0.0, ry=0.0, lt=0.0, rt=(math.sin(t * 0.7) + 1) / 2,
                  up=False, down=False, left=False, right=(int(t) % 4 == 1))
        st["a"] = int(t * 1.3) % 3 == 0
        st["rb"] = True
        self.view.set_state(st)
        self.traw.setText("Last event: ABS_RZ = %d" % int(st["rt"] * 255))

    # ---------------------------------------------------------------- keyboard & mouse
    def refresh_remap(self):
        inst = DEMO or remapper.installed()
        active = DEMO or (inst and remapper.service_active())
        if not inst:
            self.kdot.setStyleSheet(f"background:{YELLOW};border-radius:6px;")
            self.ktext.setText("input-remapper is not installed. It comes with the next PhoenixGe update "
                               "(package input-remapper).")
        elif not active:
            self.kdot.setStyleSheet(f"background:{YELLOW};border-radius:6px;")
            self.ktext.setText("The remapping service is not running.")
        else:
            self.kdot.setStyleSheet(f"background:{GREEN};border-radius:6px;")
            self.ktext.setText("Remapping is ready (input-remapper). Changes work at once, in games too, "
                               "and come back after a restart.")
        self.kfix.setVisible(bool(inst and not active))
        self.rdevs = devs.DEMO_REMAP if DEMO else devs.remap_devices()
        cur = self.kdev.currentData()
        self.kdev.blockSignals(True); self.kdev.clear()
        for d in self.rdevs:
            self.kdev.addItem(f"{d['name'].strip()}  ({d['kind']})", d["key"])
        i = self.kdev.findData(cur)
        self.kdev.setCurrentIndex(i if i >= 0 else 0)
        self.kdev.blockSignals(False)
        for wdg in (self.kdev, self.koff, self.kedit):
            wdg.setEnabled(bool(inst))
        self.show_device()
        self.fill_game_remap()

    def cur_rdev(self):
        k = self.kdev.currentData()
        return next((d for d in self.rdevs if d["key"] == k), None)

    def show_device(self):
        d = self.cur_rdev()
        amap = {"Logitech G502 HERO Gaming Mouse": "PhoenixGe - Back Forward"} if DEMO else remapper.autoload_map()
        act = amap.get(d["key"]) if d else None
        self.kactive.setText(f"Active: {act}" if act else "No remapping")
        cards = []
        for qid, (title, desc, kind, needs, _fn) in remapper.QUICK.items():
            if d and d["kind"] != kind:
                continue
            c = self.Card(title, desc)
            row = QHBoxLayout()
            keyc = None
            if needs:
                keyc = QComboBox()
                for lbl, sym in remapper.KEY_CHOICES:
                    keyc.addItem(lbl, sym)
                row.addWidget(keyc, 1)
            on = act == remapper.QUICK_NAMES[qid]
            b = QPushButton("Active ✓" if on else "Use this"); b.setObjectName("" if on else "primary")
            b.setEnabled(not on and (DEMO or remapper.installed()))
            b.clicked.connect(lambda _=False, q=qid, kc=keyc: self.apply_quick(q, kc))
            row.addStretch(); row.addWidget(b)
            c.lay.addLayout(row)
            cards.append(c)
        if not cards:
            cards.append(self.Card("No quick setups for this device", "Use the full editor for gamepads and other devices."))
        if self.qgrid:
            self.qgrid.set_items(cards)
        else:
            while self.qbox.count():
                it = self.qbox.takeAt(0)
                if it.widget():
                    it.widget().deleteLater()
            for c in cards:
                self.qbox.addWidget(c)

    def apply_quick(self, qid, keyc):
        d = self.cur_rdev()
        if not d or DEMO:
            return
        ok, msg = remapper.apply_quick(d, qid, keyc.currentData() if keyc else None)
        if not ok:
            QMessageBox.warning(self, "Remapping", f"The setup was saved but could not be switched on: {msg}")
        self.show_device(); self.fill_game_remap()

    def remap_off(self):
        d = self.cur_rdev()
        if d and not DEMO:
            ok, msg = remapper.set_active(d["key"], None)
            if not ok:
                QMessageBox.warning(self, "Remapping", msg)
            self.show_device()

    def open_editor(self):
        if not DEMO and not remapper.open_editor():
            QMessageBox.information(self, "Remapping", "The editor (input-remapper-gtk) is not installed.")

    def start_service(self):
        self.center.runner.run("pkexec", ["systemctl", "enable", "--now", "input-remapper-daemon.service"],
                               lambda _c: self.refresh_remap())

    # ---------------------------------------------------------------- per-game profiles
    def load_games(self):
        if DEMO:
            games = [dict(id="steam:730", name="Counter-Strike 2"), dict(id="heroic:legendary:Sugar", name="Rocket League"),
                     dict(id="prism:1.21", name="Minecraft 1.21"), dict(id="lutris:hollow-knight", name="Hollow Knight"),
                     dict(id="desktop:supertuxkart", name="SuperTuxKart")]
        else:
            games = []
            try:
                import importlib.util
                gp = Path("/usr/lib/phoenixge/games/games.py")
                if not gp.exists():
                    gp = Path(__file__).resolve().parent.parent / "games/games.py"
                spec = importlib.util.spec_from_file_location("phx_games_lib", gp)
                mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
                games = [dict(id=g["id"], name=g["name"]) for g in mod.all_games()]
            except Exception as e:  # noqa: BLE001
                print("inputmap: games:", e, file=sys.stderr)
        self.gbridge.result.emit(games)

    def on_games(self, games):
        self.games = games
        self.ggame.blockSignals(True); self.ggame.clear()
        if not games:
            self.ggame.addItem("No games found yet - install some from the Store", "")
        for gm in games:
            self.ggame.addItem(gm["name"], gm["id"])
        self.ggame.blockSignals(False)
        self.show_game()
        self.fill_glist()

    def fill_game_remap(self):
        while self.gremap.count():
            it = self.gremap.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        self.combos = {}
        for i, d in enumerate([d for d in self.rdevs if d["kind"] in ("mouse", "keyboard")]):
            cb = QComboBox(); cb.addItem("Keep as it is", "")
            pre = ["PhoenixGe - Push to talk", "Shooter"] if DEMO else remapper.presets(d["name"])
            for p in pre:
                cb.addItem(p, p)
            self.gremap.addWidget(QLabel(d["name"]), i, 0); self.gremap.addWidget(cb, i, 1)
            self.combos[d["key"]] = cb
        self.gremap.setColumnStretch(1, 1)
        self.show_game()

    def show_game(self):
        gid = self.ggame.currentData()
        self.gsave.setEnabled(bool(gid))
        g = profiles.game(profiles.load(), gid or "")
        if DEMO and gid == "heroic:legendary:Sugar":
            g = dict(xbox="on", remap={"Logitech G502 HERO Gaming Mouse": "PhoenixGe - Push to talk"})
        self.gxbox.setCurrentIndex(max(0, self.gxbox.findData(g["xbox"])))
        for k, cb in self.combos.items():
            cb.setCurrentIndex(max(0, cb.findData(g["remap"].get(k, ""))))

    def save_game(self):
        gid = self.ggame.currentData()
        if not gid or DEMO:
            return
        remap = {k: cb.currentData() for k, cb in self.combos.items() if cb.currentData()}
        profiles.set_game(gid, name=self.ggame.currentText(), xbox=self.gxbox.currentData(), remap=remap)
        self.gmsg.setText(f"Saved - used next time {self.ggame.currentText()} starts.")
        self.fill_glist()

    def fill_glist(self):
        while self.glist.count():
            it = self.glist.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        data = profiles.load()["games"] if not DEMO else {
            "heroic:legendary:Sugar": dict(name="Rocket League", xbox="on",
                                           remap={"Logitech G502 HERO Gaming Mouse": "PhoenixGe - Push to talk"}),
            "steam:730": dict(name="Counter-Strike 2", xbox="auto", remap={"AT Translated Set 2 keyboard": "PhoenixGe - No Windows key"})}
        if not data:
            return
        self.glist.addWidget(QLabel("<b>Saved profiles</b>"))
        for gid, g in sorted(data.items(), key=lambda kv: kv[1].get("name", kv[0]).lower()):
            w = QWidget(); h = QHBoxLayout(w); h.setContentsMargins(0, 0, 0, 0)
            parts = [f"Xbox mode {g.get('xbox', 'auto')}"] + [f"{k}: {v}" for k, v in (g.get("remap") or {}).items()]
            h.addWidget(QLabel(f"<b>{g.get('name') or gid}</b>"))
            h.addWidget(dim(" · ".join(parts)), 1)
            rm = QPushButton("Remove"); rm.clicked.connect(lambda _=False, x=gid: self.remove_game(x))
            h.addWidget(rm)
            self.glist.addWidget(w)

    def remove_game(self, gid):
        if DEMO:
            return
        data = profiles.load(); data["games"].pop(gid, None); profiles.save(data)
        self.fill_glist(); self.show_game()


def build(center):
    return InputPage(center)


if __name__ == "__main__":  # standalone test window
    from PySide6.QtWidgets import QApplication, QPlainTextEdit
    app = QApplication(sys.argv)

    class _Fake(QWidget):
        def __init__(self):
            super().__init__()
            lay = QVBoxLayout(self); self.log = QPlainTextEdit(); self.log.setMaximumHeight(150); self.log.hide()
            try:
                main = sys.modules.get("center") or __import__("center")
                self.runner = main.Runner(self.log)
            except Exception:  # noqa: BLE001
                self.runner = None
            lay.addWidget(build(self)); lay.addWidget(self.log)
    f = _Fake(); f.resize(1100, 900); f.show()
    sys.exit(app.exec())
