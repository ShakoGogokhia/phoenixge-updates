"""PhoenixGe Center > Play with friends: LAN rooms (virtual LAN over the internet, like Radmin VPN / Hamachi, built on
the open-source EasyTier) and one-click game servers (Minecraft Java, Terraria, Counter-Strike 2, Valheim).

    import friends
    ("Play with friends", "network-workgroup", lambda: friends.build(self))     # page tuple in Center.__init__

build(center) -> QWidget   (uses center.runner / center.log when present)
Logic: /usr/lib/phoenixge/friends/room.py and servers.py (no Qt there). Root steps: install-easytier.sh, firewall.sh.
Run alone:   python3 friends.py            python3 friends.py --demo   (fake data)
             python3 friends.py --demo --shot <dir>   (render PNG screenshots offscreen and quit)
"""
import json
import os
import shutil
import subprocess
import sys
import textwrap
import threading
from pathlib import Path

from PySide6.QtCore import QObject, QProcess, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QDesktopServices, QFont, QIcon, QGuiApplication
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFrame, QGridLayout,
                               QHBoxLayout, QLabel, QLayout, QLineEdit, QMenu, QMessageBox, QPlainTextEdit, QPushButton,
                               QRadioButton, QScrollArea, QSizePolicy, QSlider, QSpinBox, QToolButton, QVBoxLayout, QWidget)

FRIENDS = Path("/usr/lib/phoenixge/friends")
if not FRIENDS.exists():                                  # running from the git checkout
    FRIENDS = Path(__file__).resolve().parents[1] / "friends"
sys.path.insert(0, str(FRIENDS))
import room as rm        # noqa: E402
import servers as sv     # noqa: E402

ROOM_PY, SERVERS_PY = str(FRIENDS / "room.py"), str(FRIENDS / "servers.py")
INSTALLER, FIREWALL = str(FRIENDS / "install-easytier.sh"), str(FRIENDS / "firewall.sh")
GREEN, YELLOW, RED, GREY = "#3fb950", "#d29922", "#f85149", "#8b949e"
MONO = "font-family: 'JetBrains Mono','DejaVu Sans Mono',monospace;"
GAME_ICONS = {"minecraft": ["minecraft", "minecraft-launcher", "com.mojang.Minecraft", "lutris_minecraft"],   # Papirus names
              "terraria": ["terraria", "steam_icon_105600", "lutris_terraria"],
              "cs2": ["steam_icon_730", "counter-strike-2", "cs2", "lutris_counter-strike-global-offensive", "csgo"],
              "valheim": ["steam_icon_892970", "valheim", "lutris_valheim"]}


# ------------------------------------------------------------------ look (shared with center.py)
def _ui():
    main = sys.modules.get("__main__")
    if hasattr(main, "Card") and hasattr(main, "page"):
        return main.Card, main.page, getattr(main, "FlowGrid", None)

    class Card(QFrame):
        def __init__(self, title="", text=""):
            super().__init__()
            self.setObjectName("card")
            self.lay = QVBoxLayout(self); self.lay.setContentsMargins(18, 16, 18, 16); self.lay.setSpacing(8)
            if title:
                t = QLabel(title); t.setObjectName("cardTitle"); self.lay.addWidget(t)
            if text:
                x = QLabel(text); x.setWordWrap(True); x.setObjectName("dim"); self.lay.addWidget(x)

    def page(title, subtitle=""):
        w = QWidget(); outer = QVBoxLayout(w); outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame)
        inner = QWidget(); lay = QVBoxLayout(inner); lay.setContentsMargins(36, 30, 36, 30); lay.setSpacing(16)
        h = QLabel(title); h.setObjectName("h1"); lay.addWidget(h)
        if subtitle:
            s = QLabel(subtitle); s.setObjectName("dim"); s.setWordWrap(True); lay.addWidget(s)
        scroll.setWidget(inner); outer.addWidget(scroll)
        return w, lay
    return Card, page, None


def accent():
    fn = getattr(sys.modules.get("__main__"), "accent", None)
    try:
        return fn() if fn else "#ff7a2e"
    except Exception:
        return "#ff7a2e"


def dim(text, wrap=True):
    rich = any(t in text for t in ("<a ", "<b>", "<br>"))
    if rich:   # readable links on dark themes
        text = text.replace("<a ", f'<a style="color:{accent()};" ')
    x = QLabel(text); x.setWordWrap(wrap); x.setObjectName("dim"); x.setTextFormat(Qt.RichText if rich else Qt.PlainText)
    x.setOpenExternalLinks(True)
    return x


def pill(text, color):
    b = QLabel(text)
    b.setStyleSheet(f"QLabel {{ color: {color}; border: 1px solid {color}; border-radius: 9px; padding: 1px 9px; "
                    "font-size: 11px; font-weight: 600; }")
    b.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
    return b


def dot(color, size=10):
    d = QLabel(); d.setFixedSize(size, size); d.setStyleSheet(f"background:{color}; border-radius:{size // 2}px;")
    return d


def copy_button(get_text, label="Copy"):
    b = QPushButton(label)

    def clicked():
        QGuiApplication.clipboard().setText(get_text() if callable(get_text) else get_text)
        b.setText("Copied ✓")

        def back():
            try:
                b.setText(label)
            except RuntimeError:      # the button was rebuilt meanwhile
                pass
        QTimer.singleShot(1500, back)
    b.clicked.connect(clicked)
    return b


def game_badge(game, size=44):
    g = sv.GAMES[game]
    for name in GAME_ICONS.get(game, []):
        if QIcon.hasThemeIcon(name):
            lab = QLabel(); lab.setPixmap(QIcon.fromTheme(name).pixmap(size, size)); lab.setFixedSize(size, size)
            return lab
    lab = QLabel(g["letter"]); lab.setAlignment(Qt.AlignCenter); lab.setFixedSize(size, size)
    lab.setStyleSheet(f"background:{g['color']}; color:white; border-radius:{size // 4}px; font-weight:800; "
                      f"font-size:{size // 2 - (4 if len(g['letter']) > 1 else 0)}px;")
    return lab


def collapsible(title, body: QWidget, open_=False):
    """A '▸ title' toggle that shows/hides body (manual settings stay out of the way until wanted)."""
    t = QToolButton(); t.setText(title); t.setCheckable(True); t.setChecked(open_)
    t.setToolButtonStyle(Qt.ToolButtonTextBesideIcon); t.setArrowType(Qt.DownArrow if open_ else Qt.RightArrow)
    t.setStyleSheet("QToolButton { border: none; font-weight: 600; padding: 4px 0; background: transparent; }")
    body.setVisible(open_)
    t.toggled.connect(lambda on: (body.setVisible(on), t.setArrowType(Qt.DownArrow if on else Qt.RightArrow)))
    return t


def clear(layout):
    while layout.count():
        it = layout.takeAt(0)
        if it.widget():
            w = it.widget(); w.hide(); w.setParent(None); w.deleteLater()
        elif it.layout():
            clear(it.layout())


# ------------------------------------------------------------------ data source (real or demo)
class Backend:
    def room(self):
        return rm.status()

    def room_conf(self):
        return rm.load()

    def room_details(self):
        return rm.details()

    def servers(self):
        return sv.status_all()

    def tail(self, name):
        return sv.tail(name)

    def lan_ip(self):
        return sv.lan_ip()

    def ufw_on(self):
        return sv.ufw_on()

    def easytier_installed(self):
        return rm.installed()


class DemoBackend(Backend):
    def room(self):
        return {"state": "online", "code": "PHX-K7Q2M-9TZWA", "my_ip": "10.126.126.1", "relays": 2, "name": "shako",
                "autostart": False,
                "peers": [{"name": "nika-pc", "ip": "10.126.126.2", "ping_ms": 18.4, "link": "direct", "loss": "0.0%"},
                          {"name": "luka (Windows)", "ip": "10.126.126.3", "ping_ms": 47.9, "link": "direct", "loss": "0.0%"},
                          {"name": "gio-laptop", "ip": "10.126.126.4", "ping_ms": 131.0, "link": "relay", "loss": "1.2%"}]}

    def room_conf(self):
        return dict(rm.DEFAULTS, code="PHX-K7Q2M-9TZWA", name="shako")

    def room_details(self):
        n, s = rm.network_of("PHX-K7Q2M-9TZWA")
        return {"code": "PHX-K7Q2M-9TZWA", "network_name": n, "network_secret": s, "servers": rm.DEFAULT_SERVERS}

    def servers(self):
        mc = {"name": "phoenix-smp", "title": "Phoenix SMP", "game": "minecraft", "installed": True, "version": "26.3",
              "settings": dict(sv.defaults("minecraft"), eula=True, world="phoenix", whitelist_on=True,
                               whitelist=["shako", "nika", "luka"]),
              "active": True, "autostart": True, "state": {"ready": True, "players": 2, "max": 10, "names": ["nika", "luka"]}}
        tr = {"name": "terraria-night", "title": "Terraria night", "game": "terraria", "installed": True, "version": "1458",
              "settings": sv.defaults("terraria"), "active": False, "autostart": False, "state": {}}
        cs = {"name": "cs2-5v5", "title": "CS2 5v5", "game": "cs2", "installed": False, "version": "",
              "settings": sv.defaults("cs2"), "active": False, "autostart": False, "state": {}}
        for x in (mc, tr, cs):
            x["ports"] = sv.ports(x)
        return [mc, tr, cs]

    def tail(self, name):
        return ("[12:01:03] [Server thread/INFO]: Starting minecraft server version 26.3\n"
                "[12:01:03] [Server thread/INFO]: Loading properties\n"
                "[12:01:04] [Server thread/INFO]: Preparing level \"phoenix\"\n"
                "[12:01:09] [Server thread/INFO]: Done (5.912s)! For help, type \"help\"\n"
                "[12:03:41] [Server thread/INFO]: nika joined the game\n"
                "[12:05:12] [Server thread/INFO]: luka joined the game\n"
                "[12:05:20] [Server thread/INFO]: <luka> gamarjoba!")

    def lan_ip(self):
        return "192.168.1.20"

    def ufw_on(self):
        return True

    def easytier_installed(self):
        return True


class _Bridge(QObject):
    data = Signal(object)


# ------------------------------------------------------------------ server form (create + settings)
class ServerDialog(QDialog):
    def __init__(self, parent, game, values=None, title=None, editing=False):
        super().__init__(parent)
        g = sv.GAMES[game]
        self.game, self.widgets, self.helps = game, {}, []
        self.setWindowTitle(("Settings - " if editing else "New server - ") + (title or g["title"]))
        self.setMinimumWidth(640)
        v = dict(sv.defaults(game)); v.update(values or {})
        lay = QVBoxLayout(self); lay.setSpacing(10); lay.setSizeConstraint(QLayout.SetMinimumSize)
        head = QHBoxLayout(); head.addWidget(game_badge(game, 48))
        ht = QVBoxLayout()
        h = QLabel(g["title"]); h.setStyleSheet("font-size:18px; font-weight:700;"); ht.addWidget(h)
        ht.addWidget(dim(g["blurb"] + f"  Download: {g['size']}.")); head.addLayout(ht, 1); lay.addLayout(head)
        basic, adv = QGridLayout(), QGridLayout()
        for gl in (basic, adv):
            gl.setHorizontalSpacing(12); gl.setVerticalSpacing(8); gl.setColumnStretch(1, 1); gl.setColumnMinimumWidth(0, 190)
        adv.setContentsMargins(0, 0, 0, 0)
        if not editing:
            self.name = QLineEdit(title or f"My {g['title']} server")
            basic.addWidget(QLabel("Server name"), 0, 0); basic.addWidget(self.name, 0, 1)
        for f in sv.fields(game):
            if f.get("required"):
                continue
            self._field(adv if f.get("adv") else basic, f, v.get(f["key"], f["default"]))
        lay.addLayout(basic)
        advw = QWidget(); advw.setLayout(adv)
        lay.addWidget(collapsible("Manual settings", advw)); lay.addWidget(advw)
        for f in sv.fields(game):
            if f.get("required"):
                cb = QCheckBox(f["label"]); cb.setChecked(bool(v.get(f["key"])))
                self.widgets[f["key"]] = (f, cb)
                lay.addWidget(cb)
                if game == "minecraft":
                    lay.addWidget(dim('Mojang requires this before the server may start: '
                                      '<a href="https://aka.ms/MinecraftEULA">read the EULA</a>.'))
        self.err = QLabel(""); self.err.setStyleSheet(f"color:{RED};"); self.err.setWordWrap(True); lay.addWidget(self.err)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("Save" if editing else "Create and download")
        bb.button(QDialogButtonBox.Ok).setObjectName("primary")
        bb.accepted.connect(self._ok); bb.rejected.connect(self.reject); lay.addWidget(bb)

    def _field(self, grid, f, val):
        r = grid.rowCount()
        k = f["kind"]
        if k == "bool":
            w = QCheckBox(f["label"]); w.setChecked(bool(val)); grid.addWidget(w, r, 0, 1, 2)
        else:
            lab = QLabel(f["label"])
            grid.addWidget(lab, r, 0, Qt.AlignTop if k == "list" else Qt.AlignVCenter)
            if k == "choice":
                w = QComboBox(); w.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
                w.setMinimumContentsLength(24)       # long choices must not force the dialog wider than the screen
                for cv, ctext in f["choices"]:
                    w.addItem(ctext, cv)
                w.setCurrentIndex(max(0, w.findData(val)))
            elif k == "int":
                w = QSpinBox(); w.setRange(f.get("min", 0), f.get("max", 65535)); w.setValue(int(val or 0))
            elif k == "list":
                w = QPlainTextEdit("\n".join(val or [])); w.setFixedHeight(70)
            elif k == "ram":
                w = RamSlider(int(val or 0))
            else:
                w = QLineEdit(str(val or ""))     # game passwords stay visible: you hand them to your friends
            grid.addWidget(w, r, 1)
        self.widgets[f["key"]] = (f, w)
        if f.get("help"):
            # wrapped by hand: word-wrapped labels in grid cells get clipped (Qt height-for-width in dialogs)
            txt = textwrap.fill(f["help"], 64 if k != "bool" else 96)
            h = dim(txt, wrap=False)
            h.setMinimumHeight(h.fontMetrics().lineSpacing() * (txt.count(chr(10)) + 1) + 4)
            grid.addWidget(h, r + 1, 1 if k != "bool" else 0, 1, 1 if k != "bool" else 2)
        if f["key"] == "whitelist":       # the list only matters when the whitelist is on
            on = self.widgets.get("whitelist_on", (None, None))[1]
            if on:
                w.setEnabled(on.isChecked()); on.toggled.connect(w.setEnabled)

    def values(self):
        out = {}
        for key, (f, w) in self.widgets.items():
            k = f["kind"]
            if k == "bool":
                out[key] = w.isChecked()
            elif k == "choice":
                out[key] = w.currentData()
            elif k == "int":
                out[key] = w.value()
            elif k == "list":
                out[key] = [x.strip() for x in w.toPlainText().splitlines() if x.strip()]
            elif k == "ram":
                out[key] = w.value()
            else:
                out[key] = w.text().strip() if k != "password" else w.text()
        return out

    def _ok(self):
        err = sv.validate(self.game, dict(sv.defaults(self.game), **self.values()))
        if not err and hasattr(self, "name") and not self.name.text().strip():
            err = "Give the server a name."
        if err:
            self.err.setText(err); return
        self.accept()


class RamSlider(QWidget):
    """Automatic (0) or a fixed amount in MB."""

    def __init__(self, mb):
        super().__init__()
        lay = QHBoxLayout(self); lay.setContentsMargins(0, 0, 0, 0)
        total = sv.total_ram_mb()
        self.auto = QCheckBox(f"Automatic ({sv.auto_ram() / 1024:.1f} GB)"); self.auto.setChecked(not mb)
        self.sl = QSlider(Qt.Horizontal); self.sl.setRange(2, max(4, min(32, total * 3 // 4 // 1024 * 2)))  # 0.5 GB steps
        self.sl.setValue(max(2, (mb or sv.auto_ram()) // 512)); self.sl.setEnabled(bool(mb))
        self.lab = QLabel(); self.lab.setMinimumWidth(60)
        self.sl.valueChanged.connect(self._label); self._label(self.sl.value())
        self.auto.toggled.connect(lambda on: self.sl.setEnabled(not on))
        lay.addWidget(self.auto); lay.addWidget(self.sl, 1); lay.addWidget(self.lab)

    def _label(self, v):
        self.lab.setText(f"{v / 2:.1f} GB")

    def value(self):
        return 0 if self.auto.isChecked() else self.sl.value() * 512


# ------------------------------------------------------------------ page
class FriendsPage(QWidget):
    def __init__(self, center, backend=None):
        super().__init__()
        self.center, self.be = center, backend or Backend()
        self.demo = isinstance(self.be, DemoBackend)
        self.Card, page, FlowGrid = _ui()
        self.acc = accent()
        self.runner = getattr(center, "runner", None)
        w, lay = page("Play with friends", "Play LAN games together over the internet, and host your own game servers - "
                                           "one click each, every setting still yours to change.")
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0); outer.addWidget(w)
        self.lay = lay
        self.page_widget = w
        self.room_key, self.server_cards, self.server_key, self.room_state = None, {}, None, {}
        self.public_ip = ""

        # ---- 1. LAN room
        self.room_card = self.Card()
        self.room_box = QVBoxLayout(); self.room_box.setSpacing(10); self.room_card.lay.addLayout(self.room_box)
        self.peers_box = QGridLayout(); self.peers_box.setHorizontalSpacing(18); self.peers_box.setVerticalSpacing(6)
        self.peers_w = QWidget(); self.peers_w.setLayout(self.peers_box)
        lay.addWidget(self.room_card)
        lay.addWidget(self._room_help())

        # ---- 2. game servers
        sec = QLabel("Game servers"); sec.setObjectName("h2"); sec.setStyleSheet("font-size:19px; font-weight:700; margin-top:8px;")
        lay.addWidget(sec)
        lay.addWidget(dim("Your computer hosts the game while you play on it too. Friends join through the LAN room above, "
                          "or directly when they are on your home network. Servers keep running when this window is closed."))
        tiles = QGridLayout(); tiles.setSpacing(12)
        for i, game in enumerate(sv.GAMES):
            tiles.addWidget(self._game_tile(game), 0, i)
            tiles.setColumnStretch(i, 1)
        lay.addLayout(tiles)
        self.servers_box = QVBoxLayout(); self.servers_box.setSpacing(12)
        lay.addLayout(self.servers_box)
        lay.addStretch(1)

        self.bridge = _Bridge(); self.bridge.data.connect(self._apply)
        self.busy = False
        self.timer = QTimer(self); self.timer.timeout.connect(self.refresh); self.timer.start(3000)
        self._apply(self._collect())          # first paint synchronously

    # ------------------------------------------------------------ refresh
    def _collect(self):
        try:
            room = self.be.room()
        except Exception as e:
            room = {"state": "error", "error": str(e), "peers": []}
        try:
            servers = self.be.servers()
        except Exception as e:
            servers = [{"error": str(e)}]
        return {"room": room, "servers": servers, "lan_ip": self.be.lan_ip(), "ufw": self.be.ufw_on()}

    def refresh(self):
        if self.busy or (not self.isVisible() and not self.demo):
            return
        self.busy = True

        def work():
            try:
                d = self._collect()
            except Exception:
                d = None
            self.bridge.data.emit(d)
        threading.Thread(target=work, daemon=True).start()

    def _apply(self, d):
        self.busy = False
        if not d:
            return
        self.data = d
        self.render_room(d["room"])
        self.render_servers(d["servers"])

    # ------------------------------------------------------------ actions plumbing
    def run(self, args, done=None, program="python3"):
        if self.demo:
            return
        def end(code):
            if done:
                done(code)
            self.refresh()
        if self.runner:
            self.runner.run(program, args, end)
        else:
            r = subprocess.run([program, *args]); end(r.returncode)

    def root(self, script, args, done=None):
        self.run(["/bin/sh", script, *args], done, program="pkexec")

    # ------------------------------------------------------------ LAN room
    def render_room(self, st):
        key = (st.get("state"), st.get("code"), st.get("my_ip"))
        if key != self.room_key:
            self.room_key = key
            self.peers_w.setParent(None)
            clear(self.room_box)
            self._room_header(st)
            if st.get("state") in ("online", "connecting"):
                self._room_inside(st)
            else:
                self._room_outside(st)
        if st.get("state") in ("online", "connecting"):
            self._render_peers(st)

    def _room_header(self, st):
        row = QHBoxLayout()
        t = QLabel("LAN room"); t.setObjectName("cardTitle"); row.addWidget(t)
        s = st.get("state")
        row.addWidget({"online": pill("Connected", GREEN), "connecting": pill("Connecting…", YELLOW),
                       "error": pill("Error", RED)}.get(s, pill("Off", GREY)), 0, Qt.AlignVCenter)
        row.addStretch(1)
        self.room_box.addLayout(row)

    def _room_outside(self, st):
        self.room_box.addWidget(dim(
            "A private network just for you and your friends, over the internet. LAN games see each other as if you "
            "were all at one table: Minecraft \"Open to LAN\", Terraria and Valheim by IP, CS 1.6, Age of Empires, "
            "StarCraft, Warcraft III… No account and no server to rent - free and open source (EasyTier)."))
        row = QHBoxLayout(); row.setSpacing(10)
        cb = QPushButton("  Create room  "); cb.setObjectName("primary"); cb.setMinimumHeight(40)
        cb.clicked.connect(self.create_room)
        row.addWidget(cb)
        orl = QLabel("or"); orl.setObjectName("dim"); row.addWidget(orl)
        self.code_in = QLineEdit(); self.code_in.setPlaceholderText("Friend's room code: PHX-XXXXX-XXXXX")
        self.code_in.setMinimumHeight(40); self.code_in.setMaxLength(24)
        self.code_in.setStyleSheet(f"QLineEdit {{ {MONO} font-size:15px; padding: 0 10px; border-radius: 10px; }}")
        self.code_in.returnPressed.connect(self.join_room)
        row.addWidget(self.code_in, 1)
        jb = QPushButton("Join room"); jb.setMinimumHeight(40); jb.clicked.connect(self.join_room); row.addWidget(jb)
        self.room_box.addLayout(row)
        self.room_err = QLabel(""); self.room_err.setStyleSheet(f"color:{RED};"); self.room_err.hide()
        self.room_box.addWidget(self.room_err)
        if st.get("state") == "not-installed":
            self.room_box.addWidget(dim("The first time, PhoenixGe downloads EasyTier (25 MB, checked against its official "
                                        "checksum) and asks for your password once."))
        elif st.get("state") == "error":
            self.room_box.addWidget(dim("Could not read the room state: " + st.get("error", "")))

    def _room_inside(self, st):
        row = QHBoxLayout(); row.setSpacing(12)
        col = QVBoxLayout(); col.setSpacing(2)
        col.addWidget(dim("Room code - send it to your friends"))
        code = QLabel(st.get("code", "")); code.setTextInteractionFlags(Qt.TextSelectableByMouse)
        code.setStyleSheet(f"{MONO} font-size: 26px; font-weight: 800; letter-spacing: 2px; color: {self.acc};")
        col.addWidget(code)
        row.addLayout(col)
        row.addWidget(copy_button(st.get("code", ""), "Copy code"), 0, Qt.AlignBottom)
        row.addStretch(1)
        col2 = QVBoxLayout(); col2.setSpacing(2)
        col2.addWidget(dim("Your address in the room"))
        ip = QLabel(st.get("my_ip") or "getting an address…"); ip.setTextInteractionFlags(Qt.TextSelectableByMouse)
        ip.setStyleSheet(f"{MONO} font-size: 20px; font-weight: 700;")
        col2.addWidget(ip)
        row.addLayout(col2)
        row.addWidget(copy_button(lambda: self.room_state.get("my_ip", ""), "Copy my IP"), 0, Qt.AlignBottom)
        lb = QPushButton("Leave room"); lb.clicked.connect(self.leave_room)
        row.addWidget(lb, 0, Qt.AlignBottom)
        self.room_box.addLayout(row)
        line = QFrame(); line.setFrameShape(QFrame.HLine); line.setStyleSheet(f"color: {self.acc}22;")
        self.room_box.addWidget(line)
        self.peer_summary = dim("")
        self.room_box.addWidget(self.peer_summary)
        self.room_box.addWidget(self.peers_w)

    def _render_peers(self, st):
        self.room_state = st
        peers = st.get("peers", [])
        relays = st.get("relays", 0)
        if st.get("state") == "connecting":
            txt = "Connecting to the room…  (if this stays, a firewall at work/school may block it - try another network)"
        elif not peers:
            txt = f"You're in. Waiting for friends - send them the code.  (connected through {relays} meeting point{'s' if relays != 1 else ''})"
        else:
            direct = sum(1 for p in peers if p["link"] == "direct")
            txt = (f"{len(peers)} friend{'s' if len(peers) != 1 else ''} in the room - {direct} direct, "
                   f"{len(peers) - direct} through a relay. In games, use their room address.")
        self.peer_summary.setText(txt)
        clear(self.peers_box)
        if not peers:
            self.peers_w.hide(); return
        self.peers_w.show()
        for c, h in enumerate(["", "Friend", "Room address", "Ping", "Connection", ""]):
            lab = QLabel(h); lab.setObjectName("dim"); lab.setStyleSheet("font-size:11px; font-weight:600;")
            self.peers_box.addWidget(lab, 0, c)
        for r, p in enumerate(peers, 1):
            ms = p.get("ping_ms")
            col = GREY if ms is None else GREEN if ms < 60 else YELLOW if ms < 150 else RED
            self.peers_box.addWidget(dot(col), r, 0, Qt.AlignVCenter)
            n = QLabel(p["name"]); n.setStyleSheet("font-weight:600;"); self.peers_box.addWidget(n, r, 1)
            ip = QLabel(p["ip"]); ip.setStyleSheet(MONO); ip.setTextInteractionFlags(Qt.TextSelectableByMouse)
            self.peers_box.addWidget(ip, r, 2)
            pl = QLabel("-" if ms is None else f"{ms:.0f} ms"); pl.setStyleSheet(f"color:{col}; font-weight:600;")
            self.peers_box.addWidget(pl, r, 3)
            link = "Direct (P2P)" if p["link"] == "direct" else "Relay (slower)"
            lk = QLabel(link); lk.setObjectName("dim")
            lk.setToolTip("Direct: your computers talk to each other. Relay: traffic goes through EasyTier's public node "
                          "because a router blocks a direct link - works, with more ping.")
            self.peers_box.addWidget(lk, r, 4)
            cp = copy_button(p["ip"], "Copy IP"); cp.setStyleSheet("padding: 3px 10px;")
            self.peers_box.addWidget(cp, r, 5)
        self.peers_box.setColumnStretch(4, 1)

    def _room_help(self):
        c = self.Card()
        row = QHBoxLayout()
        t = QLabel("Friends on Windows, macOS or another Linux"); t.setObjectName("cardTitle"); row.addWidget(t); row.addStretch(1)
        c.lay.addLayout(row)
        c.lay.addWidget(dim(
            "PhoenixGe friends: Center > Play with friends > Join room. Everyone else installs the free "
            '<a href="https://easytier.cn/en/guide/download.html">EasyTier</a> app (Windows, macOS, Linux, Android) and '
            "types in the network settings below - then they are in your room too.<br>"
            "<b>Radmin VPN and Hamachi can't join</b>: they are closed programs that only talk to their own servers, "
            "so no other app can connect to them. Use EasyTier on both sides instead."))
        brow = QHBoxLayout()
        b = QPushButton("Show settings for other computers…"); b.clicked.connect(self.show_details)
        brow.addWidget(b); brow.addStretch(1); c.lay.addLayout(brow)

        # manual settings
        body = QWidget(); g = QGridLayout(body); g.setContentsMargins(0, 4, 0, 0); g.setHorizontalSpacing(12); g.setVerticalSpacing(8)
        g.setColumnStretch(1, 1)
        conf = self.be.room_conf()
        self.m_name = QLineEdit(conf.get("name", "")); self.m_name.setMaxLength(40)
        g.addWidget(QLabel("Your name in rooms"), 0, 0); g.addWidget(self.m_name, 0, 1)
        iprow = QHBoxLayout()
        self.m_auto = QRadioButton("Automatic (recommended)"); self.m_fixed = QRadioButton("Fixed:")
        self.m_ip = QLineEdit(conf.get("ip", "10.126.126.10")); self.m_ip.setMaximumWidth(160)
        (self.m_auto if conf.get("auto_ip", True) else self.m_fixed).setChecked(True)
        self.m_ip.setEnabled(not conf.get("auto_ip", True)); self.m_fixed.toggled.connect(self.m_ip.setEnabled)
        iprow.addWidget(self.m_auto); iprow.addWidget(self.m_fixed); iprow.addWidget(self.m_ip); iprow.addStretch(1)
        g.addWidget(QLabel("Room address"), 1, 0); g.addLayout(iprow, 1, 1)
        g.addWidget(dim("Fixed: everyone must pick a different address in 10.126.126.x. Handy when friends type your "
                        "address into a game once and want it to stay."), 2, 1)
        self.m_servers = QPlainTextEdit("\n".join(conf.get("servers") or rm.DEFAULT_SERVERS)); self.m_servers.setFixedHeight(64)
        self.m_servers.setStyleSheet(MONO)
        g.addWidget(QLabel("Meeting points"), 3, 0, Qt.AlignTop); g.addWidget(self.m_servers, 3, 1)
        g.addWidget(dim("EasyTier shared nodes where computers find each other (and relay when no direct link is "
                        "possible). Default: the free public nodes of the EasyTier project. Add your own node "
                        "(tcp://host:11010) for more privacy - everyone in the room must list at least one common node."), 4, 1)
        self.m_bcast = QCheckBox("Pass LAN game discovery (broadcasts) between friends"); self.m_bcast.setChecked(conf.get("broadcast", True))
        g.addWidget(self.m_bcast, 5, 1)
        self.m_auto_start = QCheckBox("Rejoin my room automatically when I log in"); self.m_auto_start.setChecked(conf.get("autostart", False))
        g.addWidget(self.m_auto_start, 6, 1)
        brow2 = QHBoxLayout()
        sb = QPushButton("Save"); sb.setObjectName("primary"); sb.clicked.connect(self.save_room_manual)
        rb = QPushButton("Reset to automatic"); rb.clicked.connect(self.reset_room_manual)
        brow2.addWidget(sb); brow2.addWidget(rb); brow2.addStretch(1)
        g.addLayout(brow2, 7, 1)
        c.lay.addWidget(collapsible("Manual settings", body)); c.lay.addWidget(body)
        return c

    def ensure_easytier(self, then):
        if self.be.easytier_installed():
            then(); return
        self.root(INSTALLER, [], lambda code: then() if code == 0 and rm.installed() else
                  QMessageBox.warning(self, "LAN rooms", "EasyTier could not be installed - is the internet on? "
                                                         "The log at the bottom of the window says why."))

    def create_room(self):
        self.ensure_easytier(lambda: self.run([ROOM_PY, "create"]))

    def join_room(self):
        code = rm.normalize(self.code_in.text())
        if not code:
            self.room_err.setText("That's not a room code. It looks like PHX-K7Q2M-9TZWA (letters and numbers, no 0/O/1/I).")
            self.room_err.show(); return
        self.room_err.hide()
        self.ensure_easytier(lambda: self.run([ROOM_PY, "join", code]))

    def leave_room(self):
        self.run([ROOM_PY, "leave"])

    def save_room_manual(self):
        c = rm.load()
        c.update(name=self.m_name.text().strip() or os.environ.get("USER", "phoenix"), auto_ip=self.m_auto.isChecked(),
                 ip=self.m_ip.text().strip(), broadcast=self.m_bcast.isChecked(), autostart=self.m_auto_start.isChecked(),
                 servers=[s.strip() for s in self.m_servers.toPlainText().splitlines() if s.strip()] or rm.DEFAULT_SERVERS)
        if not c["auto_ip"]:
            parts = c["ip"].split(".")
            if len(parts) != 4 or not all(p.isdigit() and 0 <= int(p) <= 255 for p in parts):
                QMessageBox.warning(self, "LAN room", "The fixed address must look like 10.126.126.10"); return
        if self.demo:
            return
        rm.save(c)
        rm.set_autostart(c["autostart"])
        if rm.active():
            self.run([ROOM_PY, "join", c["code"]])      # reconnect with the new settings

    def reset_room_manual(self):
        self.m_name.setText(os.environ.get("USER", "phoenix")); self.m_auto.setChecked(True)
        self.m_servers.setPlainText("\n".join(rm.DEFAULT_SERVERS)); self.m_bcast.setChecked(True)
        self.m_auto_start.setChecked(False)
        self.save_room_manual()

    def show_details(self):
        d = self.be.room_details()
        dlg = QDialog(self); dlg.setWindowTitle("Join this room from another computer"); dlg.setMinimumWidth(620)
        lay = QVBoxLayout(dlg); lay.setSpacing(10)
        if not d.get("code"):
            lay.addWidget(QLabel("Create or join a room first - then the settings for other computers appear here."))
        else:
            lay.addWidget(dim("1. Install EasyTier from easytier.cn (Windows: the GUI installer).  2. Add a network with these "
                              "settings.  3. Press Run. The friend then shows up in your room list with their address."))
            g = QGridLayout(); g.setHorizontalSpacing(12); g.setVerticalSpacing(8); g.setColumnStretch(1, 1)
            rows = [("Network name", d["network_name"]), ("Network secret", d["network_secret"]),
                    ("Virtual IPv4", "DHCP (automatic) - tick \"DHCP\""),
                    ("Peer / server", chr(10).join(d["servers"]))]
            for i, (k, v) in enumerate(rows):
                g.addWidget(QLabel(f"<b>{k}</b>"), i, 0)
                x = QLabel(v); x.setStyleSheet(MONO); x.setTextInteractionFlags(Qt.TextSelectableByMouse); x.setWordWrap(True)
                g.addWidget(x, i, 1)
                if i != 2:
                    g.addWidget(copy_button(v), i, 2)
            lay.addLayout(g)
            cmd = (f"easytier-core -d --network-name {d['network_name']} --network-secret {d['network_secret']} "
                   + " ".join(f"-p {s}" for s in d["servers"]))
            lay.addWidget(dim("Command line (any OS):"))
            t = QPlainTextEdit(cmd); t.setReadOnly(True); t.setFixedHeight(64); t.setStyleSheet(MONO); lay.addWidget(t)
            lay.addWidget(dim("The secret is like a password for the room: only share it with friends."))
        bb = QDialogButtonBox(QDialogButtonBox.Close); bb.rejected.connect(dlg.reject); bb.accepted.connect(dlg.accept)
        lay.addWidget(bb)
        self._last_dialog = dlg
        if not self.demo or not getattr(self, "_no_exec", False):
            dlg.exec()
        return dlg

    # ------------------------------------------------------------ servers
    def _game_tile(self, game):
        g = sv.GAMES[game]
        c = self.Card()
        top = QHBoxLayout(); top.addWidget(game_badge(game, 40))
        tt = QVBoxLayout(); tt.setSpacing(0)
        t = QLabel(g["title"]); t.setObjectName("cardTitle"); tt.addWidget(t)
        tt.addWidget(dim(g["size"], wrap=False)); top.addLayout(tt, 1)
        c.lay.addLayout(top)
        c.lay.addWidget(dim(g["blurb"]), 1)
        b = QPushButton("Create server"); b.clicked.connect(lambda _=False, x=game: self.new_server(x))
        c.lay.addWidget(b, 0, Qt.AlignLeft)
        return c

    def render_servers(self, servers):
        key = tuple((s.get("name"), s.get("installed"), s.get("active"), s.get("version")) for s in servers)
        if key == self.server_key:
            for s in servers:                 # just the live bits
                card = self.server_cards.get(s.get("name"))
                if card:
                    card.update_live(s)
            return
        self.server_key = key
        open_consoles = {n for n, c in self.server_cards.items() if c.console_open()}
        clear(self.servers_box); self.server_cards = {}
        if not servers:
            self.servers_box.addWidget(dim("No servers yet - pick a game above. Each one gets its own folder in "
                                           "~/Games/Servers, so worlds are easy to back up."))
            return
        h = QLabel("My servers"); h.setStyleSheet("font-weight:700; font-size:15px; margin-top:6px;"); self.servers_box.addWidget(h)
        for s in servers:
            if "error" in s:
                self.servers_box.addWidget(dim("Could not read the servers: " + s["error"])); continue
            card = ServerCard(self, s)
            self.server_cards[s["name"]] = card
            self.servers_box.addWidget(card)
            if s["name"] in open_consoles:
                card.toggle_console(True)

    def new_server(self, game):
        dlg = ServerDialog(self, game)
        if dlg.exec() != QDialog.Accepted or self.demo:
            return
        try:
            name = sv.create(game, dlg.name.text().strip(), dlg.values())
        except Exception as e:
            QMessageBox.warning(self, "New server", str(e)); return
        self.after_reach_change(name, dlg.values().get("reach"), False)
        self.run([SERVERS_PY, "install", name], lambda code: code == 0 and self.run([SERVERS_PY, "start", name]))

    def after_reach_change(self, name, reach, was_open):
        """Firewall follows 'Who can join': open the ports for home network / internet, close them for room-only."""
        if not self.be.ufw_on() and not was_open:
            return
        cfg = sv.load(name)
        if reach in ("lan", "internet"):
            specs = [f"{p}/{proto}" for p, proto in sv.ports(cfg)]
            self.root(FIREWALL, ["open", name, *specs], lambda code: code == 0 and sv.save(name, dict(sv.load(name), fw_open=True)))
        elif was_open:
            self.root(FIREWALL, ["close", name], lambda code: code == 0 and sv.save(name, dict(sv.load(name), fw_open=False)))


class ServerCard(QFrame):
    def __init__(self, pg: FriendsPage, s):
        super().__init__()
        self.pg, self.s, self.name = pg, s, s["name"]
        self.setObjectName("card")
        lay = QVBoxLayout(self); lay.setContentsMargins(18, 14, 18, 14); lay.setSpacing(8)
        g = sv.GAMES[s["game"]]
        top = QHBoxLayout(); top.setSpacing(12)
        top.addWidget(game_badge(s["game"], 44))
        tt = QVBoxLayout(); tt.setSpacing(1)
        trow = QHBoxLayout(); trow.setSpacing(8)
        t = QLabel(s["title"]); t.setObjectName("cardTitle"); trow.addWidget(t)
        self.status = QLabel(); trow.addWidget(self.status, 0, Qt.AlignVCenter); trow.addStretch(1)
        tt.addLayout(trow)
        self.sub = dim(""); tt.addWidget(self.sub)
        top.addLayout(tt, 1)
        self.main_btn = QPushButton(); self.main_btn.setMinimumWidth(96); self.main_btn.clicked.connect(self.main_action)
        cb = QPushButton("Console"); cb.setCheckable(True); cb.toggled.connect(self.toggle_console); self.console_btn = cb
        sb = QPushButton("Settings"); sb.clicked.connect(self.settings)
        more = QPushButton("More ▾")
        m = QMenu(more)
        m.addAction("Update server files", lambda: self.pg.run([SERVERS_PY, "install", self.name]))
        m.addAction("Open server folder", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(sv.ROOT / self.name))))
        if s["game"] == "minecraft":
            m.addAction("Edit server.properties", lambda: QDesktopServices.openUrl(
                QUrl.fromLocalFile(str(sv.ROOT / self.name / "server.properties"))))
        m.addSeparator()
        m.addAction("Delete server…", self.delete)
        more.setMenu(m); more.setStyleSheet("QPushButton::menu-indicator { image: none; width: 0; }")
        for b in (self.main_btn, cb, sb, more):
            top.addWidget(b, 0, Qt.AlignVCenter)
        lay.addLayout(top)

        # join addresses
        self.addr = QGridLayout(); self.addr.setHorizontalSpacing(10); self.addr.setVerticalSpacing(4)
        lay.addLayout(self.addr)
        bottom = QHBoxLayout()
        self.auto = QCheckBox("Start with the computer"); self.auto.setChecked(bool(s.get("autostart")))
        self.auto.setToolTip("Runs even before anyone logs in, and restarts by itself if it crashes.")
        self.auto.toggled.connect(lambda on: self.pg.run([SERVERS_PY, "autostart", self.name, "on" if on else "off"]))
        bottom.addWidget(self.auto)
        self.note = dim(""); bottom.addWidget(self.note, 1)
        lay.addLayout(bottom)

        # console
        self.console = QWidget(); cl = QVBoxLayout(self.console); cl.setContentsMargins(0, 4, 0, 0); cl.setSpacing(6)
        self.log = QPlainTextEdit(); self.log.setReadOnly(True); self.log.setMinimumHeight(180)
        self.log.setStyleSheet(f"QPlainTextEdit {{ {MONO} font-size: 12px; background: #0d0f14; color: #d8dee9; "
                               "border-radius: 10px; padding: 6px; }")
        self.log.setMaximumBlockCount(2000)
        cl.addWidget(self.log)
        irow = QHBoxLayout()
        self.cmd = QLineEdit(); self.cmd.setPlaceholderText(
            {"minecraft": "Command, e.g.  op nika   ·   whitelist add luka   ·   say hi   ·   time set day",
             "terraria": "Command, e.g.  save   ·   say hi   ·   kick <name>   ·   time",
             "cs2": "Command, e.g.  changelevel de_mirage   ·   mp_restartgame 1   ·   bot_add",
             "valheim": "Valheim has no console commands here - use the game's admin list (adminlist.txt)"}[s["game"]])
        self.cmd.setStyleSheet(MONO); self.cmd.returnPressed.connect(self.send)
        self.cmd.setEnabled(s["game"] != "valheim")
        send = QPushButton("Send"); send.clicked.connect(self.send); send.setEnabled(s["game"] != "valheim")
        irow.addWidget(self.cmd, 1); irow.addWidget(send)
        cl.addLayout(irow)
        self.console.hide()
        lay.addWidget(self.console)
        self.log_timer = QTimer(self); self.log_timer.timeout.connect(self.refresh_log)
        self.update_live(s)

    def console_open(self):
        return self.console.isVisible() or self.console_btn.isChecked()

    def update_live(self, s):
        self.s = s
        g = sv.GAMES[s["game"]]
        st = s.get("state") or {}
        if not s.get("installed"):
            text, col, btn = "Not downloaded", GREY, "Download"
        elif s.get("active") and st.get("ready"):
            mx = st.get("max") or s["settings"].get("max_players", "?")
            text, col, btn = f"Running · {st.get('players', 0)}/{mx} players", GREEN, "Stop"
        elif s.get("active"):
            text, col, btn = "Starting…", YELLOW, "Stop"
        else:
            text, col, btn = "Stopped", GREY, "Start"
        self.status.setText(text)
        self.status.setStyleSheet(f"QLabel {{ color: {col}; border: 1px solid {col}; border-radius: 9px; padding: 1px 9px; "
                                  "font-size: 11px; font-weight: 600; }")
        self.main_btn.setText(btn)
        self.main_btn.setObjectName("primary" if btn in ("Start", "Download") else "")
        self.main_btn.style().unpolish(self.main_btn); self.main_btn.style().polish(self.main_btn)
        sub = [g["title"]]
        if s.get("version"):
            sub.append(("version " if s["game"] in ("minecraft", "terraria") else "") + str(s["version"]))
        set_ = s["settings"]
        if s["game"] == "minecraft":
            sub.append(f"{set_.get('gamemode', '').capitalize()}, {set_.get('difficulty', '')}")
            ram = int(set_.get("ram") or 0)
            sub.append(f"RAM {(ram or sv.auto_ram()) / 1024:.1f} GB" + (" (auto)" if not ram else ""))
            if set_.get("whitelist_on"):
                sub.append(f"whitelist: {len(set_.get('whitelist', []))}")
        if st.get("names"):
            sub.append("online: " + ", ".join(st["names"][:6]))
        self.sub.setText("  ·  ".join(sub))
        self.render_addresses(s)

    def render_addresses(self, s, force=False):
        port = s["ports"][0][0]
        data = getattr(self.pg, "data", {})
        room_ip = (data.get("room") or {}).get("my_ip", "")
        lan = data.get("lan_ip", "")
        reach = s["settings"].get("reach", "lan")
        key = (port, room_ip, lan, reach, self.pg.public_ip, json.dumps(s.get("state") or {}, sort_keys=True),
               data.get("ufw"), s["settings"].get("gslt"))
        if key == getattr(self, "_addr_key", None) and not force:
            return
        self._addr_key = key
        clear(self.addr)
        fmt = (lambda ip: f"{ip}:{port}") if not (s["game"] == "minecraft" and port == 25565) else (lambda ip: ip)
        rows = []
        if room_ip:
            rows.append(("LAN room", fmt(room_ip), "friends in your room"))
        else:
            rows.append(("LAN room", "", "create a room above, then friends use your room address"))
        if reach in ("lan", "internet") and lan:
            rows.append(("Home network", fmt(lan), "same Wi-Fi / router"))
        if reach == "internet":
            pub = self.pg.public_ip or (s.get("state") or {}).get("public_ip", "")
            rows.append(("Internet", fmt(pub) if pub else "", "needs UPnP on the router or a forwarded port"))
        lab = QLabel("Join at"); lab.setObjectName("dim"); lab.setStyleSheet("font-size:11px; font-weight:600;")
        self.addr.addWidget(lab, 0, 0, 1, 4)
        for i, (k, v, hint) in enumerate(rows, 1):
            self.addr.addWidget(QLabel(k), i, 0)
            if v:
                x = QLabel(v); x.setStyleSheet(MONO + " font-weight:600;"); x.setTextInteractionFlags(Qt.TextSelectableByMouse)
                self.addr.addWidget(x, i, 1)
                cp = copy_button(v); cp.setStyleSheet("padding: 3px 10px;"); self.addr.addWidget(cp, i, 2)
            elif k == "Internet":
                b = QPushButton("Show my public IP"); b.setStyleSheet("padding: 3px 10px;"); b.clicked.connect(self.fetch_public)
                self.addr.addWidget(b, i, 1, 1, 2, Qt.AlignLeft)
            else:
                self.addr.addWidget(QLabel("-"), i, 1)
            self.addr.addWidget(dim(hint, wrap=False), i, 3)
        self.addr.setColumnStretch(3, 1)
        st = s.get("state") or {}
        notes = []
        if st.get("upnp_failed"):
            notes.append("The router did not open the port (UPnP) - use the LAN room or forward the port by hand.")
        if reach == "room" and not data.get("ufw"):
            notes.append("The firewall is off, so your home network can reach this server too (Security page).")
        if s["game"] == "cs2" and not s["settings"].get("gslt"):
            notes.append("No Steam token: LAN and LAN-room players only (Valve's rule).")
        self.note.setText("  ".join(notes))

    def fetch_public(self):
        def work():
            ip = "203.0.113.7" if self.pg.demo else sv.public_ip()
            self.pg.public_ip = ip or ""
        t = threading.Thread(target=work, daemon=True); t.start(); t.join(7)
        if not self.pg.public_ip:
            QMessageBox.information(self, "Public IP", "Could not find your public IP (offline?).")
        self.render_addresses(self.s, force=True)

    def main_action(self):
        t = self.main_btn.text()
        if t == "Download":
            self.pg.run([SERVERS_PY, "install", self.name])
        elif t == "Start":
            self.pg.run([SERVERS_PY, "start", self.name])
            self.toggle_console(True)
        else:
            self.pg.run([SERVERS_PY, "stop", self.name])

    def toggle_console(self, on):
        if self.console_btn.isChecked() != on:
            self.console_btn.setChecked(on); return
        self.console.setVisible(on)
        if on:
            self.refresh_log(); self.log_timer.start(2000)
        else:
            self.log_timer.stop()

    def refresh_log(self):
        txt = self.pg.be.tail(self.name) or "(no output yet - start the server)"
        if txt != self.log.toPlainText():
            bar = self.log.verticalScrollBar(); at_end = bar.value() >= bar.maximum() - 4
            self.log.setPlainText(txt)
            if at_end:
                bar.setValue(bar.maximum())

    def send(self):
        line = self.cmd.text().strip()
        if not line:
            return
        if self.pg.demo or sv.send_command(self.name, line):
            self.cmd.clear(); QTimer.singleShot(700, self.refresh_log)
        else:
            QMessageBox.information(self, "Console", "The server is not running.")

    def settings(self):
        s = sv.load(self.name) if not self.pg.demo else self.s
        old_reach, was_open = s["settings"].get("reach"), s.get("fw_open", False)
        dlg = ServerDialog(self.pg, s["game"], s["settings"], s["title"], editing=True)
        if dlg.exec() != QDialog.Accepted or self.pg.demo:
            return
        s = sv.load(self.name); s["settings"].update(dlg.values()); sv.save(self.name, s)
        if s["settings"].get("reach") != old_reach or (was_open and dlg.values().get("port")):
            self.pg.after_reach_change(self.name, s["settings"].get("reach"), was_open)
        if self.s.get("active") and QMessageBox.question(
                self, "Settings saved", "Restart the server now so the changes take effect? Players get disconnected "
                                        "for a moment.") == QMessageBox.Yes:
            self.pg.run([SERVERS_PY, "restart", self.name])
        self.pg.server_key = None; self.pg.refresh()

    def delete(self):
        if QMessageBox.warning(self, "Delete server",
                               f"Delete \"{self.s['title']}\" and its folder ~/Games/Servers/{self.name}?\n\n"
                               "The WORLDS are deleted too. Copy the folder first if you want to keep them.",
                               QMessageBox.Yes | QMessageBox.Cancel, QMessageBox.Cancel) != QMessageBox.Yes or self.pg.demo:
            return
        was_open = self.s.get("fw_open")
        self.pg.run([SERVERS_PY, "delete", self.name],
                    lambda code: was_open and self.pg.root(FIREWALL, ["close", self.name]))


def build(center):
    try:
        return FriendsPage(center)
    except Exception as e:  # never break the Center
        w = QLabel(f"Play with friends is unavailable: {e}"); w.setObjectName("dim"); w.setWordWrap(True)
        return w


# ------------------------------------------------------------------ standalone / screenshots
STYLE = """
    QWidget {{ font-size: 13px; }}
    #h1 {{ font-size: 26px; font-weight: 700; }}
    #dim {{ color: palette(placeholder-text); }}
    #card {{ background: palette(alternate-base); border-radius: 14px; border: 1px solid {acc}22; }}
    #cardTitle {{ font-size: 15px; font-weight: 600; }}
    QPushButton {{ padding: 8px 16px; border-radius: 10px; }}
    QPushButton#primary {{ background: {acc}; color: #1a0b06; font-weight: 600; border: none; }}
    QPushButton:checked {{ background: {acc}; color: #1a0b06; }}
"""


def _main(argv):
    demo = "--demo" in argv
    shot = argv[argv.index("--shot") + 1] if "--shot" in argv else ""
    app = QApplication.instance() or QApplication(argv)
    app.setStyle("Fusion")
    if "/usr/share/icons" not in QIcon.themeSearchPaths():       # bare environments (chroot) have no XDG_DATA_DIRS
        QIcon.setThemeSearchPaths(QIcon.themeSearchPaths() + ["/usr/share/icons"])
    if demo or not QIcon.themeName() or QIcon.themeName() == "hicolor":
        for t in ("Papirus-Dark", "Papirus", "breeze-dark"):
            if Path(f"/usr/share/icons/{t}").exists():
                QIcon.setThemeName(t); break
    from PySide6.QtGui import QPalette, QColor
    pal = QPalette()
    for role, col in [(QPalette.Window, "#16181d"), (QPalette.WindowText, "#e6e6e6"), (QPalette.Base, "#1d2027"),
                      (QPalette.AlternateBase, "#1f232b"), (QPalette.Text, "#e6e6e6"), (QPalette.Button, "#2a2e37"),
                      (QPalette.ButtonText, "#e6e6e6"), (QPalette.PlaceholderText, "#9aa1ad"), (QPalette.Highlight, "#ff7a2e"),
                      (QPalette.ToolTipBase, "#2a2e37"), (QPalette.ToolTipText, "#e6e6e6")]:
        pal.setColor(role, QColor(col))
    app.setPalette(pal)

    class _Fake(QWidget):
        def __init__(self):
            super().__init__()
            self.setStyleSheet(STYLE.format(acc=accent()))
            lay = QVBoxLayout(self); lay.setContentsMargins(0, 0, 0, 0)
            self.log = QPlainTextEdit(); self.log.setMaximumHeight(150); self.log.hide()
            main = sys.modules.get("center")
            try:
                if main is None:
                    sys.path.insert(0, str(Path(__file__).resolve().parent)); import center as main  # noqa: E401
                self.runner = main.Runner(self.log)
            except Exception:
                self.runner = None
            self.page = FriendsPage(self, DemoBackend() if demo else None)
            lay.addWidget(self.page); lay.addWidget(self.log)

    f = _Fake(); f.resize(1000, 900)
    if not shot:
        f.show(); return app.exec()
    out = Path(shot); out.mkdir(parents=True, exist_ok=True)
    pg = f.page
    for c in pg.server_cards.values():
        if c.s["name"] == "phoenix-smp":
            c.toggle_console(True)
    f.show(); app.processEvents()

    def grab_full(widget, path, width=950):
        """Whole scroll content, not just the visible part."""
        scroll = widget.findChild(QScrollArea)
        inner = scroll.widget() if scroll else widget
        inner.setFixedWidth(width); inner.adjustSize(); app.processEvents()
        inner.resize(width, inner.sizeHint().height()); app.processEvents()
        inner.grab().save(str(path)); inner.setMinimumWidth(0); inner.setMaximumWidth(16777215)
        print("saved", path)
    grab_full(pg.page_widget, out / "friends-page.png")
    # room "off" state
    pg.room_key = None
    pg.render_room({"state": "off", "code": "", "peers": []}); app.processEvents()
    scroll = pg.page_widget.findChild(QScrollArea)
    pg.room_card.grab().save(str(out / "friends-room-off.png")); print("saved", out / "friends-room-off.png")
    pg.room_key = None; pg.render_room(DemoBackend().room())
    # manual settings opened
    for tb in pg.findChildren(QToolButton):
        if tb.text() == "Manual settings":
            tb.setChecked(True); break
    app.processEvents()
    hc = pg.lay.itemAt(3).widget()
    hc.adjustSize(); app.processEvents(); hc.grab().save(str(out / "friends-room-manual.png")); print("saved", out / "friends-room-manual.png")
    # dialogs
    pg._no_exec = True
    d = pg.show_details(); d.adjustSize(); d.show(); app.processEvents(); d.grab().save(str(out / "friends-other-computers.png"))
    print("saved", out / "friends-other-computers.png"); d.close()
    for game in ("minecraft", "valheim"):
        dlg = ServerDialog(pg, game)
        for tb in dlg.findChildren(QToolButton):
            tb.setChecked(True)
        dlg.setStyleSheet(STYLE.format(acc=accent()))
        dlg.show(); app.processEvents(); dlg.adjustSize(); app.processEvents()
        dlg.grab().save(str(out / f"friends-new-{game}.png")); print("saved", out / f"friends-new-{game}.png"); dlg.close()
    return 0


if __name__ == "__main__":
    sys.exit(_main(sys.argv))
