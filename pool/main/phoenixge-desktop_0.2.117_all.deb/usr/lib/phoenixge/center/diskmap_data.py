#!/usr/bin/env python3
"""PhoenixGe Center > Disk Map - data side (no Qt): folder scanner, file categories, clean-up hints, big space users.

Scanner(root).run() -> Node tree           os.scandir, never follows symlinks, stays on one filesystem,
                                          real disk usage (st_blocks), hard links counted once, progress counters,
                                          cancel flag. Each folder keeps its 300 biggest files; the rest become one
                                          "(N smaller files)" entry so a big home stays at a few tens of MB.
hint(node, home) -> (level, text, page)   "Safe to clean?" advice; level = safe | careful | info | ""
big_users(home) -> [dict(label, bytes, detail, cat, action)]   Steam / Heroic games, Flatpak, Timeshift, Trash...
demo_tree() / demo_big_users()             made-up home for screenshots (--demo)

Root scan of "/" (pkexec): python3 diskmap_data.py --scan-json /   -> JSON tree on stdout (read by diskmap.py)
"""
import heapq
import json
import os
import random
import re
import shutil
import stat
import subprocess
import sys
import time
from pathlib import Path

KEEP_FILES = 300
CATS = {  # key: (label, color)
    "video": ("Videos", "#e8590c"),
    "games": ("Games", "#7048e8"),
    "images": ("Pictures", "#2f9e44"),
    "audio": ("Music & audio", "#0ca678"),
    "docs": ("Documents", "#1c7ed6"),
    "archives": ("Archives & disk images", "#f59f00"),
    "apps": ("Apps", "#d6336c"),
    "system": ("System & caches", "#868e96"),
    "other": ("Other", "#5c7cfa"),
}
EXT = {}
for _cat, _exts in {
    "video": "mp4 mkv avi mov webm m4v wmv flv ts m2ts mts mpg mpeg 3gp vob ogv",
    "images": "jpg jpeg png gif webp heic heif avif raw cr2 cr3 nef arw dng orf rw2 bmp tif tiff svg psd kra xcf ico exr",
    "audio": "mp3 flac ogg opus m4a aac wav wma aiff alac mka mid",
    "docs": "pdf doc docx odt rtf txt md xls xlsx ods csv ppt pptx odp epub mobi djvu tex",
    "archives": "zip rar 7z tar gz tgz xz txz bz2 zst lz4 iso img dmg vhd vhdx vdi vmdk qcow2 cab",
    "apps": "appimage exe msi deb rpm flatpak flatpakref so dll apk jar",
    "games": "pak vpk bsa ba2 assets unity3d uasset ucas utoc forge rpf gcf wad pck sav esm esp",
}.items():
    for _e in _exts.split():
        EXT[_e] = _cat

# folder name / path rules: everything below such a folder gets the category (unless a file type says otherwise)
GAME_DIRS = re.compile(r"(^|/)(steamapps|Steam/steamapps|Games|Heroic|lutris|\.minecraft|PrismLauncher|"
                       r"Epic Games|GOG Games|itch|\.wine|Bottles|compatdata|shadercache)(/|$)", re.I)
APP_DIRS = re.compile(r"(^|/)(\.var/app|flatpak|\.local/share/flatpak|opt|snap|node_modules|\.rustup|\.cargo|"
                      r"\.npm|go/pkg|Android/Sdk|\.gradle|\.m2|\.vscode|\.mozilla|\.config/google-chrome|"
                      r"\.config/chromium|\.local/share/containers|\.local/share/Trash)(/|$)")
SYSTEM_TOP = ("/usr", "/var", "/etc", "/boot", "/lib", "/lib64", "/bin", "/sbin", "/srv", "/root", "/tmp")
SKIP_TOP = {"/proc", "/sys", "/dev", "/run", "/tmp/.X11-unix"}


def human(n):
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1000 or unit == "TB":
            return f"{n:.0f} {unit}" if unit in ("B", "KB") else f"{n:.1f} {unit}"
        n /= 1000.0


class Node:
    __slots__ = ("name", "size", "is_dir", "children", "parent", "cats", "mtime", "count", "denied", "cat")

    def __init__(self, name, is_dir, parent=None, size=0, cat="other", mtime=0.0):
        self.name, self.is_dir, self.parent, self.size = name, is_dir, parent, size
        self.children = [] if is_dir else None
        self.cats = {} if is_dir else None
        self.cat, self.mtime, self.count, self.denied = cat, mtime, 0 if is_dir else 1, False

    @property
    def path(self):
        parts, n = [], self
        while n is not None:
            parts.append(n.name)
            n = n.parent
        parts.reverse()
        root = parts[0]
        return os.path.join(root, *parts[1:]) if len(parts) > 1 else root

    @property
    def is_group(self):
        """The '(N smaller files)' pseudo entry."""
        return not self.is_dir and self.name.startswith("(") and self.name.endswith("smaller files)")

    def main_cat(self):
        if not self.is_dir:
            return self.cat
        if not self.cats:
            return self.cat
        return max(self.cats.items(), key=lambda kv: kv[1])[0]

    def ancestors(self):
        out, n = [], self
        while n is not None:
            out.append(n)
            n = n.parent
        return list(reversed(out))

    def remove(self):
        """Take this entry out of the tree (after Move to Trash) and fix the sizes above it."""
        p = self.parent
        if p is None:
            return
        if self in p.children:
            p.children.remove(self)
        sub = self.cats if self.is_dir else {self.cat: self.size}
        n = p
        while n is not None:
            n.size = max(0, n.size - self.size)
            n.count = max(0, n.count - (self.count or 1))
            for c, b in (sub or {}).items():
                if c in n.cats:
                    n.cats[c] = max(0, n.cats[c] - b)
            n = n.parent


def file_cat(name, ctx):
    ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
    c = EXT.get(ext)
    if ctx == "games" and c in (None, "apps", "archives", "other"):
        return "games"
    if ctx and not c:
        return ctx
    if ctx == "system" and c in ("apps", "archives"):
        return "system"
    return c or "other"


def dir_ctx(path, parent_ctx, home):
    if parent_ctx in ("games", "system"):
        return parent_ctx
    rel = path[len(home):] if home and path.startswith(home + "/") else path
    if GAME_DIRS.search(rel):
        return "games"
    if path.startswith(SYSTEM_TOP) or rel.startswith("/.cache") or rel == "/.cache":
        if not path.startswith("/opt"):
            return "system"
    if APP_DIRS.search(rel):
        return parent_ctx or "apps"
    return parent_ctx


class Scanner:
    def __init__(self, root, one_fs=True, home=None):
        self.root = os.path.abspath(os.path.expanduser(root))
        self.one_fs, self.home = one_fs, str(home or Path.home())
        self.files = self.dirs = self.bytes = self.denied = 0
        self.current, self.cancelled, self.done = self.root, False, False
        self.top_files = []          # heap of (size, path, cat, mtime)
        self.other_mounts = []       # mount points below root that were skipped (other filesystems)
        self.denied_paths = []
        self.started = time.time()

    def cancel(self):
        self.cancelled = True

    def run(self):
        try:
            st = os.stat(self.root)
        except OSError as e:
            raise RuntimeError(f"Can't open {self.root}: {e.strerror}") from e
        dev = st.st_dev
        root = Node(self.root, True)
        stack = [(root, self.root, dir_ctx(self.root, None, self.home))]
        order, seen_inodes = [], set()
        while stack and not self.cancelled:
            node, path, ctx = stack.pop()
            order.append(node)
            self.dirs += 1
            self.current = path
            files = []
            try:
                it = os.scandir(path)
            except OSError:
                node.denied = True
                self.denied += 1
                if len(self.denied_paths) < 200:
                    self.denied_paths.append(path)
                continue
            with it:
                for e in it:
                    if self.cancelled:
                        break
                    try:
                        s = e.stat(follow_symlinks=False)
                    except OSError:
                        continue
                    m = s.st_mode
                    if stat.S_ISDIR(m):
                        if (self.one_fs and s.st_dev != dev) or e.path in SKIP_TOP:
                            if s.st_dev != dev:
                                self.other_mounts.append(e.path)
                            continue
                        child = Node(e.name, True, node, mtime=s.st_mtime)
                        node.children.append(child)
                        stack.append((child, e.path, dir_ctx(e.path, ctx, self.home)))
                    elif stat.S_ISREG(m):
                        if s.st_nlink > 1:
                            key = (s.st_dev, s.st_ino)
                            if key in seen_inodes:
                                continue
                            seen_inodes.add(key)
                        size = s.st_blocks * 512 if hasattr(s, "st_blocks") else s.st_size
                        cat = file_cat(e.name, ctx)
                        files.append((size, e.name, cat, s.st_mtime))
                        self.files += 1
                        self.bytes += size
                        item = (size, e.path, cat, s.st_mtime)
                        if len(self.top_files) < 200:
                            heapq.heappush(self.top_files, item)
                        elif size > self.top_files[0][0]:
                            heapq.heapreplace(self.top_files, item)
            for size, name, cat, mt in files:
                node.size += size
                node.cats[cat] = node.cats.get(cat, 0) + size
            node.count += len(files)
            if len(files) > KEEP_FILES:
                files.sort(reverse=True)
                rest = files[KEEP_FILES:]
                files = files[:KEEP_FILES]
                rc = {}
                for size, _n, cat, _m in rest:
                    rc[cat] = rc.get(cat, 0) + size
                g = Node(f"({len(rest)} smaller files)", False, node, sum(r[0] for r in rest),
                         max(rc.items(), key=lambda kv: kv[1])[0] if rc else "other")
                g.count = len(rest)
                node.children.append(g)
            for size, name, cat, mt in files:
                node.children.append(Node(name, False, node, size, cat, mt))
        # sizes bottom-up (order is pre-order, so reversed = children before parents)
        for node in reversed(order):
            p = node.parent
            if p is not None:
                p.size += node.size
                p.count += node.count
                for c, b in node.cats.items():
                    p.cats[c] = p.cats.get(c, 0) + b
        for node in order:
            node.children.sort(key=lambda n: -n.size)
        self.done = True
        return root

    def biggest_files(self, n=100):
        return sorted(self.top_files, reverse=True)[:n]


# ------------------------------------------------------------------ JSON (root helper <-> page)
def to_json(node):
    if not node.is_dir:
        return [node.name, node.size, 0, node.cat, int(node.mtime), node.count]
    return [node.name, node.size, 1, node.cats, int(node.mtime), node.count, int(node.denied),
            [to_json(c) for c in node.children]]


def from_json(d, parent=None):
    if not d[2]:
        n = Node(d[0], False, parent, d[1], d[3], d[4])
        n.count = d[5]
        return n
    n = Node(d[0], True, parent, d[1], mtime=d[4])
    n.cats, n.count, n.denied = d[3], d[5], bool(d[6])
    n.children = [from_json(c, n) for c in d[7]]
    return n


# ------------------------------------------------------------------ hints
def hint(node, home=None):
    """-> (level, text, page). level: safe (green) | careful (yellow) | keep (red) | info (grey) | ''"""
    home = str(home or Path.home())
    p = node.path
    rel = p[len(home):] if p.startswith(home + "/") else None
    name = node.name
    if rel is not None:
        if rel == "/.cache":
            return "safe", "Apps rebuild their caches when needed. Health › Clean up does it for you.", "health"
        if rel.startswith("/.cache/"):
            return "safe", "Cache - safe to delete, the app rebuilds it when needed.", "health"
        if rel.endswith("/shadercache") or "/shadercache/" in rel:
            return "safe", "Steam shader cache - safe; the first start of a game is a bit slower.", ""
        if rel.startswith("/.local/share/Trash"):
            return "safe", "Trash - empty it to really free the space.", ""
        if "/compatdata" in rel:
            return "careful", "Proton prefixes - game saves can live here. Remove a game in Steam instead.", ""
        if re.search(r"/steamapps/common/[^/]+$", rel):
            return "careful", "Steam game - uninstall it in Steam so the library stays correct.", ""
        if re.search(r"/steamapps/downloading", rel):
            return "safe", "Unfinished Steam download - safe if no download is running.", ""
        if "flatpak" in rel and rel.count("/") <= 4:
            return "info", "Flatpak apps and runtimes - unused runtimes: Health › Clean up.", "health"
        if rel.startswith("/.var/app/") and rel.count("/") == 3:
            return "careful", "Settings and data of a Flatpak app (logins, saves). Delete only if the app is gone.", ""
        if rel.startswith("/Downloads/") and not node.is_dir and node.mtime and time.time() - node.mtime > 90 * 86400:
            return "safe", f"Downloaded {int((time.time() - node.mtime) / 86400)} days ago - probably not needed any more.", ""
        if rel == "/Downloads":
            return "info", "Look for old installers and ISO files here.", ""
        if name.lower().endswith((".iso", ".img")) and not node.is_dir:
            return "info", "Disk image - can go once the USB stick / VM is made.", ""
        if rel.startswith(("/.local/share/Steam", "/.steam")) and node.is_dir and rel.count("/") <= 4:
            return "careful", "Steam - remove games inside Steam.", ""
        if "/.wine" in rel or "/Bottles" in rel:
            return "careful", "Windows apps (Wine prefix) - removing it removes the installed Windows programs.", ""
        if rel.startswith("/.local/share/containers") or rel.startswith("/.local/share/distrobox"):
            return "careful", "Toolbox / containers - remove tools in Phoenix Toolbox.", ""
        if rel == "/.local" or rel == "/.local/share":
            return "info", "App data, games, Flatpak apps and the Trash live in here - look inside.", ""
        if rel.startswith(("/.config", "/.local")):
            return "careful", "App settings - don't delete unless you know the app.", ""
        if node.is_dir and name in ("node_modules", "target", "__pycache__", ".gradle", "build"):
            return "safe", "Build output - rebuilt by the project when needed.", ""
        return "", "", ""
    if p.startswith("/var/cache/apt"):
        return "safe", "Update package cache - Health › Clean up.", "health"
    if p.startswith("/var/log/journal"):
        return "safe", "System logs - Health › Clean up keeps the newest 200 MB.", "health"
    if p.startswith(("/timeshift", "/run/timeshift")):
        return "info", "Timeshift snapshots - manage them in Backups.", "backups"
    if p.startswith("/var/lib/flatpak"):
        return "info", "System Flatpak apps - unused runtimes: Health › Clean up.", "health"
    if p.startswith(("/usr", "/boot", "/etc", "/var/lib", "/lib", "/bin", "/sbin", "/opt")):
        return "keep", "System files - managed by the package manager, don't delete by hand.", ""
    return "", "", ""


# ------------------------------------------------------------------ known big space users
def _read(p):
    try:
        return Path(p).read_text(errors="ignore")
    except OSError:
        return ""


def quick_size(path, limit_s=20.0):
    """Disk usage of one folder (same rules as the scanner, no tree, time limited)."""
    total, t0, seen = 0, time.time(), set()
    stack = [str(path)]
    try:
        dev = os.stat(path).st_dev
    except OSError:
        return 0
    while stack and time.time() - t0 < limit_s:
        d = stack.pop()
        try:
            with os.scandir(d) as it:
                for e in it:
                    try:
                        s = e.stat(follow_symlinks=False)
                    except OSError:
                        continue
                    if stat.S_ISDIR(s.st_mode):
                        if s.st_dev == dev:
                            stack.append(e.path)
                    elif stat.S_ISREG(s.st_mode):
                        if s.st_nlink > 1:
                            if (s.st_dev, s.st_ino) in seen:
                                continue
                            seen.add((s.st_dev, s.st_ino))
                        total += s.st_blocks * 512
        except OSError:
            continue
    return total


def steam_libraries(home):
    out = []
    for root in [home / ".var/app/com.valvesoftware.Steam/.local/share/Steam", home / ".local/share/Steam",
                 home / ".steam/steam"]:
        lf = root / "steamapps/libraryfolders.vdf"
        if not lf.exists():
            continue
        libs = [Path(x.replace("\\\\", "\\")) for x in re.findall(r'"path"\s+"([^"]+)"', _read(lf))]
        for lib in [root] + libs:
            try:
                key = lib.resolve()
            except OSError:
                key = lib
            if key not in [k for k, _ in out]:
                out.append((key, lib))
    return [lib for _k, lib in out]


def steam_games(home):
    games = []
    for lib in steam_libraries(home):
        for acf in (lib / "steamapps").glob("appmanifest_*.acf"):
            t = _read(acf)
            name = (re.findall(r'"name"\s+"([^"]*)"', t) or [acf.stem])[0]
            size = int((re.findall(r'"SizeOnDisk"\s+"(\d+)"', t) or ["0"])[0])
            if re.match(r"^(Proton|Steam Linux Runtime|Steamworks Common)", name):
                name = "Steam tools: " + name
            games.append((name, size, str(lib / "steamapps/common")))
    return sorted(games, key=lambda g: -g[1])


def heroic_games(home):
    base = home / ".var/app/com.heroicgameslauncher.hgl/config/heroic"
    if not base.exists():
        base = home / ".config/heroic"
    out = []
    try:
        leg = json.loads(_read(base / "legendaryConfig/legendary/installed.json") or "{}")
        for v in leg.values() if isinstance(leg, dict) else []:
            if isinstance(v, dict):
                out.append((v.get("title", "?"), int(v.get("install_size") or 0), v.get("install_path", "")))
    except (ValueError, TypeError):
        pass
    for f in (base / "gog_store/installed.json", base / "nile_config/nile/installed.json"):
        try:
            d = json.loads(_read(f) or "{}")
        except ValueError:
            continue
        items = d.get("installed", []) if isinstance(d, dict) else d if isinstance(d, list) else []
        for g in items:
            if isinstance(g, dict) and g.get("install_path") and Path(g["install_path"]).is_dir():
                out.append((Path(g["install_path"]).name, quick_size(g["install_path"], 10), g["install_path"]))
    return sorted(out, key=lambda g: -g[1])


def _size_text(s):
    m = re.match(r"\s*([\d.,]+)\s*([kKMGT]?)B?", s or "")
    if not m:
        return 0
    v = float(m.group(1).replace(",", "."))
    return int(v * {"": 1, "k": 1e3, "K": 1e3, "M": 1e6, "G": 1e9, "T": 1e12}[m.group(2)])


def flatpak_totals():
    if not shutil.which("flatpak"):
        return None
    out = {}
    for kind in ("--app", "--runtime"):
        try:
            t = subprocess.run(["flatpak", "list", kind, "--columns=application,size"], capture_output=True,
                               text=True, timeout=20).stdout
        except Exception:  # noqa: BLE001
            t = ""
        rows = [ln.split("\t") for ln in t.splitlines() if "\t" in ln]
        out[kind] = (len(rows), sum(_size_text(r[1]) for r in rows))
    return out


def timeshift_info():
    snaps = []
    for d in ("/timeshift/snapshots", "/run/timeshift/backup/timeshift/snapshots",
              "/run/timeshift/backup/timeshift-btrfs/snapshots"):
        try:
            snaps += [e.name for e in os.scandir(d) if e.is_dir()]
        except OSError:
            continue
    conf = Path("/etc/timeshift/timeshift.json")
    return dict(configured=conf.exists(), count=len(snaps), latest=max(snaps) if snaps else "")


def big_users(home=None):
    """-> [dict(label, bytes or None, detail, cat, page, path)] - read-only, may take a few seconds."""
    home = Path(home or Path.home())
    out = []
    sg = steam_games(home)
    if sg:
        top = ", ".join(f"{n} {human(s)}" for n, s, _p in sg[:3])
        ng = len([g for g in sg if not g[0].startswith("Steam tools")])
        out.append(dict(label=f"Steam games ({ng})", bytes=sum(s for _n, s, _p in sg), detail=top, cat="games",
                        page="", path=sg[0][2]))
    hg = heroic_games(home)
    if hg:
        out.append(dict(label=f"Heroic games - Epic, GOG, Amazon ({len(hg)})", bytes=sum(s for _n, s, _p in hg),
                        detail=", ".join(f"{n} {human(s)}" for n, s, _p in hg[:3]), cat="games", page="",
                        path=str(Path(hg[0][2]).parent) if hg[0][2] else ""))
    fl = flatpak_totals()
    if fl and any(n for n, _b in fl.values()):
        (na, ba), (nr, br) = fl.get("--app", (0, 0)), fl.get("--runtime", (0, 0))
        out.append(dict(label=f"Flatpak apps ({na}) and runtimes ({nr})", bytes=ba + br,
                        detail=f"apps {human(ba)}, runtimes {human(br)} (shared parts counted once by Flatpak itself). "
                               "Unused runtimes: Health › Clean up.", cat="apps", page="health", path=""))
    ts = timeshift_info()
    if ts["configured"] or ts["count"]:
        out.append(dict(label=f"Timeshift snapshots ({ts['count'] or '?'})", bytes=None,
                        detail=(f"newest {ts['latest']}. " if ts["latest"] else "")
                        + "They only store what changed; the size needs administrator rights - see Backups.",
                        cat="system", page="backups", path=""))
    tr = quick_size(home / ".local/share/Trash", 10)
    out.append(dict(label="Trash", bytes=tr, detail="Files you deleted are still on the disk until the Trash is emptied.",
                    cat="system", page="", path="trash:/"))
    cache = quick_size(home / ".cache", 10)
    out.append(dict(label="Caches (~/.cache)", bytes=cache, detail="Rebuilt by apps when needed - Health › Clean up.",
                    cat="system", page="health", path=str(home / ".cache")))
    old, n = 0, 0
    dl = home / "Downloads"
    now = time.time()
    try:
        for e in os.scandir(dl):
            try:
                s = e.stat(follow_symlinks=False)
            except OSError:
                continue
            if now - s.st_mtime > 90 * 86400:
                n += 1
                old += quick_size(e.path, 5) if e.is_dir(follow_symlinks=False) else s.st_blocks * 512
    except OSError:
        pass
    if n:
        out.append(dict(label=f"Downloads older than 90 days ({n})", bytes=old,
                        detail="Old installers, archives and ISO files are usually safe to delete.", cat="archives",
                        page="", path=str(dl)))
    return out


# ------------------------------------------------------------------ demo data
def demo_tree(home="/home/phoenix"):
    rnd = random.Random(7)
    G = 1_000_000_000
    M = 1_000_000
    now = time.time()
    spec = {
        ".local": {"share": {
            "Steam": {"steamapps": {"common": {
                "Baldurs Gate 3": [("Data/Gustav.pak", 62 * G), ("Data/Textures.pak", 41 * G), ("Data/Models.pak", 28 * G),
                                   ("Data/Sound.pak", 9 * G), ("bin/bg3.exe", 120 * M)],
                "Cyberpunk 2077": [("archive/pc/content/basegame_4_gamedata.archive", 21 * G),
                                   ("archive/pc/content/basegame_3_nightcity.archive", 18 * G),
                                   ("archive/pc/ep1/ep1_1_textures.archive", 14 * G), ("archive/pc/content/audio.archive", 11 * G)],
                "Counter-Strike Global Offensive": [("game/csgo/pak01_000.vpk", 18 * G), ("game/csgo/maps.vpk", 12 * G),
                                                    ("game/bin/win64/cs2.exe", 90 * M)],
                "Elden Ring": [("Game/Data0.bdt", 22 * G), ("Game/Data1.bdt", 14 * G), ("Game/sd/sd.bdt", 8 * G)],
                "Hollow Knight": [("hollow_knight_Data/sharedassets0.assets", 4 * G)],
                "Proton 9.0": [("files/lib/wine.so", 1 * G)],
            }, "shadercache": [("1086940/fozpipelinesv6/steam_pipeline_cache.foz", 3 * G), ("730/DXVK.cache", 2 * G)],
                "compatdata": [("1086940/pfx/drive_c/users/steamuser/Saves/save.dat", 800 * M)]}},
            "flatpak": {"runtime": [("org.freedesktop.Platform/x86_64/24.08/files.img", 2 * G),
                                    ("org.kde.Platform/x86_64/6.8/files.img", 1.6 * G),
                                    ("org.gnome.Platform/x86_64/47/files.img", 1.4 * G),
                                    ("org.freedesktop.Platform.GL.nvidia-550/files.img", 900 * M)],
                        "app": [("com.discordapp.Discord/files.img", 400 * M), ("com.spotify.Client/files.img", 350 * M),
                                ("com.heroicgameslauncher.hgl/files.img", 600 * M), ("com.obsproject.Studio/files.img", 500 * M)]},
            "Trash": [("files/old-backup.zip", 6 * G), ("files/recording-2026-03.mkv", 3 * G)],
        }},
        "Games": {"Heroic": {"Fortnite-like Demo": [("Content/Paks/pakchunk0.pak", 26 * G)],
                             "Hades": [("Content/Packages/1080p.pkg", 9 * G)],
                             "Cyberpunk Expansion": [("Content/data.forge", 7 * G)]}},
        ".cache": [("mozilla/firefox/cache2.bin", 1.2 * G), ("thumbnails/large.bin", 900 * M), ("pip/wheels.bin", 600 * M),
                   ("lutris/runners.tar.xz", 800 * M), ("mesa_shader_cache/index", 400 * M)],
        ".var": {"app": [("com.discordapp.Discord/config/Cache.data", 1.5 * G),
                         ("com.valvesoftware.Steam/data/logs.txt", 30 * M), ("org.mozilla.firefox/profile.db", 700 * M)]},
        "Videos": [("Wedding 2025 (4K).mp4", 38 * G), ("Clips/CS2 ace.mp4", 600 * M), ("Clips/Elden Ring boss.mkv", 1.4 * G),
                   ("Movies/Interstellar.mkv", 18 * G), ("Movies/Dune Part Two.mkv", 22 * G), ("OBS/stream-2026-10-02.mkv", 9 * G),
                   ("OBS/stream-2026-11-01.mkv", 11 * G), ("Phone/VID_2026.mp4", 4 * G)],
        "Pictures": [("Phone 2024/IMG_%04d.jpg", (900, 4 * M)), ("Phone 2025/IMG_%04d.heic", (1200, 3 * M)),
                     ("Screenshots/Screenshot_%03d.png", (400, 2 * M)), ("Wallpapers/phoenix-%02d.png", (40, 8 * M)),
                     ("RAW/DSC_%04d.NEF", (300, 25 * M))],
        "Music": [("Albums/track-%03d.flac", (500, 30 * M)), ("Podcasts/episode-%02d.mp3", (60, 70 * M))],
        "Documents": [("University/thesis.pdf", 40 * M), ("Work/report-%02d.docx", (80, 2 * M)),
                      ("Scans/scan-%03d.pdf", (120, 5 * M)), ("taxes-2025.xlsx", 3 * M)],
        "Downloads": [("debian-13.1.0-amd64-DVD-1.iso", 3.9 * G), ("Windows11_24H2.iso", 6.2 * G),
                      ("phoenixge-0.1-amd64.iso", 3.9 * G), ("setup-old-game.exe", 1.8 * G), ("drivers.zip", 700 * M),
                      ("photos-backup.tar.gz", 5 * G), ("invoice-%02d.pdf", (40, 300_000))],
        "Projects": {"chatlaxi-ai": [("node_modules/pkg-%03d/index.js", (600, 3 * M)), ("build/app.bin", 900 * M),
                                     ("src/main-%02d.ts", (50, 40_000))],
                     "vm": [("windows11.vdi", 48 * G), ("debian.qcow2", 14 * G)]},
    }
    root = Node(home, True)
    old = now - 200 * 86400

    def add_file(dirnode, relpath, size, mtime):
        parts = relpath.split("/")
        d = dirnode
        for part in parts[:-1]:
            nxt = next((c for c in d.children if c.is_dir and c.name == part), None)
            if nxt is None:
                nxt = Node(part, True, d)
                d.children.append(nxt)
            d = nxt
        path_ctx = None
        for a in reversed(d.ancestors()):
            path_ctx = dir_ctx(a.path, None, home)
            if path_ctx:
                break
        n = Node(parts[-1], False, d, int(size), file_cat(parts[-1], path_ctx), mtime)
        d.children.append(n)

    def walk(dirnode, sp):
        if isinstance(sp, dict):
            for k, v in sp.items():
                c = next((x for x in dirnode.children if x.is_dir and x.name == k), None)
                if c is None:
                    c = Node(k, True, dirnode)
                    dirnode.children.append(c)
                walk(c, v)
        else:
            for rel, size in sp:
                if isinstance(size, tuple):
                    cnt, avg = size
                    for i in range(cnt):
                        add_file(dirnode, rel % i, avg * rnd.uniform(0.4, 1.6), now - rnd.uniform(0, 400) * 86400)
                else:
                    mt = old if "Downloads" in dirnode.path and rnd.random() < 0.7 else now - rnd.uniform(0, 60) * 86400
                    add_file(dirnode, rel, size, mt)
    walk(root, spec)

    def finish(n):
        if not n.is_dir:
            return
        n.size, n.cats, n.count = 0, {}, 0
        for c in n.children:
            finish(c)
            n.size += c.size
            n.count += c.count
            for k, b in (c.cats.items() if c.is_dir else [(c.cat, c.size)]):
                n.cats[k] = n.cats.get(k, 0) + b
        n.children.sort(key=lambda x: -x.size)
    finish(root)
    return root


def demo_big_users():
    G = 1_000_000_000
    return [
        dict(label="Steam games (6)", bytes=int(331 * G), detail="Baldur's Gate 3 140.1 GB, Cyberpunk 2077 64.0 GB, Elden Ring 44.0 GB",
             cat="games", page="", path=""),
        dict(label="Heroic games - Epic, GOG, Amazon (3)", bytes=int(42 * G), detail="Fortnite-like Demo 26.0 GB, Hades 9.0 GB, "
             "Cyberpunk Expansion 7.0 GB", cat="games", page="", path=""),
        dict(label="Flatpak apps (14) and runtimes (9)", bytes=int(7.8 * G), detail="apps 2.3 GB, runtimes 5.5 GB. "
             "Unused runtimes: Health › Clean up.", cat="apps", page="health", path=""),
        dict(label="Timeshift snapshots (5)", bytes=None, detail="newest 2026-11-12_21-00-01. They only store what changed; "
             "the size needs administrator rights - see Backups.", cat="system", page="backups", path=""),
        dict(label="Trash", bytes=int(9 * G), detail="Files you deleted are still on the disk until the Trash is emptied.",
             cat="system", page="", path="trash:/"),
        dict(label="Caches (~/.cache)", bytes=int(3.9 * G), detail="Rebuilt by apps when needed - Health › Clean up.",
             cat="system", page="health", path=""),
        dict(label="Downloads older than 90 days (34)", bytes=int(14.6 * G),
             detail="Old installers, archives and ISO files are usually safe to delete.", cat="archives", page="", path=""),
    ]


def main():
    if "--scan-json" in sys.argv:
        sys.setrecursionlimit(100000)
        root = sys.argv[sys.argv.index("--scan-json") + 1]
        sc = Scanner(root, home=os.environ.get("PHOENIXGE_HOME") or None)
        tree = sc.run()
        json.dump(dict(tree=to_json(tree), denied=sc.denied, files=sc.files,
                       top=[list(t) for t in sc.biggest_files(100)]), sys.stdout, separators=(",", ":"))
        return 0
    path = sys.argv[1] if len(sys.argv) > 1 else str(Path.home())
    sc = Scanner(path)
    t0 = time.time()
    tree = sc.run()
    print(f"{tree.path}: {human(tree.size)} in {sc.files} files, {sc.dirs} folders, {sc.denied} unreadable, "
          f"{time.time() - t0:.1f} s")
    for c in tree.children[:15]:
        lv, txt, _pg = hint(c)
        print(f"  {human(c.size):>9}  {c.name:40} {CATS[c.main_cat()][0]:22} {txt}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
