"""PhoenixGe Center > Free games & deals: this week's free games (Epic, Steam, GOG, other stores) with a countdown and
a Claim button, what is free next, cross-store deals with a Linux badge, a wishlist with price alerts (or imported
from a public Steam wishlist), and notification settings (Automatic or full manual control).

build(center) -> QWidget          (backend: /usr/lib/phoenixge/deals/deals.py, no Qt)
Run alone:  python3 deals_page.py  (= phoenixge-deals)
"""
import os
import queue
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

from PySide6.QtCore import QObject, QRectF, QSize, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices, QFont, QIcon, QPainter, QPainterPath, QPixmap
from PySide6.QtWidgets import (QApplication, QButtonGroup, QCheckBox, QComboBox, QDoubleSpinBox, QFrame, QGridLayout,
                               QHBoxLayout, QLabel, QLineEdit, QPushButton, QRadioButton, QScrollArea, QSizePolicy,
                               QSpinBox, QVBoxLayout, QWidget)

HERE = Path(__file__).resolve().parent
for p in (HERE.parent / "deals", Path("/usr/lib/phoenixge/deals")):
    if (p / "deals.py").exists():
        sys.path.insert(0, str(p))
        break
import deals as dl  # noqa: E402

APP_ICON = "/usr/share/icons/hicolor/scalable/apps/phoenixge-deals.svg"
FALLBACK_ACCENT = "#ff7a2e"
STORE_COLORS = {"Epic": "#2a2a2a", "Epic Games Store": "#2a2a2a", "Steam": "#1b2838", "GOG": "#86328a",
                "Humble Store": "#cc2929", "Fanatical": "#ff9800", "GreenManGaming": "#00b16a", "Gamesplanet": "#1565c0",
                "GameBillet": "#3f51b5", "IndieGala": "#d32f2f", "WinGameStore": "#455a64"}


def _accent():
    main = sys.modules.get("__main__")
    try:
        return main.accent()
    except Exception:
        pass
    try:
        v = subprocess.run(["kreadconfig6", "--file", "kdeglobals", "--group", "General", "--key", "AccentColor"],
                           capture_output=True, text=True, timeout=3).stdout.strip()
        r, g, b = (int(x) for x in v.split(",")[:3])
        return QColor(r, g, b).name()
    except Exception:
        return FALLBACK_ACCENT


def _ui():
    """Card / page from center.py when we run inside it (same look), small copies otherwise."""
    main = sys.modules.get("__main__")
    if hasattr(main, "Card") and hasattr(main, "page"):
        return main.Card, main.page

    class Card(QFrame):
        def __init__(self, title="", text=""):
            super().__init__()
            self.setObjectName("card")
            self.lay = QVBoxLayout(self); self.lay.setContentsMargins(18, 16, 18, 16); self.lay.setSpacing(8)
            if title:
                t = QLabel(title); t.setObjectName("cardTitle"); self.lay.addWidget(t)
            if text:
                x = QLabel(text); x.setWordWrap(True); x.setObjectName("dim"); self.lay.addWidget(x)

    def page(title, subtitle=""):
        w = QWidget(); outer = QVBoxLayout(w); outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame)
        inner = QWidget(); lay = QVBoxLayout(inner); lay.setContentsMargins(36, 30, 36, 30); lay.setSpacing(16)
        h = QLabel(title); h.setObjectName("h1"); lay.addWidget(h)
        if subtitle:
            s = QLabel(subtitle); s.setObjectName("dim"); s.setWordWrap(True); lay.addWidget(s)
        scroll.setWidget(inner); outer.addWidget(scroll)
        return w, lay
    return Card, page


def open_url(url):
    if url:
        QDesktopServices.openUrl(QUrl(url))


def heroic_cmd():
    if shutil.which("heroic"):
        return ["heroic"]
    for d in (Path.home() / ".local/share/flatpak/app/com.heroicgameslauncher.hgl",
              Path("/var/lib/flatpak/app/com.heroicgameslauncher.hgl")):
        if d.exists():
            return ["flatpak", "run", "com.heroicgameslauncher.hgl"]
    return None


def clear(layout):
    while layout.count():
        it = layout.takeAt(0)
        if it.widget():
            it.widget().deleteLater()
        elif it.layout():
            clear(it.layout())


def pill(text, bg, fg="#ffffff", tip=""):
    lab = QLabel(text)
    lab.setStyleSheet(f"background:{bg}; color:{fg}; border-radius:9px; padding:2px 9px; font-size:11px; font-weight:600;")
    lab.setSizePolicy(QSizePolicy.Maximum, QSizePolicy.Fixed)
    if tip:
        lab.setToolTip(tip)
    return lab


def rounded(path, w, h, radius=12, fallback_text=""):
    """Cover image cropped to fill w x h with rounded corners (a dark tile with the title when there is no image)."""
    pm = QPixmap(path) if path else QPixmap()
    out = QPixmap(w * 2, h * 2); out.setDevicePixelRatio(2); out.fill(Qt.transparent)
    p = QPainter(out); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.SmoothPixmapTransform)
    clip = QPainterPath(); clip.addRoundedRect(QRectF(0, 0, w, h), radius, radius); p.setClipPath(clip)
    if not pm.isNull():
        sc = pm.scaled(QSize(w * 2, h * 2), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
        sc.setDevicePixelRatio(2)
        p.drawPixmap(int((w - sc.width() / 2) / 2), int((h - sc.height() / 2) / 2), sc)
    else:
        p.fillRect(QRectF(0, 0, w, h), QColor("#241a1f"))
        p.setPen(QColor("#ffb070")); f = QFont(); f.setBold(True); f.setPointSize(11); p.setFont(f)
        p.drawText(QRectF(10, 10, w - 20, h - 20), Qt.AlignCenter | Qt.TextWordWrap, fallback_text)
    p.end()
    return out


class Bridge(QObject):
    loaded = Signal(object)
    cover = Signal(str, str)
    status = Signal(str)
    imported = Signal(str)
    searched = Signal(object)


class CoverLoader:
    """One background thread downloads covers in order; labels are updated through the bridge signal."""

    def __init__(self, bridge):
        self.bridge, self.q, self.waiting = bridge, queue.Queue(), {}
        threading.Thread(target=self._run, daemon=True).start()

    def want(self, url, label, w, h, text, radius=12):
        if not url:
            label.setPixmap(rounded(None, w, h, radius, text))
            return
        f = dl.cover_path(url)
        if f and f.exists() and f.stat().st_size > 0:
            label.setPixmap(rounded(str(f), w, h, radius, text))
            return
        label.setPixmap(rounded(None, w, h, radius, text))
        self.waiting.setdefault(url, []).append((label, w, h, text, radius))
        self.q.put(url)

    def _run(self):
        while True:
            url = self.q.get()
            path = dl.get_cover(url)
            if path:
                self.bridge.cover.emit(url, path)

    def done(self, url, path):
        for label, w, h, text, radius in self.waiting.pop(url, []):
            try:
                label.setPixmap(rounded(path, w, h, radius, text))
            except RuntimeError:  # label already deleted (list rebuilt)
                pass


class DealsPage(QWidget):
    def __init__(self, center=None):
        super().__init__()
        self.center = center
        self.acc = _accent()
        self.settings = dl.load_settings()
        self.data = None
        self.countdowns = []          # (label, end, fmt)
        self.shown_once = False
        self.loading = False
        self.bridge = Bridge()
        self.bridge.loaded.connect(self.show_data)
        self.bridge.status.connect(lambda t: self.updated.setText(t))
        self.bridge.imported.connect(self.import_done)
        self.bridge.searched.connect(self.show_search)
        self.covers = CoverLoader(self.bridge)
        self.bridge.cover.connect(self.covers.done)

        Card, page = _ui()
        self.Card = Card
        w, lay = page("Free games & deals", "Games you can keep for free this week, what's free next, and the best "
                                            "deals across stores - with a wishlist that tells you when a price drops.")
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0); outer.addWidget(w)
        self.setStyleSheet(f"""
            #freeCard {{ background: palette(alternate-base); border-radius: 16px; border: 1px solid {self.acc}33; }}
            #freeCard[owned="true"] {{ border: 1px solid palette(mid); }}
            #dealRow {{ border-bottom: 1px solid palette(midlight); }}
            #big {{ font-size: 15px; font-weight: 700; }}
            #countdown {{ color: {self.acc}; font-weight: 600; }}
            #strike {{ color: palette(placeholder-text); text-decoration: line-through; }}
            #price {{ font-size: 15px; font-weight: 700; }}
            QPushButton#small {{ padding: 5px 10px; }}
        """)

        # status row
        top = QHBoxLayout()
        self.updated = QLabel("Loading…"); self.updated.setObjectName("dim")
        self.refresh_btn = QPushButton("Refresh"); self.refresh_btn.clicked.connect(lambda: self.reload(force=True))
        top.addWidget(self.updated, 1); top.addWidget(self.refresh_btn)
        lay.addLayout(top)

        # free now
        self.free_card = Card("Free right now")
        self.free_note = QLabel("Free to keep: claim it before the date and it stays in your library forever. Claim opens "
                                "the store page - claiming needs your own store account (sign in, then press Get). "
                                "Epic games then appear in Heroic after Library > Refresh.")
        self.free_note.setWordWrap(True); self.free_note.setObjectName("dim")
        self.free_card.lay.addWidget(self.free_note)
        self.free_row = QGridLayout(); self.free_row.setSpacing(14)
        self.free_card.lay.addLayout(self.free_row)
        lay.addWidget(self.free_card)

        # coming next
        self.next_card = Card("Coming next")
        self.next_row = QGridLayout(); self.next_row.setSpacing(14)
        self.next_card.lay.addLayout(self.next_row)
        lay.addWidget(self.next_card)

        # deals
        self.deals_card = Card("Deals", "Best discounts right now across stores. Prices are in US dollars (CheapShark and "
                                        "the US Steam store) - your store may show your own currency. The Linux badge is "
                                        "the ProtonDB rating (Platinum/Gold run great) or \"native\" for a Linux version.")
        bar = QHBoxLayout()
        self.filter = QLineEdit(); self.filter.setPlaceholderText("Filter by name…"); self.filter.setClearButtonEnabled(True)
        self.filter.textChanged.connect(self.render_deals)
        self.store_box = QComboBox(); self.store_box.currentIndexChanged.connect(self.render_deals)
        self.sort_box = QComboBox(); self.sort_box.addItems(["Biggest discount", "Lowest price", "Best rated on Steam",
                                                              "Runs best on Linux"])
        self.sort_box.currentIndexChanged.connect(self.render_deals)
        self.linux_only = QCheckBox("Runs on Linux"); self.linux_only.toggled.connect(self.render_deals)
        bar.addWidget(self.filter, 1); bar.addWidget(self.store_box); bar.addWidget(self.sort_box); bar.addWidget(self.linux_only)
        self.deals_card.lay.addLayout(bar)
        self.deals_box = QVBoxLayout(); self.deals_box.setSpacing(0)
        self.deals_card.lay.addLayout(self.deals_box)
        self.more_btn = QPushButton("Show more"); self.more_btn.clicked.connect(lambda: self.render_deals(more=True))
        self.deals_card.lay.addWidget(self.more_btn, 0, Qt.AlignHCenter)
        self.deals_limit = 15
        lay.addWidget(self.deals_card)

        # wishlist
        self.wish_card = Card("Wishlist", "Get a notification when a game drops below your target price or reaches its "
                                          "lowest price ever. Without a target you are told only about the lowest price ever.")
        add = QHBoxLayout()
        self.search = QLineEdit(); self.search.setPlaceholderText("Add a game: type its name…")
        self.search.returnPressed.connect(self.do_search)
        sb = QPushButton("Search"); sb.clicked.connect(self.do_search)
        add.addWidget(self.search, 1); add.addWidget(sb)
        self.wish_card.lay.addLayout(add)
        self.search_box = QVBoxLayout(); self.search_box.setSpacing(2)
        self.wish_card.lay.addLayout(self.search_box)
        imp = QHBoxLayout()
        self.profile = QLineEdit(self.settings.get("steam_profile") or "")
        self.profile.setPlaceholderText("Import a Steam wishlist: profile link, custom name or SteamID64")
        self.imp_btn = QPushButton("Import"); self.imp_btn.clicked.connect(self.do_import)
        imp.addWidget(self.profile, 1); imp.addWidget(self.imp_btn)
        self.wish_card.lay.addLayout(imp)
        self.imp_status = QLabel("The Steam wishlist must be public (Steam > Profile > Privacy: Game details Public).")
        self.imp_status.setObjectName("dim"); self.imp_status.setWordWrap(True)
        self.wish_card.lay.addWidget(self.imp_status)
        self.wish_box = QVBoxLayout(); self.wish_box.setSpacing(0)
        self.wish_card.lay.addLayout(self.wish_box)
        lay.addWidget(self.wish_card)

        # settings
        lay.addWidget(self._settings_card())
        lay.addStretch()

        self.tick = QTimer(self); self.tick.setInterval(30_000); self.tick.timeout.connect(self.update_countdowns)

    # ---------------------------------------------------------------- page shown / hidden
    def showEvent(self, e):
        super().showEvent(e)
        self.tick.start()
        if not self.shown_once:
            self.shown_once = True
            self.reload()

    def hideEvent(self, e):
        super().hideEvent(e)
        self.tick.stop()

    # ---------------------------------------------------------------- loading
    def reload(self, force=False):
        if self.loading:
            return
        self.loading = True
        self.refresh_btn.setEnabled(False)
        self.updated.setText("Checking the stores…")
        s = dict(self.settings)

        def work():
            out = {}
            try:
                out["free"], out["next"] = dl.free_games(s, force)
            except Exception as e:  # noqa: BLE001
                out["free"], out["next"], out["err"] = [], [], str(e)
            try:
                out["deals"] = dl.deals(s, force)
            except Exception as e:  # noqa: BLE001
                out["deals"], out["err"] = [], str(e)
            try:
                out["wish"] = dl.wishlist_prices(s, force)
            except Exception as e:  # noqa: BLE001
                out["wish"] = []
            out["stores"] = dl.store_names()
            self.bridge.loaded.emit(out)
        threading.Thread(target=work, daemon=True).start()

    def show_data(self, data):
        self.loading = False
        self.refresh_btn.setEnabled(True)
        self.data = data
        t = dl.last_update()
        when = ("never" if not t else "just now" if time.time() - t < 90
                else time.strftime("%d %b %H:%M", time.localtime(t)))
        offline = "" if t and time.time() - t < 6 * 3600 else "  -  offline? showing the last saved list"
        self.updated.setText(f"Updated {when}{offline}." + ("  A game is running: notifications wait until it ends."
                                                            if dl.gaming_now() else ""))
        self.countdowns = []
        self.render_free()
        self.render_next()
        names = sorted({d["store"] for d in data.get("deals", [])})
        cur = self.store_box.currentText()
        self.store_box.blockSignals(True); self.store_box.clear(); self.store_box.addItems(["All stores"] + names)
        if cur in names:
            self.store_box.setCurrentText(cur)
        self.store_box.blockSignals(False)
        self.render_deals()
        self.render_wish(data.get("wish", []))

    # ---------------------------------------------------------------- free games
    def render_free(self):
        clear(self.free_row)
        hide = dl.effective(self.settings).get("hide_owned")
        games = [g for g in self.data.get("free", []) if not (hide and g.get("owned"))]
        if not games:
            lab = QLabel("No free-to-keep games right now (or the stores could not be reached). Epic gives a new one "
                         "away every Thursday - check \"Coming next\".")
            lab.setWordWrap(True); lab.setObjectName("dim"); self.free_row.addWidget(lab, 0, 0)
        for i, g in enumerate(games):
            self.free_row.addWidget(self.free_card_widget(g), i // 2, i % 2)
        for c in (0, 1):
            self.free_row.setColumnStretch(c, 1)

    def free_card_widget(self, g):
        W, H = 186, 248
        card = QFrame(); card.setObjectName("freeCard")
        card.setProperty("owned", bool(g.get("owned")))
        hb = QHBoxLayout(card); hb.setContentsMargins(12, 12, 16, 12); hb.setSpacing(16)
        img = QLabel(); img.setFixedSize(W, H)
        self.covers.want(g.get("image") or g.get("fallback"), img, W, H, g["title"])
        hb.addWidget(img, 0, Qt.AlignTop)
        v = QVBoxLayout(); v.setSpacing(6); hb.addLayout(v, 1)
        chips = QHBoxLayout(); chips.setSpacing(6)
        chips.addWidget(pill(g["store"].replace(" Games Store", ""), STORE_COLORS.get(g["store"], "#444")))
        chips.addWidget(pill("FREE", self.acc, "#1a0b06"))
        if g.get("owned"):
            chips.addWidget(pill("In your library", "#2e7d32"))
        chips.addStretch()
        v.addLayout(chips)
        t = QLabel(g["title"]); t.setObjectName("big"); t.setWordWrap(True)
        t.setStyleSheet("font-size:18px;font-weight:700;")
        v.addWidget(t)
        if g.get("description"):
            txt = " ".join(g["description"].split())
            d = QLabel(txt if len(txt) < 220 else txt[:217].rsplit(" ", 1)[0] + "…")
            d.setWordWrap(True); d.setObjectName("dim"); v.addWidget(d)
        if g.get("end"):
            cd = QLabel(); cd.setObjectName("countdown"); cd.setWordWrap(True)
            self.countdowns.append((cd, g["end"], "until"))
            v.addWidget(cd)
        else:
            cd = QLabel("Free for a limited time"); cd.setObjectName("countdown"); v.addWidget(cd)
        if g.get("normal") and g["normal"] not in ("0", "$0.00"):
            n = QLabel(f"Normally {g['normal']}"); n.setObjectName("dim"); v.addWidget(n)
        v.addStretch()
        btns = QHBoxLayout(); v.addLayout(btns)
        b = QPushButton("Claim on " + g["store"].replace(" Games Store", "") if not g.get("owned") else "Open store page")
        b.setObjectName("primary"); b.setToolTip(g["url"])
        b.clicked.connect(lambda _=False, u=g["url"]: open_url(u))
        btns.addWidget(b)
        if g["store"] in ("Epic", "Epic Games Store", "GOG") and heroic_cmd():
            hb = QPushButton("Open Heroic")
            hb.setToolTip("Heroic's Store tab is the Epic/GOG store inside Heroic - claim there with your account, "
                          "then the game shows up in your Heroic library.")
            hb.clicked.connect(lambda: subprocess.Popen(heroic_cmd(), start_new_session=True))
            btns.addWidget(hb)
        btns.addStretch()
        self.update_countdowns()
        return card

    def render_next(self):
        clear(self.next_row)
        ups = self.data.get("next", [])
        self.next_card.setVisible(bool(ups))
        for i, g in enumerate(ups):
            W, H = 150, 200
            card = QFrame(); card.setObjectName("freeCard"); card.setFixedWidth(W + 20)
            v = QVBoxLayout(card); v.setContentsMargins(10, 10, 10, 10); v.setSpacing(5)
            img = QLabel(); img.setFixedSize(W, H)
            self.covers.want(g.get("image"), img, W, H, "Mystery game" if g.get("mystery") else g["title"])
            v.addWidget(img)
            t = QLabel(g["title"]); t.setStyleSheet("font-weight:600;"); t.setWordWrap(True); t.setFixedWidth(W)
            v.addWidget(t)
            cd = QLabel(); cd.setObjectName("dim"); cd.setWordWrap(True)
            self.countdowns.append((cd, g.get("start"), "from"))
            v.addWidget(cd)
            v.addStretch()
            self.next_row.addWidget(card, i // 6, i % 6)
        self.next_row.setColumnStretch(6, 1)
        self.update_countdowns()

    def update_countdowns(self):
        alive = []
        for lab, ts, kind in self.countdowns:
            try:
                if kind == "until":
                    left = dl.left_text(ts)
                    lab.setText("Offer ended" if left == "ended" else
                                f"Free until {time.strftime('%a %d %b, %H:%M', time.localtime(ts))}\n{left} left")
                else:
                    lab.setText(f"Free from {time.strftime('%a %d %b', time.localtime(ts))}\nin {dl.left_text(ts)}"
                                if ts else "Soon")
                alive.append((lab, ts, kind))
            except RuntimeError:
                pass
        self.countdowns = alive

    # ---------------------------------------------------------------- deals
    def render_deals(self, *_a, more=False):
        if not self.data:
            return
        if more is True:
            self.deals_limit += 15
        clear(self.deals_box)
        q = self.filter.text().strip().lower()
        store = self.store_box.currentText()
        rows = [d for d in self.data.get("deals", [])
                if (not q or q in d["title"].lower()) and (store in ("", "All stores") or d["store"] == store)
                and (not self.linux_only.isChecked() or (d.get("badge") and not d["badge"][0].endswith("borked")))]
        order = {"native": 0, "platinum": 1, "gold": 2, "silver": 3, "bronze": 4}
        k = self.sort_box.currentIndex()
        if k == 1:
            rows.sort(key=lambda d: d["price"])
        elif k == 2:
            rate = ["Overwhelmingly Positive", "Very Positive", "Positive", "Mostly Positive", "Mixed"]
            rows.sort(key=lambda d: (rate.index(d["rating"]) if d.get("rating") in rate else 9, -d["discount"]))
        elif k == 3:
            rows.sort(key=lambda d: (order.get((d.get("badge") or ("", ""))[0].split(": ")[-1], 9), -d["discount"]))
        if not rows:
            lab = QLabel("No deals match. Try a lower minimum discount, a higher price limit or more stores in Settings.")
            lab.setObjectName("dim"); lab.setWordWrap(True); self.deals_box.addWidget(lab)
        wished = {str(w.get("steam_appid")) for w in self.settings.get("wishlist", []) if w.get("steam_appid")}
        wished |= {str(w["id"]) for w in self.settings.get("wishlist", [])}
        for d in rows[:self.deals_limit]:
            self.deals_box.addWidget(self.deal_row(d, wished))
        self.more_btn.setVisible(len(rows) > self.deals_limit)

    def deal_row(self, d, wished):
        row = QFrame(); row.setObjectName("dealRow")
        h = QHBoxLayout(row); h.setContentsMargins(0, 8, 0, 8); h.setSpacing(12)
        img = QLabel(); img.setFixedSize(128, 48)
        self.covers.want(d.get("thumb"), img, 128, 48, d["title"], radius=6)
        h.addWidget(img)
        mid = QVBoxLayout(); mid.setSpacing(3)
        t = QLabel(d["title"]); t.setStyleSheet("font-weight:600;"); t.setToolTip(d["title"])
        t.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        mid.addWidget(t)
        sub = QHBoxLayout(); sub.setSpacing(6)
        sub.addWidget(pill(d["store"], STORE_COLORS.get(d["store"], "#555")))
        if d.get("badge"):
            sub.addWidget(pill(d["badge"][0], d["badge"][1], "#101010",
                               "Native Linux version" if "native" in d["badge"][0]
                               else "ProtonDB rating: how well the Windows version runs on Linux with Proton"))
        if d.get("rating"):
            r = QLabel(d["rating"]); r.setObjectName("dim"); sub.addWidget(r)
        if d.get("end"):
            e = QLabel("ends " + time.strftime("%d %b", time.localtime(d["end"]))); e.setObjectName("dim"); sub.addWidget(e)
        sub.addStretch()
        mid.addLayout(sub)
        h.addLayout(mid, 1)
        h.addWidget(pill(f"-{d['discount']}%", self.acc, "#1a0b06"))
        pr = QVBoxLayout(); pr.setSpacing(0)
        old = QLabel(f"${d['normal']:.2f}"); old.setObjectName("strike"); old.setAlignment(Qt.AlignRight)
        new = QLabel(f"${d['price']:.2f}"); new.setObjectName("price"); new.setAlignment(Qt.AlignRight)
        pr.addWidget(old); pr.addWidget(new)
        prw = QWidget(); prw.setLayout(pr); prw.setFixedWidth(70)
        h.addWidget(prw)
        ob = QPushButton("Open"); ob.setObjectName("small"); ob.setToolTip(d["url"])
        ob.clicked.connect(lambda _=False, u=d["url"]: open_url(u))
        h.addWidget(ob)
        inwl = str(d.get("steam_appid")) in wished or str(d.get("game_id")) in wished
        wb = QPushButton("On wishlist" if inwl else "+ Wishlist"); wb.setObjectName("small"); wb.setEnabled(not inwl)
        if d.get("game_id") or d.get("steam_appid"):
            wb.clicked.connect(lambda _=False, d=d, b=wb: self.wish_from_deal(d, b))
        else:
            wb.setEnabled(False)
        h.addWidget(wb)
        return row

    def wish_from_deal(self, d, btn):
        btn.setEnabled(False); btn.setText("Adding…")
        gid = d.get("game_id")

        def work():
            g = None
            if gid:
                g = dict(id=gid, title=d["title"], steam_appid=d.get("steam_appid"), thumb=d.get("thumb"))
            else:
                try:
                    import json
                    res = json.loads(dl.fetch("https://www.cheapshark.com/api/1.0/games?steamAppID=" + str(d["steam_appid"])))
                    if res:
                        g = dict(id=res[0]["gameID"], title=res[0].get("external") or d["title"],
                                 steam_appid=d["steam_appid"], thumb=res[0].get("thumb"))
                except Exception:  # noqa: BLE001
                    g = None
            if g:
                dl.wishlist_add(g)
            self.bridge.imported.emit("added" if g else "Could not find this game on CheapShark.")
        threading.Thread(target=work, daemon=True).start()

    # ---------------------------------------------------------------- wishlist
    def render_wish(self, rows):
        clear(self.wish_box)
        if not rows:
            lab = QLabel("Your wishlist is empty. Search for a game above, press + Wishlist on a deal, or import your "
                         "Steam wishlist.")
            lab.setObjectName("dim"); lab.setWordWrap(True); self.wish_box.addWidget(lab)
        rows = sorted(rows, key=lambda w: (not (w["hit_target"] or w["hit_low"]), w["title"].lower()))
        for w in rows:
            self.wish_box.addWidget(self.wish_row(w))

    def wish_row(self, w):
        row = QFrame(); row.setObjectName("dealRow")
        h = QHBoxLayout(row); h.setContentsMargins(0, 8, 0, 8); h.setSpacing(12)
        img = QLabel(); img.setFixedSize(128, 48)
        self.covers.want(w.get("thumb"), img, 128, 48, w["title"], radius=6)
        h.addWidget(img)
        mid = QVBoxLayout(); mid.setSpacing(3)
        top = QHBoxLayout(); top.setSpacing(8)
        t = QLabel(w["title"]); t.setStyleSheet("font-weight:600;"); top.addWidget(t)
        if w["hit_low"]:
            top.addWidget(pill("Lowest price ever", "#cfb53b", "#101010"))
        if w["hit_target"]:
            top.addWidget(pill("Below your target", "#3ec46d", "#101010"))
        top.addStretch()
        mid.addLayout(top)
        b = w.get("best")
        parts = []
        if b:
            parts.append(f"Now ${b['price']:.2f} on {b['store']}" + (f" (-{b['discount']}%)" if b["discount"] else ""))
        else:
            parts.append("No price found right now")
        if w.get("low") is not None:
            when = time.strftime(" (%b %Y)", time.localtime(w["low_date"])) if w.get("low_date") else ""
            parts.append(f"lowest ever ${w['low']:.2f}{when}")
        s = QLabel("  ·  ".join(parts)); s.setObjectName("dim"); mid.addWidget(s)
        h.addLayout(mid, 1)
        tl = QLabel("Alert below"); tl.setObjectName("dim"); h.addWidget(tl)
        sp = QDoubleSpinBox(); sp.setPrefix("$"); sp.setRange(0, 999); sp.setDecimals(2); sp.setSingleStep(1)
        sp.setSpecialValueText("lowest ever"); sp.setValue(float(w.get("target") or 0)); sp.setFixedWidth(110)
        sp.setToolTip("Notify me when the price is at or below this. 'lowest ever' = only at the historical low.")
        sp.editingFinished.connect(lambda gid=w["id"], sp=sp: self.set_target(gid, sp.value()))
        h.addWidget(sp)
        if b:
            ob = QPushButton("Open"); ob.setObjectName("small"); ob.clicked.connect(lambda _=False, u=b["url"]: open_url(u))
            h.addWidget(ob)
        rb = QPushButton("Remove"); rb.setObjectName("small")
        rb.clicked.connect(lambda _=False, gid=w["id"]: self.remove_wish(gid))
        h.addWidget(rb)
        return row

    def set_target(self, gid, value):
        self.settings = dl.load_settings()
        dl.wishlist_set_target(gid, round(value, 2) if value > 0 else None, self.settings)

    def remove_wish(self, gid):
        self.settings = dl.load_settings()
        dl.wishlist_remove(gid, self.settings)
        self.refresh_wish()

    def refresh_wish(self):
        self.settings = dl.load_settings()
        s = dict(self.settings)

        def work():
            try:
                rows = dl.wishlist_prices(s)
            except Exception:  # noqa: BLE001
                rows = []
            data = dict(self.data or {}, wish=rows)
            self.bridge.searched.emit(("wish", data))
        threading.Thread(target=work, daemon=True).start()

    def do_search(self):
        q = self.search.text().strip()
        if len(q) < 2:
            return
        clear(self.search_box)
        lab = QLabel("Searching…"); lab.setObjectName("dim"); self.search_box.addWidget(lab)

        def work():
            try:
                res = dl.search_games(q)
            except Exception:  # noqa: BLE001
                res = None
            self.bridge.searched.emit(("search", res))
        threading.Thread(target=work, daemon=True).start()

    def show_search(self, payload):
        kind, res = payload
        if kind == "wish":
            self.data = res
            self.render_wish(res.get("wish", []))
            self.render_deals()
            return
        clear(self.search_box)
        if res is None:
            lab = QLabel("Search failed - no internet?"); lab.setObjectName("dim"); self.search_box.addWidget(lab)
            return
        if not res:
            lab = QLabel("Nothing found. Try a shorter name."); lab.setObjectName("dim"); self.search_box.addWidget(lab)
            return
        have = {str(w["id"]) for w in self.settings.get("wishlist", [])}
        for g in res[:8]:
            r = QHBoxLayout()
            name = QLabel(g["title"] + (f"   -  from ${g['cheapest']:.2f}" if g.get("cheapest") is not None else ""))
            b = QPushButton("Added" if g["id"] in have else "Add"); b.setObjectName("small"); b.setEnabled(g["id"] not in have)
            b.clicked.connect(lambda _=False, g=g, b=b: self.add_game(g, b))
            r.addWidget(name, 1); r.addWidget(b)
            w = QWidget(); w.setLayout(r); r.setContentsMargins(4, 0, 0, 0)
            self.search_box.addWidget(w)
        close = QPushButton("Close results"); close.setObjectName("small"); close.clicked.connect(lambda: clear(self.search_box))
        self.search_box.addWidget(close, 0, Qt.AlignRight)

    def add_game(self, g, btn):
        self.settings = dl.load_settings()
        dl.wishlist_add(g, settings=self.settings)
        btn.setText("Added"); btn.setEnabled(False)
        self.refresh_wish()

    def do_import(self):
        prof = self.profile.text().strip()
        if not prof:
            return
        self.imp_btn.setEnabled(False)
        self.imp_status.setText("Reading the Steam wishlist…")

        def work():
            try:
                added, missing = dl.steam_wishlist_import(
                    prof, progress=lambda n, tot: self.bridge.imported.emit(f"progress:Looking up prices {n}/{tot}…"))
                msg = f"Imported {added} game{'s' if added != 1 else ''}."
                if missing:
                    msg += f" {len(missing)} not sold in the stores CheapShark tracks (skipped)."
            except ValueError as e:
                msg = "error:" + str(e)
            except Exception as e:  # noqa: BLE001
                msg = f"error:Import failed ({e}). Check the internet connection."
            self.bridge.imported.emit(msg)
        threading.Thread(target=work, daemon=True).start()

    def import_done(self, msg):
        if msg.startswith("progress:"):
            self.imp_status.setText(msg[9:])
            return
        if msg == "added":
            self.refresh_wish()
            return
        self.imp_btn.setEnabled(True)
        self.imp_status.setText(msg[6:] if msg.startswith("error:") else msg)
        if not msg.startswith("error:"):
            self.refresh_wish()

    # ---------------------------------------------------------------- settings
    def _settings_card(self):
        s = self.settings
        card = self.Card("Notifications & settings")
        self.auto = QRadioButton("Automatic (recommended)")
        self.manual = QRadioButton("Manual - I choose")
        grp = QButtonGroup(card); grp.addButton(self.auto); grp.addButton(self.manual)
        (self.manual if s.get("mode") == "manual" else self.auto).setChecked(True)
        a = dl.AUTO
        auto_txt = QLabel(f"Tells you about every new free game and about wishlist price drops, checks every "
                          f"{a['interval_hours']} hours and right after you log in, never while a game is running, never "
                          f"twice about the same thing. Deals list: {a['min_discount']}%+ off, up to ${a['max_price']}, "
                          f"main stores, games you own hidden.")
        auto_txt.setWordWrap(True); auto_txt.setObjectName("dim"); auto_txt.setContentsMargins(26, 0, 0, 6)
        card.lay.addWidget(self.auto); card.lay.addWidget(auto_txt); card.lay.addWidget(self.manual)

        self.man = QWidget(); g = QGridLayout(self.man); g.setContentsMargins(26, 0, 0, 0)
        g.setHorizontalSpacing(14); g.setVerticalSpacing(8)
        self.c_notify = QCheckBox("Notifications on"); self.c_free = QCheckBox("New free games")
        self.c_wish = QCheckBox("Wishlist price drops"); self.c_deals = QCheckBox("Any deal that matches my filters")
        self.c_owned = QCheckBox("Hide games I already own (Steam / Heroic on this PC)")
        for c, k in ((self.c_notify, "notify"), (self.c_free, "notify_free"), (self.c_wish, "notify_wishlist"),
                     (self.c_deals, "notify_deals"), (self.c_owned, "hide_owned")):
            c.setChecked(bool(s.get(k)))
        g.addWidget(self.c_notify, 0, 0); g.addWidget(self.c_free, 0, 1); g.addWidget(self.c_wish, 0, 2)
        g.addWidget(self.c_deals, 1, 1, 1, 2); g.addWidget(self.c_owned, 2, 0, 1, 3)
        g.addWidget(QLabel("Minimum discount"), 3, 0)
        self.s_disc = QSpinBox(); self.s_disc.setRange(0, 100); self.s_disc.setSuffix(" %"); self.s_disc.setValue(int(s["min_discount"]))
        g.addWidget(self.s_disc, 3, 1)
        g.addWidget(QLabel("Maximum price"), 4, 0)
        self.s_price = QSpinBox(); self.s_price.setRange(0, 200); self.s_price.setPrefix("$"); self.s_price.setSpecialValueText("no limit")
        self.s_price.setValue(int(float(s["max_price"] or 0))); g.addWidget(self.s_price, 4, 1)
        g.addWidget(QLabel("Check every"), 5, 0)
        self.s_int = QComboBox()
        for hrs in (1, 3, 6, 12, 24):
            self.s_int.addItem(f"{hrs} hour{'s' if hrs > 1 else ''}", hrs)
        self.s_int.setCurrentIndex(max(0, self.s_int.findData(int(s.get("interval_hours") or 6))))
        g.addWidget(self.s_int, 5, 1)
        g.addWidget(QLabel("Epic free games for country"), 6, 0)
        self.s_country = QLineEdit(s.get("country") or "GE"); self.s_country.setMaxLength(2); self.s_country.setFixedWidth(60)
        self.s_country.setToolTip("Two-letter country code (GE, US, DE…) - Epic's free games can differ by country.")
        g.addWidget(self.s_country, 6, 1)
        st = QLabel("Stores in the deals list"); st.setStyleSheet("font-weight:600;"); g.addWidget(st, 7, 0, 1, 3)
        self.store_checks = {}
        sg = QGridLayout(); sg.setHorizontalSpacing(14)
        stores = dl.active_stores()
        chosen = {str(x) for x in s.get("stores") or dl.DEFAULT_STORES}
        for i, (sid, name) in enumerate(stores):
            c = QCheckBox(name); c.setChecked(sid in chosen); self.store_checks[sid] = c
            sg.addWidget(c, i // 4, i % 4)
            c.toggled.connect(self.settings_changed)
        g.addLayout(sg, 8, 0, 1, 4)
        for w in (self.s_disc, self.s_price, self.s_int):
            w.setFixedWidth(130)
        g.setColumnStretch(3, 1)
        card.lay.addWidget(self.man)
        self.saved = QLabel(""); self.saved.setObjectName("dim"); card.lay.addWidget(self.saved)

        for w in (self.c_notify, self.c_free, self.c_wish, self.c_deals, self.c_owned, self.auto, self.manual):
            w.toggled.connect(self.settings_changed)
        self.s_disc.valueChanged.connect(self.settings_changed)
        self.s_price.valueChanged.connect(self.settings_changed)
        self.s_int.currentIndexChanged.connect(self.settings_changed)
        self.s_country.editingFinished.connect(self.settings_changed)
        self.save_timer = QTimer(self); self.save_timer.setSingleShot(True); self.save_timer.setInterval(800)
        self.save_timer.timeout.connect(self.save)
        self.man.setEnabled(self.manual.isChecked())
        return card

    def settings_changed(self, *_a):
        self.man.setEnabled(self.manual.isChecked())
        self.save_timer.start()

    def save(self):
        s = dl.load_settings()  # keep the wishlist that other parts may have changed
        s.update(mode="manual" if self.manual.isChecked() else "auto",
                 notify=self.c_notify.isChecked(), notify_free=self.c_free.isChecked(),
                 notify_wishlist=self.c_wish.isChecked(), notify_deals=self.c_deals.isChecked(),
                 hide_owned=self.c_owned.isChecked(), min_discount=self.s_disc.value(), max_price=self.s_price.value(),
                 interval_hours=self.s_int.currentData(),
                 country=(self.s_country.text().strip().upper() or "GE")[:2],
                 stores=[sid for sid, c in self.store_checks.items() if c.isChecked()] or dl.DEFAULT_STORES)
        filters_changed = any(s.get(k) != self.settings.get(k)
                              for k in ("mode", "min_discount", "max_price", "stores", "hide_owned", "country"))
        dl.save_settings(s)
        self.settings = s
        threading.Thread(target=dl.apply_timer, args=(dict(s),), daemon=True).start()
        self.saved.setText("Saved.")
        if filters_changed:
            self.reload()


def build(center):
    return DealsPage(center)


STANDALONE_QSS = """
    QWidget {{ font-size: 13px; }}
    #h1 {{ font-size: 26px; font-weight: 700; }}
    #dim {{ color: palette(placeholder-text); }}
    #card {{ background: palette(alternate-base); border-radius: 14px; border: 1px solid {acc}22; }}
    #cardTitle {{ font-size: 15px; font-weight: 600; }}
    QPushButton {{ padding: 8px 16px; border-radius: 10px; }}
    QPushButton#primary {{ background: {acc}; color: #1a0b06; font-weight: 600; border: none; }}
"""


def main():
    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("PhoenixGe Deals")
    app.setDesktopFileName("phoenixge-deals")
    win = QWidget()
    win.setWindowTitle("PhoenixGe Deals")
    if os.path.exists(APP_ICON):
        win.setWindowIcon(QIcon(APP_ICON))
    win.setStyleSheet(STANDALONE_QSS.format(acc=_accent()))
    lay = QVBoxLayout(win); lay.setContentsMargins(0, 0, 0, 0)
    lay.addWidget(build(None))
    win.resize(1100, 820)
    win.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
