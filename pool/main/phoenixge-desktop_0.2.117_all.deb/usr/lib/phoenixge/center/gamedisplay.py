"""PhoenixGe Center > Display & performance: HDR / wide colors / SDR brightness and VRR per screen, tearing for the lowest
latency, NVIDIA checks, HDR + upscaling (FSR / NIS / pixel / integer) per game, and the sched_ext gaming scheduler.

build(center) -> QWidget        python3 gamedisplay.py [--demo]   (alone, for testing / screenshots)
Logic lives in /usr/lib/phoenixge/gamedisplay/ (displays.py, profiles.py, scx.py + root helpers).
"""
import os
import sys
from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import (QButtonGroup, QCheckBox, QComboBox, QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit,
                               QMessageBox, QPushButton, QRadioButton, QSlider, QVBoxLayout, QWidget)

sys.path.insert(0, str(Path(__file__).resolve().parent))
from systools_ui import DEMO, GREEN, GREY, RED, YELLOW, accent, dim, dot, ui  # noqa: E402

LIB = Path(__file__).resolve().parent.parent / "gamedisplay"
if not LIB.is_dir():
    LIB = Path("/usr/lib/phoenixge/gamedisplay")
sys.path.insert(0, str(LIB))
import displays as dp  # noqa: E402
import profiles as pf  # noqa: E402
import scx  # noqa: E402

APT_INSTALL = "/usr/lib/phoenixge/apt-install.sh"
NV_HELPER = str(LIB / "nvidia-modeset.sh")
GPU_NAMES = {"i915": "Intel", "xe": "Intel", "amdgpu": "AMD", "radeon": "AMD", "nvidia": "NVIDIA", "nouveau": "NVIDIA (nouveau)"}
RENDER_PRESETS = ["640x360", "960x540", "1280x720", "1600x900", "1920x1080", "2560x1440"]
HDR_LABELS = [("off", "Off"), ("gamescope", "gamescope HDR (most reliable)"), ("proton", "Proton Wayland HDR (GE-Proton 10+)")]
UP_LABELS = [("off", "Off - native resolution"), ("fsr", "AMD FSR 1 (gamescope)"), ("nis", "NVIDIA NIS (gamescope)"),
             ("pixel", "Pixel art - smooth (gamescope)"), ("integer", "Pixel art - integer, sharp pixels (gamescope)"),
             ("wine-fsr", "GE-Proton fullscreen FSR (no gamescope)")]


def chip(text, color):
    w = QWidget(); h = QHBoxLayout(w); h.setContentsMargins(10, 4, 12, 4); h.setSpacing(6)
    h.addWidget(dot(color, 9)); lab = QLabel(text); h.addWidget(lab)
    w.setObjectName("chip"); w.setStyleSheet("#chip { border: 1px solid palette(mid); border-radius: 12px; }")
    return w


def hline():
    f = QFrame(); f.setFrameShape(QFrame.HLine); f.setStyleSheet("color: palette(mid);")
    return f


def bold(text, size=None):
    x = QLabel(text); x.setWordWrap(True)
    x.setStyleSheet("font-weight:600;" + (f"font-size:{size}px;" if size else ""))
    return x


def clear(layout):
    while layout.count():
        it = layout.takeAt(0)
        if it.widget():
            it.widget().deleteLater()
        elif it.layout():
            clear(it.layout())


def gpu_label(drv):
    return GPU_NAMES.get(drv, drv or "?")


def short_ops(ops):
    """'lavd_1.0.19_g1c2d…' -> 'scx_lavd 1.0.19'"""
    if not ops:
        return "a sched_ext scheduler"
    parts = ops.split("_")
    return f"scx_{parts[0]}" + (f" {parts[1]}" if len(parts) > 1 and parts[1][:1].isdigit() else "")


def ge_proton_versions():
    out = []
    for d in (Path.home() / ".steam/root/compatibilitytools.d", Path.home() / ".local/share/Steam/compatibilitytools.d",
              Path.home() / ".var/app/com.valvesoftware.Steam/.local/share/Steam/compatibilitytools.d"):
        out += [p.name for p in d.glob("GE-Proton*") if p.is_dir()]
    return sorted(set(out))


class DisplayPage(QWidget):
    def __init__(self, center):
        super().__init__()
        self.center = center
        self.acc = accent()
        Card, page, _ = ui(center)
        self.Card = Card
        w, lay = page("Display & performance", "HDR, adaptive sync (FreeSync / G-Sync), upscaling per game and the gaming "
                                               "CPU scheduler. Automatic settings are on by default - change anything here.")
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0); outer.addWidget(w)
        self.lay = lay

        self.summary = Card(); lay.addWidget(self.summary)
        self.screens = Card("Screens", "Changes apply right away (same as System Settings > Display).")
        self.sbox = QVBoxLayout(); self.sbox.setSpacing(10); self.screens.lay.addLayout(self.sbox)
        lay.addWidget(self.screens)
        self.latency = Card("Lowest input latency"); lay.addWidget(self.latency)
        self.nvidia = Card("NVIDIA"); lay.addWidget(self.nvidia)
        self.hdrgames = Card("HDR in games - what works here"); lay.addWidget(self.hdrgames)
        self.games = Card("Per-game profiles", "HDR and upscaling for one game. Steam: paste the launch option into "
                                               "the game's Properties > Launch options. Games started from Phoenix Games "
                                               "get it automatically.")
        lay.addWidget(self.games)
        self.sched = Card("Gaming CPU scheduler (sched_ext)"); lay.addWidget(self.sched)
        lay.addStretch()

        self.shown_once = False
        self.d, self.native = {}, (1920, 1080, 60.0)
        self.game_list, self.profiles, self.cur_game = [], {}, None
        self._loading = False
        self.build_latency()
        self.build_games()
        if DEMO:
            self.refresh()

    def showEvent(self, e):
        super().showEvent(e)
        if not self.shown_once:
            self.shown_once = True
            if not DEMO:
                QTimer.singleShot(0, self.refresh)

    # ---------------------------------------------------------------- data
    def data(self):
        if DEMO:
            return dict(screens=dp.DEMO_SCREENS, err="", gpus=dp.DEMO_GPUS, nv=dp.DEMO_NVIDIA, kernel=scx.DEMO["kernel"],
                        session="wayland", gamescope=True, layer=False, ge=["GE-Proton10-25"])
        scr, err = dp.outputs()
        return dict(screens=scr, err=err, gpus=dp.gpus(), nv=dp.nvidia_info(), kernel=os.uname().release,
                    session=dp.session_type(), gamescope=bool(pf.gamescope_path()), layer=pf.hdr_layer_installed(),
                    ge=ge_proton_versions())

    def refresh(self):
        self.d = self.data()
        self._scx = self.scx_info()
        self.build_summary(); self.build_screens(); self.build_nvidia(); self.build_hdrgames(); self.build_sched()
        self.load_games()

    def run(self, args, done=None):
        if DEMO:
            return
        self.center.runner.run("kscreen-doctor", args, done)

    # ---------------------------------------------------------------- summary
    def build_summary(self):
        clear(self.summary.lay)
        d = self.d
        gp = " + ".join(gpu_label(g["driver"]) if g["driver"] else g["vendor"] for g in d["gpus"]) or "unknown"
        row = QHBoxLayout(); row.setSpacing(8)
        t = QVBoxLayout(); t.setSpacing(2)
        t.addWidget(bold(f"Graphics: {gp}", 15))
        nvs = f" · NVIDIA driver {d['nv']['version']}" if d["nv"] else ""
        t.addWidget(dim(f"Kernel {d['kernel']} · {'Wayland' if d['session'] != 'x11' else 'X11'} session{nvs}"))
        row.addLayout(t, 1)
        ref = QPushButton("Refresh"); ref.clicked.connect(self.refresh); row.addWidget(ref, 0, Qt.AlignTop)
        self.summary.lay.addLayout(row)
        chips = QHBoxLayout(); chips.setSpacing(8)
        scr = d["screens"]
        hdr_on = [s for s in scr if s["hdr"]]
        hdr_cap = [s for s in scr if s["hdr_capable"]]
        vrr_cap = [s for s in scr if s["vrr_capable"]]
        chips.addWidget(chip(f"HDR on {', '.join(s['name'] for s in hdr_on)}" if hdr_on else
                             ("HDR available, off" if hdr_cap else "No HDR screen"), GREEN if hdr_on else YELLOW if hdr_cap else GREY))
        chips.addWidget(chip(f"VRR {vrr_cap[0]['vrr']}" if vrr_cap else "No VRR screen",
                             GREEN if vrr_cap and vrr_cap[0]["vrr"] != "never" else GREY))
        st = self.scx_state()
        chips.addWidget(chip(st[0], st[1]))
        chips.addStretch()
        self.summary.lay.addLayout(chips)

    # ---------------------------------------------------------------- screens
    def build_screens(self):
        clear(self.sbox)
        d = self.d
        if d["err"] or not d["screens"]:
            self.sbox.addWidget(dim(d["err"] or "No screens found.")); return
        for i, s in enumerate(d["screens"]):
            if i:
                self.sbox.addWidget(hline())
            self.sbox.addWidget(self.screen_box(s))

    def screen_box(self, s):
        w = QWidget(); g = QGridLayout(w); g.setContentsMargins(0, 4, 0, 4); g.setHorizontalSpacing(14); g.setVerticalSpacing(8)
        kind = "Laptop screen" if s["internal"] else "Monitor"
        head = bold(f"{kind}  {s['name']}", 14)
        info = dim(f"{s['width']}×{s['height']} @ {s['hz']:.0f} Hz" + (f" (max {s['maxhz']:.0f} Hz)" if s["maxhz"] > s["hz"] + 1 else "")
                   + f" · {gpu_label(s['gpu'])} graphics" + ("" if s["enabled"] else " · turned off"))
        g.addWidget(head, 0, 0, 1, 3); g.addWidget(info, 1, 0, 1, 3)
        name = s["name"]
        # HDR
        g.addWidget(QLabel("HDR"), 2, 0, Qt.AlignTop)
        if s["hdr_capable"]:
            box = QVBoxLayout(); box.setSpacing(6)
            r1 = QHBoxLayout(); r1.setSpacing(16)
            hdr = QCheckBox("HDR"); hdr.setChecked(s["hdr"])
            wcg = QCheckBox("Wide colors"); wcg.setChecked(s["wcg"]); wcg.setEnabled(s["wcg_capable"] and not s["hdr"])
            wcg.setToolTip("Rec. 2020 colors without HDR. HDR always uses wide colors.")
            r1.addWidget(hdr); r1.addWidget(wcg); r1.addStretch(); box.addLayout(r1)
            r2 = QHBoxLayout()
            lab = QLabel("Desktop brightness in HDR"); lab.setObjectName("dim")
            sl = QSlider(Qt.Horizontal); sl.setRange(80, 600); sl.setSingleStep(10); sl.setPageStep(40)
            sl.setValue(s["sdr_brightness"]); sl.setEnabled(s["hdr"]); sl.setMaximumWidth(320)
            val = QLabel(f"{s['sdr_brightness']} nits"); val.setMinimumWidth(70)
            sl.valueChanged.connect(lambda v, x=val: x.setText(f"{v} nits"))
            sl.sliderReleased.connect(lambda n=name, x=sl: self.run(dp.set_args(n, "sdr-brightness", x.value())))
            r2.addWidget(lab); r2.addWidget(sl, 1); r2.addWidget(val); r2.addStretch(); box.addLayout(r2)

            def on_hdr(on, n=name, slider=sl, wc=wcg):
                slider.setEnabled(on); wc.setEnabled(not on and s["wcg_capable"])
                self.run(dp.set_args(n, "hdr", on), lambda _c: QTimer.singleShot(400, self.refresh))
            hdr.toggled.connect(on_hdr)
            wcg.toggled.connect(lambda on, n=name: self.run(dp.set_args(n, "wcg", on)))
            box.addWidget(dim("Desktop brightness = how bright normal (SDR) windows look while HDR is on. "
                              "200-300 nits suits most HDR monitors."))
            g.addLayout(box, 2, 1, 1, 2)
        else:
            nv = self.d["nv"]
            if s["gpu"] == "nvidia" and nv and not nv["hdr_native"] and not nv["optin"]:
                why = ("Hidden by KWin: NVIDIA drivers older than 565.57 had HDR bugs, so Plasma does not offer HDR on "
                       "screens wired to the NVIDIA card. See the NVIDIA card below to try it anyway.")
            elif s["internal"]:
                why = "This laptop screen does not report HDR (most laptop panels are SDR)."
            else:
                why = "This screen (or its cable / port) does not report HDR support."
            g.addWidget(dim(why), 2, 1, 1, 2)
        # VRR
        g.addWidget(QLabel("Adaptive sync"), 3, 0, Qt.AlignTop)
        if s["vrr_capable"]:
            cb = QComboBox()
            for key, text in (("automatic", "Automatic - only for fullscreen games (recommended)"),
                              ("always", "Always on"), ("never", "Never")):
                cb.addItem(text, key)
            cb.setCurrentIndex(max(0, cb.findData(s["vrr"])))
            cb.currentIndexChanged.connect(lambda _i, n=name, c=cb: self.run(dp.set_args(n, "vrr", c.currentData())))
            g.addWidget(cb, 3, 1)
            g.addWidget(dim("FreeSync / G-Sync compatible: no tearing and no vsync stutter when FPS drops below "
                            f"{s['maxhz']:.0f} Hz."), 4, 1, 1, 2)
        else:
            g.addWidget(dim("Not supported by this screen or connection (VRR needs DisplayPort, or HDMI 2.1 VRR)."), 3, 1, 1, 2)
        g.setColumnStretch(2, 1); g.setColumnMinimumWidth(0, 110)
        return w

    # ---------------------------------------------------------------- latency
    def build_latency(self):
        c = self.latency
        self.tear = QCheckBox("Allow tearing in fullscreen games")
        self.tear.setChecked(True if DEMO else dp.tearing_allowed())
        self.tear.toggled.connect(lambda on: None if DEMO else dp.set_tearing(on))
        c.lay.addWidget(self.tear)
        c.lay.addWidget(dim("When a fullscreen game turns V-Sync off, its frames go to the screen immediately - lowest "
                            "input lag, with possible tearing lines. Games with V-Sync on are not affected. Works with "
                            "drivers that support async page flips (Intel and AMD on current kernels; NVIDIA depends on "
                            "the driver - KWin quietly falls back to normal sync when it can't). On by default."))

    # ---------------------------------------------------------------- NVIDIA
    def build_nvidia(self):
        c = self.nvidia
        while c.lay.count() > 1:
            it = c.lay.takeAt(1)
            if it.widget():
                it.widget().deleteLater()
            elif it.layout():
                clear(it.layout())
        nv = self.d["nv"]
        c.setVisible(bool(nv))
        if not nv:
            return
        r = QHBoxLayout(); r.setSpacing(10)
        ok = nv["modeset"]
        r.addWidget(dot(GREEN if ok else RED if ok is False else GREY))
        r.addWidget(QLabel("Kernel modesetting (nvidia-drm.modeset=1): " +
                           ("on" if ok else "OFF - Wayland, VRR and HDR cannot use the NVIDIA card" if ok is False
                            else "driver not loaded")), 1)
        if ok is False:
            b = QPushButton("Turn on"); b.setObjectName("primary")
            b.clicked.connect(lambda: self.center.runner.root(NV_HELPER, ["on"]))
            r.addWidget(b)
        c.lay.addLayout(r)
        r2 = QHBoxLayout(); r2.setSpacing(10)
        r2.addWidget(dot(GREEN if nv["hdr_native"] else YELLOW))
        r2.addWidget(QLabel(f"Driver {nv['version']}: " + ("HDR supported by Plasma." if nv["hdr_native"] else
                            "Plasma hides HDR for NVIDIA drivers older than 565.57 (Debian 13 ships 550).")), 1)
        c.lay.addLayout(r2)
        if not nv["hdr_native"]:
            opt = QCheckBox("Show HDR on NVIDIA screens anyway (experimental, takes effect after logging in again)")
            opt.setChecked(nv["optin"])
            opt.toggled.connect(lambda on: None if DEMO else dp.set_nvidia_hdr_optin(on))
            c.lay.addWidget(opt)
            c.lay.addWidget(dim("Sets KWIN_DRM_ALLOW_NVIDIA_COLORSPACE=1 for your session. Known problems with 550: "
                                "black screen after login if HDR was left on, washed-out colors. If that happens, switch "
                                "to the laptop screen (or another TTY) and untick this. Laptop screens are driven by the "
                                "Intel chip, so this only matters for monitors on the NVIDIA ports (usually HDMI / USB-C)."))

    # ---------------------------------------------------------------- HDR in games
    def build_hdrgames(self):
        c = self.hdrgames
        while c.lay.count() > 1:
            it = c.lay.takeAt(1)
            if it.widget():
                it.widget().deleteLater()
            elif it.layout():
                clear(it.layout())
        d = self.d
        g = QGridLayout(); g.setHorizontalSpacing(12); g.setVerticalSpacing(8)
        rows = []
        rows.append((GREEN if d["gamescope"] else YELLOW, "gamescope HDR",
                     ("Installed. " if d["gamescope"] else "Not installed (Debian backports, ~2 MB). ") +
                     "Runs the game in Valve's gamescope inside Plasma with --hdr-enabled; DXVK games (most Windows "
                     "games) and native Vulkan games can output HDR. Also does FSR / NIS / integer scaling.",
                     None if d["gamescope"] else ("Install gamescope", lambda: self.center.runner.root(APT_INSTALL, ["-b", "gamescope"]))))
        ge = d["ge"]
        ge10 = [v for v in ge if v.startswith("GE-Proton1")]
        rows.append((GREEN if ge10 and d["layer"] else YELLOW if ge10 else GREY, "Proton Wayland HDR",
                     (f"{ge10[-1]} found. " if ge10 else "Needs GE-Proton 10 or newer (Gaming page > GE-Proton). ") +
                     "Wine draws straight to Wayland: PROTON_ENABLE_WAYLAND=1 PROTON_ENABLE_HDR=1. On Plasma 6.3 with "
                     "Mesa 25.0 or NVIDIA 550 the game only sees HDR through the vk-hdr-layer Vulkan layer, which is "
                     + ("installed." if d["layer"] else "not in Debian (build it from github.com/Zamundaaa/VK_hdr_layer). "
                                                       "Without it the game starts in SDR."), None))
        rows.append((GREY, "Steam's own HDR",
                     "Big Picture / Steam Deck style HDR is gamescope too - use the gamescope option here.", None))
        for i, (col, title, text, btn) in enumerate(rows):
            g.addWidget(dot(col), i, 0, Qt.AlignTop | Qt.AlignHCenter)
            v = QVBoxLayout(); v.setSpacing(1); v.addWidget(bold(title)); v.addWidget(dim(text))
            g.addLayout(v, i, 1)
            if btn:
                b = QPushButton(btn[0]); b.clicked.connect(btn[1]); g.addWidget(b, i, 2, Qt.AlignTop)
        g.setColumnStretch(1, 1)
        c.lay.addLayout(g)
        c.lay.addWidget(dim("Honest status: HDR in games on Linux works best on AMD/Intel graphics with gamescope. On "
                            "NVIDIA 550 it is hit-and-miss (some games show black or freeze). Turn HDR on for the screen "
                            "first, then in the game's own settings."))

    # ---------------------------------------------------------------- per-game profiles
    def build_games(self):
        c = self.games
        top = QHBoxLayout(); top.setSpacing(10)
        top.addWidget(QLabel("Game"))
        self.gcombo = QComboBox(); self.gcombo.setMinimumWidth(320); self.gcombo.setMaxVisibleItems(20)
        self.gcombo.currentIndexChanged.connect(self.pick_game)
        top.addWidget(self.gcombo, 1)
        self.gsaved = QLabel(""); self.gsaved.setObjectName("dim"); top.addWidget(self.gsaved)
        c.lay.addLayout(top)

        f = QGridLayout(); f.setHorizontalSpacing(14); f.setVerticalSpacing(8)
        self.hdr_cb = QComboBox()
        for k, t in HDR_LABELS:
            self.hdr_cb.addItem(t, k)
        self.up_cb = QComboBox()
        for k, t in UP_LABELS:
            self.up_cb.addItem(t, k)
        self.render_cb = QComboBox(); self.render_cb.setEditable(True); self.render_cb.addItems(RENDER_PRESETS)
        self.out_cb = QComboBox(); self.out_cb.setEditable(True); self.out_cb.addItem("native")
        self.sharp = QSlider(Qt.Horizontal); self.sharp.setRange(0, 20); self.sharp.setMaximumWidth(260)
        self.sharp_l = QLabel(); self.sharp_l.setMinimumWidth(110)
        self.full = QCheckBox("Fullscreen"); self.full.setChecked(True)
        f.addWidget(QLabel("HDR"), 0, 0); f.addWidget(self.hdr_cb, 0, 1)
        f.addWidget(QLabel("Upscaling"), 1, 0); f.addWidget(self.up_cb, 1, 1)
        rr = QHBoxLayout(); rr.addWidget(self.render_cb); rr.addWidget(QLabel("→")); rr.addWidget(self.out_cb); rr.addStretch()
        f.addWidget(QLabel("Game renders at"), 2, 0); f.addLayout(rr, 2, 1)
        sr = QHBoxLayout(); sr.addWidget(self.sharp, 1); sr.addWidget(self.sharp_l); sr.addWidget(self.full); sr.addStretch()
        f.addWidget(QLabel("Sharpness"), 3, 0); f.addLayout(sr, 3, 1)
        f.setColumnStretch(1, 1); f.setColumnMinimumWidth(0, 120)
        c.lay.addLayout(f)
        self.hint = dim(""); c.lay.addWidget(self.hint)

        lo = QHBoxLayout(); lo.setSpacing(8)
        self.opt = QLabel(); self.opt.setWordWrap(True); self.opt.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.opt.setStyleSheet("font-family: monospace; padding: 8px 10px; background: palette(base); border-radius: 8px;")
        self.copy_b = QPushButton("Copy Steam launch option"); self.copy_b.clicked.connect(self.copy_opt)
        lo.addWidget(self.opt, 1); lo.addWidget(self.copy_b, 0, Qt.AlignTop)
        c.lay.addLayout(lo)
        br = QHBoxLayout()
        self.save_b = QPushButton("Save profile"); self.save_b.setObjectName("primary"); self.save_b.clicked.connect(self.save_game)
        self.del_b = QPushButton("Reset to normal"); self.del_b.clicked.connect(self.reset_game)
        self.saved_list = dim("")
        br.addWidget(self.save_b); br.addWidget(self.del_b); br.addSpacing(12); br.addWidget(self.saved_list, 1)
        c.lay.addLayout(br)
        for wdg in (self.hdr_cb, self.up_cb):
            wdg.currentIndexChanged.connect(self.update_opt)
        for wdg in (self.render_cb, self.out_cb):
            wdg.currentTextChanged.connect(self.update_opt)
        self.sharp.valueChanged.connect(self.update_opt)
        self.full.toggled.connect(self.update_opt)

    def load_games(self):
        self.profiles = dict(pf.DEMO_PROFILES) if DEMO else pf.load_all()
        self.game_list = list(pf.DEMO_GAMES) if DEMO else pf.list_games()
        self.native = (self.d["screens"][0]["width"], self.d["screens"][0]["height"], self.d["screens"][0]["hz"]) \
            if self.d["screens"] and self.d["screens"][0]["width"] else (1920, 1080, 60.0)
        nw, nh, _ = self.native
        self._loading = True
        self.out_cb.clear(); self.out_cb.addItem("native")
        self.out_cb.addItems([r for r in RENDER_PRESETS if int(r.split("x")[0]) <= nw][::-1][:3])
        keep = self.cur_game or (next(iter(self.profiles), None))
        self.gcombo.clear()
        for g in self.game_list:
            mark = "  ★" if g["id"] in self.profiles else ""
            self.gcombo.addItem(f"{g['name']}  ·  {g['source']}{mark}", g["id"])
        if not self.game_list:
            self.gcombo.addItem("No games found - install some with Steam / Heroic first", None)
        self._loading = False
        i = self.gcombo.findData(keep) if keep else 0
        self.gcombo.setCurrentIndex(max(0, i))
        self.pick_game()
        self.update_saved_list()

    def update_saved_list(self):
        names = [self.profiles[k].get("name") or k for k in self.profiles]
        self.saved_list.setText(("Saved: " + ", ".join(names)) if names else "No game profiles yet.")

    def pick_game(self, *_):
        if self._loading:
            return
        gid = self.gcombo.currentData()
        self.cur_game = gid
        p = self.profiles.get(gid) or dict(pf.DEFAULT)
        self._loading = True
        self.hdr_cb.setCurrentIndex(max(0, self.hdr_cb.findData(p["hdr"])))
        self.up_cb.setCurrentIndex(max(0, self.up_cb.findData(p["upscale"])))
        self.render_cb.setCurrentText(p["render"])
        self.out_cb.setCurrentText(p["output"])
        self.sharp.setValue(int(p["strength"] if p["upscale"] == "wine-fsr" else p["sharpness"]))
        self.full.setChecked(bool(p["fullscreen"]))
        self._loading = False
        self.gsaved.setText("profile saved" if gid in self.profiles else "")
        self.save_b.setEnabled(gid is not None); self.del_b.setEnabled(gid in self.profiles)
        self.update_opt()

    def current_profile(self):
        name = next((g["name"] for g in self.game_list if g["id"] == self.cur_game), "")
        up = self.up_cb.currentData()
        p = dict(pf.DEFAULT, name=name, hdr=self.hdr_cb.currentData(), upscale=up,
                 render=self.render_cb.currentText().strip().replace("×", "x"),
                 output=self.out_cb.currentText().strip().replace("×", "x") or "native", fullscreen=self.full.isChecked())
        if up == "wine-fsr":
            p["strength"] = min(5, self.sharp.value())
        else:
            p["sharpness"] = self.sharp.value()
        old = self.profiles.get(self.cur_game) or {}
        p["refresh"] = old.get("refresh", 0)
        return p

    def update_opt(self, *_):
        if self._loading:
            return
        up = self.up_cb.currentData(); hdr = self.hdr_cb.currentData()
        wine = up == "wine-fsr"
        self._loading = True
        self.sharp.setRange(0, 5 if wine else 20)
        self._loading = False
        self.sharp.setEnabled(up in ("fsr", "nis", "wine-fsr"))
        v = self.sharp.value()
        self.sharp_l.setText(f"{v} ({'sharpest' if v == 0 else 'softer' if v > (2 if wine else 8) else 'sharp'})")
        scaled = up in ("fsr", "nis", "pixel", "integer")
        self.render_cb.setEnabled(scaled); self.out_cb.setEnabled(scaled or hdr == "gamescope")
        p = self.current_profile()
        self.opt_text = pf.launch_option(p, self.native)
        plain = pf.is_default(p) or self.opt_text == "%command%"
        self.opt.setText("Nothing to add - this game runs normally." if plain else self.opt_text)
        self.copy_b.setEnabled(not plain)
        hints = []
        if pf.uses_gamescope(p) and not self.d.get("gamescope"):
            hints.append("gamescope is not installed yet - see \"HDR in games\" above.")
        if hdr == "proton" and up == "wine-fsr":
            hints.append("GE-Proton fullscreen FSR only works on the X11 path - it is left out while Proton Wayland HDR is on.")
        if hdr == "proton" and not self.d.get("layer"):
            hints.append("Without vk-hdr-layer the game will start in SDR on this Plasma version.")
        if up == "integer":
            hints.append("Integer: the picture is scaled by whole numbers (2×, 3×) - perfectly sharp pixels, black borders if "
                         "it doesn't fit exactly. Best for pixel-art games at 640×360 or 1280×720.")
        elif up in ("fsr", "nis"):
            hints.append("The game renders at the lower resolution and is upscaled to the screen - more FPS. Pick the "
                         "same resolution in the game's own settings.")
        elif up == "wine-fsr":
            hints.append("Set the game to fullscreen at a resolution lower than your screen; GE-Proton upscales it with FSR 1. "
                         "Not every GE-Proton build still includes this - gamescope FSR always works.")
        if self.d.get("nv") and pf.uses_gamescope(p):
            hints.append("NVIDIA 550 + gamescope: works in many games, but some show a black window - then use Off.")
        if self.cur_game and str(self.cur_game).startswith("heroic:"):
            hints.append("Heroic: game Settings > Advanced > Environment variables and Wrapper (gamescope …).")
        self.hint.setText(chr(10).join("• " + h for h in hints))
        self.hint.setVisible(bool(hints))

    def copy_opt(self):
        QGuiApplication.clipboard().setText(self.opt_text)
        self.gsaved.setText("copied - paste into Steam > Properties > Launch options")

    def save_game(self):
        if not self.cur_game:
            return
        p = self.current_profile()
        if pf.is_default(p):
            return self.reset_game()
        if not DEMO:
            try:
                pf.save(self.cur_game, p)
            except OSError as e:
                QMessageBox.warning(self, "Save profile", str(e)); return
        self.profiles[self.cur_game] = p
        self.load_games()
        self.gsaved.setText("profile saved")

    def reset_game(self):
        if not self.cur_game:
            return
        if not DEMO:
            pf.save(self.cur_game, None)
        self.profiles.pop(self.cur_game, None)
        self.load_games()

    # ---------------------------------------------------------------- scheduler
    def scx_info(self):
        if DEMO:
            x = scx.DEMO
            return dict(support=x["support"], scheds=x["scheds"], status=x["status"], conf=x["conf"], apt=x["apt"],
                        kernel=x["kernel"])
        return dict(support=scx.kernel_support(), scheds=scx.schedulers(), status=scx.status(), conf=scx.load_conf(),
                    apt=scx.apt_candidate() if not scx.schedulers() else "", kernel=scx.kernel_release())

    def scx_state(self):
        i = self._scx
        if not i["support"]:
            return "Scheduler: kernel has no sched_ext", GREY
        if i["status"]["state"] == "enabled":
            return f"Scheduler: {short_ops(i['status']['ops'])} running", GREEN
        if not i["scheds"]:
            return "Scheduler: not installed", GREY
        return f"Scheduler: {i['conf']['MODE']}", YELLOW if i["conf"]["MODE"] == "off" else GREEN

    def build_sched(self):
        c = self.sched
        while c.lay.count() > 1:
            it = c.lay.takeAt(1)
            if it.widget():
                it.widget().deleteLater()
            elif it.layout():
                clear(it.layout())
        i = self._scx
        c.lay.addWidget(dim("sched_ext lets the kernel load a CPU scheduler made for games. scx_lavd (made for the Steam "
                            "Deck) keeps a game's frame-critical threads on time: steadier frame times and better 1% lows "
                            "when the CPU is busy. If it ever crashes, Linux switches back to its normal scheduler by itself."))
        st = i["status"]
        r = QHBoxLayout(); r.setSpacing(10)
        if not i["support"]:
            r.addWidget(dot(GREY))
            r.addWidget(QLabel(f"Not available with this kernel ({i['kernel']}): Debian 13's standard 6.12 kernel is built "
                               "without sched_ext. The PhoenixGe gaming kernel (Gaming page, Debian backports 6.16+) has it."), 1)
            r.itemAt(1).widget().setWordWrap(True)
            c.lay.addLayout(r)
            return
        on = st["state"] == "enabled"
        r.addWidget(dot(GREEN if on else GREY))
        r.addWidget(QLabel(f"Kernel {i['kernel']}: sched_ext supported · now: " +
                           (f"<b>{short_ops(st['ops'])}</b> running" if on else "normal Linux scheduler")), 1)
        c.lay.addLayout(r)
        if not i["scheds"]:
            msg = ("The scx schedulers (scx_lavd, scx_bpfland…) are not packaged in Debian yet, so PhoenixGe cannot install "
                   "them for you. " + (f"Your package sources offer \"{i['apt']}\" - install it below." if i["apt"] else
                                       "As soon as Debian (or the PhoenixGe repository) ships them, they appear here."))
            c.lay.addWidget(dim(msg))
            if i["apt"]:
                b = QPushButton(f"Install {i['apt']}")
                b.clicked.connect(lambda: self.center.runner.root(APT_INSTALL, [i["apt"]], lambda _c: self.refresh()))
                c.lay.addWidget(b, 0, Qt.AlignLeft)
            return
        conf = i["conf"]
        self.mode_g = QButtonGroup(self)
        modes = QVBoxLayout(); modes.setSpacing(4)
        for key, text in (("auto", "Automatic - only while a game runs (recommended)"),
                          ("manual", "Always on"), ("off", "Off - normal Linux scheduler")):
            rb = QRadioButton(text); rb.setProperty("mode", key); rb.setChecked(conf["MODE"] == key)
            self.mode_g.addButton(rb); modes.addWidget(rb)
        c.lay.addLayout(modes)
        sr = QHBoxLayout(); sr.setSpacing(10)
        sr.addWidget(QLabel("Scheduler"))
        self.sched_cb = QComboBox()
        for name in sorted(i["scheds"], key=lambda n: (n != "scx_lavd", n != "scx_bpfland", n)):
            self.sched_cb.addItem(name + (" - " + scx.KNOWN[name][0] if name in scx.KNOWN else ""), name)
        self.sched_cb.setCurrentIndex(max(0, self.sched_cb.findData(conf["SCHED"])))
        sr.addWidget(self.sched_cb, 1)
        c.lay.addLayout(sr)
        fr = QHBoxLayout(); fr.setSpacing(10)
        fr.addWidget(QLabel("Extra options"))
        self.flags = QLineEdit(conf["FLAGS"]); self.flags.setPlaceholderText("e.g. --performance  (scx_lavd: --autopower on battery)")
        fr.addWidget(self.flags, 1)
        ap = QPushButton("Apply"); ap.setObjectName("primary"); ap.clicked.connect(self.apply_sched)
        fr.addWidget(ap)
        c.lay.addLayout(fr)
        c.lay.addWidget(dim("Automatic uses the GameMode hooks: the scheduler starts with your game and stops after it. "
                            "Applying asks for your password once."))

    def apply_sched(self):
        mode = self.mode_g.checkedButton().property("mode") if self.mode_g.checkedButton() else "auto"
        try:
            args = scx.setup_args(mode, self.sched_cb.currentData(), self.flags.text().strip())
        except ValueError as e:
            QMessageBox.warning(self, "Gaming scheduler", f"{e}. Only letters, numbers, - = . , are allowed."); return
        if DEMO:
            return
        self.center.runner.root(args[0], args[1:], lambda _c: self.refresh())


def build(center):
    return DisplayPage(center)


if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication, QPlainTextEdit
    app = QApplication(sys.argv)

    class _Host(QWidget):
        def __init__(self):
            super().__init__()
            lay = QVBoxLayout(self); self.log = QPlainTextEdit(); self.log.setMaximumHeight(120); self.log.hide()
            import center as cmod
            self.runner = cmod.Runner(self.log)
            lay.addWidget(build(self)); lay.addWidget(self.log)
    h = _Host(); h.resize(1100, 800); h.show()
    sys.exit(app.exec())
