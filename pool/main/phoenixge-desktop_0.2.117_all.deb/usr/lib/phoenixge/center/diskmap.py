"""PhoenixGe Center > Disk Map: what is using my disk? A squarified treemap of a folder or drive, coloured by file
type (videos, games, pictures, archives, apps, system...), click to zoom into a folder, breadcrumb to go back, a list
of the biggest folders/files with Open folder / Move to Trash and "safe to clean?" hints, and the usual big space
users (Steam / Heroic games, Flatpak, Timeshift, Trash, caches, old downloads).

build(center) -> QWidget        page key "diskmap"
python3 diskmap.py [--demo]     run alone (--demo: a made-up home for screenshots)
Scanning runs in a thread (diskmap_data.Scanner); "/" as administrator runs diskmap_data.py --scan-json via pkexec.
"""
import os
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

from PySide6.QtCore import QObject, QProcess, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QFontMetrics, QIcon, QLinearGradient, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (QComboBox, QFileDialog, QFrame, QHBoxLayout, QHeaderView, QLabel, QMenu, QMessageBox,
                               QProgressBar, QPushButton, QSizePolicy, QToolButton, QToolTip, QTreeWidget,
                               QTreeWidgetItem, QVBoxLayout, QWidget)

sys.path.insert(0, str(Path(__file__).resolve().parent))
import diskmap_data as dd  # noqa: E402

DEMO = "--demo" in sys.argv or os.environ.get("PHOENIXGE_DEMO") == "1"
HOME = str(Path.home()) if not DEMO else "/home/phoenix"
HELPER = str(Path(__file__).resolve().parent / "diskmap_data.py")
LEVEL_COLORS = {"safe": "#3fb950", "careful": "#e3b341", "keep": "#f85149", "info": "#8b949e"}
MAX_DEPTH = 3          # nested folder levels drawn inside the map
LEVEL_WORDS = {"safe": "Safe to clean", "careful": "Careful", "keep": "Keep", "info": "Info"}


def ui(center):
    for name in (type(center).__module__ if center is not None else None, "__main__", "center"):
        mod = sys.modules.get(name) if name else None
        if mod is not None and hasattr(mod, "Card") and hasattr(mod, "page"):
            return mod.Card, mod.page
    from systools_ui import ui as _ui
    c, p, _f = _ui(center)
    return c, p


def accent():
    try:
        v = subprocess.run(["kreadconfig6", "--file", "kdeglobals", "--group", "General", "--key", "AccentColor"],
                           capture_output=True, text=True, timeout=3).stdout.strip()
        r, g, b = (int(x) for x in v.split(",")[:3])
        return QColor(r, g, b).name()
    except Exception:
        return "#ff7a2e"


def goto_page(center, key):
    """Switch the Center to another page (works with the old title-based and the new key-based navigation)."""
    for meth in ("goto_page", "show_page", "open_page", "select_page"):
        f = getattr(center, meth, None)
        if callable(f):
            try:
                f(key)
                return
            except Exception:  # noqa: BLE001
                pass
    nav = getattr(center, "nav", None)
    titles = {"health": "health", "backups": "backups", "gaming": "gaming"}
    if nav is not None:
        for r in range(nav.count()):
            it = nav.item(r)
            if it.data(Qt.UserRole) == key or it.text().lower() == titles.get(key, key):
                nav.setCurrentRow(r)
                return
    QProcess.startDetached("phoenixge-center", ["--page", key])


def statvfs(path):
    try:
        s = os.statvfs(path)
        return s.f_blocks * s.f_frsize, s.f_bavail * s.f_frsize
    except OSError:
        return 0, 0


def mounts():
    """Real mounted filesystems -> [(mount point, label)]"""
    out = []
    try:
        lines = Path("/proc/self/mounts").read_text().splitlines()
    except OSError:
        return out
    for ln in lines:
        f = ln.split()
        if len(f) < 3 or f[2] not in dd_REAL_FS:
            continue
        mp = f[1].replace("\\040", " ")
        if mp in ("/", HOME) or mp.startswith(("/boot", "/run/live", "/snap", "/var/lib", "/sys", "/proc")):
            continue
        out.append((mp, f"{os.path.basename(mp) or mp}  ({mp})"))
    return out


dd_REAL_FS = {"ext2", "ext3", "ext4", "btrfs", "xfs", "f2fs", "vfat", "exfat", "ntfs", "ntfs3", "fuseblk", "zfs", "bcachefs"}


# ------------------------------------------------------------------ squarified treemap layout
def squarify(sizes, rect):
    """Bruls, Huizing, van Wijk (2000). sizes: descending, > 0. -> [QRectF] in the same order."""
    out = []
    total = float(sum(sizes))
    if total <= 0 or rect.width() <= 0 or rect.height() <= 0:
        return [QRectF() for _ in sizes]
    scale = rect.width() * rect.height() / total
    areas = [s * scale for s in sizes]
    x, y, w, h = rect.x(), rect.y(), rect.width(), rect.height()
    i = 0
    n = len(areas)

    def worst(row, side):
        s = sum(row)
        if s <= 0 or side <= 0:
            return float("inf")
        return max(max(side * side * r / (s * s), (s * s) / (side * side * r)) for r in row)

    while i < n:
        side = min(w, h)
        row = [areas[i]]
        j = i + 1
        while j < n and worst(row + [areas[j]], side) <= worst(row, side):
            row.append(areas[j])
            j += 1
        s = sum(row)
        if w >= h:  # lay the row out as a column on the left
            cw = s / h if h else 0
            yy = y
            for a in row:
                ch = a / cw if cw else 0
                out.append(QRectF(x, yy, cw, ch))
                yy += ch
            x += cw
            w -= cw
        else:       # as a row on top
            rh = s / w if w else 0
            xx = x
            for a in row:
                rw = a / rh if rh else 0
                out.append(QRectF(xx, y, rw, rh))
                xx += rw
            y += rh
            h -= rh
        i = j
    return out


class Treemap(QWidget):
    activated = Signal(object)      # folder clicked -> zoom
    selected = Signal(object)       # any entry clicked
    context = Signal(object, object)  # node, global pos

    def __init__(self):
        super().__init__()
        self.node, self.items, self.hover, self.sel, self.chain = None, [], None, None, {}
        self.accent = QColor(accent())
        self.setMouseTracking(True)
        self.setMinimumHeight(420)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def set_node(self, node):
        self.node, self.hover = node, None
        self.relayout()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self.relayout()

    def relayout(self):
        self.items, self.chain = [], {}
        if self.node is not None and self.node.size > 0:
            self._layout(self.node, QRectF(self.rect()).adjusted(1, 1, -1, -1), 0)
        self.update()

    def _layout(self, node, rect, depth):
        kids = [c for c in node.children if c.size > 0][:400]
        if not kids:
            return
        total = node.size
        shown = sum(c.size for c in kids)
        sizes = [c.size for c in kids]
        if total > shown * 1.002:  # tiny entries cut off -> keep proportions honest with an empty remainder
            sizes.append(total - shown)
        rects = squarify(sizes, rect)
        for c, r in zip(kids, rects):
            if r.width() < 2 or r.height() < 2:
                continue
            gap = 1.5 if depth == 0 else 1.0
            r = r.adjusted(gap, gap, -gap, -gap)
            if r.width() < 1 or r.height() < 1:
                continue
            self.items.append((r, c, depth))
            if c.is_dir and depth < MAX_DEPTH and r.width() > 46 and r.height() > 40:
                head = 18 if depth == 0 else 15
                inner = r.adjusted(3, head, -3, -3)
                if inner.width() > 20 and inner.height() > 14:
                    # a folder that is (almost) only one sub-folder ('.local' -> 'share') doesn't use up a level
                    d = c
                    while len(d.children) >= 1 and d.children[0].is_dir and d.children[0].size >= 0.97 * d.size > 0:
                        d = d.children[0]
                    self.chain[id(c)] = d
                    self._layout(d, inner, depth + 1)

    def color(self, node, depth):
        c = QColor(dd.CATS.get(node.main_cat(), dd.CATS["other"])[1])
        if node.is_dir:
            c = c.darker(130 + 25 * (MAX_DEPTH - depth)) if depth < MAX_DEPTH else c
        return c

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        bg = self.palette().color(self.palette().ColorRole.Base)
        p.fillRect(self.rect(), bg)
        if not self.items:
            p.setPen(self.palette().color(self.palette().ColorRole.PlaceholderText))
            p.drawText(self.rect(), Qt.AlignCenter, "Pick a folder or drive and press Scan." if self.node is None
                       else "This folder is empty.")
            p.end()
            return
        f = QFont(self.font())
        small = QFont(f); small.setPointSizeF(max(7.0, f.pointSizeF() - 1.5))
        bold = QFont(f); bold.setBold(True)
        for r, n, depth in self.items:
            base = self.color(n, depth)
            g = QLinearGradient(r.topLeft(), r.bottomRight())
            g.setColorAt(0, base.lighter(118))
            g.setColorAt(1, base.darker(112))
            p.setPen(QPen(base.darker(160), 1))
            p.setBrush(g)
            rad = 5 if depth == 0 else 3
            p.drawRoundedRect(r, rad, rad)
            # labels
            room_h = 18 if depth == 0 else 15
            if n.is_dir and depth < MAX_DEPTH and r.width() > 46 and r.height() > 40:
                self._label(p, QRectF(r.x() + 5, r.y() + 1, r.width() - 10, room_h - 2), n, bold if depth == 0 else small,
                            one_line=True)
            elif r.width() > 54 and r.height() > 30:
                self._label(p, r.adjusted(5, 3, -5, -3), n, bold if depth == 0 else small, one_line=False)
        for n, col, w in ((self.sel, QColor("#ffffff"), 2.5), (self.hover, self.accent, 2.0)):
            if n is None:
                continue
            for r, m, _d in self.items:
                if m is n:
                    p.setPen(QPen(col, w)); p.setBrush(Qt.NoBrush)
                    p.drawRoundedRect(r.adjusted(0.5, 0.5, -0.5, -0.5), 4, 4)
                    break
        p.end()

    def _label(self, p, r, n, font, one_line):
        fm = QFontMetrics(font)
        name = n.name if n.parent is not None else os.path.basename(n.name) or n.name
        size = dd.human(n.size)
        p.setFont(font)
        shadow = QColor(0, 0, 0, 150)
        if one_line:
            d, chain = self.chain.get(id(n)), []
            while d is not None and d is not n:
                chain.append(d.name)
                d = d.parent
            if chain:
                name = " › ".join([name] + chain[::-1])
            txt = fm.elidedText(f"{name}  ·  {size}", Qt.ElideMiddle, int(r.width()))
            lines = [txt]
        else:
            lines = [fm.elidedText(name, Qt.ElideMiddle, int(r.width()))]
            if r.height() > fm.height() * 2 + 2:
                lines.append(size)
        y = r.y()
        for i, t in enumerate(lines):
            rr = QRectF(r.x(), y, r.width(), fm.height())
            p.setPen(shadow); p.drawText(rr.translated(1, 1), Qt.AlignLeft | Qt.AlignVCenter, t)
            p.setPen(QColor("#ffffff") if i == 0 else QColor(255, 255, 255, 200))
            p.drawText(rr, Qt.AlignLeft | Qt.AlignVCenter, t)
            y += fm.height()

    def at(self, pos):
        hit = None
        for r, n, _d in self.items:
            if r.contains(pos):
                hit = n  # later items are nested deeper
        return hit

    def mouseMoveEvent(self, e):
        n = self.at(e.position())
        if n is not self.hover:
            self.hover = n
            self.update()
        if n is not None and self.node is not None:
            pct = 100.0 * n.size / self.node.size if self.node.size else 0
            kind = "Folder" if n.is_dir else "Files" if n.is_group else "File"
            extra = f"\n{n.count:,} files" if n.is_dir else ""
            cat = dd.CATS.get(n.main_cat(), dd.CATS["other"])[0]
            lv, txt, _pg = dd.hint(n, HOME)
            QToolTip.showText(e.globalPosition().toPoint(),
                              f"{n.path}\n{kind} · {dd.human(n.size)} · {pct:.1f}% of this view{extra}\n"
                              f"Mostly: {cat}" + (f"\n{txt}" if txt else "")
                              + ("\nClick to open this folder" if n.is_dir else ""), self)
        else:
            QToolTip.hideText()

    def leaveEvent(self, _e):
        self.hover = None
        self.update()

    def mousePressEvent(self, e):
        n = self.at(e.position())
        if n is None:
            return
        if e.button() == Qt.RightButton:
            self.context.emit(n, e.globalPosition().toPoint())
            return
        self.sel = n
        self.selected.emit(n)
        target = n if n.is_dir else None
        if target is None and n.parent is not None and n.parent is not self.node:
            target = n.parent
        if target is not None and target is not self.node:
            self.activated.emit(target)
        self.update()


# ------------------------------------------------------------------ the page
class Bridge(QObject):
    scanned = Signal(object, object)   # tree, scanner (or error string, None)
    big = Signal(object)


def swatch(color, size=12):
    pm = QPixmap(size, size)
    pm.fill(Qt.transparent)
    p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing)
    p.setBrush(QColor(color)); p.setPen(Qt.NoPen); p.drawRoundedRect(QRectF(0, 0, size, size), 3, 3); p.end()
    return QIcon(pm)


class DiskMapPage(QWidget):
    def __init__(self, center):
        super().__init__()
        self.center = center
        Card, page = ui(center)
        self.Card = Card
        self.scanner, self.tree, self.node, self.top = None, None, None, []
        self.bridge = Bridge()
        self.bridge.scanned.connect(self.on_scanned)
        self.bridge.big.connect(self.on_big)
        self.proc = None
        w, lay = page("Disk Map", "What is filling your disk? Every box is a folder or file, sized by the space it uses "
                                  "and coloured by type. Click a box to look inside.")
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0); outer.addWidget(w)

        # --- controls
        top = Card()
        row = QHBoxLayout()
        self.where = QComboBox(); self.where.setMinimumWidth(260)
        self.where.addItem(QIcon.fromTheme("user-home"), "My home folder", HOME)
        self.where.addItem(QIcon.fromTheme("drive-harddisk-root"), "Whole system ( / )", "/")
        for mp, label in ([] if DEMO else mounts()):
            self.where.addItem(QIcon.fromTheme("drive-harddisk"), label, mp)
        self.where.addItem(QIcon.fromTheme("folder-open"), "Choose a folder…", "")
        self.where.activated.connect(self.where_changed)
        self.scan_btn = QPushButton(QIcon.fromTheme("view-refresh"), "Scan"); self.scan_btn.setObjectName("primary")
        self.scan_btn.clicked.connect(self.scan)
        self.cancel_btn = QPushButton("Stop"); self.cancel_btn.clicked.connect(self.cancel); self.cancel_btn.hide()
        self.root_btn = QPushButton(QIcon.fromTheme("security-high"), "Scan as administrator")
        self.root_btn.setToolTip("Also count system folders only the administrator can read (asks for your password).")
        self.root_btn.clicked.connect(self.scan_root); self.root_btn.hide()
        row.addWidget(QLabel("Look at")); row.addWidget(self.where); row.addWidget(self.scan_btn)
        row.addWidget(self.cancel_btn); row.addWidget(self.root_btn); row.addStretch()
        top.lay.addLayout(row)
        self.prog = QProgressBar(); self.prog.setTextVisible(False); self.prog.setFixedHeight(6); self.prog.hide()
        top.lay.addWidget(self.prog)
        self.status = QLabel("Pick a folder or drive and press Scan."); self.status.setObjectName("dim")
        self.status.setWordWrap(True)
        top.lay.addWidget(self.status)
        lay.addWidget(top)

        # --- map
        mapcard = Card()
        crumbs = QHBoxLayout(); crumbs.setSpacing(2)
        self.up_btn = QToolButton(); self.up_btn.setIcon(QIcon.fromTheme("go-up")); self.up_btn.setToolTip("Up one folder")
        self.up_btn.clicked.connect(self.go_up); self.up_btn.setAutoRaise(True)
        crumbs.addWidget(self.up_btn)
        self.crumb_box = QHBoxLayout(); self.crumb_box.setSpacing(0)
        crumbs.addLayout(self.crumb_box); crumbs.addStretch()
        self.here = QLabel(); self.here.setObjectName("dim"); crumbs.addWidget(self.here)
        mapcard.lay.addLayout(crumbs)
        self.map = Treemap()
        self.map.activated.connect(self.zoom)
        self.map.selected.connect(self.select_node)
        self.map.context.connect(self.menu)
        mapcard.lay.addWidget(self.map, 1)
        self.legend = QLabel(); self.legend.setWordWrap(True); self.legend.setTextFormat(Qt.RichText)
        mapcard.lay.addWidget(self.legend)
        lay.addWidget(mapcard, 1)

        # --- list
        lc = Card("Biggest folders and files")
        lrow = QHBoxLayout()
        self.list_mode = QComboBox()
        self.list_mode.addItems(["In this folder", "Biggest files in the whole scan"])
        self.list_mode.currentIndexChanged.connect(self.fill_list)
        lrow.addWidget(self.list_mode); lrow.addStretch()
        self.open_btn = QPushButton(QIcon.fromTheme("document-open-folder"), "Open folder")
        self.open_btn.clicked.connect(lambda: self.open_folder(self.current_selection()))
        self.trash_btn = QPushButton(QIcon.fromTheme("user-trash"), "Move to Trash")
        self.trash_btn.clicked.connect(lambda: self.trash(self.current_selection()))
        self.clean_btn = QPushButton(QIcon.fromTheme("edit-clear-all"), "Clean up…")
        self.clean_btn.setToolTip("Health › Clean up: caches, old kernels, unused Flatpak runtimes, logs, Trash")
        self.clean_btn.clicked.connect(lambda: goto_page(self.center, "health"))
        for b in (self.open_btn, self.trash_btn, self.clean_btn):
            lrow.addWidget(b)
        lc.lay.addLayout(lrow)
        self.list = QTreeWidget()
        self.list.setHeaderLabels(["Name", "Size", "Share", "Safe to clean?"])
        self.list.setRootIsDecorated(False); self.list.setUniformRowHeights(True); self.list.setAlternatingRowColors(True)
        self.list.setMinimumHeight(300)
        hd = self.list.header()
        hd.setSectionResizeMode(0, QHeaderView.Stretch)
        for c in (1, 2):
            hd.setSectionResizeMode(c, QHeaderView.ResizeToContents)
        hd.setSectionResizeMode(3, QHeaderView.Interactive); hd.resizeSection(3, 380)
        self.list.itemDoubleClicked.connect(self.list_double)
        self.list.currentItemChanged.connect(lambda *_: self.update_buttons())
        self.list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.list.customContextMenuRequested.connect(
            lambda pos: self.current_selection() and self.menu(self.current_selection(), self.list.viewport().mapToGlobal(pos)))
        lc.lay.addWidget(self.list)
        lay.addWidget(lc)

        # --- big space users
        self.big_card = Card("Big space users", "The usual suspects, wherever they are on this computer.")
        self.big_box = QVBoxLayout(); self.big_box.setSpacing(6)
        self.big_card.lay.addLayout(self.big_box)
        self.big_box.addWidget(QLabel("Looking…"))
        lay.addWidget(self.big_card)
        self.note = QLabel(""); self.note.setObjectName("dim"); self.note.setWordWrap(True)
        lay.addWidget(self.note)

        self.timer = QTimer(self); self.timer.timeout.connect(self.progress)
        self.update_buttons()
        self.load_big()
        if DEMO:
            QTimer.singleShot(0, self.scan)

    # ---------------------------------------------------------------- scanning
    def where_changed(self, i):
        if self.where.itemData(i) == "":
            d = QFileDialog.getExistingDirectory(self, "Folder to look at", HOME)
            if not d:
                self.where.setCurrentIndex(0)
                return
            self.where.insertItem(self.where.count() - 1, QIcon.fromTheme("folder"), d, d)
            self.where.setCurrentIndex(self.where.count() - 2)
        self.root_btn.setVisible(self.where.currentData() == "/" and not DEMO)

    def scan(self):
        path = self.where.currentData() or HOME
        self.cancel()
        self.scan_btn.setEnabled(False); self.cancel_btn.show(); self.prog.show()
        total, free = statvfs(path)
        self.estimate = (total - free) if os.path.ismount(path) else 0
        self.prog.setRange(0, 1000 if self.estimate else 0); self.prog.setValue(0)
        self.status.setText(f"Looking at {path}…")
        if DEMO:
            self.bridge.scanned.emit(dd.demo_tree(HOME), None)
            return
        sc = dd.Scanner(path, home=HOME)
        self.scanner = sc

        def work():
            try:
                tree = sc.run()
                self.bridge.scanned.emit(tree, sc)
            except Exception as e:  # noqa: BLE001
                self.bridge.scanned.emit(str(e), None)
        threading.Thread(target=work, daemon=True).start()
        self.timer.start(150)

    def progress(self):
        sc = self.scanner
        if sc is None:
            return
        if self.estimate:
            self.prog.setValue(min(990, int(1000 * sc.bytes / max(1, self.estimate))))
        cur = sc.current
        if len(cur) > 70:
            cur = "…" + cur[-69:]
        self.status.setText(f"{sc.files:,} files · {dd.human(sc.bytes)} so far · {cur}")

    def cancel(self):
        if self.scanner is not None and not self.scanner.done:
            self.scanner.cancel()
        if self.proc is not None:
            self.proc.kill()
            self.proc = None
        self.timer.stop()
        self.scan_btn.setEnabled(True); self.cancel_btn.hide(); self.prog.hide()

    def on_scanned(self, tree, sc):
        self.timer.stop()
        self.scan_btn.setEnabled(True); self.cancel_btn.hide(); self.prog.hide()
        if isinstance(tree, str):
            self.status.setText(tree)
            return
        if sc is not None and sc.cancelled:
            self.status.setText("Stopped. What was counted so far is shown.")
        self.tree = tree
        if sc is not None:
            self.top = [(s, p, c, m) for s, p, c, m in sc.biggest_files(100)]
            denied, took = sc.denied, time.time() - sc.started
        else:
            self.top = self.collect_top(tree)
            denied, took = 0, 1.8
        total, free = statvfs(tree.path) if not DEMO else (512 * 10**9, 63 * 10**9)
        msg = (f"{tree.path} uses {dd.human(tree.size)} in {tree.count:,} files"
               + (f" · drive {dd.human(total)}, {dd.human(free)} free" if total else "")
               + f" · scanned in {took:.1f} s")
        if sc is None or not sc.cancelled:
            self.status.setText(msg)
        notes = []
        if denied:
            notes.append(f"{denied:,} folders could not be read (they belong to the system or another user) and are "
                         "not counted." + (" Use \"Scan as administrator\" to include them." if tree.path == "/" else ""))
        if sc is not None and sc.other_mounts:
            notes.append("Other drives below this folder are not included: " + ", ".join(sc.other_mounts[:5])
                         + ("…" if len(sc.other_mounts) > 5 else ""))
        self.note.setText("\n".join(notes))
        self.root_btn.setVisible(tree.path == "/" and not DEMO)
        self.zoom(tree)

    def collect_top(self, tree, n=100):
        out, stack = [], [tree]
        while stack:
            x = stack.pop()
            for c in x.children:
                if c.is_dir:
                    stack.append(c)
                elif not c.is_group:
                    out.append((c.size, c.path, c.cat, c.mtime))
        return sorted(out, reverse=True)[:n]

    def scan_root(self):
        """Whole system as administrator: the same scanner runs as root (pkexec) and sends the tree back as JSON."""
        self.cancel()
        self.scan_btn.setEnabled(False); self.cancel_btn.show(); self.prog.show(); self.prog.setRange(0, 0)
        self.status.setText("Scanning the whole system as administrator… (this can take a minute)")
        p = QProcess(self)
        p.setProcessEnvironment(p.processEnvironment())
        self.proc, buf = p, bytearray()
        p.readyReadStandardOutput.connect(lambda: buf.extend(bytes(p.readAllStandardOutput())))

        def done(code, _status):
            if self.proc is not p:
                return
            self.proc = None
            if code != 0 or not buf:
                self.on_scanned("The administrator scan was cancelled or failed (code %s)." % code, None)
                return

            def parse():
                import json
                try:
                    d = json.loads(bytes(buf).decode("utf-8", "replace"))
                    tree = dd.from_json(d["tree"])

                    class R:  # looks like a finished Scanner for on_scanned()
                        cancelled, denied, other_mounts, started = False, d.get("denied", 0), [], self._root_t0

                        def biggest_files(self, n=100):
                            return [tuple(t) for t in d.get("top", [])][:n]
                    self.bridge.scanned.emit(tree, R())
                except Exception as e:  # noqa: BLE001
                    self.bridge.scanned.emit(f"Could not read the administrator scan: {e}", None)
            threading.Thread(target=parse, daemon=True).start()
        p.finished.connect(done)
        self._root_t0 = time.time()
        p.start("pkexec", ["env", f"PHOENIXGE_HOME={HOME}", "/usr/bin/python3", HELPER, "--scan-json", "/"])

    # ---------------------------------------------------------------- navigation
    def zoom(self, node):
        self.node = node
        self.map.sel = None
        self.map.set_node(node)
        while self.crumb_box.count():
            it = self.crumb_box.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        chain = node.ancestors()
        if len(chain) > 6:
            chain = chain[:1] + [None] + chain[-4:]
        for i, a in enumerate(chain):
            if i:
                sep = QLabel("›"); sep.setObjectName("dim"); self.crumb_box.addWidget(sep)
            if a is None:
                lab = QLabel(" … "); lab.setObjectName("dim"); self.crumb_box.addWidget(lab)
                continue
            name = a.name if a.parent is not None else ("Home" if a.name == HOME else a.name)
            b = QToolButton(); b.setText(name); b.setAutoRaise(True)
            if a.parent is None:
                b.setIcon(QIcon.fromTheme("user-home" if a.name == HOME else "drive-harddisk"))
                b.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            if a is node:
                f = b.font(); f.setBold(True); b.setFont(f)
            b.clicked.connect(lambda _=False, x=a: self.zoom(x))
            self.crumb_box.addWidget(b)
        pct = f" · {100.0 * node.size / self.tree.size:.0f}% of the scan" if self.tree and node is not self.tree and self.tree.size else ""
        self.here.setText(f"{dd.human(node.size)}{pct}")
        self.up_btn.setEnabled(node.parent is not None)
        self.fill_legend()
        self.fill_list()

    def go_up(self):
        if self.node is not None and self.node.parent is not None:
            self.zoom(self.node.parent)

    def fill_legend(self):
        if self.node is None:
            self.legend.setText("")
            return
        cats = sorted(((b, c) for c, b in (self.node.cats or {}).items() if b > 0), reverse=True)
        parts = []
        for b, c in cats:
            label, color = dd.CATS.get(c, dd.CATS["other"])
            parts.append(f"<span style='color:{color}'>&#9632;</span>&nbsp;{label}&nbsp;"
                         f"<span style='color:#8b949e'>{dd.human(b)}</span>")
        self.legend.setText(" &nbsp;&nbsp; ".join(parts))

    # ---------------------------------------------------------------- list
    def fill_list(self):
        self.list.clear()
        if self.node is None:
            return
        rows = []
        if self.list_mode.currentIndex() == 0:
            base = self.node.size or 1
            for c in self.node.children[:150]:
                rows.append((c, c.size, 100.0 * c.size / base))
        else:
            base = (self.tree.size if self.tree else 1) or 1
            for s, path, cat, mt in self.top:
                n = self.find(path)
                if n is None:
                    continue
                rows.append((n, s, 100.0 * s / base))
        for n, size, pct in rows:
            name = n.name if self.list_mode.currentIndex() == 0 else n.path.replace(HOME, "~", 1)
            it = QTreeWidgetItem([name + ("/" if n.is_dir else ""), dd.human(size), f"{pct:.1f}%", ""])
            it.setIcon(0, swatch(dd.CATS.get(n.main_cat(), dd.CATS["other"])[1]))
            it.setTextAlignment(1, Qt.AlignRight | Qt.AlignVCenter)
            it.setTextAlignment(2, Qt.AlignRight | Qt.AlignVCenter)
            lv, txt, _pg = dd.hint(n, HOME)
            if lv:
                it.setText(3, f"{LEVEL_WORDS[lv]}: {txt}" if lv in ("safe", "careful", "keep") else txt)
                it.setForeground(3, QColor(LEVEL_COLORS[lv]))
                it.setToolTip(3, txt)
            it.setToolTip(0, n.path)
            it.setData(0, Qt.UserRole, n)
            self.list.addTopLevelItem(it)
        self.update_buttons()

    def find(self, path):
        """Node for an absolute path inside the scanned tree (files in '(N smaller files)' are not kept)."""
        if self.tree is None or not path.startswith(self.tree.path):
            return None
        rel = path[len(self.tree.path):].strip("/")
        n = self.tree
        for part in rel.split("/") if rel else []:
            n = next((c for c in (n.children or []) if c.name == part), None)
            if n is None:
                return None
        return n

    def current_selection(self):
        it = self.list.currentItem()
        if it is not None:
            return it.data(0, Qt.UserRole)
        return self.map.sel

    def select_node(self, n):
        for i in range(self.list.topLevelItemCount()):
            it = self.list.topLevelItem(i)
            if it.data(0, Qt.UserRole) is n:
                self.list.setCurrentItem(it)
                return
        self.list.setCurrentItem(None)
        self.update_buttons()

    def update_buttons(self):
        n = self.current_selection()
        self.open_btn.setEnabled(n is not None and not DEMO)
        self.trash_btn.setEnabled(n is not None and self.can_trash(n))

    def list_double(self, it, _col):
        n = it.data(0, Qt.UserRole)
        if n is not None and n.is_dir:
            self.zoom(n)
        elif n is not None:
            self.open_folder(n)

    # ---------------------------------------------------------------- actions
    def can_trash(self, n):
        if n is None or n.parent is None or n.is_group:
            return False
        p = n.path
        if not (p.startswith(HOME + "/") or p.startswith(("/media/", "/mnt/", "/run/media/"))):
            return False
        return p not in (HOME + "/.local", HOME + "/.config", HOME + "/.local/share")

    def open_folder(self, n):
        if n is None:
            return
        target = n.path if n.is_dir else os.path.dirname(n.path)
        if not n.is_dir and not n.is_group and shutil.which("dolphin"):
            QProcess.startDetached("dolphin", ["--select", n.path])
        else:
            QProcess.startDetached("xdg-open", [target])

    def trash(self, n):
        if not self.can_trash(n):
            return
        lv, txt, _pg = dd.hint(n, HOME)
        warn = f"\n\n{txt}" if lv in ("careful", "keep") else ""
        what = "folder" if n.is_dir else "file"
        r = QMessageBox.question(self, "Move to Trash",
                                 f"Move this {what} to the Trash?\n\n{n.path}\n{dd.human(n.size)}{warn}\n\n"
                                 "You can restore it from the Trash until you empty it.")
        if r != QMessageBox.Yes:
            return
        ok = DEMO
        if not DEMO:
            for cmd in (["gio", "trash", "--", n.path], ["kioclient", "move", n.path, "trash:/"]):
                if shutil.which(cmd[0]):
                    try:
                        ok = subprocess.run(cmd, capture_output=True, timeout=120).returncode == 0
                    except Exception:  # noqa: BLE001
                        ok = False
                    if ok:
                        break
        if not ok:
            QMessageBox.warning(self, "Move to Trash", f"Could not move {n.path} to the Trash.")
            return
        path = n.path
        n.remove()
        self.top = [t for t in self.top if not (t[1] == path or t[1].startswith(path + "/"))]
        self.status.setText(f"Moved to the Trash: {path} ({dd.human(n.size)}). Empty the Trash to free the space.")
        self.zoom(self.node if self.node is not n else n.parent)

    def menu(self, n, pos):
        if n is None:
            return
        m = QMenu(self)
        if n.is_dir and n is not self.node:
            m.addAction(QIcon.fromTheme("zoom-in"), "Look inside", lambda: self.zoom(n))
        m.addAction(QIcon.fromTheme("document-open-folder"), "Open folder", lambda: self.open_folder(n))
        a = m.addAction(QIcon.fromTheme("user-trash"), "Move to Trash", lambda: self.trash(n))
        a.setEnabled(self.can_trash(n))
        lv, txt, pg = dd.hint(n, HOME)
        if pg:
            m.addAction(QIcon.fromTheme("go-next"), {"health": "Open Health › Clean up", "backups": "Open Backups"}.get(pg, pg),
                        lambda: goto_page(self.center, pg))
        m.addAction(QIcon.fromTheme("edit-copy"), "Copy path", lambda: self._copy(n.path))
        m.exec(pos)

    def _copy(self, text):
        from PySide6.QtWidgets import QApplication
        QApplication.clipboard().setText(text)

    # ---------------------------------------------------------------- big space users
    def load_big(self):
        if DEMO:
            QTimer.singleShot(0, lambda: self.on_big(dd.demo_big_users()))
            return
        threading.Thread(target=lambda: self.bridge.big.emit(dd.big_users(HOME)), daemon=True).start()

    def on_big(self, rows):
        while self.big_box.count():
            it = self.big_box.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        total = max([r["bytes"] or 0 for r in rows] + [1])
        for r in rows:
            w = QFrame(); h = QHBoxLayout(w); h.setContentsMargins(0, 4, 0, 4); h.setSpacing(10)
            color = dd.CATS.get(r["cat"], dd.CATS["other"])[1]
            sw = QLabel(); sw.setFixedSize(12, 12); sw.setStyleSheet(f"background:{color}; border-radius:3px;")
            h.addWidget(sw, 0, Qt.AlignTop)
            col = QVBoxLayout(); col.setSpacing(2)
            t = QLabel(f"<b>{r['label']}</b>")
            d = QLabel(r["detail"]); d.setObjectName("dim"); d.setWordWrap(True)
            col.addWidget(t); col.addWidget(d)
            h.addLayout(col, 1)
            bar = QProgressBar(); bar.setTextVisible(False); bar.setFixedSize(140, 6)
            bar.setRange(0, 1000); bar.setValue(int(1000 * (r["bytes"] or 0) / total))
            bar.setStyleSheet(f"QProgressBar {{ border: none; background: palette(base); border-radius: 3px; }}"
                              f"QProgressBar::chunk {{ background: {color}; border-radius: 3px; }}")
            h.addWidget(bar, 0, Qt.AlignVCenter)
            s = QLabel(dd.human(r["bytes"]) if r["bytes"] is not None else "—"); s.setMinimumWidth(70)
            s.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            h.addWidget(s)
            if r.get("page"):
                b = QPushButton({"health": "Clean up", "backups": "Backups"}.get(r["page"], "Open"))
                b.clicked.connect(lambda _=False, pg=r["page"]: goto_page(self.center, pg))
                h.addWidget(b)
            elif r.get("path"):
                b = QPushButton("Open")
                b.clicked.connect(lambda _=False, pth=r["path"]: QProcess.startDetached("xdg-open", [pth]))
                b.setEnabled(not DEMO)
                h.addWidget(b)
            else:
                h.addSpacing(70)
            self.big_box.addWidget(w)


def build(center):
    return DiskMapPage(center)


if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication, QPlainTextEdit
    app = QApplication(sys.argv)

    class _Host(QWidget):
        def __init__(self):
            super().__init__()
            lay = QVBoxLayout(self); lay.setContentsMargins(0, 0, 0, 0)
            self.log = QPlainTextEdit(); self.log.hide()
            lay.addWidget(build(self))
    h = _Host(); h.resize(1180, 900); h.show()
    sys.exit(app.exec())
