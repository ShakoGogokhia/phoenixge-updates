"""PhoenixGe laptop features - hardware detection, settings and the smart-battery logic (no Qt).

Used by the Center (laptop.py), the CLI /usr/bin/phoenixge-laptop and through the CLI by the tray widget.
Every path goes through sysroot() so tests can point PHOENIXGE_SYSROOT at a fixture folder.

Files
  ~/.config/phoenixge/laptop.conf       user part (smart battery: mode + per-state choices)
  ~/.cache/phoenixge/laptop-state.json  what the watcher saw/changed (values to restore, learned choices)
  /etc/phoenixge/laptop.conf            system part, written only by /usr/lib/phoenixge/laptop-root.sh
"""
import configparser
import glob
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

ROOT_HELPER = "/usr/lib/phoenixge/laptop-root.sh"
PROFILES = ("power-saver", "balanced", "performance")
PROFILE_NAMES = {"power-saver": "Battery saver", "balanced": "Balanced", "performance": "Performance"}
NVIDIA, INTEL, AMD = "0x10de", "0x8086", "0x1002"
VENDOR_NAMES = {NVIDIA: "NVIDIA", INTEL: "Intel", AMD: "AMD"}

USER_DEFAULTS = {
    "mode": "auto",          # auto | manual | off
    "bat_profile": "power-saver",   # keep | power-saver | balanced | performance
    "bat_refresh": "60",     # keep | <Hz>
    "ac_profile": "restore", # restore | keep | power-saver | balanced | performance
    "ac_refresh": "restore", # restore | max | keep | <Hz>
    "notify": "true",
}
SYSTEM_DEFAULTS = {"CHARGE_MODE": "auto", "CHARGE_PROTECT": "1", "CHARGE_LIMIT": "80",
                   "GPU_MODE": "auto", "NV_SLEEP_AC": "1", "NV_SLEEP_BAT": "1"}


# ------------------------------------------------------------------ paths / small io
def sysroot():
    return Path(os.environ.get("PHOENIXGE_SYSROOT", "/"))


def sp(path):
    """System path inside the (test) root."""
    return sysroot() / str(path).lstrip("/")


def read(path, default=None):
    try:
        return Path(path).read_text(errors="replace").strip()
    except Exception:
        return default


def read_int(path, default=None):
    try:
        return int(read(path))
    except Exception:
        return default


def run(cmd, timeout=8):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout).stdout
    except Exception:
        return ""


def home():
    return Path(os.environ.get("PHOENIXGE_HOME", str(Path.home())))


def user_conf_path():
    return home() / ".config/phoenixge/laptop.conf"


def state_path():
    return home() / ".cache/phoenixge/laptop-state.json"


# ------------------------------------------------------------------ batteries / AC
def batteries():
    """System batteries (not mouse/headset batteries, which have scope=Device)."""
    out = []
    for d in sorted(sp("/sys/class/power_supply").glob("*")):
        if read(d / "type") == "Battery" and (read(d / "scope") or "System") != "Device":
            out.append(d)
    return out


def is_laptop():
    return bool(batteries())


def ac_online():
    """True/False when a charger supply exists, None when the machine has none we can read."""
    seen = False
    for d in sp("/sys/class/power_supply").glob("*"):
        if read(d / "type") in ("Mains", "USB", "USB_C", "USB_PD", "USB_PD_DRP"):
            v = read(d / "online")
            if v is None:
                continue
            seen = True
            if v == "1":
                return True
    return False if seen else None


def on_battery():
    ac = ac_online()
    if ac is not None:
        return not ac
    return any(read(b / "status") == "Discharging" for b in batteries())


def fmt_minutes(mins):
    if mins is None or mins <= 0:
        return ""
    h, m = divmod(int(round(mins)), 60)
    return f"{h} h {m} min" if h else f"{m} min"


def parse_time(text):
    """'3.2 hours' / '45.0 minutes' / '1,5 hours' -> minutes."""
    m = re.match(r"\s*([\d.,]+)\s*(\w+)", text or "")
    if not m:
        return None
    v = float(m.group(1).replace(",", "."))
    unit = m.group(2).lower()
    if unit.startswith("hour"):
        return v * 60
    if unit.startswith("min"):
        return v
    if unit.startswith("sec"):
        return v / 60
    if unit.startswith("day"):
        return v * 1440
    return None


def parse_upower(text):
    """Parse `upower -i <battery>` output."""
    info = {}
    for line in (text or "").splitlines():
        if ":" not in line:
            continue
        k, v = (x.strip() for x in line.split(":", 1))
        if k == "percentage":
            try:
                info["percent"] = int(round(float(v.rstrip("%").replace(",", "."))))
            except ValueError:
                pass
        elif k == "state":
            info["state"] = v
        elif k == "time to empty":
            info["time_to_empty"] = parse_time(v)
        elif k == "time to full":
            info["time_to_full"] = parse_time(v)
        elif k == "native-path":
            info["native_path"] = v
    return info


def upower_battery():
    if not shutil.which("upower"):
        return {}
    dev = next((l.strip() for l in run(["upower", "-e"]).splitlines() if "battery_BAT" in l or "/battery_" in l), "")
    return parse_upower(run(["upower", "-i", dev])) if dev else {}


def battery_info(use_upower=True):
    """Percent, state and remaining time. upower when available, sysfs as fallback."""
    bats = batteries()
    if not bats:
        return {}
    b = bats[0]
    info = {"percent": read_int(b / "capacity"), "state": (read(b / "status") or "Unknown").lower()}
    now = read_int(b / "energy_now") or read_int(b / "charge_now")
    full = read_int(b / "energy_full") or read_int(b / "charge_full")
    rate = read_int(b / "power_now") or read_int(b / "current_now")
    if rate and now:
        if info["state"] == "discharging":
            info["time_to_empty"] = now / rate * 60
        elif info["state"] == "charging" and full:
            info["time_to_full"] = max(0, full - now) / rate * 60
    if use_upower:
        info.update({k: v for k, v in upower_battery().items() if v is not None})
    info["time"] = fmt_minutes(info.get("time_to_empty") if info.get("state") == "discharging" else info.get("time_to_full"))
    return info


# ------------------------------------------------------------------ charge limit
def charge_control():
    """What this laptop offers for limiting the charge.
    kind = ideapad   (Lenovo IdeaPad/LOQ/Legion: conservation_mode 0/1, firmware decides the stop level)
           threshold (ThinkPad, ASUS, Dell, Framework, ...: charge_control_end_threshold 1-100)
           none
    """
    for f in sorted(sp("/sys/bus/platform/drivers/ideapad_acpi").glob("*/conservation_mode")):
        return {"kind": "ideapad", "path": str(f), "value": read_int(f)}
    for b in batteries():
        f = b / "charge_control_end_threshold"
        if f.exists():
            s = b / "charge_control_start_threshold"
            return {"kind": "threshold", "path": str(f), "value": read_int(f),
                    "start_path": str(s) if s.exists() else "", "start": read_int(s) if s.exists() else None}
    return {"kind": "none"}


def observed_stop(state):
    """Level where an IdeaPad really stopped charging in conservation mode (measured by the watcher)."""
    v = state.get("observed_stop")
    return v if isinstance(v, int) and 40 <= v <= 100 else None


def learn_conservation_stop(state, cc=None, info=None):
    """In conservation mode, on AC, battery 'Not charging' -> that capacity is the real stop level."""
    cc = cc or charge_control()
    if cc.get("kind") != "ideapad" or cc.get("value") != 1 or ac_online() is not True:
        return False
    bats = batteries()
    if not bats or read(bats[0] / "status") not in ("Not charging", "Full"):
        return False
    cap = read_int(bats[0] / "capacity")
    if cap and 40 <= cap <= 100 and state.get("observed_stop") != cap:
        state["observed_stop"] = cap
        return True
    return False


# ------------------------------------------------------------------ graphics
def pci_display_devices():
    out = []
    for d in sorted(sp("/sys/bus/pci/devices").glob("*")):
        cls = read(d / "class") or ""
        if not cls.startswith("0x03"):
            continue
        drv = d / "driver"
        out.append({"addr": d.name, "vendor": read(d / "vendor") or "", "class": cls,
                    "driver": os.path.basename(os.readlink(drv)) if drv.is_symlink() else "",
                    "boot_vga": read(d / "boot_vga") == "1",
                    "runtime_status": read(d / "power/runtime_status") or "",
                    "power_control": read(d / "power/control") or ""})
    return out


def nvidia_driver_installed():
    if sp("/sys/module/nvidia").exists() or sp("/usr/bin/nvidia-smi").exists():
        return True
    pats = ["/lib/modules/*/updates/dkms/nvidia*.ko*", "/usr/lib/modules/*/updates/dkms/nvidia*.ko*"]
    return any(glob.glob(str(sp(p))) for p in pats)


def gpu_name(dev):
    if sysroot() == Path("/") and shutil.which("lspci"):
        line = run(["lspci", "-s", dev["addr"]]).strip()
        if ": " in line:
            name = line.split(": ", 1)[1]
            m = re.search(r"\[([^\]]*(?:GeForce|RTX|GTX|Radeon|Arc|UHD|Iris)[^\]]*)\]", name)
            return (VENDOR_NAMES.get(dev["vendor"], "") + " " + m.group(1)).strip() if m else name
    return VENDOR_NAMES.get(dev["vendor"], dev["vendor"]) + " graphics"


def legion_mux():
    """Out-of-tree legion_laptop driver: 'gsync' = dGPU-only (MUX). Read-only here: we only show it."""
    for f in sp("/sys/bus/platform/drivers/legion").glob("*/gsync"):
        return read_int(f)
    return None


def boot_id():
    return read(sp("/proc/sys/kernel/random/boot_id"), "")


def gpu_status(syscfg=None, names=True):
    syscfg = syscfg or system_conf()
    devs = pci_display_devices()
    nv = [d for d in devs if d["vendor"] == NVIDIA]
    ig = [d for d in devs if d["vendor"] != NVIDIA]
    integrated_files = sp("/etc/modprobe.d/00-phoenixge-gpu-integrated.conf").exists()
    pend = read(sp("/var/lib/phoenixge/laptop-gpu-reboot"), "")
    st = {"igpu": gpu_name(ig[0]) if ig and names else (VENDOR_NAMES.get(ig[0]["vendor"], "") if ig else ""),
          "dgpu": gpu_name(nv[0]) if nv and names else ("NVIDIA" if nv else ""),
          "has_igpu": bool(ig), "has_nvidia": bool(nv), "hybrid": bool(ig and nv),
          "driver": nvidia_driver_installed(), "driver_loaded": any(d["driver"] == "nvidia" for d in nv),
          "mode": syscfg.get("GPU_MODE", "auto"), "integrated_active": integrated_files,
          "dgpu_state": "", "reboot_pending": bool(pend and pend == boot_id()),
          "nv_sleep_ac": syscfg.get("NV_SLEEP_AC", "1") == "1", "nv_sleep_bat": syscfg.get("NV_SLEEP_BAT", "1") == "1",
          "legion_mux": legion_mux(), "live": sp("/run/live").exists()}
    if nv:
        rs = nv[0]["runtime_status"]
        st["dgpu_state"] = "asleep" if rs == "suspended" else ("awake" if rs == "active" else rs)
    elif integrated_files:
        st["dgpu_state"] = "off"
    if not ig and nv:
        st["effective"] = "nvidia"          # BIOS 'dGPU only' / discrete mode: the iGPU is hidden by the firmware
    elif integrated_files:
        st["effective"] = "integrated"
    elif ig and nv:
        st["effective"] = "hybrid"
    else:
        st["effective"] = "single"
    st["can_integrated"] = bool(ig) and (bool(nv) or integrated_files) and not st["live"]
    st["can_hybrid"] = (bool(ig) and (bool(nv) or integrated_files)) and not st["live"]
    st["can_nvidia"] = False   # needs the firmware MUX; see nvidia_hint
    st["nvidia_hint"] = ("NVIDIA-only mode is a firmware switch on this laptop: restart, press F2 for the BIOS/UEFI setup and "
                         "set 'GPU Working Mode' (or 'Graphics Device') to 'Discrete' / 'dGPU'. Choose 'Hybrid'/'Dynamic' there "
                         "to come back." if (nv or integrated_files) else "")
    return st


# ------------------------------------------------------------------ screens (kscreen-doctor, user session only)
def parse_kscreen(text):
    """`kscreen-doctor -j` -> internal panel {name, mode_id, width, height, refresh, modes:[{id, refresh}]} or None."""
    try:
        data = json.loads(text)
    except Exception:
        return None
    for o in data.get("outputs", []):
        name = o.get("name", "")
        internal = name.startswith(("eDP", "LVDS", "DSI")) or o.get("type") in (7, "Panel", "Internal")
        if not internal or not o.get("enabled", True) or not o.get("connected", True):
            continue
        modes = o.get("modes", [])
        cur = next((m for m in modes if str(m.get("id")) == str(o.get("currentModeId"))), None)
        if not cur:
            continue
        w, h = cur.get("size", {}).get("width"), cur.get("size", {}).get("height")
        same = [{"id": str(m["id"]), "refresh": round(float(m.get("refreshRate", 0)), 2)} for m in modes
                if m.get("size", {}).get("width") == w and m.get("size", {}).get("height") == h]
        same.sort(key=lambda m: m["refresh"])
        return {"name": name, "mode_id": str(cur["id"]), "width": w, "height": h,
                "refresh": round(float(cur.get("refreshRate", 0)), 2), "modes": same}
    return None


def panel():
    if not shutil.which("kscreen-doctor"):
        return None
    return parse_kscreen(run(["kscreen-doctor", "-j"], timeout=10))


def refresh_options(p):
    """Distinct whole-Hz refresh rates of the panel at its current resolution."""
    seen = []
    for m in (p or {}).get("modes", []):
        hz = int(round(m["refresh"]))
        if hz not in seen:
            seen.append(hz)
    return seen


def pick_mode(p, target):
    """Mode id for target ('max' or Hz) at the current resolution; None if nothing to change."""
    if not p or not p["modes"]:
        return None
    if target == "max":
        m = max(p["modes"], key=lambda m: m["refresh"])
    else:
        try:
            hz = float(target)
        except (TypeError, ValueError):
            return None
        m = min(p["modes"], key=lambda m: (abs(m["refresh"] - hz), -m["refresh"]))
    return None if m["id"] == p["mode_id"] else m["id"]


def set_panel_mode(p, mode_id):
    if p and mode_id:
        run(["kscreen-doctor", f"output.{p['name']}.mode.{mode_id}"], timeout=15)


# ------------------------------------------------------------------ configs
def user_conf():
    c = configparser.ConfigParser()
    c.read(user_conf_path())
    sec = c["smart-battery"] if c.has_section("smart-battery") else {}
    return {k: sec.get(k, v) for k, v in USER_DEFAULTS.items()}


def save_user_conf(values):
    cur = user_conf()
    cur.update({k: str(v) for k, v in values.items() if k in USER_DEFAULTS})
    c = configparser.ConfigParser()
    c["smart-battery"] = cur
    path = user_conf_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        f.write("# PhoenixGe laptop settings (smart battery). Charge limit and graphics live in /etc/phoenixge/laptop.conf.\n")
        c.write(f)
    return cur


def validate_user(key, value):
    value = str(value).strip()
    if key == "mode":
        return value in ("auto", "manual", "off")
    if key == "bat_profile":
        return value in ("keep",) + PROFILES
    if key == "ac_profile":
        return value in ("keep", "restore") + PROFILES
    if key in ("bat_refresh", "ac_refresh"):
        words = ("keep",) if key == "bat_refresh" else ("keep", "restore", "max")
        return value in words or (value.isdigit() and 20 <= int(value) <= 500)
    if key == "notify":
        return value in ("true", "false")
    return False


def system_conf():
    out = dict(SYSTEM_DEFAULTS)
    for line in (read(sp("/etc/phoenixge/laptop.conf"), "") or "").splitlines():
        m = re.match(r"\s*([A-Z_]+)=([\w.-]*)\s*$", line)
        if m and m.group(1) in out:
            out[m.group(1)] = m.group(2)
    return out


def load_state():
    try:
        return json.loads(state_path().read_text())
    except Exception:
        return {}


def save_state(st):
    p = state_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(st, indent=1))


# ------------------------------------------------------------------ status (Center + tray)
def charge_status(syscfg=None, state=None):
    syscfg = syscfg or system_conf()
    state = state if state is not None else load_state()
    cc = charge_control()
    st = {"supported": cc["kind"] != "none", "kind": cc["kind"], "mode": syscfg["CHARGE_MODE"],
          "once": sp("/var/lib/phoenixge/laptop-charge-once").exists(), "slider": cc["kind"] == "threshold"}
    if cc["kind"] == "ideapad":
        st["protect"] = cc["value"] == 1
        stop = observed_stop(state)
        st["stop_text"] = f"about {stop}% (measured on this laptop)" if stop else "about 60-80% (the exact level depends on the model)"
        st["actual"] = cc["value"]
        st["external_change"] = (not st["once"]) and (cc["value"] == 1) != (syscfg["CHARGE_PROTECT"] == "1")
    elif cc["kind"] == "threshold":
        v = cc["value"] or 100
        st["protect"] = v < 100
        st["actual"] = v
        st["limit"] = int(syscfg["CHARGE_LIMIT"]) if syscfg["CHARGE_LIMIT"].isdigit() else 80
        st["stop_text"] = f"{v}%"
        want = st["limit"] if syscfg["CHARGE_PROTECT"] == "1" else 100
        st["external_change"] = (not st["once"]) and v != want
    return st


def status(fast=False):
    syscfg = system_conf()
    state = load_state()
    laptop = is_laptop()
    out = {"laptop": laptop, "on_battery": on_battery() if laptop else False, "live": sp("/run/live").exists()}
    if not laptop:
        return out
    out["battery"] = battery_info(use_upower=not fast)
    if shutil.which("powerprofilesctl"):
        out["power_profile"] = run(["powerprofilesctl", "get"]).strip()
    smart = dict(user_conf())
    smart["running"] = bool(state.get("watcher_pid")) and Path(f"/proc/{state.get('watcher_pid')}").exists()
    if not fast:
        p = panel()
        smart["panel"] = {"name": p["name"], "refresh": p["refresh"], "options": refresh_options(p)} if p else None
    out["smart"] = smart
    out["charge"] = charge_status(syscfg, state)
    out["gpu"] = gpu_status(syscfg, names=not fast)
    out["automatic"] = smart["mode"] == "auto" and syscfg["CHARGE_MODE"] == "auto" and syscfg["GPU_MODE"] == "auto"
    return out


# ------------------------------------------------------------------ smart battery (user session)
def powerprofile_get():
    return run(["powerprofilesctl", "get"]).strip() if shutil.which("powerprofilesctl") else ""


def powerprofile_set(p):
    if p in PROFILES and shutil.which("powerprofilesctl"):
        run(["powerprofilesctl", "set", p])


def notify(title, body):
    if shutil.which("notify-send"):
        run(["notify-send", "-a", "PhoenixGe", "-i", "battery-good", title, body])


def plan_battery(conf, state, pnl):
    """What to do when the charger is unplugged -> (profile or None, refresh target or None)."""
    if conf["mode"] == "off":
        return None, None
    if conf["mode"] == "auto":
        learned = state.get("learned", {})
        prof = learned.get("bat_profile", "power-saver")
        ref = learned.get("bat_refresh", 60)
    else:
        prof = None if conf["bat_profile"] == "keep" else conf["bat_profile"]
        ref = None if conf["bat_refresh"] == "keep" else conf["bat_refresh"]
    if ref is not None and pnl and float(ref) >= pnl["refresh"] - 0.5:
        ref = None   # already at or below the battery rate
    return prof, ref


def plan_ac(conf, state, pnl):
    """What to do when the charger is plugged in -> (profile or None, refresh target or None)."""
    if conf["mode"] == "off":
        return None, None
    saved = state.get("ac", {})
    if conf["mode"] == "auto":
        prof = saved.get("profile") or "balanced"
        ref = saved.get("refresh") or "max"
    else:
        prof = {"keep": None, "restore": saved.get("profile") or "balanced"}.get(conf["ac_profile"], conf["ac_profile"])
        ref = {"keep": None, "restore": saved.get("refresh") or "max"}.get(conf["ac_refresh"], conf["ac_refresh"])
    return prof, ref


def to_battery(conf, state, pnl=None, apply=True):
    """Charger unplugged: remember the user's AC values, switch to the battery values."""
    state["ac"] = {"profile": powerprofile_get() if apply else state.get("ac", {}).get("profile"),
                   "refresh": pnl["refresh"] if pnl else None}
    prof, ref = plan_battery(conf, state, pnl)
    done = []
    if prof and apply:
        powerprofile_set(prof); done.append(PROFILE_NAMES.get(prof, prof))
    if ref is not None and pnl:
        mid = pick_mode(pnl, ref)
        if mid:
            if apply:
                set_panel_mode(pnl, mid)
            hz = next(m["refresh"] for m in pnl["modes"] if m["id"] == mid)
            done.append(f"screen {int(round(hz))} Hz")
    state["bat_applied"] = {"profile": prof, "refresh": float(ref) if ref is not None else None}
    return done


def to_ac(conf, state, pnl=None, apply=True):
    """Charger plugged in: learn what the user changed on battery (auto mode), restore the AC values."""
    applied = state.get("bat_applied") or {}
    if conf["mode"] == "auto" and applied:
        learned = state.setdefault("learned", {})
        cur = powerprofile_get() if apply else state.get("_test_profile")
        if applied.get("profile") and cur in PROFILES and cur != applied["profile"]:
            learned["bat_profile"] = cur
        if applied.get("refresh") and pnl and abs(pnl["refresh"] - applied["refresh"]) > 1:
            learned["bat_refresh"] = int(round(pnl["refresh"]))
    prof, ref = plan_ac(conf, state, pnl)
    if prof and apply:
        powerprofile_set(prof)
    if ref is not None and pnl:
        mid = pick_mode(pnl, ref)
        if mid and apply:
            set_panel_mode(pnl, mid)
    state["bat_applied"] = {}
    return prof, ref
