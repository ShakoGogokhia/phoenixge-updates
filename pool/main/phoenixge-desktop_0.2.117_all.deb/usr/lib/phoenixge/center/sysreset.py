"""PhoenixGe Center > Reset: like Windows "Reset this PC - keep my files".

  Reset settings      the desktop (or all apps') settings go back to PhoenixGe's defaults at the next login; the old ones
                      are moved to ~/PhoenixGe-reset-backup-<date> (can be put back). No password.
  Reset system        the operating system goes back to the factory state, /home is kept:
                      btrfs + factory snapshot -> the snapshot (accounts, passwords, Wi-Fi of today are kept)
                      otherwise -> apt repair: apps installed later are removed (list shown first), removed factory
                      packages come back, changed system files are reinstalled, PhoenixGe's /etc defaults re-applied.
                      Needs the word RESET typed in.
  Remove installed apps (optional)  Flatpak apps installed after setup (user + system).

build(center) -> QWidget        python3 sysreset.py [--demo]
helpers: sysreset-user.sh (user), sysreset-system.sh (--status/--plan as user, --apply as root), sysreset-factory-snapshot.sh
"""
import os
import sys
import threading
from pathlib import Path

from PySide6.QtCore import QProcess, Qt
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox, QHBoxLayout, QLabel, QLineEdit, QMessageBox,
                               QPlainTextEdit, QPushButton, QVBoxLayout, QWidget)

sys.path.insert(0, str(Path(__file__).resolve().parent))
from systools_ui import DEMO, GREEN, GREY, RED, YELLOW, Bridge, dim, dot, facts, sh  # noqa: E402
from systools_ui import ui  # noqa: E402

LIB = "/usr/lib/phoenixge"
USER = f"{LIB}/sysreset-user.sh"
SYSTEM = f"{LIB}/sysreset-system.sh"
FACTORY = f"{LIB}/sysreset-factory-snapshot.sh"

DEMO_STATUS = dict(method="apt", btrfs="0", factory_snapshot="", manifest_kind="firstboot", timeshift="1",
                   factory_recorded="2026-11-13 18:02:11 firstboot")
DEMO_PLAN = dict(METHOD=["apt"], MANIFEST=["firstboot"],
                 REMOVE=["audacity", "blender", "gimp", "kdenlive", "obs-studio", "vlc"],
                 ALSO=["blender-data", "libavcodec-extra61", "libmlt7", "obs-plugins", "vlc-plugin-base"],
                 MISSING=["kcalc", "okular"], CHANGED=["libqt6core6t64", "plasma-workspace", "python3-pyside6.qtcore"],
                 BLOCKED=[], PLANHASH=["3f2a9c0d11ab"])
DEMO_FLATPAKS = ["com.spotify.Client", "org.telegram.desktop", "com.obsproject.Studio"]


def parse_kv(text):
    return dict(l.split("=", 1) for l in text.splitlines() if "=" in l)


def parse_plan(text):
    out = {}
    for l in text.splitlines():
        k, _, v = l.partition(" ")
        if k.isupper() and v:
            out.setdefault(k, []).append(v.strip())
    return out


def user_flatpaks():
    if DEMO:
        return ["org.telegram.desktop"]
    return [x for x in sh("flatpak list --user --app --columns=application 2>/dev/null", 20).split() if x]


class ConfirmReset(QDialog):
    """The big one: lists what happens, needs RESET typed in."""

    def __init__(self, parent, html):
        super().__init__(parent)
        self.setWindowTitle("Reset PhoenixGe")
        lay = QVBoxLayout(self)
        t = QLabel(html); t.setWordWrap(True); t.setTextFormat(Qt.RichText); lay.addWidget(t)
        lay.addWidget(QLabel("Type <b>RESET</b> to continue:"))
        self.e = QLineEdit(); self.e.setPlaceholderText("RESET"); lay.addWidget(self.e)
        bb = QDialogButtonBox(QDialogButtonBox.Cancel)
        self.go = bb.addButton("Reset now", QDialogButtonBox.AcceptRole); self.go.setEnabled(False); self.go.setObjectName("primary")
        self.e.textChanged.connect(lambda s: self.go.setEnabled(s.strip() == "RESET"))
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject); lay.addWidget(bb)
        self.setMinimumWidth(560)


class ResetPage(QWidget):
    def __init__(self, center):
        super().__init__()
        self.center = center
        Card, page, _F = ui(center)
        w, lay = page("Reset PhoenixGe", "Start fresh without reinstalling - like \"Reset this PC\" on Windows. Your files in "
                                         "the home folder (documents, pictures, downloads, games) are always kept.")
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0); outer.addWidget(w)
        self.bridge = Bridge(); self.bridge.result.connect(self.on_result)
        self.plan, self.status, self.flatpaks = None, {}, []

        # ---- 1. settings
        s = Card("1. Reset settings", "The desktop goes back to how PhoenixGe looks after installing: Ember theme, taskbar, "
                 "start menu, shortcuts, widgets. Your old settings are moved to a backup folder in your home folder, "
                 "not deleted. Kept: language, keyboard layouts, screen setup, Wi-Fi.")
        self.all_apps = QCheckBox("Also reset the settings of all apps")
        s.lay.addWidget(self.all_apps)
        n = dim("Apps like Chrome, Discord and VS Code then forget their logins too. Firefox, Steam and Flatpak apps are "
                "never affected."); n.setContentsMargins(26, 0, 0, 0); s.lay.addWidget(n)
        row = QHBoxLayout()
        self.set_btn = QPushButton("Reset settings…"); self.set_btn.setObjectName("primary"); self.set_btn.clicked.connect(self.reset_settings)
        self.set_show = QPushButton("What will be reset?"); self.set_show.clicked.connect(self.show_settings_list)
        self.set_cancel = QPushButton("Cancel the scheduled reset"); self.set_cancel.clicked.connect(self.cancel_settings)
        row.addWidget(self.set_btn); row.addWidget(self.set_show); row.addWidget(self.set_cancel); row.addStretch()
        s.lay.addLayout(row)
        self.set_state = dim(""); self.set_state.hide(); s.lay.addWidget(self.set_state)
        brow = QHBoxLayout()
        self.backups = QComboBox(); self.backups.setMinimumWidth(320)
        self.restore_btn = QPushButton("Restore settings from this backup"); self.restore_btn.clicked.connect(self.restore_backup)
        brow.addWidget(QLabel("Backups:")); brow.addWidget(self.backups); brow.addWidget(self.restore_btn); brow.addStretch()
        s.lay.addLayout(brow)
        lay.addWidget(s)

        # ---- 2. system
        self.sys_card = Card("2. Reset system (keep my files)")
        self.sys_head = QVBoxLayout(); self.sys_card.lay.addLayout(self.sys_head)
        self.opt_apps = QCheckBox("Remove apps I installed after setup (apt)"); self.opt_apps.setChecked(True)
        self.opt_flat = QCheckBox("Also remove Flatpak apps I installed (Discover / Store)")
        self.opt_full = QCheckBox("Thorough: reinstall every system package (slow, downloads about 3 GB)")
        self.opt_full.toggled.connect(lambda _on: self.plan and self.load_plan())
        for c in (self.opt_apps, self.opt_flat, self.opt_full):
            self.sys_card.lay.addWidget(c)
        for c in (self.opt_apps, self.opt_flat):   # the list below follows the options
            c.toggled.connect(lambda _on: self.plan and self.show_plan())
        self.plan_box = QPlainTextEdit(); self.plan_box.setReadOnly(True); self.plan_box.setMinimumHeight(210)
        self.plan_box.setPlaceholderText("Press \"Check what a reset would do\" - nothing is changed by checking.")
        self.sys_card.lay.addWidget(self.plan_box)
        row = QHBoxLayout()
        self.plan_btn = QPushButton("Check what a reset would do"); self.plan_btn.clicked.connect(self.load_plan)
        self.sys_btn = QPushButton("Reset system…"); self.sys_btn.setObjectName("primary"); self.sys_btn.setEnabled(False)
        self.sys_btn.clicked.connect(self.reset_system)
        self.reboot_btn = QPushButton("Restart now"); self.reboot_btn.hide()
        self.reboot_btn.clicked.connect(lambda: sh("qdbus6 org.kde.LogoutPrompt /LogoutPrompt promptReboot 2>/dev/null || systemctl reboot"))
        row.addWidget(self.plan_btn); row.addWidget(self.sys_btn); row.addWidget(self.reboot_btn); row.addStretch()
        self.sys_card.lay.addLayout(row)
        lay.addWidget(self.sys_card)

        # ---- 3. reset point
        p = Card("Reset point", "The factory state is recorded automatically when PhoenixGe finishes its first-start setup. "
                 "You can make the current system the new reset point - for example after setting everything up the way "
                 "you like it.")
        self.point = dim(""); p.lay.addWidget(self.point)
        pb = QPushButton("Use the current system as the reset point…"); pb.clicked.connect(self.new_point)
        p.lay.addWidget(pb, 0, Qt.AlignLeft)
        lay.addWidget(p); lay.addStretch()
        self.shown_once = False

    def showEvent(self, e):
        super().showEvent(e)
        if not self.shown_once:
            self.shown_once = True
            self.refresh()

    # ---------------------------------------------------------------- status
    def refresh(self):
        self.status = DEMO_STATUS if DEMO else parse_kv(sh(["sh", SYSTEM, "--status"], 30))
        st = self.status
        while self.sys_head.count():
            it = self.sys_head.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
            elif it.layout():
                _clear(it.layout())
        if st.get("live") == "1":
            self.sys_head.addWidget(dim("This is the live session - there is nothing to reset."))
            self.plan_btn.setEnabled(False)
        snap = st.get("method") == "snapshot"
        kind = st.get("manifest_kind", "none")
        if snap:
            how = (f"Your system goes back to the factory snapshot from {pretty(st.get('factory_snapshot', ''))} (btrfs). "
                   "It is exact and quick; the current system is kept as an extra snapshot, so even this can be undone.")
            keep = ("Everything in /home, user accounts and their current passwords, Wi-Fi networks, computer name, "
                    "time zone. Apps and system changes made after that point are gone (Flatpak apps installed for all "
                    "users too).")
        else:
            src = {"firstboot": "the list of packages recorded when PhoenixGe was set up",
                   "iso": "the package list of the PhoenixGe installer (this computer has no recorded factory point)",
                   "none": "nothing - this system has no factory list, so only damaged packages are repaired"}[kind]
            how = ("PhoenixGe repairs the system with the package manager, using " + src + ": apps you installed later "
                   "are removed, factory apps you removed come back, system files that were changed are reinstalled "
                   "fresh, and PhoenixGe's settings in /etc are restored.")
            keep = ("Everything in /home, user accounts and passwords, Wi-Fi networks, drivers (NVIDIA), kernels. "
                    "A snapshot is saved first when backups are on (Backups page).")
            if st.get("btrfs") == "1":
                how += " (There is no factory snapshot on this computer yet - see Reset point below.)"
        self.sys_head.addWidget(facts([("Method", "Factory snapshot" if snap else "Repair with the package manager"),
                                       ("How", how), ("Kept", keep)]))
        self.opt_apps.setVisible(not snap); self.opt_full.setVisible(not snap)
        rec = st.get("factory_recorded", "")
        if rec.startswith("late") or not rec:
            self.point.setText("No reset point recorded on this computer" + (" (it was set up before this feature existed)."
                                                                             if rec.startswith("late") else "."))
        else:
            parts = rec.split()
            self.point.setText(f"Reset point: {parts[0]} {parts[1][:5] if len(parts) > 1 else ''} "
                               f"({'made by you' if 'manual' in rec else 'after the first-start setup'})"
                               + (" - with a system snapshot." if snap else " - package list."))
        self.refresh_settings_state()

    def refresh_settings_state(self):
        pend = "pending" in (sh(["sh", USER, "--pending"]) if not DEMO else "")
        self.set_cancel.setVisible(pend)
        self.set_state.setText("A settings reset is scheduled for your next login." if pend else "")
        self.set_state.setVisible(pend)
        self.backups.clear()
        bl = ["/home/you/PhoenixGe-reset-backup-2026-11-02_19-40-12"] if DEMO else [b for b in sh(["sh", USER, "--backups"]).splitlines() if b]
        for b in bl:
            self.backups.addItem(Path(b).name.replace("PhoenixGe-reset-backup-", "").replace("_", " ").replace("-before-restore", " (before restore)"), b)
        self.backups.setEnabled(bool(bl)); self.restore_btn.setEnabled(bool(bl))
        if not bl:
            self.backups.addItem("no backups yet")

    # ---------------------------------------------------------------- settings
    def show_settings_list(self):
        args = ["--list"] + (["--all"] if self.all_apps.isChecked() else [])
        items = sh(["sh", USER, *args]).splitlines() if not DEMO else [".config/kdeglobals", ".config/kwinrc"]
        QMessageBox.information(self, "Reset settings", f"{len(items)} settings will be moved to the backup folder:\n\n"
                                + "\n".join("~/" + i for i in items[:60]) + ("\n…" if len(items) > 60 else ""))

    def reset_settings(self):
        allapps = self.all_apps.isChecked()
        ans = QMessageBox.question(self, "Reset settings",
                                   "Your desktop settings" + (" and the settings of all apps" if allapps else "") +
                                   " are reset at the next login. The old ones are kept in a backup folder in your home "
                                   "folder.\n\nLog out now to do it? (No = at the next login)",
                                   QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel)
        if ans == QMessageBox.Cancel:
            return
        sh(["sh", USER, "--schedule"] + (["--all"] if allapps else []))
        self.refresh_settings_state()
        if ans == QMessageBox.Yes:
            logout()

    def cancel_settings(self):
        sh(["sh", USER, "--cancel"]); self.refresh_settings_state()

    def restore_backup(self):
        b = self.backups.currentData()
        if not b:
            return
        if QMessageBox.question(self, "Restore settings", f"Put the settings from\n{b}\nback at the next login? (The current "
                                "settings are kept in another backup.)\n\nLog out now?") != QMessageBox.Yes:
            return
        sh(["sh", USER, "--restore", b]); self.refresh_settings_state(); logout()

    # ---------------------------------------------------------------- system
    def load_plan(self):
        self.plan_btn.setEnabled(False); self.sys_btn.setEnabled(False)
        self.plan_box.setPlainText("Checking the system… (this reads every installed package, about a minute)")
        full = self.opt_full.isChecked()

        def work():
            if DEMO:
                self.bridge.result.emit(("plan", DEMO_PLAN, DEMO_FLATPAKS + user_flatpaks())); return
            p = parse_plan(sh(["sh", SYSTEM, "--plan"] + (["--full"] if full else []), 600))
            fl = [x for x in sh(["sh", SYSTEM, "--flatpak-plan"], 30).split() if x] + user_flatpaks()
            self.bridge.result.emit(("plan", p, fl))
        threading.Thread(target=work, daemon=True).start()

    def on_result(self, r):
        if r[0] == "plan":
            self.plan, self.flatpaks = r[1], list(dict.fromkeys(r[2]))
            self.show_plan()

    def show_plan(self):
        p = self.plan
        self.plan_btn.setEnabled(True); self.plan_btn.setText("Check again")
        if not p.get("PLANHASH"):
            self.plan_box.setPlainText("Could not check the system. Is this the installed PhoenixGe?"); return
        lines = []
        if p.get("METHOD", [""])[0] == "snapshot":
            lines.append(f"Going back to the factory snapshot {p.get('SNAPSHOT', ['?'])[0]}.")
            lines.append("Everything installed or changed in the system since then is undone. /home is not touched.")
        else:
            rm, also, miss, ch, bl = (p.get(k, []) for k in ("REMOVE", "ALSO", "MISSING", "CHANGED", "BLOCKED"))
            lines.append(f"Apps installed after setup - removed ({len(rm)}):" if self.opt_apps.isChecked()
                         else f"Apps installed after setup - KEPT ({len(rm)}):")
            lines.append("   " + (", ".join(rm) or "none"))
            if also and self.opt_apps.isChecked():
                lines.append(f"…and packages that are part of them ({len(also)}): " + ", ".join(also[:30]) + (" …" if len(also) > 30 else ""))
            if bl:
                lines.append("!! Removing them would also remove system packages (" + ", ".join(bl[:10]) + ") - so apps are NOT "
                             "removed. Remove them yourself in Discover if you want.")
            lines.append(f"Factory apps that were removed - installed again ({len(miss)}): " + (", ".join(miss[:40]) or "none"))
            lines.append(f"System packages with changed or missing files - reinstalled ({len(ch)}): " + (", ".join(ch[:40]) or "none")
                         + (" …" if len(ch) > 40 else ""))
            lines.append("PhoenixGe's settings in /etc - restored.")
        if self.flatpaks or self.opt_flat.isChecked():
            lines.append(("Flatpak apps - removed: " if self.opt_flat.isChecked() else "Flatpak apps - kept (option above): ")
                         + (", ".join(self.flatpaks) or "none"))
        self.plan_box.setPlainText("\n".join(lines))
        self.sys_btn.setEnabled(True)

    def reset_system(self):
        p = self.plan
        if not p:
            return
        snap = p.get("METHOD", [""])[0] == "snapshot"
        n_rm = len(p.get("REMOVE", [])) if self.opt_apps.isChecked() and not p.get("BLOCKED") else 0
        html = ("<h3>Reset the system?</h3><p>" +
                ("The system goes back to the <b>factory snapshot</b>. Apps and system changes since then are gone. "
                 if snap else f"<b>{n_rm}</b> apps are removed, damaged system files are reinstalled, PhoenixGe's "
                              "defaults are restored. This downloads packages and can take 10-40 minutes. ") +
                "<b>Your files in /home stay.</b></p><p>Save your work and keep the computer plugged in. "
                "A restart is needed at the end.</p>")
        d = ConfirmReset(self, html)
        if d.exec() != QDialog.Accepted:
            return
        self.sys_btn.setEnabled(False); self.plan_btn.setEnabled(False)
        args = ["--apply", p["PLANHASH"][0]]
        if self.opt_full.isChecked():
            args.append("--full")
        if self.opt_flat.isChecked():
            args.append("--flatpaks")
        if not self.opt_apps.isChecked():
            args.append("--keep-apps")

        def done(code):
            self.plan_btn.setEnabled(True)
            if code == 0:
                self.reboot_btn.show(); self.reboot_btn.setObjectName("primary"); self.reboot_btn.style().polish(self.reboot_btn)
                QMessageBox.information(self, "Reset PhoenixGe", "Done. Restart the computer to finish.")
            else:
                QMessageBox.warning(self, "Reset PhoenixGe", "The reset stopped - see the log below (also in "
                                    "/var/log/phoenixge-reset.log). Nothing in /home was touched.")
        if self.opt_flat.isChecked() and user_flatpaks():   # the user's own Flatpaks need no password
            self.center.runner.run("flatpak", ["uninstall", "--user", "--all", "-y", "--noninteractive"])
        self.center.runner.root(SYSTEM, args, done)

    def new_point(self):
        if QMessageBox.question(self, "Reset point", "Make the system as it is now the state that \"Reset system\" goes back "
                                "to? The previous reset point is replaced.") != QMessageBox.Yes:
            return
        self.center.runner.root(FACTORY, ["--now"], lambda _c: self.refresh())


def pretty(name):
    # 2026-11-13_18-02-11 -> 2026-11-13 18:02
    if len(name) >= 16:
        return name[:10] + " " + name[11:16].replace("-", ":")
    return name or "?"


def logout():
    if DEMO:
        return
    QProcess.startDetached("sh", ["-c", "qdbus6 org.kde.LogoutPrompt /LogoutPrompt promptLogout 2>/dev/null || "
                                        "qdbus org.kde.LogoutPrompt /LogoutPrompt promptLogout"])


def _clear(layout):
    while layout.count():
        it = layout.takeAt(0)
        if it.widget():
            it.widget().deleteLater()
        elif it.layout():
            _clear(it.layout())


def build(center):
    return ResetPage(center)


if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication
    app = QApplication(sys.argv)

    class _Host(QWidget):
        def __init__(self):
            super().__init__()
            lay = QVBoxLayout(self); self.log = QPlainTextEdit(); self.log.setMaximumHeight(120); self.log.hide()
            import center as cmod
            self.runner = cmod.Runner(self.log)
            lay.addWidget(build(self)); lay.addWidget(self.log)
    h = _Host(); h.resize(1000, 800); h.show()
    sys.exit(app.exec())
