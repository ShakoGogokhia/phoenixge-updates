"""Small shared pieces for the PhoenixGe Center system tools (sysreset.py, hibernate.py, netping.py).

ui(center) -> (Card, page, FlowGrid)  taken from the running Center (same look), small copies when run alone.
DEMO                                 True with --demo or PHOENIXGE_DEMO=1 (screenshots with made-up data)
"""
import os
import subprocess
import sys

from PySide6.QtCore import QObject, QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QFrame, QGridLayout, QLabel, QScrollArea, QVBoxLayout, QWidget

DEMO = "--demo" in sys.argv or os.environ.get("PHOENIXGE_DEMO") == "1"
GREEN, YELLOW, RED, GREY = "#3fb950", "#e3b341", "#f85149", "#8b949e"


def sh(cmd, timeout=10):
    try:
        return subprocess.run(cmd, shell=isinstance(cmd, str), capture_output=True, text=True, timeout=timeout).stdout.strip()
    except Exception:
        return ""


def ui(center=None):
    for name in (type(center).__module__ if center is not None else None, "__main__", "center"):
        mod = sys.modules.get(name) if name else None
        if mod is not None and hasattr(mod, "Card") and hasattr(mod, "page"):
            return mod.Card, mod.page, getattr(mod, "FlowGrid", None)

    class Card(QFrame):
        def __init__(self, title="", text=""):
            super().__init__()
            self.setObjectName("card")
            self.lay = QVBoxLayout(self); self.lay.setContentsMargins(18, 16, 18, 16); self.lay.setSpacing(8)
            if title:
                t = QLabel(title); t.setObjectName("cardTitle"); self.lay.addWidget(t)
            if text:
                x = QLabel(text); x.setWordWrap(True); x.setObjectName("dim"); self.lay.addWidget(x)

    def page(title, subtitle=""):
        w = QWidget(); outer = QVBoxLayout(w); outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame)
        inner = QWidget(); lay = QVBoxLayout(inner); lay.setContentsMargins(36, 30, 36, 30); lay.setSpacing(16)
        h = QLabel(title); h.setObjectName("h1"); lay.addWidget(h)
        if subtitle:
            s = QLabel(subtitle); s.setObjectName("dim"); s.setWordWrap(True); lay.addWidget(s)
        scroll.setWidget(inner); outer.addWidget(scroll)
        return w, lay
    return Card, page, None


def accent():
    v = sh(["kreadconfig6", "--file", "kdeglobals", "--group", "General", "--key", "AccentColor"])
    try:
        r, g, b = (int(x) for x in v.split(",")[:3])
        return QColor(r, g, b).name()
    except Exception:
        return "#ff7a2e"


def dot(color, size=12, tip=""):
    d = QLabel(); d.setFixedSize(size, size)
    d.setStyleSheet(f"background:{color}; border-radius:{size // 2}px;")
    if tip:
        d.setToolTip(tip)
    return d


def dim(text):
    x = QLabel(text); x.setObjectName("dim"); x.setWordWrap(True)
    return x


def facts(rows):
    """Two-column label grid: [(key, value), ...]"""
    w = QWidget(); g = QGridLayout(w); g.setContentsMargins(0, 0, 0, 0); g.setHorizontalSpacing(18); g.setVerticalSpacing(4)
    for i, (k, v) in enumerate(rows):
        a = QLabel(k); a.setObjectName("dim"); g.addWidget(a, i, 0, Qt.AlignTop)
        b = QLabel(v); b.setWordWrap(True); b.setTextInteractionFlags(Qt.TextSelectableByMouse); g.addWidget(b, i, 1)
    g.setColumnStretch(1, 1)
    return w


class Bridge(QObject):
    """Thread -> UI thread."""
    result = Signal(object)


class LineGraph(QWidget):
    """Latency graph: one line per series, gaps + red ticks for lost packets. series: [(label, color, [ms or None])]"""

    def __init__(self, height=170):
        super().__init__()
        self.series, self.unit = [], "ms"
        self.setMinimumHeight(height)

    def set_series(self, series):
        self.series = series
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(40, 10, -10, -22)
        pal = self.palette()
        txt = pal.color(pal.ColorRole.PlaceholderText)
        vals = [v for _l, _c, s in self.series for v in s if v is not None]
        top = max(20.0, max(vals) * 1.2 if vals else 100.0)
        for step in (5, 10, 20, 25, 50, 100, 200, 250, 500, 1000):
            if top / step <= 5:
                break
        top = step * (int(top / step) + 1)
        f = QFont(self.font()); f.setPointSizeF(max(7.0, f.pointSizeF() - 1.5)); p.setFont(f)
        grid = QColor(txt); grid.setAlpha(50)
        y = 0
        while y <= top:
            yy = r.bottom() - r.height() * y / top
            p.setPen(QPen(grid, 1)); p.drawLine(QPointF(r.left(), yy), QPointF(r.right(), yy))
            p.setPen(txt); p.drawText(QRectF(0, yy - 8, 34, 16), Qt.AlignRight | Qt.AlignVCenter, f"{y:g}")
            y += step
        n = max((len(s) for _l, _c, s in self.series), default=0)
        width = 60
        p.setPen(txt)
        p.drawText(QRectF(r.left(), r.bottom() + 4, r.width(), 16), Qt.AlignLeft, f"{width} s ago")
        p.drawText(QRectF(r.left(), r.bottom() + 4, r.width(), 16), Qt.AlignRight, "now")
        dx = r.width() / (width - 1)
        for _label, color, s in self.series:
            s = s[-width:]
            off = width - len(s)
            path, started = QPainterPath(), False
            for i, v in enumerate(s):
                x = r.left() + (off + i) * dx
                if v is None:
                    started = False
                    p.setPen(QPen(QColor(RED), 2)); p.drawLine(QPointF(x, r.bottom()), QPointF(x, r.bottom() - 10))
                    continue
                pt = QPointF(x, r.bottom() - r.height() * min(v, top) / top)
                if started:
                    path.lineTo(pt)
                else:
                    path.moveTo(pt); started = True
            p.setPen(QPen(QColor(color), 2)); p.setBrush(Qt.NoBrush); p.drawPath(path)
        if not n:
            p.setPen(txt); p.drawText(r, Qt.AlignCenter, "Waiting for the first replies…")
        p.end()


class Bars(QWidget):
    """Signal-strength style bars (0-100)."""

    def __init__(self, value=0, color="#ff7a2e"):
        super().__init__()
        self.value, self.color = value, color
        self.setFixedSize(30, 20)

    def set_value(self, v):
        self.value = v; self.update()

    def paintEvent(self, _e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        off = QColor(self.palette().color(self.palette().ColorRole.PlaceholderText)); off.setAlpha(70)
        for i in range(4):
            h = 5 + i * 5
            on = self.value >= (i + 1) * 22
            p.setPen(Qt.NoPen); p.setBrush(QColor(self.color) if on else off)
            p.drawRoundedRect(QRectF(i * 7 + 1, 20 - h, 5, h), 1.5, 1.5)
        p.end()
