"""PhoenixGe Center > Desktop & touchpad: touchpad settings and gestures (presets + every gesture by hand),
monitors (per-monitor wallpaper) and taskbars on every monitor.

build(center) -> QWidget   (center = PhoenixGe Center main window; uses center.log if present)
Logic: /usr/lib/phoenixge/desktopsetup/ds_data.py (shared with the session agent).
Run alone:  python3 desktopsetup.py [--demo] [--shot out.png] [--size 1100x2200]
"""
import sys
import threading
from pathlib import Path

from PySide6.QtCore import QObject, QPointF, QProcess, QRectF, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QColor, QFont, QIcon, QPainter, QPainterPath, QPen, QPixmap
from PySide6.QtWidgets import (QButtonGroup, QCheckBox, QComboBox, QFileDialog, QFrame, QGridLayout, QHBoxLayout, QLabel,
                               QPushButton, QRadioButton, QScrollArea, QSizePolicy, QSlider, QVBoxLayout, QWidget)

_here = Path(__file__).resolve().parent
for p in (_here, _here.parent / "desktopsetup", Path("/usr/lib/phoenixge/desktopsetup")):
    sys.path.insert(0, str(p))
import ds_data as dd  # noqa: E402


def _ui():
    """Card / page / accent from center.py when we run inside it (same look), small copies otherwise."""
    main = sys.modules.get("__main__")
    if hasattr(main, "Card") and hasattr(main, "page"):
        return main.Card, main.page, getattr(main, "accent", lambda: "#ff7a2e")

    class Card(QFrame):
        def __init__(self, title="", text=""):
            super().__init__()
            self.setObjectName("card")
            self.lay = QVBoxLayout(self); self.lay.setContentsMargins(18, 16, 18, 16); self.lay.setSpacing(8)
            if title:
                t = QLabel(title); t.setObjectName("cardTitle"); self.lay.addWidget(t)
            if text:
                x = QLabel(text); x.setWordWrap(True); x.setObjectName("dim"); self.lay.addWidget(x)

    def page(title, subtitle=""):
        w = QWidget(); outer = QVBoxLayout(w); outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame)
        inner = QWidget(); lay = QVBoxLayout(inner); lay.setContentsMargins(36, 30, 36, 30); lay.setSpacing(16)
        h = QLabel(title); h.setObjectName("h1"); lay.addWidget(h)
        if subtitle:
            s = QLabel(subtitle); s.setObjectName("dim"); s.setWordWrap(True); lay.addWidget(s)
        scroll.setWidget(inner); outer.addWidget(scroll)
        return w, lay
    return Card, page, lambda: "#ff7a2e"


def dim(text):
    lab = QLabel(text); lab.setObjectName("dim"); lab.setWordWrap(True)
    return lab


def hint(text, acc):
    lab = QLabel(text); lab.setWordWrap(True)
    lab.setStyleSheet(f"background:{acc}1f; border:1px solid {acc}55; border-radius:10px; padding:8px 12px;")
    return lab


# ================================================================== drawings
def _arrow(p, a, b, head=7):
    p.drawLine(a, b)
    v = b - a
    ln = max((v.x() ** 2 + v.y() ** 2) ** 0.5, 1)
    ux, uy = v.x() / ln, v.y() / ln
    left = QPointF(b.x() - head * ux + head * 0.6 * uy, b.y() - head * uy - head * 0.6 * ux)
    right = QPointF(b.x() - head * ux - head * 0.6 * uy, b.y() - head * uy + head * 0.6 * ux)
    path = QPainterPath(b); path.lineTo(left); path.lineTo(right); path.closeSubpath()
    p.fillPath(path, p.pen().color())


class GestureTile(QWidget):
    """A little touchpad with finger dots and the movement, plus gesture name and action."""

    def __init__(self, kind, fingers, direction, title, action, acc, fixed=False):
        super().__init__()
        self.kind, self.n, self.dir, self.title, self.action = kind, fingers, direction, title, action
        self.acc, self.fixed = QColor(acc), fixed
        self.setFixedSize(176, 150)
        self.setToolTip(f"{title}: {action}" + (" (built into Plasma, cannot be changed)" if fixed else ""))

    def set_action(self, action):
        self.action = action; self.update()

    def paintEvent(self, _e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        pal = self.palette()
        fg, base = pal.text().color(), pal.base().color()
        off = self.action in ("Nothing", "")
        bg = QColor(self.acc); bg.setAlpha(18 if not off else 6)
        p.setPen(QPen(QColor(self.acc.red(), self.acc.green(), self.acc.blue(), 70), 1))
        p.setBrush(bg); p.drawRoundedRect(QRectF(1, 1, self.width() - 2, self.height() - 2), 14, 14)
        # touchpad
        pad = QRectF(38, 12, 100, 64)
        p.setPen(QPen(QColor(fg.red(), fg.green(), fg.blue(), 90), 1.4)); p.setBrush(base)
        p.drawRoundedRect(pad, 9, 9)
        col = QColor(self.acc) if not off else QColor(fg.red(), fg.green(), fg.blue(), 110)
        c = pad.center()
        dots = []
        if self.kind == "swipe":
            sp = 13
            for i in range(self.n):
                o = (i - (self.n - 1) / 2) * sp
                dots.append(QPointF(c.x() + o, c.y()))   # fingers side by side, as on a real touchpad
            d = {"up": (0, -1), "down": (0, 1), "left": (-1, 0), "right": (1, 0)}[self.dir]
            shift = QPointF(-d[0] * (8 + self.n * 4), -d[1] * 9)
            dots = [q + shift for q in dots]
            p.setPen(QPen(col, 2.2, Qt.SolidLine, Qt.RoundCap))
            a = QPointF(c.x() + d[0] * (self.n * 4), c.y() + d[1] * 4) + QPointF(d[0] * 6, d[1] * 6)
            b = a + QPointF(d[0] * 18, d[1] * 14)
            _arrow(p, a, b)
        else:  # pinch: fingers on a circle, arrows in or out
            import math
            r = 19
            for i in range(self.n):
                ang = -math.pi / 2 + i * 2 * math.pi / self.n
                dots.append(QPointF(c.x() + r * math.cos(ang), c.y() + r * 0.72 * math.sin(ang)))
            p.setPen(QPen(col, 1.8, Qt.SolidLine, Qt.RoundCap))
            for q in dots:
                v = q - c
                if self.dir == "in":
                    _arrow(p, q + v * 0.22, c + v * 0.42, 5)
                else:
                    _arrow(p, q + v * 0.25, q + v * 0.62, 5)
        p.setPen(Qt.NoPen); p.setBrush(col)
        for q in dots:
            p.drawEllipse(q, 5, 5)
        # text
        f = QFont(self.font()); f.setPixelSize(12); f.setBold(True); p.setFont(f)
        p.setPen(fg)
        p.drawText(QRectF(6, 84, self.width() - 12, 20), Qt.AlignCenter, self.title)
        f.setBold(False); p.setFont(f)
        p.setPen(QColor(self.acc) if not off else QColor(fg.red(), fg.green(), fg.blue(), 120))
        p.drawText(QRectF(8, 104, self.width() - 16, 40), Qt.AlignHCenter | Qt.AlignTop | Qt.TextWordWrap,
                   self.action + ("  • Plasma" if self.fixed else ""))


class MonitorMap(QWidget):
    """Monitors as seen from the front, scaled to fit, with their wallpaper inside."""
    picked = Signal(int)

    def __init__(self, acc):
        super().__init__()
        self.acc = QColor(acc); self.outs, self.walls, self.sel, self.rects = [], {}, 0, []
        self.setMinimumHeight(190); self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self._pix = {}

    def set_data(self, outs, walls):
        self.outs, self.walls = outs, walls
        self.sel = min(self.sel, max(len(outs) - 1, 0)); self.update()

    def pix(self, path):
        if path not in self._pix:
            self._pix[path] = QPixmap(path) if path else QPixmap()
        return self._pix[path]

    def mousePressEvent(self, e):
        for i, r in enumerate(self.rects):
            if r.contains(e.position()):
                self.sel = i; self.update(); self.picked.emit(i)

    def paintEvent(self, _e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.SmoothPixmapTransform)
        self.rects = []
        if not self.outs:
            return
        x0 = min(o["x"] for o in self.outs); y0 = min(o["y"] for o in self.outs)
        x1 = max(o["x"] + o["lw"] for o in self.outs); y1 = max(o["y"] + o["lh"] for o in self.outs)
        W, H = self.width() - 20, self.height() - 34
        s = min(W / max(x1 - x0, 1), H / max(y1 - y0, 1))
        ox = (self.width() - (x1 - x0) * s) / 2; oy = 6
        fg = self.palette().text().color()
        for i, o in enumerate(self.outs):
            r = QRectF(ox + (o["x"] - x0) * s + 3, oy + (o["y"] - y0) * s + 3, o["lw"] * s - 6, o["lh"] * s - 6)
            self.rects.append(r)
            path = QPainterPath(); path.addRoundedRect(r, 6, 6)
            pm = self.pix(self.walls.get(o["name"], ""))
            p.save(); p.setClipPath(path)
            if not pm.isNull():
                src = pm.size(); k = max(r.width() / src.width(), r.height() / src.height())
                tw, th = src.width() * k, src.height() * k
                p.drawPixmap(QRectF(r.center().x() - tw / 2, r.center().y() - th / 2, tw, th), pm, QRectF(pm.rect()))
            else:
                p.fillRect(r, QColor(40, 30, 28))
            p.fillRect(QRectF(r.left(), r.bottom() - 9, r.width(), 9), QColor(10, 8, 8, 200))  # taskbar strip
            p.restore()
            p.setPen(QPen(self.acc if i == self.sel else QColor(fg.red(), fg.green(), fg.blue(), 90),
                          3 if i == self.sel else 1.2))
            p.setBrush(Qt.NoBrush); p.drawRoundedRect(r, 6, 6)
            # badge
            f = QFont(self.font()); f.setBold(True); p.setFont(f)
            label = f"{i + 1}" + ("  ★" if o["primary"] else "")
            bw = p.fontMetrics().horizontalAdvance(label) + 16
            b = QRectF(r.left() + 8, r.top() + 8, bw, 22)
            p.setPen(Qt.NoPen); p.setBrush(QColor(0, 0, 0, 150)); p.drawRoundedRect(b, 11, 11)
            p.setPen(QColor("white")); p.drawText(b, Qt.AlignCenter, label)
            f.setBold(False); p.setFont(f); p.setPen(fg)
            p.drawText(QRectF(r.left(), r.bottom() + 6, r.width(), 18), Qt.AlignCenter,
                       f"{o['name']}  {o['w']}×{o['h']}")


class TileFlow(QWidget):
    """Fixed-size tiles in as many columns as fit (the Center can be narrow)."""

    def __init__(self, spacing=10):
        super().__init__()
        self.tiles, self.sp, self.cols = [], spacing, 0
        self.grid = QGridLayout(self); self.grid.setContentsMargins(0, 0, 0, 0); self.grid.setSpacing(spacing)
        self.grid.setAlignment(Qt.AlignLeft | Qt.AlignTop)

    def add(self, w):
        self.tiles.append(w); self.reflow()

    def reflow(self):
        tw = self.tiles[0].width() if self.tiles else 1
        cols = max(1, (self.width() + self.sp) // (tw + self.sp)) if self.width() > 50 else 4
        if cols == self.cols and self.grid.count() == len(self.tiles):
            return
        self.cols = cols
        for t in self.tiles:
            self.grid.removeWidget(t)
        for i, t in enumerate(self.tiles):
            self.grid.addWidget(t, i // cols, i % cols)

    def resizeEvent(self, e):
        super().resizeEvent(e); self.reflow()

    def minimumSizeHint(self):
        from PySide6.QtCore import QSize
        return QSize(self.tiles[0].width() if self.tiles else 0, 0)


# ================================================================== page
class _Bridge(QObject):
    loaded = Signal(object)


class DesktopSetupPage(QWidget):
    def __init__(self, center):
        super().__init__()
        self.center = center
        Card, page, accent = _ui()
        self.Card, self.acc = Card, accent()
        w, lay = page("Desktop & touchpad",
                      "Touchpad, gestures, monitors and taskbars. PhoenixGe sets good defaults by itself - "
                      "change anything you like here.")
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0); outer.addWidget(w)
        self.lay = lay
        self.bridge = _Bridge(); self.bridge.loaded.connect(self.populate)
        self.tp_card = Card("Touchpad"); lay.addWidget(self.tp_card)
        self.g_card = Card("Touchpad gestures"); lay.addWidget(self.g_card)
        self.m_card = Card("Monitors & wallpaper"); lay.addWidget(self.m_card)
        self.t_card = Card("Taskbars"); lay.addWidget(self.t_card)
        lay.addStretch()
        for c in (self.tp_card, self.m_card, self.t_card):
            c.lay.addWidget(dim("Looking…"))
        self.build_gestures()
        self.refresh()

    # ------------------------------------------------------------------ data
    def refresh(self):
        def work():
            data = {"tp": dd.touchpads(), "outs": dd.outputs(), "state": dd.plasma_state(),
                    "svc": dd.gesture_service_state(), "desks": dd.desktop_count(), "walls": dd.wallpapers()}
            self.bridge.loaded.emit(data)
        if dd.DEMO:
            work()
        else:
            threading.Thread(target=work, daemon=True).start()

    def populate(self, data):
        self.data = data
        self.build_touchpad(data["tp"])
        self.update_gesture_status(data["svc"], data["desks"], bool(data["tp"]))
        self.build_monitors(data["outs"], data["state"], data["walls"])
        self.build_taskbars(data["outs"], data["state"])

    def log(self, text):
        lg = getattr(self.center, "log", None)
        if lg is not None:
            lg.show(); lg.appendPlainText(text)

    @staticmethod
    def clear(card, keep=1):
        while card.lay.count() > keep:
            it = card.lay.takeAt(keep)
            if it.widget():
                it.widget().deleteLater()
            elif it.layout():
                _clear_layout(it.layout())

    # ------------------------------------------------------------------ touchpad
    def build_touchpad(self, tps):
        c = self.tp_card; self.clear(c)
        if not tps:
            c.lay.addWidget(dim("No touchpad found. Laptop touchpads and USB / Bluetooth trackpads appear here by "
                                "themselves as soon as they are connected."))
            return
        self.tp = tps[0]
        if len(tps) > 1:
            sel = QComboBox()
            for t in tps:
                sel.addItem(t.get("name", t["sysName"]))
            sel.currentIndexChanged.connect(lambda i: (setattr(self, "tp", tps[i]), self.build_touchpad_controls()))
            c.lay.addWidget(sel)
        self.tp_box = QVBoxLayout(); c.lay.addLayout(self.tp_box)
        self.build_touchpad_controls()

    def build_touchpad_controls(self):
        _clear_layout(self.tp_box)
        t = self.tp
        head = QHBoxLayout()
        icon = QLabel()
        ic = QIcon.fromTheme("input-touchpad")
        if ic.isNull():
            icon.setText("▭"); icon.setStyleSheet(f"font-size:30px; color:{self.acc};")
        else:
            icon.setPixmap(ic.pixmap(40, 40))
        name = QLabel(f"<b>{t.get('name', '?')}</b><br><span style='color:gray'>{t['sysName']} • "
                      f"USB id {int(t.get('vendor', 0)):04x}:{int(t.get('product', 0)):04x} • "
                      f"tap with up to {t.get('tapFingerCount', 3)} fingers</span>")
        head.addWidget(icon); head.addWidget(name, 1)
        self.tp_box.addLayout(head)
        self.tp_checks = {}
        grid = QGridLayout(); grid.setHorizontalSpacing(24); grid.setVerticalSpacing(6)
        order = ["tapToClick", "tapAndDrag", "naturalScroll", "disableWhileTyping", "clickMethodClickfinger",
                 "disableEventsOnExternalMouse", "pointerAccelerationProfileFlat"]
        i = 0
        for prop in order:
            sup = t.get("supports" + prop[0].upper() + prop[1:], True)
            if prop in ("tapToClick", "tapAndDrag"):
                sup = t.get("tapFingerCount", 1) > 0
            if prop not in t or not sup:
                continue
            cb = QCheckBox(dd.TP_PROPS[prop][1]); cb.setChecked(bool(t[prop]))
            self.tp_checks[prop] = cb
            grid.addWidget(cb, i, 0); i += 1
        self.tp_box.addLayout(grid)
        self.tp_sliders = {}
        sg = QGridLayout(); sg.setHorizontalSpacing(12)
        for row, (prop, lo, hi, scale, left, right) in enumerate([
                ("pointerAcceleration", -100, 100, 100.0, "Slow", "Fast"),
                ("scrollFactor", 10, 300, 100.0, "Slow", "Fast")]):
            if prop not in t:
                continue
            sl = QSlider(Qt.Horizontal); sl.setRange(lo, hi); sl.setValue(int(round(float(t[prop]) * scale)))
            sl.setPageStep(10)
            self.tp_sliders[prop] = (sl, scale)
            sg.addWidget(QLabel(dd.TP_PROPS[prop][1]), row, 0)
            sg.addWidget(dim(left), row, 1); sg.addWidget(sl, row, 2); sg.addWidget(dim(right), row, 3)
        sg.setColumnStretch(2, 1)
        self.tp_box.addLayout(sg)
        row = QHBoxLayout()
        ap = QPushButton("Apply"); ap.setObjectName("primary"); ap.clicked.connect(self.apply_touchpad)
        df = QPushButton("PhoenixGe defaults"); df.clicked.connect(self.touchpad_defaults)
        kc = QPushButton("More in System Settings"); kc.clicked.connect(lambda: QProcess.startDetached("kcmshell6", ["kcm_touchpad"]))
        self.tp_msg = dim("")
        row.addWidget(ap); row.addWidget(df); row.addWidget(kc); row.addStretch()
        self.tp_box.addLayout(row); self.tp_box.addWidget(self.tp_msg)
        auto = QCheckBox("Automatic defaults for new touchpads")
        auto.setToolTip("Tap to click, two-finger right click and ignore-while-typing, once for each new touchpad")
        auto.setChecked(dd.desk_cfg().get("touchpadAuto", True))
        auto.toggled.connect(lambda on: dd.save_desk_cfg(touchpadAuto=on))
        self.tp_box.addWidget(auto)
        self.tp_box.addWidget(dim("Tap to click, two-finger right click and ignore-while-typing are switched on once "
                                  "for every new touchpad. Your own changes are never overwritten."))

    def apply_touchpad(self):
        t, n = self.tp, 0
        for prop, cb in self.tp_checks.items():
            if bool(t.get(prop)) != cb.isChecked():
                if dd.set_touchpad(t["sysName"], prop, cb.isChecked()) or not dd.DEMO:
                    t[prop] = cb.isChecked(); n += 1
        for prop, (sl, scale) in self.tp_sliders.items():
            v = sl.value() / scale
            if abs(float(t.get(prop, 0)) - v) > 0.004:
                dd.set_touchpad(t["sysName"], prop, v); t[prop] = v; n += 1
        self.tp_msg.setText(f"Applied {n} change(s) - active now." if n else "Nothing changed.")
        cfg = dd.load_json(dd.DESKCFG, {})   # the user set this touchpad up - automatic defaults leave it alone
        key = f"{t.get('vendor')}:{t.get('product')}:{t.get('name')}"
        done = set(cfg.get("touchpadDefaultsDone", [])); done.add(key)
        dd.save_desk_cfg(touchpadDefaultsDone=sorted(done))

    def touchpad_defaults(self):
        for prop, val in dd.TP_DEFAULTS.items():
            if prop in self.tp_checks:
                self.tp_checks[prop].setChecked(val)
        for prop in ("naturalScroll",):
            if prop in self.tp_checks:
                self.tp_checks[prop].setChecked(False)
        if "pointerAccelerationProfileFlat" in self.tp_checks:
            self.tp_checks["pointerAccelerationProfileFlat"].setChecked(False)
        if "pointerAcceleration" in self.tp_sliders:
            self.tp_sliders["pointerAcceleration"][0].setValue(int(float(self.tp.get("defaultPointerAcceleration", 0)) * 100))
        if "scrollFactor" in self.tp_sliders:
            self.tp_sliders["scrollFactor"][0].setValue(100)
        self.apply_touchpad()

    # ------------------------------------------------------------------ gestures
    def build_gestures(self):
        c = self.g_card
        c.lay.addWidget(dim("Swipe or pinch with three or four fingers. Pick a style, or choose each gesture yourself."))
        self.preset, self.gmap = dd.gesture_config()
        prow = QHBoxLayout(); self.pbtn = {}
        grp = QButtonGroup(self); grp.setExclusive(True)
        for pid, (label, _m) in dd.PRESETS.items():
            b = QPushButton(label); b.setCheckable(True); grp.addButton(b); self.pbtn[pid] = b
            b.clicked.connect(lambda _=False, k=pid: self.pick_preset(k)); prow.addWidget(b)
        self.custom_lab = QLabel("Custom"); self.custom_lab.setStyleSheet(f"color:{self.acc}; font-weight:600;")
        prow.addWidget(self.custom_lab); prow.addStretch()
        c.lay.addLayout(prow)
        # cheat sheet
        self.tiles = {}
        sheet = TileFlow()
        items = []
        for k in dd.GESTURE_KEYS:
            kind, rest = k.split("_")[0][:5], k.split("_")[1]
            fingers = int(k[5])
            items.append((k, kind, fingers, rest, dd.GESTURE_LABEL[k], False))
        for k, label, act in dd.BUILTIN:
            items.append((k, "swipe", 4, k.split("_")[1], label, act))
        for i, (k, kind, n, d, label, fixed) in enumerate(items):
            t = GestureTile(kind, n, d, label, fixed if fixed else "", self.acc, bool(fixed))
            self.tiles[k] = t
            sheet.add(t)
        c.lay.addWidget(sheet)
        # manual
        self.manual_btn = QPushButton("Choose each gesture yourself ▾"); self.manual_btn.setCheckable(True)
        self.manual_btn.setStyleSheet(
            f"QPushButton {{ text-align:left; border:1px solid {self.acc}44; }}"
            f" QPushButton:checked {{ background:{self.acc}1f; color:palette(text); }}")
        c.lay.addWidget(self.manual_btn)
        self.manual = QWidget(); mg = QGridLayout(self.manual); mg.setContentsMargins(0, 0, 0, 0)
        mg.setHorizontalSpacing(16); mg.setVerticalSpacing(6)
        self.combos = {}
        for i, k in enumerate(dd.GESTURE_KEYS):
            cb = QComboBox()
            for aid, (label, _c, _n) in dd.ACTIONS.items():
                if aid == "builtin" and k not in ("swipe3_left", "swipe3_right"):
                    continue
                cb.addItem(label, aid)
            cb.currentIndexChanged.connect(lambda _i, key=k: self.combo_changed(key))
            self.combos[k] = cb
            mg.addWidget(QLabel(dd.GESTURE_LABEL[k]), i // 2, (i % 2) * 2)
            mg.addWidget(cb, i // 2, (i % 2) * 2 + 1)
        mg.setColumnStretch(1, 1); mg.setColumnStretch(3, 1)
        self.manual.setVisible(False)
        self.manual_btn.toggled.connect(lambda on: (self.manual.setVisible(on),
                                                    self.manual_btn.setText("Choose each gesture yourself " +
                                                                            ("▴" if on else "▾"))))
        c.lay.addWidget(self.manual)
        self.g_warn = hint("", self.acc); self.g_warn.hide(); c.lay.addWidget(self.g_warn)
        self.g_status = dim(""); c.lay.addWidget(self.g_status)
        c.lay.addWidget(dim("Four-finger gestures and three-finger left/right desktop switching are built into Plasma "
                            "6.3 and cannot be changed or turned off (KDE bug 402857). Two-finger scrolling and "
                            "pinch-to-zoom in apps always work."))
        self._loading = False
        self.show_gestures()

    def show_gestures(self):
        self._loading = True
        for pid, b in self.pbtn.items():
            b.setChecked(pid == self.preset)
        self.custom_lab.setVisible(self.preset == "custom")
        for k, cb in self.combos.items():
            i = cb.findData(self.gmap.get(k, "none")); cb.setCurrentIndex(max(i, 0))
        for k in dd.GESTURE_KEYS:
            self.tiles[k].set_action(dd.ACTIONS[self.gmap.get(k, "none")][0])
        self._loading = False
        self.check_conflicts()

    def pick_preset(self, pid):
        self.preset, self.gmap = pid, dict(dd.PRESETS[pid][1])
        dd.save_gestures(pid, self.gmap)
        self.show_gestures()

    def combo_changed(self, key):
        if self._loading:
            return
        self.gmap[key] = self.combos[key].currentData()
        self.preset = dd.match_preset(self.gmap)
        dd.save_gestures(self.preset, self.gmap)
        self.show_gestures()

    def check_conflicts(self):
        desks = getattr(self, "data", {}).get("desks", 1)
        side = [k for k in ("swipe3_left", "swipe3_right") if self.gmap.get(k) not in ("builtin", "none")]
        if side and desks > 1:
            self.g_warn.setText(f"You have {desks} virtual desktops, so Plasma also switches the desktop on a "
                                "three-finger left/right swipe. Keep “Plasma default” there, or use one desktop.")
            self.g_warn.show()
        else:
            self.g_warn.hide()

    def update_gesture_status(self, svc, desks, has_tp):
        self.check_conflicts()
        msg = {"running": "● Gestures are active.",
               "no-touchpad": "No touchpad is connected - gestures start by themselves when one is.",
               "missing": "The gesture helper (libinput-tools) is missing: sudo apt install libinput-tools"}[svc]
        if svc == "running" and not has_tp:
            msg = "No touchpad is connected - gestures start by themselves when one is."
        self.g_status.setText(msg)
        if svc == "running":
            self.g_status.setStyleSheet(f"color:{self.acc};")

    # ------------------------------------------------------------------ monitors
    def build_monitors(self, outs, state, walls):
        c = self.m_card; self.clear(c)
        self.outs, self.walls = outs, walls
        if not outs:
            c.lay.addWidget(dim("Could not read the monitor list (kscreen-doctor). Display settings still work."))
            return
        cur = {}
        for d in state.get("desktops", []):
            for o in outs:
                if o["x"] == d["x"] and o["y"] == d["y"]:
                    cur[o["name"]] = d.get("image", "")
        self.cur_wall = cur
        self.map = MonitorMap(self.acc)
        self.map.set_data(outs, {n: dd.preview_for(u) for n, u in cur.items()})
        c.lay.addWidget(self.map)
        if len(outs) == 1:
            c.lay.addWidget(hint("One monitor connected. Plug in another one and it shows up here - PhoenixGe gives it "
                                 "a taskbar and a wallpaper by itself.", self.acc))
        grid = QGridLayout(); grid.setHorizontalSpacing(14); grid.setVerticalSpacing(8)
        for col, h in enumerate(["", "Monitor", "Wallpaper"]):
            lab = QLabel(h); lab.setObjectName("dim"); grid.addWidget(lab, 0, col)
        self.wcombos = []
        for i, o in enumerate(outs):
            num = QLabel(str(i + 1)); num.setAlignment(Qt.AlignCenter); num.setFixedSize(26, 26)
            num.setStyleSheet(f"background:{self.acc}; color:#1a0b06; border-radius:13px; font-weight:700;")
            grid.addWidget(num, i + 1, 0)
            sc = "" if abs(o["scale"] - 1) < 0.01 else f" • {round(o['scale'] * 100)}%"
            nm = QLabel(f"<b>{o['name']}</b> • {o['label']}" +
                        (f" <span style='color:{self.acc}'>★ main</span>" if o["primary"] else "") +
                        f"<br><span style='color:gray'>{o['w']}×{o['h']} @ {o['hz']} Hz{sc} • "
                        f"at {o['x']}, {o['y']}</span>")
            grid.addWidget(nm, i + 1, 1)
            cb = QComboBox(); cb.setMinimumWidth(150)
            for name, url, _pv in walls:
                cb.addItem(name, url)
            u = cur.get(o["name"], "")
            if u and cb.findData(u) < 0:
                cb.addItem(Path(u.replace("file://", "")).name or "Custom", u)
            cb.addItem("Choose a picture…", "__file__")
            cb.setCurrentIndex(max(cb.findData(u), 0) if u else 0)
            cb.activated.connect(lambda _i, k=i: self.pick_wall(k))
            self.wcombos.append(cb)
            grid.addWidget(cb, i + 1, 2)
        grid.setColumnStretch(1, 3); grid.setColumnStretch(2, 2)
        c.lay.addLayout(grid)
        self.map.picked.connect(lambda i: self.wcombos[i].setFocus())
        row = QHBoxLayout()
        same = QCheckBox("Same wallpaper on every monitor"); same.setChecked(dd.desk_cfg()["sameWallpaper"])
        same.toggled.connect(self.same_wall)
        self.same = same
        disp = QPushButton("Arrange, resolution, scale…")
        disp.clicked.connect(lambda: QProcess.startDetached("kcmshell6", ["kcm_kscreen"]))
        row.addWidget(same); row.addStretch(); row.addWidget(disp)
        c.lay.addLayout(row)
        self.m_msg = dim(""); c.lay.addWidget(self.m_msg)

    def pick_wall(self, i):
        cb, o = self.wcombos[i], self.outs[i]
        url = cb.currentData()
        if url == "__file__":
            f, _ = QFileDialog.getOpenFileName(self, "Wallpaper", str(Path.home() / "Pictures"),
                                               "Pictures (*.jpg *.jpeg *.png *.webp *.avif *.jxl)")
            if not f:
                cb.setCurrentIndex(max(cb.findData(self.cur_wall.get(o["name"], "")), 0)); return
            url = QUrl.fromLocalFile(f).toString()
            cb.insertItem(cb.count() - 1, Path(f).name, url); cb.setCurrentIndex(cb.findData(url))
        if self.same.isChecked():
            ok, out = dd.evaluate(dd.js_wallpaper([{"all": True, "url": url}]))
            for k, other in enumerate(self.outs):
                self.cur_wall[other["name"]] = url
                c2 = self.wcombos[k]
                if c2.findData(url) < 0:
                    c2.insertItem(c2.count() - 1, Path(url.replace("file://", "")).name, url)
                c2.blockSignals(True); c2.setCurrentIndex(c2.findData(url)); c2.blockSignals(False)
        else:
            ok, out = dd.evaluate(dd.js_wallpaper([{"x": o["x"], "y": o["y"], "url": url}]))
            self.cur_wall[o["name"]] = url
        self.map.set_data(self.outs, {n: dd.preview_for(u) for n, u in self.cur_wall.items()})
        self.m_msg.setText("Wallpaper changed." if ok else f"Could not change the wallpaper: {out}")

    def same_wall(self, on):
        dd.save_desk_cfg(sameWallpaper=on)
        if on and self.outs:
            prim = next((k for k, o in enumerate(self.outs) if o["primary"]), 0)
            self.pick_wall(prim)

    # ------------------------------------------------------------------ taskbars
    def build_taskbars(self, outs, state):
        c = self.t_card; self.clear(c)
        cfg = dd.desk_cfg()
        panels = state.get("panels", [])
        clones = sum(1 for p in panels if p.get("clone"))
        tasks = [p for p in panels if p.get("tasks")]
        if len(outs) <= 1:
            c.lay.addWidget(hint("These settings matter once a second monitor is connected. They are remembered "
                                 "and used automatically when you plug one in.", self.acc))
        self.every = QCheckBox("Taskbar on every monitor"); self.every.setChecked(cfg["taskbarEvery"])
        c.lay.addWidget(self.every)
        c.lay.addWidget(dim("Each extra monitor gets a copy of your main taskbar (start menu, apps, clock). "
                            "The system tray stays on the main monitor."))
        c.lay.addWidget(QLabel("Taskbar buttons show windows from:"))
        self.only = QRadioButton("its own monitor (like Windows 11)")
        allr = QRadioButton("all monitors")
        (self.only if cfg["tasksOnlyScreen"] else allr).setChecked(True)
        g = QButtonGroup(self); g.addButton(self.only); g.addButton(allr)
        rr = QHBoxLayout(); rr.addWidget(self.only); rr.addWidget(allr); rr.addStretch(); c.lay.addLayout(rr)
        self.auto_m = QCheckBox("Automatic when a monitor is plugged in")
        self.auto_m.setToolTip("Give new monitors a taskbar (and the same wallpaper, if chosen) by themselves")
        self.auto_m.setChecked(cfg["monitorsAuto"]); c.lay.addWidget(self.auto_m)
        row = QHBoxLayout()
        ap = QPushButton("Apply"); ap.setObjectName("primary"); ap.clicked.connect(self.apply_taskbars)
        self.t_msg = dim(f"Now: {len(tasks)} taskbar(s), {clones} of them copies made by PhoenixGe." if panels else "")
        row.addWidget(ap); row.addWidget(self.t_msg, 1); c.lay.addLayout(row)

    def apply_taskbars(self):
        every, only = self.every.isChecked(), self.only.isChecked()
        dd.save_desk_cfg(taskbarEvery=every, tasksOnlyScreen=only, monitorsAuto=self.auto_m.isChecked())
        prim = next((o for o in getattr(self, "outs", []) if o["primary"]), None)
        ok, out = dd.evaluate(dd.js_taskbar(every, only, (prim["x"], prim["y"]) if prim else None))
        if ok:
            try:
                r = __import__("json").loads(out.strip().splitlines()[-1])
                self.t_msg.setText(f"Done: {r.get('made', 0)} taskbar(s) added, {r.get('removed', 0)} removed.")
            except Exception:  # noqa: BLE001
                self.t_msg.setText("Done.")
        else:
            self.t_msg.setText(f"Plasma did not accept the change: {out}")
        self.log(f"taskbars: every={every} onlyScreen={only} -> {out}")


def _clear_layout(lay):
    while lay.count():
        it = lay.takeAt(0)
        if it.widget():
            it.widget().deleteLater()
        elif it.layout():
            _clear_layout(it.layout())


def build(center):
    return DesktopSetupPage(center)


if __name__ == "__main__":  # standalone test window / screenshot
    from PySide6.QtWidgets import QApplication, QPlainTextEdit
    if "--demo" in sys.argv:
        dd.DEMO = True
        dd.GESTURES = Path.home() / ".demo-gestures.json"
        dd.DESKCFG = Path.home() / ".demo-desktopsetup.json"
        dd.GESTURES.unlink(missing_ok=True); dd.DESKCFG.unlink(missing_ok=True)
    app = QApplication(sys.argv)
    acc = "#ff7a2e"
    if dd.DEMO:
        for a in sys.argv:
            if a.startswith("--preset=") and a[9:] in dd.PRESETS:
                dd.save_gestures(a[9:], dd.PRESETS[a[9:]][1])
        if "--dark" in sys.argv:   # roughly the Ember look (breeze-dark) for screenshots
            from PySide6.QtGui import QPalette
            app.setStyle("Fusion")
            pal = QPalette()
            for role, col in [(QPalette.Window, "#1b1513"), (QPalette.Base, "#140f0d"), (QPalette.AlternateBase, "#241b18"),
                              (QPalette.Text, "#f5ede6"), (QPalette.WindowText, "#f5ede6"), (QPalette.Button, "#2c211d"),
                              (QPalette.ButtonText, "#f5ede6"), (QPalette.PlaceholderText, "#a8968c"),
                              (QPalette.Highlight, acc), (QPalette.HighlightedText, "#1a0b06")]:
                pal.setColor(role, QColor(col))
            app.setPalette(pal)
    app.setStyleSheet(f"""
        QWidget {{ font-size: 13px; }}
        #h1 {{ font-size: 26px; font-weight: 700; }}
        #dim {{ color: palette(placeholder-text); }}
        #card {{ background: palette(alternate-base); border-radius: 14px; border: 1px solid {acc}22; }}
        #cardTitle {{ font-size: 15px; font-weight: 600; }}
        QPushButton {{ padding: 8px 16px; border-radius: 10px; }}
        QPushButton#primary {{ background: {acc}; color: #1a0b06; font-weight: 600; border: none; }}
        QPushButton:checked {{ background: {acc}; color: #1a0b06; }}
    """)

    class _Fake(QWidget):
        def __init__(self):
            super().__init__()
            lay = QVBoxLayout(self); lay.setContentsMargins(0, 0, 0, 0)
            self.log = QPlainTextEdit(); self.log.setMaximumHeight(120); self.log.hide()
            lay.addWidget(build(self)); lay.addWidget(self.log)
    f = _Fake()
    size = next((a.split("=", 1)[1] for a in sys.argv if a.startswith("--size=")), "1100x900")
    w, h = (int(x) for x in size.split("x"))
    f.resize(w, h)
    if "--shot" in sys.argv:
        out = sys.argv[sys.argv.index("--shot") + 1]
        if "--manual" in sys.argv:
            pg = f.findChild(DesktopSetupPage); pg.manual_btn.setChecked(True)
        f.show()
        QTimer.singleShot(600, lambda: (f.grab().save(out), app.quit()))
        sys.exit(app.exec())
    f.show()
    sys.exit(app.exec())
