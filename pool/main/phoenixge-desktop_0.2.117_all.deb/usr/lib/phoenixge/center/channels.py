"""PhoenixGe Center > Updates: update channel (Stable / Beta), the PhoenixGe version installed and in each channel,
and the changelog of each channel (dists/<channel>/changelog.json in the update repo).

build(center) -> QWidget       root work: /usr/lib/phoenixge/update-channel.sh (pkexec)
python3 channels.py [--demo]
"""
import html
import json
import subprocess
import sys
import threading
import urllib.request
from pathlib import Path

from PySide6.QtWidgets import (QButtonGroup, QComboBox, QHBoxLayout, QLabel, QMessageBox, QPushButton, QRadioButton,
                               QTextBrowser, QVBoxLayout, QWidget)

sys.path.insert(0, str(Path(__file__).resolve().parent))
from systools_ui import DEMO, GREEN, GREY, YELLOW, Bridge, dim, dot, facts, sh, ui  # noqa: E402

HELPER = "/usr/lib/phoenixge/update-channel.sh"
CHANNEL_FILE = Path("/etc/phoenixge/channel")
SOURCES = Path("/etc/apt/sources.list.d/phoenixge.sources")
DEFAULT_URI = "https://shakogogokhia.github.io/phoenixge-updates"
PKG = "phoenixge-desktop"
CHANNELS = [
    ("stable", "Stable (recommended)",
     "Updates that were tested in Beta first. Fewer surprises - the right choice for most people."),
    ("beta", "Beta",
     "New features first, may have bugs. You get updates days or weeks before Stable and help find problems before "
     "they reach everyone. A snapshot is saved before every update, and you can go back to Stable at any time."),
]


def vkey(v):
    """Rough Debian version sort key (our versions are plain dotted numbers)."""
    out = []
    for part in v.replace("-", ".").replace("+", ".").replace("~", ".").split("."):
        out.append((0, int(part), "") if part.isdigit() else (1, 0, part))
    return out


def channel():
    try:
        return "beta" if CHANNEL_FILE.read_text().strip() == "beta" else "stable"
    except OSError:
        return "stable"


def repo_uri():
    try:
        for line in SOURCES.read_text().splitlines():
            if line.startswith("URIs:"):
                return line.split(":", 1)[1].strip().rstrip("/") or DEFAULT_URI
    except OSError:
        pass
    return DEFAULT_URI


def versions():
    """dict(installed=, stable=, beta=) for phoenixge-desktop ('' = not installed / not known to apt yet)."""
    if DEMO:
        return dict(installed="0.2.104", stable="0.2.101", beta="0.2.104")
    r = dict(installed=sh(["dpkg-query", "-W", "-f=${Version}", PKG]), stable="", beta="")
    for line in sh(["apt-cache", "madison", PKG]).splitlines():
        f = [x.strip() for x in line.split("|")]
        if len(f) < 3:
            continue
        for s in ("stable", "beta"):
            if f" {s}/main" in " " + f[2] and (not r[s] or vkey(f[1]) > vkey(r[s])):
                r[s] = f[1]
    return r


def newer_than_stable():
    """[(pkg, installed, stable)] PhoenixGe packages that would go back when switching to Stable."""
    if DEMO:
        return [("phoenixge-desktop", "0.2.104", "0.2.101")]
    out = []
    for line in sh(["/bin/sh", HELPER, "newer"], timeout=30).splitlines():
        f = line.split()
        if len(f) == 3:
            out.append(tuple(f))
    return out


def fetch_changelog(suite):
    if DEMO:
        return {"entries": [{"version": "0.2.104", "date": "2026-11-13", "changes": ["Center: update channels",
                             "Clips: vertical export"]}, {"version": "0.2.101", "date": "2026-11-10",
                             "changes": ["Network & Ping page"], "promoted": "2026-11-12"}]}
    url = f"{repo_uri()}/dists/{suite}/changelog.json"
    with urllib.request.urlopen(url, timeout=15) as f:  # display only; apt verifies the packages themselves
        return json.loads(f.read().decode("utf-8", "replace"))


class ChannelsPage(QWidget):
    def __init__(self, center):
        super().__init__()
        self.center = center
        Card, page, _grid = ui(center)
        self.Card = Card
        w, lay = page("Update channel", "Choose how early you get new PhoenixGe versions. This only affects PhoenixGe "
                                        "itself (themes, start menu, Center, tools) - Debian system updates are the "
                                        "same on both channels.")
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0); outer.addWidget(w)
        self.bridge = Bridge(); self.bridge.result.connect(self.show_changelog)

        c = Card("Channel")
        self.group = QButtonGroup(self)
        for cid, title, text in CHANNELS:
            rb = QRadioButton(title); rb.setProperty("cid", cid); rb.setStyleSheet("font-weight:600;")
            self.group.addButton(rb)
            c.lay.addWidget(rb)
            d = dim(text); d.setContentsMargins(26, 0, 0, 6); c.lay.addWidget(d)
        row = QHBoxLayout()
        self.apply_btn = QPushButton("Switch channel"); self.apply_btn.setObjectName("primary")
        self.apply_btn.clicked.connect(self.switch)
        chk = QPushButton("Check for new versions"); chk.clicked.connect(self.check)
        row.addWidget(self.apply_btn); row.addWidget(chk); row.addStretch()
        c.lay.addLayout(row)
        self.group.buttonToggled.connect(lambda *_: self.sync_button())
        lay.addWidget(c)

        self.ver_card = Card("Versions")
        self.ver_box = QVBoxLayout(); self.ver_card.lay.addLayout(self.ver_box)
        lay.addWidget(self.ver_card)

        cl = Card("What's new")
        top = QHBoxLayout()
        self.cl_pick = QComboBox()
        self.cl_pick.addItem("Stable", "stable"); self.cl_pick.addItem("Beta", "beta")
        self.cl_pick.currentIndexChanged.connect(lambda _i: self.load_changelog())
        top.addWidget(QLabel("Channel:")); top.addWidget(self.cl_pick); top.addStretch()
        cl.lay.addLayout(top)
        self.cl_view = QTextBrowser(); self.cl_view.setOpenExternalLinks(False); self.cl_view.setMinimumHeight(260)
        cl.lay.addWidget(self.cl_view)
        lay.addWidget(cl)
        lay.addStretch()
        self.refresh()

    # ------------------------------------------------------------------ state
    def refresh(self):
        self.cur = channel()
        for b in self.group.buttons():
            b.setChecked(b.property("cid") == self.cur)
        self.sync_button()
        v = self.v = versions()
        while self.ver_box.count():
            it = self.ver_box.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        inst = v["installed"] or "not installed"
        mine = v[self.cur]
        if not mine:
            color, state = GREY, ("Not known yet - press \"Check for new versions\" (needs internet). The update "
                                  "server may not have this channel yet.")
        elif v["installed"] and vkey(v["installed"]) >= vkey(mine):
            color, state = GREEN, "Up to date for your channel."
        else:
            color, state = YELLOW, f"Version {mine} is ready - install it on the Updates page or in Discover."
        head = QHBoxLayout(); head.addWidget(dot(color)); head.addWidget(QLabel(state), 1)
        hw = QWidget(); hw.setLayout(head); self.ver_box.addWidget(hw)
        rows = [("Installed", inst), ("Stable channel", v["stable"] or "-"), ("Beta channel", v["beta"] or "-")]
        if self.cur == "stable" and v["installed"] and v["stable"] and vkey(v["installed"]) > vkey(v["stable"]):
            rows.append(("Note", "You have a Beta version installed. It stays until Stable catches up, or switch to "
                                 "Stable again and choose \"go back now\"."))
        self.ver_box.addWidget(facts(rows))
        self.cl_pick.blockSignals(True)
        self.cl_pick.setCurrentIndex(0 if self.cur == "stable" else 1)
        self.cl_pick.blockSignals(False)
        self.load_changelog()

    def selected(self):
        b = self.group.checkedButton()
        return b.property("cid") if b else self.cur

    def sync_button(self):
        sel = self.selected()
        self.apply_btn.setEnabled(sel != getattr(self, "cur", sel))
        self.apply_btn.setText("Switch to Beta" if sel == "beta" else "Switch to Stable" if sel != self.cur
                               else "Switch channel")

    # ------------------------------------------------------------------ actions
    def run_helper(self, args):
        if DEMO:
            QMessageBox.information(self, "Demo", "Would run: pkexec " + HELPER + " " + " ".join(args))
            return
        self.center.runner.root(HELPER, args, self.after)

    def after(self, code):
        if code not in (0, 10):
            QMessageBox.warning(self, "Update channel", "That did not work - see the details in the log below.")
        self.refresh()

    def check(self):
        self.run_helper(["refresh"])

    def switch(self):
        sel = self.selected()
        if sel == self.cur:
            return
        if sel == "beta":
            if QMessageBox.question(self, "Switch to Beta",
                                    "Beta gets new PhoenixGe features first, and they may have bugs.\n\nA snapshot is "
                                    "saved before every update, and you can switch back to Stable at any time.\n\n"
                                    "Switch to Beta? (asks for your password)") != QMessageBox.Yes:
                self.refresh(); return
            self.run_helper(["set", "beta"])
            return
        back = newer_than_stable()
        if not back:
            self.run_helper(["set", "stable"])
            return
        lst = "\n".join(f"  {p}: {i} -> {s}" for p, i, s in back)
        box = QMessageBox(self)
        box.setWindowTitle("Switch to Stable")
        box.setIcon(QMessageBox.Question)
        box.setText("You have Beta versions that are newer than Stable:\n\n" + lst)
        box.setInformativeText("Go back to the Stable versions now? A system snapshot is saved first, so you can undo "
                               "it from the boot menu. Or keep the Beta versions until Stable catches up - you then "
                               "get Stable updates only.")
        now = box.addButton("Go back now", QMessageBox.AcceptRole)
        keep = box.addButton("Keep until Stable catches up", QMessageBox.ActionRole)
        box.addButton(QMessageBox.Cancel)
        box.exec()
        if box.clickedButton() is now:
            self.run_helper(["set", "stable", "--downgrade"])
        elif box.clickedButton() is keep:
            self.run_helper(["set", "stable"])
        else:
            self.refresh()

    # ------------------------------------------------------------------ changelog
    def load_changelog(self):
        suite = self.cl_pick.currentData()
        self.cl_view.setHtml(f"<i>Loading the {suite} changelog…</i>")

        def work():
            try:
                self.bridge.result.emit((suite, fetch_changelog(suite), None))
            except Exception as e:  # noqa: BLE001
                self.bridge.result.emit((suite, None, e))
        threading.Thread(target=work, daemon=True).start()

    def show_changelog(self, res):
        suite, data, err = res
        if suite != self.cl_pick.currentData():
            return
        if err is not None or not data:
            self.cl_view.setHtml("<i>No changelog available for this channel (offline, or not published yet).</i>")
            return
        inst = self.v.get("installed", "")
        parts = []
        for e in data.get("entries", []):
            ver = e.get("version", "?")
            tag = ""
            if inst and vkey(ver) > vkey(inst):
                tag = " &nbsp;<b style='color:#e3b341'>new for you</b>"
            elif inst and ver == inst:
                tag = " &nbsp;<b style='color:#3fb950'>installed</b>"
            when = html.escape(e.get("date", ""))
            if e.get("promoted"):
                when += f", in Stable since {html.escape(e['promoted'])}"
            items = "".join(f"<li>{html.escape(c)}</li>" for c in e.get("changes", []))
            parts.append(f"<h3 style='margin-bottom:2px'>{html.escape(ver)}{tag}</h3>"
                         f"<div style='color:gray'>{when}</div><ul>{items}</ul>")
        self.cl_view.setHtml("".join(parts) or "<i>The changelog is empty.</i>")


def build(center):
    return ChannelsPage(center)


if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication, QPlainTextEdit
    app = QApplication(sys.argv)

    class _Host(QWidget):
        def __init__(self):
            super().__init__()
            lay = QVBoxLayout(self); self.log = QPlainTextEdit(); self.log.setMaximumHeight(120); self.log.hide()
            import center as cmod
            self.runner = cmod.Runner(self.log)
            lay.addWidget(build(self)); lay.addWidget(self.log)
    h = _Host(); h.resize(1000, 760); h.show()
    sys.exit(app.exec())
