"""PhoenixGe Center - "Sound & camera" page.

    import avstudio
    ("Sound & camera", "audio-headset", lambda: avstudio.build(self)),      # in Center's page list

Clean Mic (noise removal), PhoenixGe Sound (10-band EQ + 3D for headphones), Android phone as webcam/mic,
webcam background blur. Logic: /usr/lib/phoenixge/avstudio/{audio,video}.py (also usable from a terminal),
root parts: /usr/lib/phoenixge/avstudio/avstudio-root.sh. `--demo` shows sample devices (screenshots).
"""
import json
import sys
from pathlib import Path

from PySide6.QtCore import QProcess, QRectF, QSize, Qt, QTimer
from PySide6.QtGui import QColor, QFont, QFontMetrics, QPainter
from PySide6.QtWidgets import (QAbstractButton, QButtonGroup, QCheckBox, QComboBox, QFrame, QGridLayout, QHBoxLayout,
                               QLabel, QLineEdit, QPushButton, QSizePolicy, QSlider, QVBoxLayout, QWidget)

LIB = Path("/usr/lib/phoenixge/avstudio")
if not LIB.exists():  # running from the source tree
    LIB = Path(__file__).resolve().parent.parent / "avstudio"
sys.path.insert(0, str(LIB))
import audio  # noqa: E402
import video  # noqa: E402

AUDIO, VIDEO, ROOT = str(LIB / "audio.py"), str(LIB / "video.py"), str(LIB / "avstudio-root.sh")
DEMO = audio.DEMO
DEMO_ARGS = ["--demo"] if DEMO else []


def _center_mod(center):
    return sys.modules.get(type(center).__module__) or sys.modules.get("__main__")


def _accent(center):
    mod = _center_mod(center)
    try:
        return mod.accent()
    except Exception:
        return "#ff7a2e"


def dim(text):
    x = QLabel(text); x.setWordWrap(True); x.setObjectName("dim")
    return x


def combo(items, current):
    c = QComboBox()
    for v, label in items:
        c.addItem(label, v)
    i = c.findData(current)
    c.setCurrentIndex(i if i >= 0 else 0)
    return c


class Switch(QAbstractButton):
    """Pill on/off switch."""

    def __init__(self, color="#ff7a2e"):
        super().__init__()
        self.setCheckable(True); self.setCursor(Qt.PointingHandCursor)
        self.color = QColor(color)
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

    def sizeHint(self):
        return QSize(52, 28)

    def paintEvent(self, _e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(1, 1, self.width() - 2, self.height() - 2)
        on = self.isChecked()
        off_col = self.palette().mid().color()
        p.setPen(Qt.NoPen)
        p.setBrush(self.color if on else off_col)
        if not self.isEnabled():
            p.setOpacity(0.4)
        p.drawRoundedRect(r, r.height() / 2, r.height() / 2)
        d = r.height() - 6
        x = r.right() - d - 3 if on else r.left() + 3
        p.setBrush(QColor("#1a0b06") if on else QColor("#f2f2f2"))
        p.drawEllipse(QRectF(x, r.top() + 3, d, d))


def chip(text, ok):
    color = "#3fb950" if ok else "#8b949e"
    b = QLabel(("✓ " if ok else "○ ") + text)
    b.setStyleSheet(f"QLabel {{ color: {color}; border: 1px solid {color}; border-radius: 10px; padding: 2px 10px; "
                    f"font-size: 12px; }}")
    b.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
    return b


def header(card, title, switch=None, badge=None):
    """Card title row: title (big) + optional status badge + switch on the right. Returns the status label."""
    row = QHBoxLayout()
    t = QLabel(title); t.setObjectName("cardTitle"); row.addWidget(t)
    if badge is not None:
        row.addWidget(badge)
    row.addStretch(1)
    if switch is not None:
        row.addWidget(switch)
    card.lay.addLayout(row)


def status_label():
    s = QLabel(); s.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
    return s


def set_status(lbl, text, color):
    lbl.setText(text)
    lbl.setStyleSheet(f"QLabel {{ color: {color}; border: 1px solid {color}; border-radius: 9px; padding: 1px 9px; "
                      f"font-size: 11px; font-weight: 600; }}")


GREEN, GREY, ORANGE = "#3fb950", "#8b949e", "#ff7a2e"


class AVPage(QWidget):
    def __init__(self, center):
        super().__init__()
        self.center = center
        mod = _center_mod(center)
        self.Card, self.acc = mod.Card, _accent(center)
        w, lay = mod.page("Sound & camera", "A clean microphone, better sound in your headphones, and your phone or a "
                                            "blurred webcam as a camera - for Discord, Zoom, OBS, the browser and games.")
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0); outer.addWidget(w)
        self.lay = lay
        self.st = audio.load()
        self.astatus = audio.status()
        self.vstatus = None
        self.live_timer = QTimer(self); self.live_timer.setSingleShot(True); self.live_timer.setInterval(250)
        self.live_timer.timeout.connect(self.push_live)
        self.live_what = set()
        self.build_mic(); self.build_sound(); self.build_phone(); self.build_blur()
        lay.addStretch(1)
        self.refresh_video()

    # ------------------------------------------------------------ plumbing
    def run(self, script, args, done=None):
        self.center.runner.run("python3", [script, *args, *DEMO_ARGS], done)

    def save(self):
        audio.save(self.st)

    def live(self, what):
        """Slider moved: save now, push to PipeWire a moment later (no restart, no dropout)."""
        self.save(); self.live_what.add(what); self.live_timer.start()

    def push_live(self):
        for what in self.live_what:
            active = self.astatus["mic_active"] if what == "mic" else self.astatus["sound_active"]
            if active and not DEMO:
                QProcess.startDetached("python3", [AUDIO, what, "live"])
        self.live_what.clear()

    def reload_audio(self, _code=None):
        self.st = audio.load(); self.astatus = audio.status()
        self.mic_sw.blockSignals(True); self.mic_sw.setChecked(self.astatus["mic_active"]); self.mic_sw.blockSignals(False)
        self.snd_sw.blockSignals(True); self.snd_sw.setChecked(self.astatus["sound_active"]); self.snd_sw.blockSignals(False)
        self.mic_sw.setEnabled(True); self.snd_sw.setEnabled(True)
        self.update_audio_status()

    # ------------------------------------------------------------ 1. Clean Mic
    def build_mic(self):
        c = self.Card()
        self.mic_badge = status_label()
        self.mic_sw = Switch(self.acc); self.mic_sw.setChecked(self.astatus["mic_active"])
        header(c, "Clean Mic - noise removal", self.mic_sw, self.mic_badge)
        c.lay.addWidget(dim("Removes keyboard clicks, fans, street noise and the echo of your own speakers from your "
                            "microphone - like NVIDIA Broadcast, but on any computer. Apps get a new microphone, "
                            "\"PhoenixGe Clean Mic\", which becomes the default while this is on."))
        g = QGridLayout(); g.setHorizontalSpacing(14); g.setVerticalSpacing(10); g.setColumnStretch(1, 1)
        m = self.st["mic"]
        devs = audio.devices("source")
        self.mic_dev = combo([("", "Automatic (your current microphone)")] + devs, m.get("device", ""))
        self.mic_dev.currentIndexChanged.connect(self.mic_device_changed)
        g.addWidget(QLabel("Microphone"), 0, 0); g.addWidget(self.mic_dev, 0, 1, 1, 2)
        self.mic_strength = QSlider(Qt.Horizontal); self.mic_strength.setRange(0, 100)
        self.mic_strength.setValue(int(m.get("strength", 50)))
        self.mic_strength_lbl = QLabel(); self.mic_strength_lbl.setMinimumWidth(110)
        self.mic_strength.valueChanged.connect(self.mic_strength_changed)
        g.addWidget(QLabel("Strength"), 1, 0); g.addWidget(self.mic_strength, 1, 1); g.addWidget(self.mic_strength_lbl, 1, 2)
        self.mic_strength_changed(self.mic_strength.value(), save=False)
        if not self.astatus["gate"]:
            self.mic_strength.setEnabled(False)
            self.mic_strength_lbl.setText("not available")
        c.lay.addLayout(g)
        hint = dim("Strength: Light keeps every whisper; Strong also mutes the background between words "
                   "(a voice gate). Noise removal itself is always on." if self.astatus["gate"] else
                   "Strength control needs the package swh-plugins. Noise removal works without it.")
        c.lay.addWidget(hint)
        self.mic_agc = QCheckBox("Automatic mic volume (evens out quiet and loud speech)")
        self.mic_agc.setChecked(bool(m.get("agc")))
        self.mic_agc.toggled.connect(self.mic_agc_changed)
        c.lay.addWidget(self.mic_agc)
        row = QHBoxLayout()
        t = QPushButton("Test: record 5 seconds and play back")
        t.clicked.connect(lambda: self.run(AUDIO, ["mic-test", "5"]))
        row.addWidget(t); row.addStretch(1)
        c.lay.addLayout(row)
        self.mic_sw.toggled.connect(lambda on: self.toggle_audio("mic", on))
        if not self.astatus["pipewire"]:
            self.mic_sw.setEnabled(False)
        self.lay.addWidget(c)

    def mic_device_changed(self):
        self.st["mic"]["device"] = self.mic_dev.currentData() or ""
        self.save()
        if self.astatus["mic_active"]:
            self.run(AUDIO, ["mic", "apply"], self.reload_audio)

    def mic_strength_changed(self, v, save=True):
        word = "Light" if v < 34 else "Medium" if v < 67 else "Strong"
        self.mic_strength_lbl.setText(f"{word} ({v}%)")
        if save:
            self.st["mic"]["strength"] = v; self.live("mic")

    def mic_agc_changed(self, on):
        self.st["mic"]["agc"] = on; self.save()
        if self.astatus["mic_active"]:
            self.run(AUDIO, ["mic", "apply"], self.reload_audio)

    def toggle_audio(self, what, on):
        sw = self.mic_sw if what == "mic" else self.snd_sw
        sw.setEnabled(False)
        if DEMO:
            sw.setEnabled(True); return
        self.run(AUDIO, [what, "on" if on else "off"], self.reload_audio)

    # ------------------------------------------------------------ 2. Sound (EQ + 3D)
    def build_sound(self):
        c = self.Card()
        self.snd_badge = status_label()
        self.snd_sw = Switch(self.acc); self.snd_sw.setChecked(self.astatus["sound_active"])
        header(c, "PhoenixGe Sound - equalizer and 3D", self.snd_sw, self.snd_badge)
        c.lay.addWidget(dim("Shapes the sound of everything you hear. It follows your output automatically - speakers, "
                            "USB or Bluetooth headphones - so you never have to pick it."))
        s = self.st["sound"]
        prow = QHBoxLayout(); prow.setSpacing(6)
        self.presets = QButtonGroup(self); self.presets.setExclusive(True)
        for key, (label, _g) in audio.PRESETS.items():
            b = QPushButton(label); b.setCheckable(True); b.setProperty("preset", key)
            b.setStyleSheet(f"QPushButton {{ border: 1px solid {self.acc}44; border-radius: 14px; padding: 5px 12px; }}"
                            f"QPushButton:checked {{ background: {self.acc}; color: #1a0b06; font-weight: 600; }}")
            bold = QFont(b.font()); bold.setBold(True)  # checked = bold, must still fit
            b.setMinimumWidth(QFontMetrics(bold).horizontalAdvance(label) + 36)
            self.presets.addButton(b); prow.addWidget(b)
            if s.get("preset") == key:
                b.setChecked(True)
        self.custom_lbl = QLabel("Custom"); self.custom_lbl.setObjectName("dim")
        prow.addWidget(self.custom_lbl); prow.addStretch(1)
        self.presets.buttonClicked.connect(self.preset_clicked)
        c.lay.addLayout(prow)
        eq = QFrame(); eq.setObjectName("eqbox")
        eq.setStyleSheet(f"#eqbox {{ background: palette(base); border-radius: 12px; border: 1px solid {self.acc}22; }}")
        g = QGridLayout(eq); g.setContentsMargins(14, 10, 14, 10); g.setHorizontalSpacing(4); g.setVerticalSpacing(4)
        scale = QVBoxLayout()
        for txt in ("+12 dB", "", "0", "", "-12 dB"):
            lb = QLabel(txt); lb.setObjectName("dim"); lb.setStyleSheet("font-size: 10px;"); scale.addWidget(lb, 1)
        g.addLayout(scale, 1, 0)
        self.band_sliders, self.band_vals = [], []
        for i, f in enumerate(audio.BANDS):
            v = QLabel(); v.setAlignment(Qt.AlignCenter); v.setStyleSheet("font-size: 11px;")
            sl = QSlider(Qt.Vertical); sl.setRange(-120, 120); sl.setPageStep(10); sl.setMinimumHeight(150)
            sl.setValue(int(round(s["bands"][i] * 10)))
            sl.valueChanged.connect(lambda val, k=i: self.band_changed(k, val))
            fl = QLabel(f"{f // 1000}k" if f >= 1000 else str(f)); fl.setAlignment(Qt.AlignCenter); fl.setObjectName("dim")
            g.addWidget(v, 0, i + 1); g.addWidget(sl, 1, i + 1, Qt.AlignHCenter); g.addWidget(fl, 2, i + 1)
            g.setColumnStretch(i + 1, 1)
            self.band_sliders.append(sl); self.band_vals.append(v)
        hz = QLabel("Hz"); hz.setObjectName("dim"); g.addWidget(hz, 2, 0)
        c.lay.addWidget(eq)
        self.update_band_labels()
        orow = QHBoxLayout()
        self.preamp = QCheckBox("Prevent distortion (lowers the volume a little when you boost)")
        self.preamp.setChecked(bool(s.get("auto_preamp", True)))
        self.preamp.toggled.connect(self.preamp_changed)
        orow.addWidget(self.preamp); orow.addStretch(1)
        reset = QPushButton("Reset"); reset.clicked.connect(lambda: self.apply_preset("flat"))
        orow.addWidget(reset)
        c.lay.addLayout(orow)
        sep = QFrame(); sep.setFrameShape(QFrame.HLine); sep.setStyleSheet(f"color: {self.acc}22;"); c.lay.addWidget(sep)
        r3 = QHBoxLayout()
        t3 = QLabel("3D sound for headphones (virtual 7.1 surround)"); t3.setStyleSheet("font-weight: 600;")
        r3.addWidget(t3)
        self.hp_chip = chip("Headphones detected", True) if audio.headphones() else None
        if self.hp_chip:
            r3.addWidget(self.hp_chip)
        r3.addStretch(1)
        self.surround = Switch(self.acc); self.surround.setChecked(bool(s.get("surround")))
        self.surround.toggled.connect(self.surround_changed)
        r3.addWidget(self.surround)
        c.lay.addLayout(r3)
        if self.astatus["surround_available"]:
            c.lay.addWidget(dim("Places game sound around your head, so you can hear where footsteps come from. "
                                "Works best with games set to 5.1 / 7.1 output; stereo music stays in front of you. "
                                "Headphones only - turn it off for speakers."))
        else:
            self.surround.setEnabled(False)
            c.lay.addWidget(dim("Not available: needs the PipeWire spatializer and libmysofa1 (HRTF data)."))
        self.snd_sw.toggled.connect(lambda on: self.toggle_audio("sound", on))
        if not self.astatus["pipewire"]:
            self.snd_sw.setEnabled(False)
        self.lay.addWidget(c)
        self.update_audio_status()

    def update_band_labels(self):
        for sl, v in zip(self.band_sliders, self.band_vals):
            x = sl.value() / 10
            v.setText(f"{x:+.0f}" if x else "0")
        custom = self.st["sound"].get("preset") == "custom"
        self.custom_lbl.setVisible(custom)
        if custom:
            self.presets.setExclusive(False)
            for b in self.presets.buttons():
                b.setChecked(False)
            self.presets.setExclusive(True)

    def band_changed(self, i, val):
        self.st["sound"]["bands"][i] = val / 10
        if not getattr(self, "_setting", False):
            self.st["sound"]["preset"] = "custom"
            self.live("sound")
        self.update_band_labels()

    def apply_preset(self, key):
        self.st["sound"]["preset"] = key
        gains = audio.PRESETS[key][1]
        self._setting = True
        for sl, gdb in zip(self.band_sliders, gains):
            sl.setValue(int(gdb * 10))
        self._setting = False
        self.st["sound"]["bands"] = [float(x) for x in gains]
        for b in self.presets.buttons():
            if b.property("preset") == key:
                b.setChecked(True)
        self.update_band_labels()
        self.live("sound")

    def preset_clicked(self, b):
        self.apply_preset(b.property("preset"))

    def preamp_changed(self, on):
        self.st["sound"]["auto_preamp"] = on; self.live("sound")

    def surround_changed(self, on):
        self.st["sound"]["surround"] = on; self.save()
        if self.astatus["sound_active"] and not DEMO:  # 2 <-> 8 channels: the sink has to be rebuilt (1 s gap)
            self.run(AUDIO, ["sound", "apply"], self.reload_audio)

    def update_audio_status(self):
        a = self.astatus
        if not a["pipewire"]:
            set_status(self.mic_badge, "PipeWire missing", GREY); set_status(self.snd_badge, "PipeWire missing", GREY)
            return
        set_status(self.mic_badge, "On" if a["mic_active"] else "Off", GREEN if a["mic_active"] else GREY)
        set_status(self.snd_badge, "On" if a["sound_active"] else "Off", GREEN if a["sound_active"] else GREY)

    # ------------------------------------------------------------ 3. Phone as webcam / mic
    def build_phone(self):
        c = self.Card()
        self.phone_badge = status_label()
        header(c, "Phone as webcam and microphone", None, self.phone_badge)
        c.lay.addWidget(dim("Use your Android phone's camera (front or back) as a webcam, and its microphone as a mic - "
                            "over USB or Wi-Fi, no app needed on the phone. Apps see \"PhoenixGe Phone Camera\" and "
                            "\"PhoenixGe Phone Mic\". Needs Android 12 or newer."))
        self.phone_req = QHBoxLayout(); self.phone_req.setSpacing(8)
        c.lay.addLayout(self.phone_req)
        steps = QLabel("<b>First time on the phone:</b><br>"
                       "1. Settings › About phone › tap <i>Build number</i> 7 times (developer mode).<br>"
                       "2. Settings › System › Developer options › turn on <i>USB debugging</i> "
                       "(for Wi-Fi: <i>Wireless debugging</i>).<br>"
                       "3. Connect the USB cable, unlock the phone and tap <i>Allow</i> (tick \"Always allow\").")
        steps.setWordWrap(True); steps.setTextFormat(Qt.RichText)
        steps.setStyleSheet(f"QLabel {{ background: palette(base); border-radius: 10px; padding: 10px 12px; "
                            f"border-left: 3px solid {self.acc}; }}")
        c.lay.addWidget(steps)
        cam = video.cam_state()[1]
        g = QGridLayout(); g.setHorizontalSpacing(14); g.setVerticalSpacing(10); g.setColumnStretch(1, 1)
        self.phone_combo = QComboBox(); self.phone_combo.setPlaceholderText("No phone found")
        rb = QPushButton("Refresh"); rb.clicked.connect(self.refresh_video)
        g.addWidget(QLabel("Phone"), 0, 0); g.addWidget(self.phone_combo, 0, 1); g.addWidget(rb, 0, 2)
        self.facing = combo([("front", "Front camera (selfie)"), ("back", "Back camera (better quality)")], cam["facing"])
        self.quality = combo([("720", "HD 720p (smooth, less data)"), ("1080", "Full HD 1080p")], cam["quality"])
        self.facing.currentIndexChanged.connect(lambda: self.cam_set("facing", self.facing.currentData()))
        self.quality.currentIndexChanged.connect(lambda: self.cam_set("quality", self.quality.currentData()))
        g.addWidget(QLabel("Camera"), 1, 0); g.addWidget(self.facing, 1, 1, 1, 2)
        g.addWidget(QLabel("Quality"), 2, 0); g.addWidget(self.quality, 2, 1, 1, 2)
        c.lay.addLayout(g)
        self.phone_mic = QCheckBox("Also use the phone's microphone (\"PhoenixGe Phone Mic\")")
        self.phone_mic.setChecked(bool(cam["phone_mic"]))
        self.phone_mic.toggled.connect(lambda on: self.cam_set("phone_mic", on))
        c.lay.addWidget(self.phone_mic)
        wifi = QFrame(); wl = QVBoxLayout(wifi); wl.setContentsMargins(0, 4, 0, 0); wl.setSpacing(6)
        wt = QLabel("Wi-Fi (phone and PC on the same network)"); wt.setStyleSheet("font-weight: 600;"); wl.addWidget(wt)
        r1 = QHBoxLayout()
        gw = QPushButton("Switch the USB phone to Wi-Fi"); gw.clicked.connect(lambda: self.run(VIDEO, ["phone", "wireless"], self.refresh_video))
        r1.addWidget(gw); r1.addWidget(dim("…then unplug the cable.")); r1.addStretch(1); wl.addLayout(r1)
        r2 = QHBoxLayout()
        self.pair_addr = QLineEdit(); self.pair_addr.setPlaceholderText("IP:port from \"Pair device with pairing code\"")
        self.pair_code = QLineEdit(); self.pair_code.setPlaceholderText("6-digit code"); self.pair_code.setMaximumWidth(120)
        pb = QPushButton("Pair"); pb.clicked.connect(self.pair)
        r2.addWidget(self.pair_addr, 2); r2.addWidget(self.pair_code, 1); r2.addWidget(pb); wl.addLayout(r2)
        r3 = QHBoxLayout()
        self.conn_addr = QLineEdit(cam.get("addr", "")); self.conn_addr.setPlaceholderText("IP:port shown under Wireless debugging")
        cb = QPushButton("Connect"); cb.clicked.connect(self.connect_wifi)
        r3.addWidget(self.conn_addr, 3); r3.addWidget(cb); wl.addLayout(r3)
        c.lay.addWidget(wifi)
        row = QHBoxLayout()
        self.phone_btn = QPushButton("Start phone camera"); self.phone_btn.setObjectName("primary")
        self.phone_btn.clicked.connect(self.phone_toggle)
        self.phone_setup = QPushButton("Set up (installs scrcpy + virtual camera driver)")
        self.phone_setup.clicked.connect(lambda: self.root_setup(["camera-driver"], ["phone-tools"]))
        row.addWidget(self.phone_btn); row.addWidget(self.phone_setup); row.addStretch(1)
        c.lay.addLayout(row)
        c.lay.addWidget(dim("iPhone: not supported - Apple does not allow camera access over USB from Linux. "
                            "Use an app such as DroidCam or Iriun with its own instructions, or a USB webcam."))
        self.lay.addWidget(c)

    def cam_set(self, key, value):
        st, cam = video.cam_state(audio.load()); cam[key] = value; audio.save(st)
        self.st = audio.load()
        if key == "serial":
            return
        if key in ("device", "blur", "strength") and self.vstatus and self.vstatus.get("blur_active") and not DEMO:
            self.blur_timer.start()

    def pair(self):
        a, code = self.pair_addr.text().strip(), self.pair_code.text().strip()
        if a and code:
            self.run(VIDEO, ["phone", "pair", a, code], self.refresh_video)

    def connect_wifi(self):
        a = self.conn_addr.text().strip()
        if a:
            self.cam_set("addr", a)
            self.run(VIDEO, ["phone", "connect", a], self.refresh_video)

    def phone_toggle(self):
        if self.phone_combo.currentData():
            self.cam_set("serial", self.phone_combo.currentData())
        active = bool(self.vstatus and self.vstatus.get("phone_active"))
        self.phone_btn.setEnabled(False)
        self.run(VIDEO, ["phone", "stop" if active else "start"], self.refresh_video)

    def root_setup(self, *steps):
        """Run root helper steps one after the other (one pkexec prompt each), then refresh."""
        steps = list(steps)
        if not steps:
            self.refresh_video(); return
        first = steps.pop(0)
        self.center.runner.root(ROOT, first, lambda code: self.root_setup(*steps) if code == 0 else self.refresh_video())

    # ------------------------------------------------------------ 4. Background blur
    def build_blur(self):
        c = self.Card()
        self.blur_badge = status_label()
        header(c, "Webcam background blur", None, self.blur_badge)
        c.lay.addWidget(dim("Blurs everything behind you, with AI person detection, and sends the result to a new camera, "
                            "\"PhoenixGe Camera\" - pick it in Discord, Zoom, Teams, OBS or the browser. "
                            "Works with any webcam, or with your phone camera."))
        self.blur_req = QHBoxLayout(); self.blur_req.setSpacing(8)
        c.lay.addLayout(self.blur_req)
        cam = video.cam_state()[1]
        g = QGridLayout(); g.setHorizontalSpacing(14); g.setVerticalSpacing(10); g.setColumnStretch(1, 1)
        self.cam_combo = QComboBox(); self.cam_combo.setPlaceholderText("No webcam found")
        self.cam_combo.currentIndexChanged.connect(self.cam_changed)
        g.addWidget(QLabel("Webcam"), 0, 0); g.addWidget(self.cam_combo, 0, 1, 1, 2)
        self.blur_on = QCheckBox("Blur the background"); self.blur_on.setChecked(bool(cam["blur"]))
        self.blur_on.toggled.connect(lambda on: (self.cam_set("blur", on), self.blur_strength.setEnabled(on)))
        g.addWidget(self.blur_on, 1, 0, 1, 3)
        self.blur_strength = QSlider(Qt.Horizontal); self.blur_strength.setRange(1, 20)
        self.blur_strength.setValue(int(cam["strength"])); self.blur_strength.setEnabled(bool(cam["blur"]))
        self.blur_lbl = QLabel(); self.blur_lbl.setMinimumWidth(110)
        self.blur_strength.valueChanged.connect(self.blur_strength_changed)
        self.blur_strength_changed(self.blur_strength.value(), save=False)
        g.addWidget(QLabel("Strength"), 2, 0); g.addWidget(self.blur_strength, 2, 1); g.addWidget(self.blur_lbl, 2, 2)
        c.lay.addLayout(g)
        self.blur_timer = QTimer(self); self.blur_timer.setSingleShot(True); self.blur_timer.setInterval(1200)
        self.blur_timer.timeout.connect(lambda: self.run(VIDEO, ["blur", "apply"], self.refresh_video))
        row = QHBoxLayout()
        self.blur_btn = QPushButton("Start PhoenixGe Camera"); self.blur_btn.setObjectName("primary")
        self.blur_btn.clicked.connect(self.blur_toggle)
        self.blur_install = QPushButton("Install OBS + Background Removal")
        self.blur_install.clicked.connect(self.install_obs)
        self.blur_setup = QPushButton("Set up virtual camera")
        self.blur_setup.clicked.connect(lambda: self.root_setup(["camera-driver"]))
        self.obs_btn = QPushButton("Fine-tune in OBS…")
        self.obs_btn.clicked.connect(lambda: QProcess.startDetached("flatpak", [
            "run", video.OBS, "--collection", video.COLLECTION, "--profile", video.COLLECTION]))
        for b in (self.blur_btn, self.blur_install, self.blur_setup, self.obs_btn):
            row.addWidget(b)
        row.addStretch(1)
        c.lay.addLayout(row)
        c.lay.addWidget(dim("Runs OBS Studio quietly in the tray (about one CPU core). Changing the strength restarts the "
                            "camera for a second. In Chrome, Discord and Zoom the camera only appears while it is running."))
        self.lay.addWidget(c)

    def blur_strength_changed(self, v, save=True):
        word = "Soft" if v < 7 else "Medium" if v < 14 else "Strong"
        self.blur_lbl.setText(f"{word} ({v})")
        if save:
            self.cam_set("strength", v)

    def cam_changed(self):
        if getattr(self, "_filling", False):
            return
        self.cam_set("device", self.cam_combo.currentData() or "")

    def blur_toggle(self):
        active = bool(self.vstatus and self.vstatus.get("blur_active"))
        self.blur_btn.setEnabled(False)
        self.run(VIDEO, ["blur", "stop" if active else "start"], lambda _c: QTimer.singleShot(1500, self.refresh_video))

    def install_obs(self):
        self.blur_install.setEnabled(False); self.blur_install.setText("Installing…")
        self.center.runner.run("flatpak", ["install", "-y", "--noninteractive", "flathub", video.OBS, video.OBS_PLUGIN],
                               lambda _c: self.refresh_video())

    # ------------------------------------------------------------ video status (async: adb can take a moment)
    def refresh_video(self, _code=None):
        if getattr(self, "_vproc", None):
            return
        p = QProcess(self); self._vproc = p
        p.finished.connect(lambda *_: self.got_video(bytes(p.readAllStandardOutput()).decode(errors="replace")))
        p.start("python3", [VIDEO, "status", *DEMO_ARGS])

    @staticmethod
    def _clear(layout):
        while layout.count():
            it = layout.takeAt(0)
            if it.widget():
                it.widget().deleteLater()

    def got_video(self, out):
        self._vproc = None
        try:
            v = json.loads(out)
        except Exception:
            v = {"camera": video.CAM_DEFAULTS, "driver_installed": False, "driver_ready": False, "phones": [],
                 "phones_unauthorized": [], "phone_active": False, "obs": {"obs": False, "plugin": False},
                 "blur_active": False, "webcams": [], "phone_tools": {"scrcpy": False, "adb": False}}
        self.vstatus = v
        tools = v["phone_tools"]
        # phone
        self._clear(self.phone_req)
        self.phone_req.addWidget(chip("Virtual camera driver", v["driver_ready"]))
        self.phone_req.addWidget(chip("scrcpy", tools["scrcpy"]))
        self.phone_req.addWidget(chip("adb", tools["adb"]))
        self.phone_req.addStretch(1)
        ready = v["driver_ready"] and tools["scrcpy"] and tools["adb"]
        self.phone_setup.setVisible(not ready)
        cur = self.phone_combo.currentData() or v["camera"].get("serial")
        self.phone_combo.clear()
        for serial, desc in v["phones"]:
            self.phone_combo.addItem(desc, serial)
        for serial, desc in v["phones_unauthorized"]:
            self.phone_combo.addItem(f"{desc} - unlock the phone and tap Allow", "")
        i = self.phone_combo.findData(cur)
        if self.phone_combo.count():  # Qt 6 keeps index -1 after clear() when a placeholder is set
            self.phone_combo.setCurrentIndex(i if i >= 0 else 0)
        if v["phone_active"]:
            set_status(self.phone_badge, "Camera on", GREEN)
        elif v["phones"]:
            set_status(self.phone_badge, "Phone connected", ORANGE)
        else:
            set_status(self.phone_badge, "No phone", GREY)
        self.phone_btn.setText("Stop phone camera" if v["phone_active"] else "Start phone camera")
        self.phone_btn.setEnabled(ready and (bool(v["phones"]) or v["phone_active"]))
        # blur
        self._clear(self.blur_req)
        self.blur_req.addWidget(chip("Virtual camera driver", v["driver_ready"]))
        self.blur_req.addWidget(chip("OBS Studio", v["obs"]["obs"]))
        self.blur_req.addWidget(chip("Background Removal plugin", v["obs"]["plugin"]))
        self.blur_req.addStretch(1)
        have_obs = v["obs"]["obs"] and v["obs"]["plugin"]
        self.blur_install.setVisible(not have_obs); self.blur_install.setEnabled(True)
        self.blur_install.setText("Install OBS + Background Removal (Flathub)")
        self.blur_setup.setVisible(not v["driver_ready"])
        self.obs_btn.setVisible(have_obs and not v["blur_active"])
        self._filling = True
        cur = v["camera"].get("device", "")
        self.cam_combo.clear()
        self.cam_combo.addItem("Automatic (first webcam)", "")
        for d in v["webcams"]:
            self.cam_combo.addItem(f"{d['name']}  ({d['dev']})", d["dev"])
        i = self.cam_combo.findData(cur)
        self.cam_combo.setCurrentIndex(i if i >= 0 else 0)
        self._filling = False
        set_status(self.blur_badge, "Camera on" if v["blur_active"] else "Off", GREEN if v["blur_active"] else GREY)
        self.blur_btn.setText("Stop PhoenixGe Camera" if v["blur_active"] else "Start PhoenixGe Camera")
        self.blur_btn.setEnabled(have_obs and v["driver_ready"] and (bool(v["webcams"]) or v["blur_active"]))


def build(center):
    return AVPage(center)


if __name__ == "__main__":  # test window: the real Center with this page added and selected.  [--demo]
    from PySide6.QtGui import QIcon
    from PySide6.QtWidgets import QApplication, QListWidgetItem
    app = QApplication(sys.argv)
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import center as main  # noqa: E402
    win = main.Center()
    QListWidgetItem(QIcon.fromTheme("audio-headset"), "Sound & camera", win.nav)
    win.stack.addWidget(build(win))
    win.nav.setCurrentRow(win.nav.count() - 1)
    win.show()
    sys.exit(app.exec())
