"""PhoenixGe Center > USB Creator: put PhoenixGe on a USB stick so a friend can install it.

1. get the ISO (download - once there is a public URL - or pick a local .iso)  2. pick a USB stick (only USB disks are
listed; the system disk never)  3. big red confirmation  4. write with dd via pkexec, verify sha256.
build(center) -> QWidget.  Run alone for testing:  python3 usbmaker.py
"""
import hashlib
import os
import sys
import urllib.request
from pathlib import Path

from PySide6.QtCore import QProcess, Qt, QThread, QTimer, Signal
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QFileDialog, QHBoxLayout, QLabel, QMessageBox, QProgressBar,
                               QPushButton, QVBoxLayout, QWidget)

sys.path.insert(0, str(Path(__file__).resolve().parent))
import usb_data as ud  # noqa: E402
from health import _ui  # noqa: E402  (shared Card/page lookup)

DOWNLOADS = Path.home() / "Downloads"


class Downloader(QThread):
    progress = Signal(object, object)  # done, total (object: sizes are > 2 GB, Qt int is 32-bit)
    ok = Signal(str)
    failed = Signal(str)

    def __init__(self, url, dest, sha_url=""):
        super().__init__()
        self.url, self.dest, self.sha_url, self.stop = url, Path(dest), sha_url, False

    def run(self):
        tmp = self.dest.with_name(self.dest.name + ".part")
        try:
            want = None
            if self.sha_url:
                with urllib.request.urlopen(urllib.request.Request(self.sha_url, headers={"User-Agent": "PhoenixGe-Center"}), timeout=30) as r:
                    want = ud.parse_sha256_file(r.read(4096).decode(errors="replace"))
            h = hashlib.sha256()
            req = urllib.request.Request(self.url, headers={"User-Agent": "PhoenixGe-Center"})
            with urllib.request.urlopen(req, timeout=30) as r, open(tmp, "wb") as f:
                total, done = int(r.headers.get("Content-Length") or 0), 0
                while not self.stop:
                    b = r.read(1 << 20)
                    if not b:
                        break
                    f.write(b); h.update(b); done += len(b)
                    self.progress.emit(done, total)
            if self.stop:
                tmp.unlink(missing_ok=True); self.failed.emit("Download cancelled."); return
            if want and h.hexdigest() != want:
                tmp.unlink(missing_ok=True); self.failed.emit("The download is damaged (checksum mismatch). Try again."); return
            tmp.replace(self.dest)
            self.ok.emit(str(self.dest))
        except Exception as e:  # network errors, disk full...
            tmp.unlink(missing_ok=True)
            self.failed.emit(f"Download failed: {e}")


class ConfirmErase(QDialog):
    """Big red 'this erases everything' dialog. Cancel is the default; Erase needs a tick first."""

    def __init__(self, parent, target, iso):
        super().__init__(parent)
        self.setWindowTitle("Erase USB stick?")
        self.setMinimumWidth(520)
        lay = QVBoxLayout(self); lay.setSpacing(12)
        head = QLabel("⚠  EVERYTHING ON THIS DISK WILL BE ERASED")
        head.setStyleSheet("background:#b42318; color:white; font-size:18px; font-weight:800; padding:14px; border-radius:10px;")
        head.setAlignment(Qt.AlignCenter); lay.addWidget(head)
        big = QLabel(f"<b style='font-size:20px'>{target['model']}</b><br>"
                     f"<span style='font-size:16px'>{ud.human(target['size'])} &nbsp;·&nbsp; {target['path']}</span>")
        big.setAlignment(Qt.AlignCenter); lay.addWidget(big)
        txt = ("All files, photos and partitions on it are deleted and cannot be recovered. "
               f"It will then contain PhoenixGe ({Path(iso).name}).")
        if target["mounts"]:
            txt += "\n\nIt is open right now (" + ", ".join(target["mounts"]) + ") - it will be closed first."
        if target["warn"]:
            txt += "\n\n" + target["warn"]
        t = QLabel(txt); t.setWordWrap(True); lay.addWidget(t)
        self.tick = QCheckBox(f"Yes, erase {target['model']} ({ud.human(target['size'])})")
        lay.addWidget(self.tick)
        row = QHBoxLayout(); row.addStretch()
        cancel = QPushButton("Cancel"); cancel.setDefault(True); cancel.setAutoDefault(True); cancel.clicked.connect(self.reject)
        self.go = QPushButton("Erase and write"); self.go.setEnabled(False); self.go.setAutoDefault(False)
        self.go.setStyleSheet("QPushButton{background:#d92d20;color:white;font-weight:700;border:none;padding:8px 18px;border-radius:10px;}"
                              "QPushButton:disabled{background:#d92d2055;}")
        self.go.clicked.connect(self.accept)
        self.tick.toggled.connect(self.go.setEnabled)
        row.addWidget(cancel); row.addWidget(self.go); lay.addLayout(row)
        cancel.setFocus()


class UsbPage(QWidget):
    def __init__(self, center):
        super().__init__()
        self.center = center
        Card, page = _ui()
        w, lay = page("USB Creator", "Make a PhoenixGe USB stick so a friend can try and install it. "
                                     "You need a USB stick of 8 GB or more - everything on it will be erased.")
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0); outer.addWidget(w)
        self.iso, self.dl, self.proc, self.targets = "", None, None, []
        self.stage, self.total = "", 0

        c1 = Card("1. Get PhoenixGe")
        r1 = QHBoxLayout()
        self.dlbtn = QPushButton("Download newest PhoenixGe"); self.dlbtn.setObjectName("primary")
        self.dlbtn.clicked.connect(self.download)
        pick = QPushButton("Choose .iso file…"); pick.clicked.connect(self.pick_iso)
        r1.addWidget(self.dlbtn); r1.addWidget(pick); r1.addStretch(); c1.lay.addLayout(r1)
        if not ud.ISO_URL:
            self.dlbtn.setEnabled(False)
            self.dlbtn.setToolTip("There is no public download yet.")
            n = QLabel("There is no public download yet - choose a PhoenixGe .iso file you already have."); n.setObjectName("dim")
            c1.lay.addWidget(n)
        self.dlbar = QProgressBar(); self.dlbar.setRange(0, 1000); self.dlbar.hide(); c1.lay.addWidget(self.dlbar)
        self.isolabel = QLabel("No ISO selected."); self.isolabel.setWordWrap(True); c1.lay.addWidget(self.isolabel)
        lay.addWidget(c1)

        c2 = Card("2. Pick the USB stick", "Only USB disks are shown. Your computer's own drives are never listed.")
        r2 = QHBoxLayout()
        self.combo = QComboBox(); self.combo.setMinimumWidth(360); self.combo.currentIndexChanged.connect(self.update_state)
        ref = QPushButton("Refresh"); ref.clicked.connect(self.refresh)
        r2.addWidget(self.combo, 1); r2.addWidget(ref); c2.lay.addLayout(r2)
        self.tinfo = QLabel(""); self.tinfo.setWordWrap(True); self.tinfo.setObjectName("dim"); c2.lay.addWidget(self.tinfo)
        lay.addWidget(c2)

        c3 = Card("3. Write")
        warn = QLabel("Everything on the selected stick will be erased.")
        warn.setStyleSheet("color:#f85149; font-weight:700;"); c3.lay.addWidget(warn)
        r3 = QHBoxLayout()
        self.wbtn = QPushButton("Write to USB stick")
        self.wbtn.setStyleSheet("QPushButton{background:#d92d20;color:white;font-weight:700;border:none;}"
                                "QPushButton:disabled{background:#d92d2044;color:#ffffff88;}")
        self.wbtn.clicked.connect(self.write)
        r3.addWidget(self.wbtn); r3.addStretch(); c3.lay.addLayout(r3)
        self.status = QLabel(""); self.status.setWordWrap(True); c3.lay.addWidget(self.status)
        self.bar = QProgressBar(); self.bar.setRange(0, 1000); self.bar.hide(); c3.lay.addWidget(self.bar)
        lay.addWidget(c3)
        tip = Card("Booting the stick", "Plug it into the other computer, switch it on and press the boot-menu key "
                                        "(often F12, F11, F8 or Esc; Lenovo: F12, HP: F9, Dell: F12, ASUS: F8/Esc). "
                                        "Choose the USB stick. PhoenixGe starts without changing the computer until you install.")
        lay.addWidget(tip); lay.addStretch()

        self.timer = QTimer(self); self.timer.setInterval(3000); self.timer.timeout.connect(self.refresh)
        self.update_state()

    def showEvent(self, e):
        super().showEvent(e)
        self.refresh(); self.timer.start()

    def hideEvent(self, e):
        super().hideEvent(e)
        self.timer.stop()

    # ---------------------------------------------------------------- ISO
    def set_iso(self, path):
        if not ud.is_iso(path):
            QMessageBox.warning(self, "USB Creator", f"{Path(path).name} is not an ISO image.")
            return
        self.iso = path
        self.isolabel.setText(f"✓ {Path(path).name}  ({ud.human(os.path.getsize(path))})")
        self.refresh()

    def pick_iso(self):
        f, _ = QFileDialog.getOpenFileName(self, "PhoenixGe ISO", str(DOWNLOADS), "ISO images (*.iso)")
        if f:
            self.set_iso(f)

    def download(self):
        if self.dl:
            self.dl.stop = True
            return
        DOWNLOADS.mkdir(parents=True, exist_ok=True)
        self.dl = Downloader(ud.ISO_URL, DOWNLOADS / ud.ISO_NAME, ud.ISO_SHA256_URL)
        self.dl.progress.connect(self.dl_progress)
        self.dl.ok.connect(lambda p: (self.dl_end(), self.set_iso(p)))
        self.dl.failed.connect(lambda m: (self.dl_end(), self.isolabel.setText(m)))
        self.dlbar.setValue(0); self.dlbar.show(); self.dlbtn.setText("Cancel download")
        self.dl.start()

    def dl_progress(self, done, total):
        if total:
            self.dlbar.setValue(int(done * 1000 / total))
            self.dlbar.setFormat(f"{ud.human(done)} of {ud.human(total)}")
        else:
            self.dlbar.setRange(0, 0)

    def dl_end(self):
        self.dl.wait(); self.dl = None
        self.dlbar.hide(); self.dlbar.setRange(0, 1000); self.dlbtn.setText("Download newest PhoenixGe")

    # ---------------------------------------------------------------- targets
    def refresh(self):
        if self.proc:
            return
        new = ud.list_targets(self.iso)
        key = [(t["path"], t["size"], t["model"], t["blocked"], tuple(t["mounts"])) for t in new]
        if key == [(t["path"], t["size"], t["model"], t["blocked"], tuple(t["mounts"])) for t in self.targets] and self.combo.count():
            return
        cur = self.combo.currentData()
        self.targets = new
        self.combo.blockSignals(True); self.combo.clear()
        if not new:
            self.combo.addItem("No USB stick found - plug one in", None)
        for t in new:
            label = f"{t['model']}  -  {ud.human(t['size'])}  ({t['path']})"
            if t["blocked"]:
                label += f"  - not allowed: {t['blocked']}"
            self.combo.addItem(label, t["path"])
            if t["blocked"]:
                self.combo.model().item(self.combo.count() - 1).setEnabled(False)
        idx = self.combo.findData(cur) if cur else -1
        if idx < 0 or (idx >= 0 and self.target_at(idx) and self.target_at(idx)["blocked"]):
            idx = next((i for i, t in enumerate(new) if not t["blocked"]), 0)
        self.combo.setCurrentIndex(max(0, idx))
        self.combo.blockSignals(False)
        self.update_state()

    def target_at(self, idx):
        path = self.combo.itemData(idx)
        return next((t for t in self.targets if t["path"] == path), None)

    def current_target(self):
        t = self.target_at(self.combo.currentIndex())
        return t if t and not t["blocked"] else None

    def update_state(self):
        t = self.current_target()
        busy = bool(self.proc)
        info = ""
        if t:
            info = f"{t['model']}, {ud.human(t['size'])}"
            if t["mounts"]:
                info += " - open in: " + ", ".join(t["mounts"])
            if t["warn"]:
                info += "\n⚠ " + t["warn"]
            if self.iso and os.path.getsize(self.iso) > t["size"]:
                info += "\n✗ Too small for this ISO."
        self.tinfo.setText(info)
        ok = bool(t and self.iso and os.path.exists(self.iso) and os.path.getsize(self.iso) <= t["size"]) and not busy
        self.wbtn.setEnabled(ok)
        self.combo.setEnabled(not busy)

    # ---------------------------------------------------------------- write
    def write(self):
        t = self.current_target()
        if not t or not self.iso:
            return
        # re-check right before asking: the stick may have been swapped
        fresh = next((x for x in ud.list_targets(self.iso) if x["path"] == t["path"]), None)
        if not fresh or fresh["blocked"] or fresh["size"] != t["size"] or fresh["model"] != t["model"]:
            QMessageBox.warning(self, "USB Creator", "The USB stick changed. Please pick it again.")
            self.refresh(); return
        if ConfirmErase(self, fresh, self.iso).exec() != QDialog.Accepted:
            return
        self.stage, self.total = "", os.path.getsize(self.iso)
        self.bar.setValue(0); self.bar.show(); self.status.setText("Waiting for your password…")
        log = self.center.log; log.show()
        log.appendPlainText(f"$ pkexec usb-write.sh {self.iso} {fresh['path']}  ({fresh['model']}, {ud.human(fresh['size'])})")
        p = QProcess(self); p.setProcessChannelMode(QProcess.MergedChannels)
        self.buf, self.result, self.error = "", None, None
        p.readyReadStandardOutput.connect(lambda: self.on_output(bytes(p.readAllStandardOutput()).decode(errors="replace")))
        p.finished.connect(self.on_finished)
        p.errorOccurred.connect(lambda err: err == QProcess.ProcessError.FailedToStart and self.on_finished(-1))
        self.proc = p
        self.update_state()
        p.start("pkexec", ["/bin/sh", ud.WRITE_HELPER, self.iso, fresh["path"]])

    def on_output(self, text):
        self.buf += text
        parts = self.buf.replace("\r", "\n").split("\n")
        self.buf = parts.pop()
        for line in parts:
            ev = ud.parse_helper_line(line)
            if not ev:
                if line.strip():
                    self.center.log.appendPlainText(line.rstrip())
                continue
            kind, what, n = ev
            if kind == "stage":
                self.stage = what
                if n:
                    self.total = n
                self.center.log.appendPlainText(line.strip())
                if what == "hash":
                    self.bar.setRange(0, 0); self.status.setText("Checking the ISO file…")
                else:
                    self.bar.setRange(0, 1000); self.bar.setValue(0)
                    self.status.setText("Writing… don't remove the stick." if what == "write" else "Checking the stick…")
            elif kind == "progress" and self.total:
                self.bar.setValue(min(1000, int(n * 1000 / self.total)))
                self.bar.setFormat(f"{ud.human(n)} of {ud.human(self.total)}")
            elif kind == "result":
                self.result = what; self.center.log.appendPlainText(line.strip())
            elif kind == "error":
                self.error = what; self.center.log.appendPlainText(line.strip())

    def on_finished(self, code, _status=None):
        if self.buf:
            self.on_output("\n")
        self.proc = None
        self.bar.hide(); self.bar.setRange(0, 1000); self.bar.setFormat("%p%")
        if self.result == "ok" and code == 0:
            self.status.setText("✓ Done! The USB stick is ready - you can remove it.")
            QMessageBox.information(self, "USB Creator", "The PhoenixGe USB stick is ready and verified.\nYou can remove it now.")
        elif code in (126, 127) and not self.stage:
            self.status.setText("Cancelled - nothing was changed.")
        elif self.result == "fail":
            self.status.setText("✗ The check after writing failed - the stick may be faulty. Try again or use another stick.")
        else:
            self.status.setText("✗ " + (self.error or f"Failed ({code})."))
        self.refresh(); self.update_state()


def build(center):
    return UsbPage(center)


if __name__ == "__main__":  # standalone test window
    from PySide6.QtWidgets import QApplication, QPlainTextEdit
    app = QApplication(sys.argv)

    class _Fake(QWidget):
        def __init__(self):
            super().__init__()
            lay = QVBoxLayout(self); self.log = QPlainTextEdit(); self.log.setMaximumHeight(150)
            import center as main
            self.runner = main.Runner(self.log)
            lay.addWidget(build(self)); lay.addWidget(self.log)
    f = _Fake(); f.resize(1000, 760); f.show()
    sys.exit(app.exec())
