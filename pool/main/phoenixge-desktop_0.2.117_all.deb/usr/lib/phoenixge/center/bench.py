"""PhoenixGe Center > Benchmark - one button "Is my PC OK?" (about 2-3 minutes).

Processor (7-Zip), memory (sysbench), disk (fio, 1 GB temp file in your home, removed after), graphics (vkmark,
Vulkan, on the NVIDIA card on laptops), temperatures and throttling while it runs. Results are compared with
approximate typical values for your hardware (no PhoenixGe server - a curated table, see bench/reference.json),
explained, and turned into recommendations with buttons. History: ~/.local/share/phoenixge/bench.json.

build(center) -> QWidget        python3 bench.py [--demo]   (alone, for testing)
Engine: /usr/lib/phoenixge/bench/benchrun.py (works in a terminal too).
"""
import json
import sys
import time
from pathlib import Path

from PySide6.QtCore import QPointF, QProcess, QRectF, Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import (QCheckBox, QGridLayout, QHBoxLayout, QLabel, QProgressBar, QPushButton, QVBoxLayout,
                               QWidget)

sys.path.insert(0, str(Path(__file__).resolve().parent))
from systools_ui import DEMO, GREEN, GREY, RED, YELLOW, accent, dim, dot, facts, ui  # noqa: E402

LIB = Path("/usr/lib/phoenixge/bench")
if not LIB.exists():  # running from the source tree
    LIB = Path(__file__).resolve().parent.parent / "bench"
sys.path.insert(0, str(LIB))
import benchref  # noqa: E402

COL = {"green": GREEN, "yellow": YELLOW, "red": RED, "grey": GREY}
STAGE_NAMES = {"idle": "Idle", "cpu": "CPU", "ram": "RAM", "disk": "Disk", "gpu": "GPU", "end": ""}
TOTAL_SECS = 125


def fmt(v, unit):
    if v is None:
        return "-"
    if unit == "MiB/s":
        return f"{v / 1024:.1f} GiB/s"
    if unit == "MB/s" and v >= 1000:
        return f"{v / 1000:.2f} GB/s"
    return f"{v:,} {unit}".replace(",", " ")


class RatioBar(QWidget):
    """Your result vs typical: bar to 150%, tick at 100%."""

    def __init__(self, ratio, color):
        super().__init__()
        self.ratio, self.color = ratio, QColor(color)
        self.setFixedHeight(10); self.setMinimumWidth(120)

    def paintEvent(self, _e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        off = QColor(self.palette().color(self.palette().ColorRole.PlaceholderText)); off.setAlpha(60)
        r = QRectF(self.rect()).adjusted(0, 1, 0, -1)
        p.setPen(Qt.NoPen); p.setBrush(off); p.drawRoundedRect(r, 4, 4)
        if self.ratio:
            w = r.width() * min(self.ratio, 1.5) / 1.5
            p.setBrush(self.color); p.drawRoundedRect(QRectF(r.left(), r.top(), w, r.height()), 4, 4)
        x = r.left() + r.width() / 1.5
        p.setPen(QPen(self.palette().color(self.palette().ColorRole.WindowText), 2))
        p.drawLine(QPointF(x, 0), QPointF(x, self.height()))
        p.end()


class TempGraph(QWidget):
    """CPU and GPU temperature over the run, test stages shaded."""

    def __init__(self, acc):
        super().__init__()
        self.samples, self.acc = [], acc
        self.setMinimumHeight(170)

    def set_samples(self, s):
        self.samples = list(s); self.update()

    def paintEvent(self, _e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        pal = self.palette(); txt = pal.color(pal.ColorRole.PlaceholderText)
        r = QRectF(self.rect()).adjusted(36, 18, -10, -20)
        f = QFont(self.font()); f.setPointSizeF(max(7.0, f.pointSizeF() - 1.5)); p.setFont(f)
        grid = QColor(txt); grid.setAlpha(50)
        lo, hi = 30, 100
        for v in (40, 60, 80, 100):
            y = r.bottom() - r.height() * (v - lo) / (hi - lo)
            p.setPen(QPen(grid, 1)); p.drawLine(QPointF(r.left(), y), QPointF(r.right(), y))
            p.setPen(txt); p.drawText(QRectF(0, y - 8, 30, 16), Qt.AlignRight | Qt.AlignVCenter, f"{v}°")
        s = self.samples
        if not s:
            p.setPen(txt); p.drawText(r, Qt.AlignCenter, "Temperatures appear here while the test runs.")
            p.end(); return
        t0, t1 = s[0]["t"], max(s[-1]["t"], s[0]["t"] + 1)

        def X(t):
            return r.left() + r.width() * (t - t0) / (t1 - t0)
        # stage bands
        band = QColor(self.acc); band.setAlpha(22)
        i = 0
        while i < len(s):
            st = s[i].get("stage"); j = i
            while j + 1 < len(s) and s[j + 1].get("stage") == st:
                j += 1
            if st not in ("idle", "end") and i:
                x0, x1 = X(s[i]["t"]), X(s[j]["t"])
                if (list(STAGE_NAMES).index(st) if st in STAGE_NAMES else 0) % 2:
                    p.fillRect(QRectF(x0, r.top(), x1 - x0, r.height()), band)
                p.setPen(txt); p.drawText(QRectF(x0, 0, max(30, x1 - x0), 16), Qt.AlignHCenter, STAGE_NAMES.get(st, st))
            i = j + 1
        for key, color, label in (("cpu_temp", self.acc, "CPU"), ("gpu_temp", "#58a6ff", "GPU")):
            pts = [(x["t"], x[key]) for x in s if x.get(key)]
            if len(pts) < 2:
                continue
            path = QPainterPath()
            for k, (t, v) in enumerate(pts):
                pt = QPointF(X(t), r.bottom() - r.height() * (min(max(v, lo), hi) - lo) / (hi - lo))
                path.moveTo(pt) if k == 0 else path.lineTo(pt)
            p.setPen(QPen(QColor(color), 2)); p.setBrush(Qt.NoBrush); p.drawPath(path)
        p.setPen(QColor(self.acc)); p.drawText(QRectF(r.left(), r.bottom() + 3, 60, 16), Qt.AlignLeft, "— CPU")
        p.setPen(QColor("#58a6ff")); p.drawText(QRectF(r.left() + 60, r.bottom() + 3, 60, 16), Qt.AlignLeft, "— GPU")
        p.setPen(txt); p.drawText(QRectF(r.left(), r.bottom() + 3, r.width(), 16), Qt.AlignRight, f"{int(t1 - t0)} s")
        p.end()


class BenchPage(QWidget):
    def __init__(self, center):
        super().__init__()
        self.center = center
        self.acc = accent()
        Card, page, _FG = ui(center)
        self.Card = Card
        w, lay = page("Benchmark", "Is your PC as fast as it should be? One test of processor, memory, disk and "
                                   "graphics, compared with typical results for your hardware.")
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0); outer.addWidget(w)

        # ---- start
        hero = Card()
        hrow = QHBoxLayout()
        self.go = QPushButton("Is my PC OK?"); self.go.setObjectName("primary")
        self.go.setStyleSheet("font-size:16px;padding:12px 28px;")
        self.go.clicked.connect(self.start)
        self.cancel = QPushButton("Cancel"); self.cancel.clicked.connect(self.stop); self.cancel.hide()
        htxt = QVBoxLayout()
        self.hint = QLabel("About 2-3 minutes. Close games and big downloads first - the fans will get loud, that's normal.")
        self.hint.setWordWrap(True)
        htxt.addWidget(self.hint)
        tests = QHBoxLayout()
        self.checks = {}
        for tid, label in (("cpu", "Processor"), ("ram", "Memory"), ("disk", "Disk"), ("gpu", "Graphics")):
            cb = QCheckBox(label); cb.setChecked(True); tests.addWidget(cb); self.checks[tid] = cb
        tests.addStretch(); htxt.addLayout(tests)
        hrow.addWidget(self.go); hrow.addSpacing(16); hrow.addLayout(htxt, 1); hrow.addWidget(self.cancel)
        hero.lay.addLayout(hrow)
        self.prog = QProgressBar(); self.prog.setRange(0, 1000); self.prog.setTextVisible(False); self.prog.setFixedHeight(8)
        self.prog.hide()
        self.stage = QLabel(""); self.stage.setStyleSheet("font-weight:600;")
        self.live = dim("")
        hero.lay.addWidget(self.prog); hero.lay.addWidget(self.stage); hero.lay.addWidget(self.live)
        lay.addWidget(hero)

        # ---- verdict
        self.vcard = Card()
        vrow = QHBoxLayout(); self.vdot = QLabel(); self.vdot.setFixedSize(22, 22)
        self.vtext = QLabel("No test yet."); self.vtext.setWordWrap(True); self.vtext.setStyleSheet("font-size:16px;font-weight:600;")
        self.vwhen = dim("")
        vv = QVBoxLayout(); vv.addWidget(self.vtext); vv.addWidget(self.vwhen)
        vrow.addWidget(self.vdot); vrow.addLayout(vv, 1)
        self.vcard.lay.addLayout(vrow)
        lay.addWidget(self.vcard)

        # ---- recommendations
        self.rcard = Card("What to do")
        self.rbox = QVBoxLayout(); self.rbox.setSpacing(10); self.rcard.lay.addLayout(self.rbox)
        self.rcard.hide(); lay.addWidget(self.rcard)

        # ---- results
        self.res = Card("Your result vs typical for your hardware")
        self.grid = QGridLayout(); self.grid.setHorizontalSpacing(14); self.grid.setVerticalSpacing(6)
        self.res.lay.addLayout(self.grid)
        self.res.lay.addWidget(dim("Typical values are approximate: there is no PhoenixGe results server, so they come "
                                   "from a curated table of public results (graphics values are estimates). The black "
                                   "line is 100% of typical. Laptops differ by ±20% depending on the maker's power limits."))
        self.res.hide(); lay.addWidget(self.res)

        # ---- thermals
        self.tcard = Card("Temperatures during the test")
        self.graph = TempGraph(self.acc); self.tcard.lay.addWidget(self.graph)
        self.tfacts = QVBoxLayout(); self.tcard.lay.addLayout(self.tfacts)
        lay.addWidget(self.tcard)

        # ---- system + history
        self.scard = Card("Tested hardware"); self.sbox = QVBoxLayout(); self.scard.lay.addLayout(self.sbox)
        self.scard.hide(); lay.addWidget(self.scard)
        self.hcard = Card("Earlier runs"); self.hgrid = QGridLayout(); self.hgrid.setHorizontalSpacing(18)
        self.hcard.lay.addLayout(self.hgrid); self.hcard.hide(); lay.addWidget(self.hcard)
        lay.addStretch()

        self.proc, self.buf, self.samples, self.t0, self.done_secs, self.cur_secs = None, "", [], 0, 0, 0
        self.shown = False

    def showEvent(self, e):
        super().showEvent(e)
        if not self.shown:
            self.shown = True
            runs = [benchref.demo_run()] if DEMO else benchref.load_history()
            if DEMO:
                old = json.loads(json.dumps(runs[0]))
                old["time"] -= 86400 * 12
                old["results"]["cpu"]["multi"] = 44100; old["results"]["gpu"]["score"] = 8810
                old["analysis"] = benchref.analyze(old)
                self.history = [old] + runs
            else:
                self.history = runs
            if runs:
                self.show_run(runs[-1])
            self.show_history()

    # ---------------------------------------------------------------- run
    def start(self):
        if self.proc or DEMO:
            return
        skip = [t for t, cb in self.checks.items() if not cb.isChecked()]
        if len(skip) == 4:
            return
        self.go.setEnabled(False); self.cancel.show(); self.prog.show(); self.prog.setValue(0)
        for cb in self.checks.values():
            cb.setEnabled(False)
        self.samples, self.buf, self.t0, self.done_secs, self.cur_secs = [], "", time.time(), 0, 0
        self.total = sum(s for t, _n, s in (("cpu", 0, 35), ("ram", 0, 10), ("disk", 0, 25), ("gpu", 0, 50))
                         if t not in skip) + 3
        self.stage.setText("Starting…"); self.graph.set_samples([])
        p = QProcess(self)
        p.setProcessChannelMode(QProcess.SeparateChannels)
        p.readyReadStandardOutput.connect(self.read_out)
        p.finished.connect(self.finished)
        p.errorOccurred.connect(lambda err: err == QProcess.ProcessError.FailedToStart and self.finished(-1))
        self.proc = p
        args = [str(LIB / "benchrun.py"), "--json"] + (["--skip", ",".join(skip)] if skip else [])
        p.start(sys.executable or "python3", args)

    def stop(self):
        if self.proc:
            self.proc.terminate()
            self.stage.setText("Cancelling…")

    def read_out(self):
        self.buf += bytes(self.proc.readAllStandardOutput()).decode(errors="replace")
        while "\n" in self.buf:
            line, self.buf = self.buf.split("\n", 1)
            try:
                ev = json.loads(line)
            except ValueError:
                continue
            self.on_event(ev)

    def on_event(self, ev):
        k = ev.get("ev")
        if k == "stage":
            self.done_secs += self.cur_secs
            self.cur_secs, self.stage_t = ev["secs"], time.time()
            self.stage.setText(f"{ev['n']}/{ev['of']}  {ev['title']}…")
        elif k == "sample":
            self.samples.append(ev)
            self.graph.set_samples(self.samples)
            parts = []
            if ev.get("cpu_temp"):
                parts.append(f"CPU {ev['cpu_temp']:.0f} °C" + (f" · {ev['cpu_mhz'] / 1000:.1f} GHz" if ev.get("cpu_mhz") else ""))
            if ev.get("gpu_temp"):
                parts.append(f"GPU {ev['gpu_temp']:.0f} °C" + (f" · {ev['gpu_power']:.0f} W" if ev.get("gpu_power") else ""))
            self.live.setText("   ".join(parts))
            if self.cur_secs:
                frac = min(0.97, (self.done_secs + min(time.time() - self.stage_t, self.cur_secs)) / self.total)
                self.prog.setValue(int(frac * 1000))
        elif k == "done":
            self.history = benchref.load_history() or [ev["run"]]
            self.show_run(ev["run"])
            self.show_history()

    def finished(self, code, _s=None):
        self.proc = None
        self.go.setEnabled(True); self.cancel.hide(); self.prog.hide(); self.live.setText("")
        for cb in self.checks.values():
            cb.setEnabled(True)
        if code == 0:
            self.stage.setText("")
        elif code in (130, 15, -15) or code is None:
            self.stage.setText("Cancelled.")
        else:
            self.stage.setText(f"The test stopped unexpectedly ({code}).")

    # ---------------------------------------------------------------- show results
    def clear(self, box):
        while box.count():
            it = box.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
            elif it.layout():
                self.clear(it.layout())

    def show_run(self, run):
        a = run.get("analysis") or benchref.analyze(run)
        self.vdot.setStyleSheet(f"background:{COL[a['state']]}; border-radius:11px;")
        self.vtext.setText(a["summary"])
        self.vwhen.setText("Tested " + time.strftime("%d %b %Y %H:%M", time.localtime(run.get("time", 0))))
        # recommendations
        self.clear(self.rbox)
        for r in a["recommendations"]:
            row = QWidget(); g = QGridLayout(row); g.setContentsMargins(0, 0, 0, 0); g.setHorizontalSpacing(10)
            g.addWidget(dot(COL[r["severity"]]), 0, 0, Qt.AlignTop)
            t = QLabel(f"<b>{r['title']}</b>"); g.addWidget(t, 0, 1)
            g.addWidget(dim(r["text"]), 1, 1)
            btn = self.action_button(r.get("action"))
            if btn:
                g.addWidget(btn, 0, 2, 2, 1, Qt.AlignVCenter)
            g.setColumnStretch(1, 1)
            self.rbox.addWidget(row)
        self.rcard.setVisible(bool(a["recommendations"]))
        # results
        self.clear(self.grid)
        for c, h in enumerate(("", "Test", "Your result", "Typical", "", "")):
            if h:
                x = QLabel(h); x.setObjectName("dim"); self.grid.addWidget(x, 0, c)
        for i, it in enumerate(a["items"], 1):
            self.grid.addWidget(dot(COL[it["state"]]), i, 0)
            self.grid.addWidget(QLabel(it["title"]), i, 1)
            self.grid.addWidget(QLabel(f"<b>{fmt(it.get('value'), it.get('unit', ''))}</b>"), i, 2)
            typ = fmt(it.get("typical"), it.get("unit", "")) if it.get("typical") else "-"
            if it.get("typical") and it.get("estimated"):
                typ = "≈ " + typ
            self.grid.addWidget(QLabel(typ), i, 3)
            if it.get("ratio"):
                self.grid.addWidget(RatioBar(it["ratio"], COL[it["state"]]), i, 4)
                self.grid.addWidget(QLabel(f"{it['ratio'] * 100:.0f}%"), i, 5)
            elif it.get("note"):
                self.grid.addWidget(dim(it["note"]), i, 4, 1, 2)
        self.grid.setColumnStretch(4, 1)
        self.res.show()
        # thermals
        self.graph.set_samples(run.get("samples") or [])
        th = a["thermal"]
        self.clear(self.tfacts)
        rows = []
        if th.get("cpu_max") is not None:
            rows.append(("Processor", f"max {th['cpu_max']} °C" + (" - slowed down because of heat" if th["cpu_throttled"]
                                                                   else " - no throttling")))
        if th.get("gpu_max") is not None:
            rows.append(("Graphics", f"max {th['gpu_max']} °C" + (" - slowed down: " + ", ".join(th["gpu_reasons"])
                                                                  if th["gpu_throttled"] else " - no throttling")))
        if run.get("throttle_events"):
            rows.append(("Thermal events", f"{run['throttle_events']} during the test (reported by the processor)"))
        if rows:
            self.tfacts.addWidget(facts(rows))
        # system
        s = run.get("system", {}); d = s.get("disk") or {}
        self.clear(self.sbox)
        rows = [("Processor", f"{s.get('cpu', '?')} ({s.get('threads', '?')} threads)" +
                 (f" - compared with {a['cpu_ref']}" if a.get("cpu_ref") else "")),
                ("Graphics", "\n".join(s.get("gpus") or ["?"])),
                ("Tested on", (run.get("results", {}).get("gpu", {}) or {}).get("used", "") or "-"),
                ("NVIDIA driver", s.get("nvidia_driver") or ("not loaded" if s.get("nvidia_present") else "-")),
                ("Memory", f"{s.get('ram_mib', 0) / 1024:.1f} GB"),
                ("Disk", " · ".join(x for x in (d.get("model", ""), d.get("link", "")) if x) or "-"),
                ("Power", (s.get("power_profile") or "-").replace("-", " ").title() +
                 ("" if not s.get("laptop") else (" · charger plugged in" if s.get("on_ac") else " · on battery")))]
        self.sbox.addWidget(facts(rows))
        self.scard.show()

    def action_button(self, action):
        if action == "performance":
            b = QPushButton("Switch to Performance"); b.clicked.connect(self.set_performance)
        elif action == "drivers":
            b = QPushButton("Open Drivers"); b.clicked.connect(self.open_drivers)
        elif action == "rerun":
            b = QPushButton("Run again"); b.clicked.connect(self.start)
        else:
            return None
        return b

    def set_performance(self):
        if DEMO:
            return
        self.center.runner.run("powerprofilesctl", ["set", "performance"])

    def open_drivers(self):
        if hasattr(self.center, "go"):
            self.center.go("drivers")
            return
        nav = getattr(self.center, "nav", None)
        if nav is not None:
            items = nav.findItems("Drivers", Qt.MatchExactly)
            if items:
                nav.setCurrentItem(items[0])

    def show_history(self):
        self.clear(self.hgrid)
        runs = list(reversed(self.history[-8:]))
        if len(runs) < 2:
            self.hcard.hide(); return
        for c, h in enumerate(("When", "Processor", "Memory", "Disk read", "Graphics", "Result")):
            x = QLabel(h); x.setObjectName("dim"); self.hgrid.addWidget(x, 0, c)
        for i, r in enumerate(runs, 1):
            res = r.get("results", {})
            a = r.get("analysis") or {}
            vals = [time.strftime("%d %b %H:%M", time.localtime(r.get("time", 0))),
                    fmt((res.get("cpu") or {}).get("multi"), "MIPS"), fmt((res.get("ram") or {}).get("write_mibs"), "MiB/s"),
                    fmt((res.get("disk") or {}).get("read_mbs"), "MB/s"), fmt((res.get("gpu") or {}).get("score"), "pts")]
            for c, v in enumerate(vals):
                self.hgrid.addWidget(QLabel(v), i, c)
            st = QWidget(); h = QHBoxLayout(st); h.setContentsMargins(0, 0, 0, 0)
            h.addWidget(dot(COL.get(a.get("state", "grey"), GREY))); h.addStretch()
            self.hgrid.addWidget(st, i, 5)
        self.hgrid.setColumnStretch(5, 1)
        self.hcard.show()


def build(center):
    return BenchPage(center)


if __name__ == "__main__":  # standalone test window
    from PySide6.QtWidgets import QApplication, QPlainTextEdit
    app = QApplication(sys.argv)

    class _Fake(QWidget):
        def __init__(self):
            super().__init__()
            lay = QVBoxLayout(self); self.log = QPlainTextEdit(); self.log.setMaximumHeight(150); self.log.hide()
            try:
                main = sys.modules.get("center") or __import__("center")
                self.runner = main.Runner(self.log)
            except Exception:  # noqa: BLE001
                self.runner = None
            lay.addWidget(build(self)); lay.addWidget(self.log)
    f = _Fake(); f.resize(1100, 1500); f.show()
    sys.exit(app.exec())
