"""USB Creator - pure logic (no Qt): which disks are safe targets, dd progress parsing. Unit-testable anywhere.

The real safety checks are repeated as root in /usr/lib/phoenixge/usb-write.sh - this file decides what the user
is even allowed to pick.
"""
import json
import os
import re
import subprocess

# TODO: set once there is a public download. Empty = the "Download" button is disabled and users pick a local .iso.
ISO_URL = ""
ISO_SHA256_URL = ""  # optional: URL of a "<sha256>  <name>" file for ISO_URL
ISO_NAME = "phoenixge-latest-amd64.iso"
WRITE_HELPER = "/usr/lib/phoenixge/usb-write.sh"

# a disk that holds any of these is the running system and can never be a target
SYSTEM_MOUNTS = {"/", "/boot", "/boot/efi", "/efi", "/usr", "/var", "/home", "[SWAP]",
                 "/run/live/medium", "/lib/live/mount/medium", "/run/initramfs/live"}
BIG_DISK = 256e9  # bigger than this is probably an external hard drive, not a stick -> extra warning
LSBLK_CMD = ["lsblk", "-J", "-b", "-o", "NAME,PATH,SIZE,MODEL,VENDOR,TRAN,RM,RO,HOTPLUG,TYPE,MOUNTPOINTS"]


def human(n):
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1000 or unit == "TB":
            return f"{n:.0f} {unit}" if unit in ("B", "KB") else f"{n:.1f} {unit}"
        n /= 1000.0


def _mounts(node):
    """All mount points of a device and everything below it (partitions, LUKS, LVM)."""
    out = [m for m in (node.get("mountpoints") or ([node["mountpoint"]] if node.get("mountpoint") else [])) if m]
    for c in node.get("children") or []:
        out += _mounts(c)
    return out


def _holders(node):
    """Types of everything below the disk that is not a plain partition (crypt / lvm / raid)."""
    out = []
    for c in node.get("children") or []:
        if c.get("type") not in ("part",):
            out.append(c.get("type"))
        out += _holders(c)
    return out


def _flag(v):
    return v in (True, 1, "1", "true")


def _under(path, mnt):
    path = path.rstrip("/") or "/"
    mnt = mnt.rstrip("/") or "/"
    return mnt != "/" and (path == mnt or path.startswith(mnt + "/"))


def usb_targets(lsblk_json, iso_path=""):
    """lsblk -J output -> list of dict(path, name, model, size, mounts, blocked, warn) for USB disks only."""
    try:
        data = json.loads(lsblk_json) if isinstance(lsblk_json, str) else lsblk_json
    except ValueError:
        return []
    out = []
    for d in data.get("blockdevices", []):
        if d.get("type") != "disk" or (d.get("tran") or "").lower() != "usb":
            continue
        path = d.get("path") or "/dev/" + d.get("name", "")
        size = int(d.get("size") or 0)
        model = " ".join(x for x in ((d.get("vendor") or "").strip(), (d.get("model") or "").strip()) if x) or "USB drive"
        mounts = _mounts(d)
        blocked = None
        if not re.fullmatch(r"/dev/sd[a-z]{1,2}", path):
            blocked = "unexpected device name"
        elif any(m in SYSTEM_MOUNTS for m in mounts):
            blocked = "this disk holds the running system"
        elif iso_path and any(_under(iso_path, m) for m in mounts):
            blocked = "the ISO file is stored on this disk"
        elif _flag(d.get("ro")):
            blocked = "read-only (write-protect switch?)"
        elif size <= 0:
            blocked = "no medium inserted"
        elif _holders(d):
            blocked = "has open encrypted/LVM volumes - close them first"
        warn = "This is bigger than a normal USB stick - is it an external hard drive?" if size > BIG_DISK else ""
        out.append(dict(path=path, name=d.get("name"), model=model, size=size, mounts=mounts, blocked=blocked, warn=warn))
    return out


def list_targets(iso_path=""):
    try:
        txt = subprocess.run(LSBLK_CMD, capture_output=True, text=True, timeout=10).stdout
    except Exception:
        txt = ""
    return usb_targets(txt or "{}", os.path.realpath(iso_path) if iso_path else "")


_BYTES = re.compile(r"(\d+) bytes")


def parse_dd_progress(text):
    """Last byte count in a chunk of `dd status=progress` output (lines end in \\r), or None."""
    found = _BYTES.findall(text)
    return int(found[-1]) if found else None


def parse_helper_line(line):
    """'PHX-STAGE write 123' -> ('stage', 'write', 123); 'PHX-RESULT ok' -> ('result', 'ok', None);
    'PHX-ERROR text' -> ('error', 'text', None); dd progress -> ('progress', None, n); else None."""
    line = line.strip()
    m = re.match(r"PHX-STAGE (\w+)(?: (\d+))?$", line)
    if m:
        return ("stage", m.group(1), int(m.group(2)) if m.group(2) else None)
    m = re.match(r"PHX-RESULT (\w+)", line)
    if m:
        return ("result", m.group(1), None)
    m = re.match(r"PHX-ERROR (.*)", line)
    if m:
        return ("error", m.group(1), None)
    n = parse_dd_progress(line)
    if n is not None and "copied" in line:
        return ("progress", None, n)
    return None


def is_iso(path):
    """ISO 9660 signature 'CD001' at byte 32769."""
    try:
        with open(path, "rb") as f:
            f.seek(32769)
            return f.read(5) == b"CD001"
    except OSError:
        return False


def parse_sha256_file(text):
    m = re.search(r"\b([0-9a-fA-F]{64})\b", text or "")
    return m.group(1).lower() if m else None
