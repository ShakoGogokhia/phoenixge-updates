"""PhoenixGe Center > Hibernate: check whether this computer can hibernate (save everything to disk and switch off,
continue exactly there at the next start), turn it on/off with one button, and "sleep, then hibernate after N hours".

build(center) -> QWidget       root work: /usr/lib/phoenixge/hibernate-setup.sh (pkexec)
python3 hibernate.py [--demo]
"""
import math
import os
import shutil
import sys
from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import QCheckBox, QComboBox, QHBoxLayout, QLabel, QMessageBox, QPushButton, QVBoxLayout, QWidget

sys.path.insert(0, str(Path(__file__).resolve().parent))
from systools_ui import DEMO, GREEN, GREY, RED, YELLOW, dim, dot, facts, sh, ui  # noqa: E402

HELPER = "/usr/lib/phoenixge/hibernate-setup.sh"
STATE = Path("/var/lib/phoenixge/hibernate.state")
GRUBCFG = Path("/etc/default/grub.d/phoenixge-resume.cfg")
SLEEPCONF = Path("/etc/systemd/sleep.conf.d/phoenixge-hibernate.conf")
DELAYS = [("30 minutes", 1800), ("1 hour", 3600), ("2 hours", 7200), ("3 hours", 10800), ("6 hours", 21600)]


def read(p, default=""):
    try:
        return Path(p).read_text(errors="ignore").strip()
    except OSError:
        return default


def gb(kb):
    return f"{kb / 1048576:.1f} GB"


def check():
    """Everything the page shows. dict(state=on|pending|off|impossible, reasons=[...], facts=[...], ...)"""
    if DEMO:
        return dict(state="off", ram_kb=16 * 1048576 - 380000, fs="btrfs", free_kb=212 * 1048576, need_gb=16,
                    swaps=[("/dev/zram0", "zram", 8 * 1048576)], secureboot="off", lockdown="none", kernel=True,
                    can="na", reasons=[], plan="A 16 GB swap file is created in /swap (btrfs subvolume @swap).",
                    delay="", live=False)
    r = dict(reasons=[], live=Path("/run/live").exists())
    mem = {l.split(":")[0]: int(l.split()[1]) for l in read("/proc/meminfo").splitlines() if l.split()[1:2] and l.split()[1].isdigit()}
    r["ram_kb"] = mem.get("MemTotal", 0)
    r["need_gb"] = math.ceil(r["ram_kb"] / 1048576)
    r["fs"] = sh("findmnt -no FSTYPE /")
    try:
        st = os.statvfs("/")
        r["free_kb"] = st.f_bavail * st.f_frsize // 1024
    except OSError:
        r["free_kb"] = 0
    r["swaps"] = []
    for l in read("/proc/swaps").splitlines()[1:]:
        f = l.split()
        if len(f) >= 3:
            r["swaps"].append((f[0], "zram" if "zram" in f[0] else f[1], int(f[2])))
    lock = read("/sys/kernel/security/lockdown")
    r["lockdown"] = lock[lock.find("[") + 1:lock.find("]")] if "[" in lock else "unknown"
    sb = sh("mokutil --sb-state 2>/dev/null")
    r["secureboot"] = "on" if "enabled" in sb.lower() else "off" if sb else "unknown"
    r["kernel"] = "disk" in read("/sys/power/state").split()
    disk = read("/sys/power/disk")
    r["can"] = sh("busctl call org.freedesktop.login1 /org/freedesktop/login1 org.freedesktop.login1.Manager CanHibernate "
                  "2>/dev/null").replace('s "', "").strip('"') or "unknown"
    cmd = read("/proc/cmdline")
    conf = GRUBCFG.exists()
    r["delay"] = ""
    for l in read(SLEEPCONF).splitlines():
        if l.startswith("HibernateDelaySec="):
            r["delay"] = l.split("=", 1)[1]
    # verdict
    if r["live"]:
        r["reasons"].append("This is the live session - install PhoenixGe first.")
    if r["lockdown"] in ("integrity", "confidentiality") or "[disabled]" in disk:
        r["reasons"].append("Secure Boot is on, and Linux then locks hibernation (a hibernated memory image could be "
                            "changed while the computer is off). Turn Secure Boot off in the firmware setup (F2/Del at "
                            "start) to use hibernation. Sleep still works.")
    elif not r["kernel"]:
        r["reasons"].append("This kernel doesn't support hibernation.")
    big_part = [s for s in r["swaps"] if s[1] == "partition" and s[2] >= r["ram_kb"] * 0.95]
    if big_part:
        r["plan"] = f"Your swap partition {big_part[0][0]} ({gb(big_part[0][2])}) is big enough - it is used."
    elif r["fs"] not in ("btrfs", "ext4", "xfs"):
        r["reasons"].append(f"The system disk uses {r['fs'] or 'an unknown file system'}; a swap file needs btrfs, ext4 or xfs.")
    else:
        cur = 0
        f = "/swap/swapfile" if r["fs"] == "btrfs" else "/swapfile"
        try:
            cur = os.path.getsize(f) // 1024
        except OSError:
            pass
        need = r["need_gb"] * 1048576
        if cur < need and r["free_kb"] + cur < need + 3 * 1048576:
            r["reasons"].append(f"Not enough free disk space: hibernation needs a {r['need_gb']} GB swap file (the size of your "
                                f"memory) plus 3 GB to spare, but only {gb(r['free_kb'] + cur)} is free. Free some space "
                                "(Health > Clean up) and check again.")
        r["plan"] = (f"A {r['need_gb']} GB swap file is created in /swap (btrfs subvolume @swap, not included in snapshots)."
                     if r["fs"] == "btrfs" else f"A {r['need_gb']} GB swap file /swapfile is created.")
        if cur >= need:
            r["plan"] = f"The existing swap file {f} ({gb(cur)}) is big enough - it is used."
    if conf and "resume=" in cmd:
        r["state"] = "on"
    elif conf:
        r["state"] = "pending"
    elif r["reasons"]:
        r["state"] = "impossible"
    else:
        r["state"] = "off"
    return r


class HibernatePage(QWidget):
    def __init__(self, center):
        super().__init__()
        self.center = center
        Card, page, _F = ui(center)
        self.Card = Card
        w, lay = page("Hibernate", "Hibernate saves everything that is open to the disk and switches the computer off completely. "
                                   "At the next start you continue exactly where you were - and it uses no battery meanwhile.")
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0); outer.addWidget(w)
        self.status = Card()
        lay.addWidget(self.status)
        self.sleep_card = Card("Sleep, then hibernate", "When the laptop sleeps for a long time (lid closed, bag), it hibernates "
                               "by itself so the battery isn't drained. Opening the lid before that wakes it instantly as usual.")
        row = QHBoxLayout()
        self.sth = QCheckBox("Hibernate after sleeping for"); self.sth_time = QComboBox()
        for label, sec in DELAYS:
            self.sth_time.addItem(label, sec)
        self.sth_time.setCurrentIndex(2)
        self.sth_save = QPushButton("Save"); self.sth_save.clicked.connect(self.save_delay)
        row.addWidget(self.sth); row.addWidget(self.sth_time); row.addWidget(self.sth_save); row.addStretch()
        self.sleep_card.lay.addLayout(row)
        lay.addWidget(self.sleep_card)
        lay.addWidget(Card("Good to know", "• Hibernating and starting again takes 10-30 seconds (the memory is written to and "
                                           "read from the disk).\n• Don't start Windows while PhoenixGe is hibernated and change "
                                           "files on shared drives.\n• NVIDIA: if the screen stays black after waking up, update "
                                           "the driver (Drivers page) - newer drivers handle it."))
        lay.addStretch()
        self.info = None
        self.shown_once = False

    def showEvent(self, e):
        super().showEvent(e)
        if not self.shown_once:
            self.shown_once = True
            self.refresh()

    def refresh(self):
        self.info = r = check()
        lay = self.status.lay
        while lay.count():
            it = lay.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
            elif it.layout():
                _clear(it.layout())
        col, title = {"on": (GREEN, "Hibernation is on"), "pending": (YELLOW, "Hibernation is set up - restart once to finish"),
                      "off": (GREY, "Hibernation is off - this computer can use it"),
                      "impossible": (RED, "Hibernation is not possible right now")}[r["state"]]
        head = QHBoxLayout(); head.addWidget(dot(col, 18))
        t = QLabel(title); t.setStyleSheet("font-size:16px;font-weight:600;"); head.addWidget(t, 1)
        again = QPushButton("Check again"); again.clicked.connect(self.refresh); head.addWidget(again)
        lay.addLayout(head)
        swaps = ", ".join(f"{n} ({'compressed RAM' if k == 'zram' else k}, {gb(s)})" for n, k, s in r["swaps"]) or "none"
        sb = {"on": "on", "off": "off", "unknown": "unknown"}[r["secureboot"]]
        if r.get("lockdown") in ("integrity", "confidentiality"):
            sb += " - kernel lockdown active"
        lay.addWidget(facts([("Memory (RAM)", gb(r["ram_kb"])), ("Swap now", swaps),
                             ("System disk", f"{r['fs'] or '?'}, {gb(r['free_kb'])} free"),
                             ("Secure Boot", sb)]))
        for reason in r["reasons"]:
            x = QLabel("• " + reason); x.setWordWrap(True); lay.addWidget(x)
        if r["state"] == "off" and r.get("plan"):
            lay.addWidget(dim("What happens: " + r["plan"] + " The boot files are updated (resume=) and \"Hibernate\" appears "
                              "in the power menu after one restart. Turning it off again removes all of it."))
        row = QHBoxLayout()
        if r["state"] in ("on", "pending"):
            b = QPushButton("Turn hibernation off"); b.clicked.connect(self.disable)
            row.addWidget(b)
            if r["state"] == "pending":
                rb = QPushButton("Restart now"); rb.setObjectName("primary"); rb.clicked.connect(_restart); row.addWidget(rb)
            else:
                tb = QPushButton("Hibernate now"); tb.setObjectName("primary")
                tb.clicked.connect(lambda: self.center.runner.run("systemctl", ["hibernate"])); row.addWidget(tb)
        else:
            b = QPushButton("Enable hibernation"); b.setObjectName("primary"); b.setEnabled(r["state"] == "off")
            b.clicked.connect(self.enable); row.addWidget(b)
        row.addStretch(); lay.addLayout(row)
        on = r["state"] in ("on", "pending")
        self.sleep_card.setEnabled(on)
        self.sth.setChecked(bool(r.get("delay")) and r["delay"] != "off")
        if r.get("delay", "").isdigit():
            i = self.sth_time.findData(int(r["delay"]))
            if i >= 0:
                self.sth_time.setCurrentIndex(i)
        if not on:
            self.sth.setToolTip("Turn hibernation on first.")

    def enable(self):
        r = self.info
        if QMessageBox.question(self, "Enable hibernation", f"{r.get('plan', '')}\n\nThe boot files are updated - this takes "
                                "a minute and asks for your password. Continue?") != QMessageBox.Yes:
            return
        self.center.runner.root(HELPER, ["enable"], lambda code: self.after(code))

    def disable(self):
        if QMessageBox.question(self, "Turn hibernation off", "Remove the hibernation setup (and the swap file PhoenixGe "
                                "created)? Sleep keeps working.") != QMessageBox.Yes:
            return
        self.center.runner.root(HELPER, ["disable"], lambda code: self.after(code, plasma_mode=1))

    def after(self, code, plasma_mode=None):
        if code == 3:
            QMessageBox.warning(self, "Hibernate", "Not possible - see the details in the log below.")
        if plasma_mode:
            set_plasma_sleep_mode(1)
        self.refresh()

    def save_delay(self):
        on = self.sth.isChecked()
        sec = self.sth_time.currentData()
        self.center.runner.root(HELPER, ["delay", str(sec) if on else "off"], lambda code: code == 0 and self.refresh())
        set_plasma_sleep_mode(3 if on else 1)


def set_plasma_sleep_mode(mode):
    """Plasma's own sleep button/lid: 1 = Standby (sleep), 3 = Standby, then hibernate. Per user (powerdevilrc)."""
    if DEMO or not shutil.which("kwriteconfig6"):
        return
    for prof in ("AC", "Battery", "LowBattery"):
        sh(["kwriteconfig6", "--file", "powerdevilrc", "--group", prof, "--group", "SuspendAndShutdown", "--key", "SleepMode", str(mode)])
    sh("gdbus call --session --dest org.kde.Solid.PowerManagement --object-path /org/kde/Solid/PowerManagement "
       "--method org.kde.Solid.PowerManagement.reparseConfiguration >/dev/null 2>&1")


def _restart():
    sh("qdbus6 org.kde.LogoutPrompt /LogoutPrompt promptReboot 2>/dev/null || systemctl reboot")


def _clear(layout):
    while layout.count():
        it = layout.takeAt(0)
        if it.widget():
            it.widget().deleteLater()
        elif it.layout():
            _clear(it.layout())


def build(center):
    return HibernatePage(center)


if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication, QPlainTextEdit
    app = QApplication(sys.argv)

    class _Host(QWidget):
        def __init__(self):
            super().__init__()
            lay = QVBoxLayout(self); self.log = QPlainTextEdit(); self.log.setMaximumHeight(120); self.log.hide()
            import center as cmod
            self.runner = cmod.Runner(self.log)
            lay.addWidget(build(self)); lay.addWidget(self.log)
    h = _Host(); h.resize(1000, 760); h.show()
    sys.exit(app.exec())
