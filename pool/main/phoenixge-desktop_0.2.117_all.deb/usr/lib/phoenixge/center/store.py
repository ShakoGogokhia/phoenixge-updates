"""Phoenix Store catalog (PhoenixGe Center > Store).

kind:
  flatpak  id = Flathub app id (installed per user, sandboxed, auto-updated)
  apt      id = space separated Debian packages (installed with the admin password)
  aptbpo   same, from Debian backports (newer versions)
  script   id = /usr/lib/phoenixge/dev/<script> run as the user (e.g. Flutter, EAS CLI)
  info     no install, just text (e.g. iOS)
"""

CATEGORIES = ["Games", "Coding", "Android dev", "iOS dev", "Design", "Learning", "Internet & media", "Office"]

STORE = [
    # ---- games
    ("Games", "flatpak", "com.valvesoftware.Steam", "Steam", "Games store, Proton runs Windows games"),
    ("Games", "flatpak", "com.heroicgameslauncher.hgl", "Heroic", "Epic Games (Rocket League) and GOG"),
    ("Games", "flatpak", "org.prismlauncher.PrismLauncher", "Prism Launcher", "Minecraft (Java), mods"),
    ("Games", "flatpak", "net.davidotek.pupgui2", "ProtonUp-Qt", "Installs GE-Proton for Steam/Heroic/Lutris"),
    ("Games", "flatpak", "com.usebottles.bottles", "Bottles", "Windows programs in isolated bottles"),
    ("Games", "flatpak", "org.libretro.RetroArch", "RetroArch", "Retro consoles (emulators)"),
    ("Games", "flatpak", "com.discordapp.Discord", "Discord", "Voice chat for gamers"),
    ("Games", "flatpak", "net.lutris.Lutris", "Lutris (Flatpak)", "Game launcher (already built in)"),
    ("Games", "flatpak", "com.dec05eba.gpu_screen_recorder", "Instant Replay", "Save the last 30-60 s of a game with a hotkey (GPU Screen Recorder)"),
    ("Games", "flatpak", "org.openrgb.OpenRGB", "OpenRGB", "RGB lights of every brand in one app"),
    ("Games", "flatpak", "io.github.ilya_zlobintsev.LACT", "LACT", "Graphics card fans, clocks, power limit, temperatures"),
    ("Games", "apt", "corectrl", "CoreCtrl", "AMD graphics card control"),
    # ---- coding
    ("Coding", "flatpak", "com.visualstudio.code", "VS Code", "Microsoft's code editor + extensions"),
    ("Coding", "flatpak", "com.vscodium.codium", "VSCodium", "VS Code without Microsoft telemetry"),
    ("Coding", "flatpak", "dev.zed.Zed", "Zed", "Very fast modern editor with AI"),
    ("Coding", "flatpak", "com.jetbrains.IntelliJ-IDEA-Community", "IntelliJ IDEA CE", "Java / Kotlin IDE"),
    ("Coding", "flatpak", "com.jetbrains.PyCharm-Community", "PyCharm CE", "Python IDE"),
    ("Coding", "flatpak", "com.sublimehq.SublimeText", "Sublime Text", "Lightweight editor"),
    ("Coding", "flatpak", "io.github.shiftey.Desktop", "GitHub Desktop", "Git with a GUI"),
    ("Coding", "flatpak", "com.getpostman.Postman", "Postman", "Test APIs"),
    ("Coding", "flatpak", "io.dbeaver.DBeaverCommunity", "DBeaver", "Databases: MySQL, Postgres, SQLite…"),
    ("Coding", "flatpak", "io.podman_desktop.PodmanDesktop", "Podman Desktop", "Containers with a GUI (Docker compatible)"),
    ("Coding", "flatpak", "org.godotengine.Godot", "Godot", "Game engine"),
    ("Coding", "apt", "build-essential git cmake clang gdb python3-pip python3-venv pipx nodejs npm default-jdk golang rustc cargo php composer sqlite3 neovim",
     "Developer pack", "C/C++, Python, Node.js, Java, Go, Rust, PHP + git - everything for the terminal"),
    ("Coding", "apt", "docker.io docker-compose", "Docker", "Docker engine (you are added to the docker group)"),
    # ---- android
    ("Android dev", "flatpak", "com.google.AndroidStudio", "Android Studio", "Official Android IDE + emulator"),
    ("Android dev", "apt", "adb fastboot", "Android tools", "adb / fastboot for phones"),
    ("Android dev", "aptbpo", "scrcpy", "scrcpy", "Show and control your Android phone on the PC"),
    ("Android dev", "script", "flutter.sh", "Flutter SDK", "Android, web and desktop apps from one code base"),
    ("Android dev", "script", "eas.sh", "Expo / EAS CLI", "React Native apps; build Android AND iOS in the cloud"),
    # ---- ios
    ("iOS dev", "info", "", "Run iOS?",
     "iOS (iPhone system) can't run on a PC - Apple only allows it on its own devices, and there is no iOS "
     "emulator outside macOS. What works on PhoenixGe:"),
    ("iOS dev", "script", "eas.sh", "Build iPhone apps (Expo EAS)",
     "Write the app in React Native/Expo here, `eas build -p ios` builds it on Expo's Macs; test on your iPhone with Expo Go."),
    ("iOS dev", "script", "flutter.sh", "Flutter", "Same code for Android and iOS; iOS builds via a cloud CI (Codemagic)."),
    # ---- design
    ("Design", "flatpak", "org.gimp.GIMP", "GIMP", "Photo editing"),
    ("Design", "flatpak", "org.inkscape.Inkscape", "Inkscape", "Vector graphics, logos"),
    ("Design", "flatpak", "org.kde.krita", "Krita", "Digital painting"),
    ("Design", "flatpak", "org.blender.Blender", "Blender", "3D, animation, video"),
    ("Design", "flatpak", "com.authormore.penpotdesktop", "Penpot", "UI design like Figma, open source (unofficial desktop app)"),
    ("Design", "flatpak", "org.kde.kdenlive", "Kdenlive", "Video editing"),
    # ---- learning
    ("Learning", "flatpak", "net.ankiweb.Anki", "Anki", "Flash cards - learn anything"),
    ("Learning", "flatpak", "org.geogebra.GeoGebra", "GeoGebra", "Math: graphs, geometry"),
    ("Learning", "flatpak", "md.obsidian.Obsidian", "Obsidian", "Notes and knowledge base"),
    ("Learning", "flatpak", "org.kde.marble", "Marble", "Globe and maps"),
    # ---- internet & media
    ("Internet & media", "flatpak", "com.google.Chrome", "Google Chrome", "Browser"),
    ("Internet & media", "flatpak", "org.telegram.desktop", "Telegram", "Messenger"),
    ("Internet & media", "flatpak", "com.spotify.Client", "Spotify", "Music"),
    ("Internet & media", "flatpak", "com.obsproject.Studio", "OBS Studio", "Record and stream"),
    ("Internet & media", "flatpak", "us.zoom.Zoom", "Zoom", "Video calls"),
    # ---- office
    ("Office", "flatpak", "org.libreoffice.LibreOffice", "LibreOffice", "Word / Excel / PowerPoint files"),
    ("Office", "flatpak", "org.onlyoffice.desktopeditors", "ONLYOFFICE", "Office that looks like Microsoft Office"),
]
