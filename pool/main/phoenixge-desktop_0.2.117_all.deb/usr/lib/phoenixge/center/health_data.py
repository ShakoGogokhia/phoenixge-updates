"""System Health - data collection and plain-language rating (no Qt here, so it can be unit-tested anywhere).

Every check returns "items": dict(title, state, value, text) where state is green / yellow / red / grey
(grey = could not be checked) and text is an explanation for normal people.
"""
import glob
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

GREEN, YELLOW, RED, GREY = "green", "yellow", "red", "grey"
_RANK = {GREY: 0, GREEN: 1, YELLOW: 2, RED: 3}
COLORS = {GREEN: "#3fb950", YELLOW: "#e3b341", RED: "#f85149", GREY: "#8b949e"}

DISK_HELPER = "/usr/lib/phoenixge/health-disks.sh"
CLEAN_HELPER = "/usr/lib/phoenixge/health-clean.sh"
JOURNAL_KEEP = 200 * 1024 * 1024
# ~/.cache folders that are pure caches (rebuilt automatically). NOTHING outside this list is ever deleted.
USER_CACHE_DIRS = ("thumbnails", "pip", "go-build", "yarn")
REAL_FS = {"ext2", "ext3", "ext4", "btrfs", "xfs", "f2fs", "vfat", "exfat", "ntfs", "ntfs3", "fuseblk", "jfs", "reiserfs", "zfs", "bcachefs"}
SKIP_MOUNT_PREFIX = ("/run/live", "/lib/live", "/snap/", "/var/lib/docker", "/var/lib/containers", "/proc", "/sys")


def item(title, state, value, text):
    return dict(title=title, state=state, value=value, text=text)


def worst(states):
    states = list(states)
    return max(states, key=lambda s: _RANK[s]) if states else GREY


def human(n):
    if n is None:
        return "?"
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1000 or unit == "TB":
            return f"{n:.0f} {unit}" if unit in ("B", "KB") else f"{n:.1f} {unit}"
        n /= 1000.0


def run(cmd, timeout=10):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout).stdout
    except Exception:
        return ""


# ------------------------------------------------------------------ drives (SMART)
WEAR_ATTRS = (177, 202, 231, 233)  # normalized value = % of life remaining (Samsung/Crucial/Kingston/Intel...)


def _attr(table, aid):
    for a in table or []:
        if a.get("id") == aid:
            return a
    return None


def disk_metrics_smartctl(d):
    """smartctl -j -a output (dict) -> metrics dict."""
    dev = d.get("device") or {}
    proto = (dev.get("protocol") or "").upper()
    m = dict(dev=dev.get("name", ""), model=d.get("model_name") or d.get("model_family") or dev.get("name", "Drive"),
             size=(d.get("user_capacity") or {}).get("bytes") or d.get("nvme_total_capacity"),
             kind="nvme" if proto == "NVME" else ("hdd" if (d.get("rotation_rate") or 0) > 0 else "ssd"),
             passed=None, used=None, temp=None, errors=None, hours=None, critical=0, asleep=False, available=True)
    msgs = " ".join(x.get("string", "") for x in (d.get("smartctl") or {}).get("messages", []))
    if re.search(r"STANDBY|SLEEP", msgs, re.I):
        m["asleep"] = True
    status = d.get("smart_status")
    if isinstance(status, dict) and "passed" in status:
        m["passed"] = bool(status["passed"])
    if (d.get("temperature") or {}).get("current") is not None:
        m["temp"] = d["temperature"]["current"]
    if (d.get("power_on_time") or {}).get("hours") is not None:
        m["hours"] = d["power_on_time"]["hours"]
    if (d.get("endurance_used") or {}).get("current_percent") is not None:
        m["used"] = d["endurance_used"]["current_percent"]
    nv = d.get("nvme_smart_health_information_log")
    if nv:
        m["used"] = nv.get("percentage_used", m["used"])
        m["temp"] = nv.get("temperature", m["temp"])
        m["hours"] = nv.get("power_on_hours", m["hours"])
        m["errors"] = nv.get("media_errors", 0) or 0
        m["critical"] = nv.get("critical_warning", 0) or 0
    table = (d.get("ata_smart_attributes") or {}).get("table")
    if table:
        errs = 0
        for aid in (5, 197, 198):
            a = _attr(table, aid)
            if a:
                try:
                    errs += int((a.get("raw") or {}).get("value", 0)) & 0xFFFFFFFF
                except (TypeError, ValueError):
                    pass
        m["errors"] = errs
        if m["used"] is None and m["kind"] != "hdd":
            for aid in WEAR_ATTRS:
                a = _attr(table, aid)
                if a and isinstance(a.get("value"), int) and 0 < a["value"] <= 100:
                    m["used"] = 100 - a["value"]
                    break
        if m["temp"] is None:
            a = _attr(table, 194) or _attr(table, 190)
            if a:
                m["temp"] = ((a.get("raw") or {}).get("value", 0) or 0) & 0xFF or None
        if m["hours"] is None:
            a = _attr(table, 9)
            if a:
                m["hours"] = ((a.get("raw") or {}).get("value", 0) or 0) & 0xFFFFFFFF
    if m["passed"] is None and not nv and not table:
        m["available"] = False
    return m


def disk_metrics_nvme(dev, d):
    """`nvme smart-log -o json` output (dict) -> metrics dict (fallback when smartctl is missing)."""
    temp = d.get("temperature")
    if isinstance(temp, (int, float)) and temp > 200:  # nvme-cli reports Kelvin
        temp = round(temp - 273.15)
    used = d.get("percent_used", d.get("percentage_used"))
    crit = d.get("critical_warning", 0)
    if isinstance(crit, dict):
        crit = crit.get("value", 0)
    return dict(dev=dev, model=dev, size=None, kind="nvme", passed=None, used=used, temp=temp,
                errors=d.get("media_errors", 0), hours=d.get("power_on_hours"), critical=crit or 0,
                asleep=False, available=True)


def rate_disk(m):
    size = human(m["size"]) if m.get("size") else ""
    name = (m["model"] if m["model"] != m["dev"] else "Drive") + " (" + ", ".join(x for x in (m["dev"], size) if x) + ")"
    if m["asleep"]:
        return item(name, GREY, "asleep", "The drive is in power-saving sleep; it was not woken up just to check it. Try again later.")
    if not m["available"]:
        return item(name, GREY, "no data", "This drive does not report its health (common for USB adapters, memory cards and "
                                           "virtual machines). Nothing to worry about by itself.")
    state, why = GREEN, []
    hot_y, hot_r = (65, 75) if m["kind"] == "nvme" else ((50, 60) if m["kind"] == "hdd" else (60, 70))
    if m["passed"] is False:
        state = RED; why.append("The drive's own self-test says it is FAILING. Back up your files now and replace it.")
    if m["critical"]:
        state = RED; why.append("The drive reports a critical warning (worn out, too hot or read-only mode). Back up your files now.")
    if m["used"] is not None:
        if m["used"] >= 100:
            state = worst([state, RED]); why.append("It has used up its rated write life. It may still work for a while, "
                                                    "but keep backups and plan a replacement.")
        elif m["used"] >= 80:
            state = worst([state, YELLOW]); why.append(f"{m['used']}% of its rated write life is used - plan a replacement.")
    if m["errors"]:
        if m["errors"] > 50:
            state = worst([state, RED]); why.append(f"{m['errors']} damaged areas found. The drive is wearing out - back up now.")
        else:
            state = worst([state, YELLOW]); why.append(f"{m['errors']} damaged area(s) found. A few can be harmless, but if this "
                                                       "number grows the drive is dying. Keep backups.")
    if m["temp"] is not None:
        if m["temp"] >= hot_r:
            state = worst([state, RED]); why.append(f"Very hot ({m['temp']} °C). Check airflow / fans.")
        elif m["temp"] >= hot_y:
            state = worst([state, YELLOW]); why.append(f"Warm ({m['temp']} °C). Fine during heavy copying, not when idle.")
    if state == GREEN:
        life = f"{m['used']}% of its life used" if m["used"] is not None else "no wear problems"
        why.append(f"Healthy - {life}, no errors.")
    parts = []
    if m["used"] is not None:
        parts.append(f"{m['used']}% worn")
    if m["temp"] is not None:
        parts.append(f"{m['temp']} °C")
    if m["hours"] is not None:
        parts.append(f"{m['hours']:,} h on".replace(",", " "))
    return item(name, state, " · ".join(parts) or ("OK" if state == GREEN else ""), " ".join(why))


def parse_disk_report(text):
    """Output of health-disks.sh -> list of items."""
    try:
        data = json.loads(text)
    except (ValueError, TypeError):
        return [item("Drives", GREY, "error", "Could not read the drive report.")]
    out = []
    for d in data.get("disks", []):
        if isinstance(d.get("smartctl"), dict):
            m = disk_metrics_smartctl(d["smartctl"])
            m["dev"] = m["dev"] or d.get("dev", "")
        elif isinstance(d.get("nvme"), dict):
            m = disk_metrics_nvme(d.get("dev", ""), d["nvme"])
        else:
            m = dict(dev=d.get("dev", ""), model=d.get("model") or d.get("dev", "Drive"), size=None, kind="ssd", passed=None, used=None,
                     temp=None, errors=None, hours=None, critical=0, asleep=False, available=False)
        if d.get("model") and m["model"] == m["dev"]:
            m["model"] = d["model"]
        out.append(rate_disk(m))
    if not out:
        out.append(item("Drives", GREY, "none", "No drives found."))
    return out


# ------------------------------------------------------------------ disk space
def parse_mounts(text):
    """/proc/mounts -> [(device, mountpoint, fstype)] of real file systems, one per device."""
    seen, out = set(), []
    for line in text.splitlines():
        f = line.split()
        if len(f) < 3:
            continue
        dev, mnt, fs = f[0], f[1].replace("\\040", " "), f[2]
        if fs not in REAL_FS or dev in seen or mnt.startswith(SKIP_MOUNT_PREFIX):
            continue
        seen.add(dev)
        out.append((dev, mnt, fs))
    return out


def rate_space(mnt, total, avail):
    name = {"/": "System (/)", "/home": "Your files (/home)", "/boot/efi": "Boot partition (/boot/efi)"}.get(mnt, mnt)
    if not total:
        return item(name, GREY, "?", "Size unknown.")
    pct = avail * 100.0 / total
    value = f"{human(avail)} free of {human(total)}"
    if pct < 5 or (avail < 1e9 and total > 8e9):
        return item(name, RED, value, "Almost full. Updates and programs can fail. Use Clean up below or delete big files.")
    if pct < 15:
        return item(name, YELLOW, value, "Getting full. Consider cleaning up or moving big files.")
    return item(name, GREEN, value, f"Plenty of room ({pct:.0f}% free).")


def space_items(mounts_text=None):
    if mounts_text is None:
        mounts_text = Path("/proc/mounts").read_text(errors="ignore")
    out = []
    for _dev, mnt, _fs in parse_mounts(mounts_text):
        try:
            st = os.statvfs(mnt)
        except OSError:
            continue
        out.append(rate_space(mnt, st.f_blocks * st.f_frsize, st.f_bavail * st.f_frsize))
    return out


# ------------------------------------------------------------------ battery
def _num(v):
    try:
        return int(str(v).strip())
    except (TypeError, ValueError):
        return None


def rate_battery(name, props):
    """props = sysfs files of one /sys/class/power_supply/BAT* as {file: text}."""
    full = _num(props.get("energy_full")) or _num(props.get("charge_full"))
    design = _num(props.get("energy_full_design")) or _num(props.get("charge_full_design"))
    cycles = _num(props.get("cycle_count"))
    cap = _num(props.get("capacity"))
    status = (props.get("status") or "").strip()
    extra = (f"{cycles} charge cycles. " if cycles else "")
    if not full or not design:
        return item(f"Battery {name}", GREY, f"{cap}%" if cap is not None else "?",
                    extra + "This battery does not report its wear.")
    health = min(100.0, full * 100.0 / design)
    value = f"{health:.0f}% health" + (f" · {cap}% charged" if cap is not None else "") + (f" · {status}" if status else "")
    if health < 60:
        return item(f"Battery {name}", RED, value, extra + f"Holds only {health:.0f}% of its original charge. Battery life is much "
                                                           "shorter than new - a replacement battery will help.")
    if health < 80:
        return item(f"Battery {name}", YELLOW, value, extra + f"Holds {health:.0f}% of its original charge. Normal after a few years; "
                                                              "it lasts noticeably shorter than new.")
    return item(f"Battery {name}", GREEN, value, extra + "Battery is in good shape.")


def battery_items(base="/sys/class/power_supply"):
    out = []
    for d in sorted(glob.glob(os.path.join(base, "*"))):
        props = {}
        for f in ("type", "scope", "energy_full", "energy_full_design", "charge_full", "charge_full_design",
                  "cycle_count", "capacity", "status"):
            try:
                props[f] = Path(d, f).read_text(errors="ignore").strip()
            except OSError:
                pass
        if props.get("type") != "Battery" or props.get("scope") == "Device":  # skip mice / headsets
            continue
        out.append(rate_battery(os.path.basename(d), props))
    return out


# ------------------------------------------------------------------ temperatures
CPU_CHIPS = ("coretemp", "k10temp", "zenpower", "cpu_thermal", "x86_pkg_temp")
GPU_CHIPS = ("amdgpu", "radeon", "nouveau", "i915", "xe")


def parse_sensors(data):
    """`sensors -j` dict -> {"cpu": [temps], "gpu": {chip: [temps]}, crit: {...}}"""
    cpu, gpu, cpu_crit = [], {}, None
    for chip, feats in (data or {}).items():
        if not isinstance(feats, dict):
            continue
        kind = "cpu" if chip.startswith(CPU_CHIPS) else ("gpu" if chip.startswith(GPU_CHIPS) else None)
        if not kind:
            continue
        temps, pkg = [], None
        for label, vals in feats.items():
            if not isinstance(vals, dict):
                continue
            for k, v in vals.items():
                if re.fullmatch(r"temp\d+_input", k) and isinstance(v, (int, float)) and -40 < v < 150:
                    temps.append(float(v))
                    if label.startswith(("Package id", "Tctl", "Tdie", "edge")):
                        pkg = float(v)
                if kind == "cpu" and re.fullmatch(r"temp\d+_crit", k) and isinstance(v, (int, float)) and 60 < v < 130:
                    cpu_crit = min(cpu_crit or v, v)
        if not temps:
            continue
        if kind == "cpu":
            cpu.append(pkg if pkg is not None else max(temps))
        else:
            gpu[chip.split("-")[0]] = max(temps)
    return dict(cpu=cpu, gpu=gpu, cpu_crit=cpu_crit)


def parse_nvidia_smi(text):
    """nvidia-smi --query-gpu=name,temperature.gpu --format=csv,noheader,nounits"""
    out = []
    for line in text.splitlines():
        f = [x.strip() for x in line.split(",")]
        if len(f) >= 2:
            try:
                out.append((f[0], float(f[1])))
            except ValueError:
                pass
    return out


def rate_temp(title, t, yellow, red, crit=None):
    if crit:
        red = min(red, crit - 5)
        yellow = min(yellow, red - 10)
    v = f"{t:.0f} °C"
    if t >= red:
        return item(title, RED, v, "Very hot. It will slow itself down to protect itself. Clean the fans / air vents and "
                                   "don't block them (soft surfaces like a bed or sofa).")
    if t >= yellow:
        return item(title, YELLOW, v, "Hot. Normal while gaming or compiling; if it's like this when idle, clean the fans.")
    return item(title, GREEN, v, "Normal temperature.")


def temp_items(sensors_json=None, nvidia_text=None):
    if sensors_json is None:
        try:
            sensors_json = json.loads(run(["sensors", "-j"], 5) or "{}")
        except ValueError:
            sensors_json = {}
    if nvidia_text is None:
        nvidia_text = run(["nvidia-smi", "--query-gpu=name,temperature.gpu", "--format=csv,noheader,nounits"], 5) \
            if shutil.which("nvidia-smi") else ""
    s = parse_sensors(sensors_json)
    out = []
    if s["cpu"]:
        out.append(rate_temp("Processor (CPU)", max(s["cpu"]), 85, 95, s["cpu_crit"]))
    for chip, t in s["gpu"].items():
        out.append(rate_temp(f"Graphics ({chip})", t, 85, 95))
    for name, t in parse_nvidia_smi(nvidia_text):
        out.append(rate_temp(f"Graphics ({name})", t, 83, 90))
    if not out:
        out.append(item("Temperatures", GREY, "no sensors", "This computer does not report temperatures "
                                                           "(normal in a virtual machine)."))
    return out


# ------------------------------------------------------------------ memory
def parse_meminfo(text):
    kv = {}
    for line in text.splitlines():
        m = re.match(r"(\w+):\s+(\d+)", line)
        if m:
            kv[m.group(1)] = int(m.group(2)) * 1024
    return kv


def ram_items(meminfo_text=None):
    if meminfo_text is None:
        try:
            meminfo_text = Path("/proc/meminfo").read_text(errors="ignore")
        except OSError:
            meminfo_text = ""
    kv = parse_meminfo(meminfo_text)
    total, avail = kv.get("MemTotal", 0), kv.get("MemAvailable", 0)
    if not total:
        return [item("Memory (RAM)", GREY, "?", "Unknown.")]
    used_pct = 100 - avail * 100.0 / total
    v = f"{human(total - avail)} used of {human(total)}"
    swap_used = kv.get("SwapTotal", 0) - kv.get("SwapFree", 0)
    if swap_used > 256e6:
        v += f" · swap {human(swap_used)}"
    if used_pct >= 95:
        out = item("Memory (RAM)", RED, v, "Memory is full - the computer will be slow. Close some apps or browser tabs.")
    elif used_pct >= 85:
        out = item("Memory (RAM)", YELLOW, v, "Memory is nearly full. Close apps you don't use if things feel slow.")
    else:
        out = item("Memory (RAM)", GREEN, v, "Enough free memory.")
    if total < 6e9:
        out["text"] += " (Less than 8 GB - fine for basics, tight for games.)"
    return [out]


# ------------------------------------------------------------------ clean-up estimates
def dir_size(path):
    """Size in bytes of everything under path; never follows symlinks."""
    total = 0
    try:
        if os.path.islink(path):
            return 0
        if os.path.isfile(path):
            return os.lstat(path).st_size
    except OSError:
        return 0
    for root, dirs, files in os.walk(path, followlinks=False):
        for f in files:
            try:
                total += os.lstat(os.path.join(root, f)).st_size
            except OSError:
                pass
    return total


def _kver_key(rel):
    return [int(x) if x.isdigit() else x for x in re.findall(r"\d+|[a-z]+", rel)]


def kernel_release(pkg):
    """linux-image-6.12.38+deb13-amd64(-unsigned|-dbg) -> 6.12.38+deb13-amd64"""
    if not re.match(r"linux-(image|headers)-\d", pkg):
        return None
    rel = re.sub(r"^linux-(image|headers)-", "", pkg)
    return re.sub(r"-(unsigned|dbg)$", "", rel)


def old_kernels(rows, running):
    """rows = [(status, package, installed_kib)] from dpkg-query. Keeps the running kernel + the newest other one
    (same rule as health-clean.sh). Returns (releases_to_remove, packages, bytes)."""
    installed = [(p, kib) for st, p, kib in rows if st.startswith("ii")]
    rels = sorted({kernel_release(p) for p, _ in installed if p.startswith("linux-image-") and kernel_release(p)}, key=_kver_key)
    others = [r for r in rels if r != running]
    keep = {running} | ({others[-1]} if others else set())
    remove = [r for r in rels if r not in keep]
    pkgs, size = [], 0
    for p, kib in installed:
        if kernel_release(p) in remove:
            pkgs.append(p)
            size += (kib or 0) * 1024
    return remove, pkgs, size


def parse_dpkg_rows(text):
    rows = []
    for line in text.splitlines():
        f = line.split("\t")
        if len(f) >= 3:
            rows.append((f[0], f[1], _num(f[2]) or 0))
    return rows


def parse_apt_sim(text):
    """`apt-get -s autoremove --purge` -> package names that would be removed."""
    return [m.group(1).split(":")[0] for m in re.finditer(r"^(?:Purg|Remv) (\S+)", text, re.M)]


def parse_flatpak_unused(text):
    """Table printed by `flatpak uninstall --unused` before its (declined) question -> [(id, branch)]."""
    out = []
    for line in text.splitlines():
        m = re.match(r"^\s*\d+\.\s+(\S+)\s+(\S+)\s+(.*)$", line)
        if m and re.search(r"(^|\s)r(\s|$)", m.group(3)):
            out.append((m.group(1), m.group(2)))
    return out


def parse_size_text(s):
    m = re.match(r"\s*([\d.,]+)\s*([kKMGT]?)i?B", s or "")
    if not m:
        return 0
    n = float(m.group(1).replace(",", "."))
    return int(n * {"": 1, "k": 1e3, "K": 1e3, "M": 1e6, "G": 1e9, "T": 1e12}[m.group(2)])


def flatpak_sizes(text):
    """`flatpak list --runtime --columns=application,branch,size` -> {(id, branch): bytes}"""
    out = {}
    for line in text.splitlines():
        f = line.split("\t")
        if len(f) >= 3:
            out[(f[0].strip(), f[1].strip())] = parse_size_text(f[2])
    return out


def user_cache_paths(home=None):
    home = Path(home or Path.home())
    return [home / ".cache" / d for d in USER_CACHE_DIRS]


def trash_paths(home=None):
    t = Path(home or Path.home()) / ".local/share/Trash"
    return [t / "files", t / "info", t / "expunged"]


def clear_dir(path, must_be_under):
    """Delete the CONTENTS of path (not path itself). Refuses anything that isn't a real directory inside must_be_under.
    Symlinks are removed as links, never followed. Returns bytes freed (approx.)."""
    path, base = Path(path), Path(must_be_under)
    if path.is_symlink() or not path.is_dir():
        return 0
    real, rbase = os.path.realpath(path), os.path.realpath(base)
    if not real.startswith(rbase + os.sep) or real == rbase:
        return 0
    freed = 0
    for entry in os.scandir(real):
        p = entry.path
        try:
            if entry.is_symlink() or not entry.is_dir(follow_symlinks=False):
                freed += os.lstat(p).st_size
                os.unlink(p)
            else:
                freed += dir_size(p)
                shutil.rmtree(p)
        except OSError:
            pass
    return freed


def cleanup_estimates():
    """-> list of dict(key, title, bytes, detail, root, enabled) for the Clean up card."""
    live = Path("/run/live").exists()
    est = []
    apt = sum(dir_size(p) for p in glob.glob("/var/cache/apt/archives/*.deb") + glob.glob("/var/cache/apt/*.bin"))
    est.append(dict(key="apt", title="Downloaded update packages (apt cache)", bytes=apt, root=True, enabled=apt > 0,
                    detail="Installer files of updates already installed. Safe to delete."))
    rows = parse_dpkg_rows(run(["dpkg-query", "-W", "-f=${db:Status-Abbrev}\t${Package}\t${Installed-Size}\n",
                                "linux-image-[0-9]*", "linux-headers-[0-9]*"], 15))
    rels, kpkgs, ksize = old_kernels(rows, os.uname().release)
    auto = [p for p in parse_apt_sim(run(["apt-get", "-s", "autoremove", "--purge"], 30)) if p not in kpkgs]
    if auto:
        arows = parse_dpkg_rows(run(["dpkg-query", "-W", "-f=${db:Status-Abbrev}\t${Package}\t${Installed-Size}\n", *auto], 15))
        ksize += sum(k * 1024 for _s, _p, k in arows)
    detail = ("Keeps the kernel you are running and one older one as a fallback. "
              + (f"Removes kernel {', '.join(rels)}. " if rels else "No old kernels. ")
              + (f"Also {len(auto)} packages nothing needs any more." if auto else ""))
    est.append(dict(key="kernels", title="Old kernels and unneeded packages", bytes=ksize, root=True,
                    enabled=bool(rels or auto) and not live, detail=detail if not live else "Not available in the live session."))
    fl_unused, fl_bytes = [], 0
    if shutil.which("flatpak"):
        sizes = flatpak_sizes(run(["flatpak", "list", "--runtime", "--columns=application,branch,size"], 20))
        # without a terminal flatpak answers its own "Proceed?" question with "n" - this only lists, never removes
        txt = ""
        try:
            txt = subprocess.run(["flatpak", "uninstall", "--unused"], input="n\n", capture_output=True, text=True, timeout=30).stdout
        except Exception:
            pass
        fl_unused = parse_flatpak_unused(txt)
        fl_bytes = sum(sizes.get(r, 0) for r in fl_unused)
    est.append(dict(key="flatpak", title="Unused Flatpak runtimes", bytes=fl_bytes, root=True, enabled=bool(fl_unused),
                    detail=(f"{len(fl_unused)} runtimes no app uses any more: " + ", ".join(i for i, _ in fl_unused[:4])
                            + ("…" if len(fl_unused) > 4 else "")) if fl_unused else "Nothing unused."))
    j = dir_size("/var/log/journal")
    est.append(dict(key="journal", title="Old system logs (journal)", bytes=max(0, j - JOURNAL_KEEP), root=True,
                    enabled=j > JOURNAL_KEEP, detail=f"Logs use {human(j)}; the newest 200 MB are kept."))
    uc = sum(dir_size(p) for p in user_cache_paths())
    est.append(dict(key="cache", title="Picture previews and download caches", bytes=uc, root=False, enabled=uc > 0,
                    detail="Thumbnails and developer download caches in ~/.cache (" + ", ".join(USER_CACHE_DIRS)
                           + "). They are rebuilt when needed. Nothing else is touched."))
    tr = sum(dir_size(p) for p in trash_paths())
    est.append(dict(key="trash", title="Trash", bytes=tr, root=False, enabled=tr > 0,
                    detail="Files you deleted. Emptying the trash cannot be undone."))
    return est
