"""PhoenixGe Center > Network: live ping to game regions (jitter, packet loss, graph), Wi-Fi / Ethernet details with hints,
DNS chooser (with a speed test of each DNS and undo) and an internet speed test.

build(center) -> QWidget        python3 netping.py [--demo]   (alone, for testing)

Ping targets
  Steam (Valve SDR relays): read live from Valve's public network config
      https://api.steampowered.com/ISteamApps/GetSDRConfig/v1/?appid=730   (cached ~/.cache/phoenixge/sdr.json, 7 days)
      Valve's relays answer ICMP ping; CS2/Dota 2/Deadlock matchmaking goes through them.
  AWS Frankfurt / Stockholm: TCP connect time to dynamodb.<region>.amazonaws.com:443 (used by many games' servers).
  Your router (gateway), Cloudflare 1.1.1.1, Google 8.8.8.8, Quad9.
  Riot/FACEIT/Istanbul: no public endpoint that answers pings (checked) - not faked; a custom host can be added.
"""
import json
import os
import random
import re
import shutil
import socket
import struct
import subprocess
import sys
import threading
import time
import urllib.request
from collections import deque
from pathlib import Path

from PySide6.QtCore import QProcess, Qt, QTimer
from PySide6.QtWidgets import (QComboBox, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPushButton, QVBoxLayout,
                               QWidget)

sys.path.insert(0, str(Path(__file__).resolve().parent))
from systools_ui import (DEMO, GREEN, GREY, RED, YELLOW, Bars, Bridge, LineGraph, accent, dim, dot, sh, ui)  # noqa: E402

CACHE = Path.home() / ".cache/phoenixge"
CFGF = Path.home() / ".config/phoenixge/network.json"
SDR_URL = "https://api.steampowered.com/ISteamApps/GetSDRConfig/v1/?appid=730"
# fallback when Valve's config can't be downloaded (taken from it, Nov 2026)
SDR_FALLBACK = {"fra": ("Frankfurt (Germany)", "155.133.226.68"), "sto": ("Stockholm (Sweden)", "162.254.198.41"),
                "vie": ("Vienna (Austria)", "146.66.155.66"), "waw": ("Warsaw (Poland)", "155.133.230.100"),
                "ams": ("Amsterdam (Netherlands)", "155.133.248.36"), "dxb": ("Dubai (UAE)", "185.25.183.163"),
                "lhr": ("London (England)", "162.254.196.66"), "par": ("Paris (France)", "185.25.182.18"),
                "mad": ("Madrid (Spain)", "155.133.246.34")}
DEFAULT_POPS = ["fra", "sto", "vie", "waw", "dxb"]
COLORS = ["#ff7a2e", "#58a6ff", "#3fb950", "#d2a8ff", "#e3b341", "#f778ba", "#79c0ff", "#ffa657", "#56d364", "#bc8cff"]
DNS = [("Automatic", "From your router / internet provider", [], []),
       ("Cloudflare", "Fast, private (1.1.1.1)", ["1.1.1.1", "1.0.0.1"], ["2606:4700:4700::1111", "2606:4700:4700::1001"]),
       ("Google", "Fast, reliable (8.8.8.8)", ["8.8.8.8", "8.8.4.4"], ["2001:4860:4860::8888", "2001:4860:4860::8844"]),
       ("Quad9", "Blocks known malware sites", ["9.9.9.9", "149.112.112.112"], ["2620:fe::fe", "2620:fe::9"]),
       ("AdGuard", "Blocks ads and trackers", ["94.140.14.14", "94.140.15.15"], ["2a10:50c0::ad1:ff", "2a10:50c0::ad2:ff"])]


# ------------------------------------------------------------------ data
def sdr_pops():
    """{code: (desc, ip)} from Valve's live config (cached), fallback list otherwise."""
    f = CACHE / "sdr.json"
    data = None
    try:
        if f.exists() and time.time() - f.stat().st_mtime < 7 * 86400:
            data = json.loads(f.read_text())
    except Exception:
        data = None
    if data is None and not DEMO:
        try:
            with urllib.request.urlopen(urllib.request.Request(SDR_URL, headers={"User-Agent": "PhoenixGe"}), timeout=6) as r:
                data = json.loads(r.read().decode())
            CACHE.mkdir(parents=True, exist_ok=True); f.write_text(json.dumps(data))
        except Exception:
            data = None
    out = {}
    for code, pop in ((data or {}).get("pops") or {}).items():
        relays = [x.get("ipv4") for x in pop.get("relays") or [] if x.get("ipv4")]
        if relays and pop.get("desc"):
            out[code] = (pop["desc"], relays[0])
    return out or dict(SDR_FALLBACK)


def nm_split(line):
    """nmcli -t line -> fields (':' separated, '\\:' escaped)."""
    return [x.replace("\\:", ":").replace("\\\\", "\\") for x in re.split(r"(?<!\\):", line)]


def connection():
    """Active connection facts (or None)."""
    if DEMO:
        return dict(kind="wifi", device="wlp2s0", name="PhoenixNet-5G", uuid="demo", ssid="PhoenixNet-5G", signal=64, chan=36,
                    freq=5180, rate="433 Mbit/s", security="WPA2", crowded=3, ip="192.168.1.34/24", gateway="192.168.1.1",
                    dns=["192.168.1.1"], speed="")
    devs = [nm_split(l) for l in sh("nmcli -t -f DEVICE,TYPE,STATE,CONNECTION dev status").splitlines()]
    act = [d for d in devs if len(d) >= 4 and d[2] == "connected" and d[1] in ("ethernet", "wifi")]
    if not act:
        return None
    act.sort(key=lambda d: d[1] != "ethernet")  # cable first
    dev, kind, _st, name = act[0][:4]
    c = dict(kind=kind, device=dev, name=name, uuid="", ip="", gateway="", dns=[], speed="")
    for l in sh("nmcli -t -f UUID,DEVICE con show --active").splitlines():
        f = nm_split(l)
        if len(f) >= 2 and f[1] == dev:
            c["uuid"] = f[0]
    for l in sh(["nmcli", "-t", "-f", "IP4.ADDRESS,IP4.GATEWAY,IP4.DNS", "dev", "show", dev]).splitlines():
        k, _, v = l.partition(":")
        if k.startswith("IP4.ADDRESS") and not c["ip"]:
            c["ip"] = v
        elif k == "IP4.GATEWAY":
            c["gateway"] = v
        elif k.startswith("IP4.DNS"):
            c["dns"].append(v)
    if kind == "ethernet":
        try:
            c["speed"] = Path(f"/sys/class/net/{dev}/speed").read_text().strip() + " Mbit/s"
        except OSError:
            pass
    else:
        nets = [nm_split(l) for l in sh("nmcli -t -f IN-USE,SSID,SIGNAL,CHAN,FREQ,RATE,SECURITY dev wifi list --rescan no").splitlines()]
        me = next((n for n in nets if len(n) >= 7 and n[0] == "*"), None)
        if me:
            c.update(ssid=me[1], signal=int(me[2] or 0), chan=int(me[3] or 0), freq=int((me[4] or "0").split()[0]),
                     rate=me[5], security=me[6])
            c["crowded"] = sum(1 for n in nets if len(n) >= 7 and n[0] != "*" and n[3] == me[3])
    return c


def wifi_hints(c):
    hints = []
    if c["kind"] == "wifi":
        hints.append("You're on Wi-Fi. For online games a network cable gives the steadiest ping (no spikes, no loss).")
        if c.get("freq", 0) and c["freq"] < 3000:
            hints.append("2.4 GHz band: slower and busier. If your router has a 5 GHz network, connect to that one.")
        if c.get("signal", 100) < 45:
            hints.append("Weak signal - move closer to the router or remove walls / metal in between.")
        if c.get("crowded", 0) >= 4:
            hints.append(f"{c['crowded']} other networks use the same channel ({c.get('chan')}). Picking another channel in the "
                         "router settings can lower spikes.")
    return hints


def dns_query_ms(server, name="example.com", timeout=1.5):
    """Time one DNS A query over UDP (no tools needed). None on timeout."""
    if DEMO:
        return {"1.1.1.1": 9.0, "8.8.8.8": 24.0, "9.9.9.9": 31.0, "94.140.14.14": 41.0}.get(server, 18.0) + random.random() * 3
    qid = random.randint(0, 65535)
    q = struct.pack(">HHHHHH", qid, 0x0100, 1, 0, 0, 0) + b"".join(
        bytes([len(p)]) + p.encode() for p in name.split(".")) + b"\0" + struct.pack(">HH", 1, 1)
    fam = socket.AF_INET6 if ":" in server else socket.AF_INET
    s = socket.socket(fam, socket.SOCK_DGRAM); s.settimeout(timeout)
    try:
        t = time.perf_counter(); s.sendto(q, (server, 53))
        while True:
            data, _ = s.recvfrom(512)
            if data[:2] == q[:2]:
                return (time.perf_counter() - t) * 1000
    except OSError:
        return None
    finally:
        s.close()


def dns_best(server):
    vals = [v for v in (dns_query_ms(server, n) for n in ("example.com", "debian.org", "wikipedia.org")) if v is not None]
    return sorted(vals)[len(vals) // 2] if vals else None


# ------------------------------------------------------------------ ping engine
class Target:
    def __init__(self, key, label, host, mode="icmp", port=443, group=""):
        self.key, self.label, self.host, self.mode, self.port, self.group = key, label, host, mode, port, group
        self.samples = deque(maxlen=120)   # ms or None (lost)
        self.seqs = deque(maxlen=120)      # ICMP sequence number of each sample (late replies fix their sample)
        self.error, self.stop_ev, self.thread, self.proc = "", threading.Event(), None, None

    def stats(self, n=60):
        s = list(self.samples)[-n:]
        ok = [v for v in s if v is not None]
        if not s:
            return None
        jit = [abs(a - b) for a, b in zip(ok, ok[1:])]
        return dict(now=s[-1], avg=sum(ok) / len(ok) if ok else None, min=min(ok) if ok else None,
                    jitter=sum(jit) / len(jit) if jit else 0.0, loss=100.0 * (len(s) - len(ok)) / len(s), n=len(s))

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self.stop_ev.clear(); self.error = ""
        self.thread = threading.Thread(target=self._run, daemon=True); self.thread.start()

    def stop(self):
        self.stop_ev.set()
        if self.proc:
            try:
                self.proc.terminate()
            except Exception:
                pass

    def _run(self):
        if DEMO:
            return self._demo()
        if self.mode == "icmp" and shutil.which("ping"):
            return self._icmp()
        return self._tcp()

    def _demo(self):
        base = {"gw": 3, "fra": 58, "sto": 79, "vie": 47, "waw": 52, "dxb": 96, "cf": 6, "g": 34, "aws-fra": 61}.get(self.key, 40)
        rnd = random.Random(self.key)
        for i in range(60):
            spike = 35 if (self.key == "fra" and i in (21, 22, 44)) else 0
            self.samples.append(None if (self.key in ("dxb",) and i in (17, 40)) else base + rnd.random() * 4 + spike)
        while not self.stop_ev.wait(1.0):
            self.samples.append(base + rnd.random() * 4)

    def _icmp(self):
        seqs = set()
        try:
            self.proc = subprocess.Popen(["ping", "-n", "-O", "-i", "1", "-W", "2", self.host], stdout=subprocess.PIPE,
                                         stderr=subprocess.STDOUT, text=True, bufsize=1)
        except OSError as e:
            self.error = str(e); return
        for line in self.proc.stdout:
            if self.stop_ev.is_set():
                break
            m = re.search(r"icmp_seq=(\d+).*time=([\d.]+)", line)
            if m:
                seq, ms = int(m.group(1)), float(m.group(2))
                if seq in seqs:            # late answer for a packet already counted as lost: fix that sample
                    seqs.discard(seq)
                    try:
                        self.samples[list(self.seqs).index(seq)] = ms
                    except (ValueError, IndexError):
                        pass
                    continue
                self.samples.append(ms); self.seqs.append(seq); self.error = ""
                continue
            m = re.search(r"no answer yet for icmp_seq=(\d+)", line)
            if m:
                seq = int(m.group(1)); seqs.add(seq)
                self.samples.append(None); self.seqs.append(seq); continue
            if "unknown host" in line.lower() or "failure" in line.lower() or "not permitted" in line.lower():
                self.error = line.strip()
        try:
            self.proc.terminate()
        except Exception:
            pass
        if not self.stop_ev.is_set() and not self.samples:
            self.error = self.error or "no reply"

    def _tcp(self):
        while not self.stop_ev.is_set():
            t0 = time.perf_counter()
            try:
                addr = socket.getaddrinfo(self.host, self.port, socket.AF_INET, socket.SOCK_STREAM)[0][4]
                t = time.perf_counter()
                with socket.create_connection(addr, timeout=2):
                    self.samples.append((time.perf_counter() - t) * 1000)
                self.error = ""
            except OSError as e:
                self.samples.append(None); self.error = str(e)
            self.seqs.append(None)
            self.stop_ev.wait(max(0.1, 1.0 - (time.perf_counter() - t0)))


def quality(st):
    """traffic light + words for a target's stats"""
    if not st or st["avg"] is None:
        return GREY, "no reply"
    if st["loss"] >= 5 or st["avg"] >= 150 or st["jitter"] >= 30:
        return RED, "bad for online games"
    if st["loss"] > 0 or st["avg"] >= 100 or st["jitter"] >= 10:
        return YELLOW, "playable"
    if st["avg"] >= 50 or st["jitter"] >= 5:
        return GREEN, "good"
    return GREEN, "great"


# ------------------------------------------------------------------ page
class NetworkPage(QWidget):
    def __init__(self, center):
        super().__init__()
        self.center = center
        Card, page, _Flow = ui(center)
        self.Card = Card
        w, lay = page("Network & Ping", "Live ping to game servers, Wi-Fi quality, a faster DNS and a speed test.")
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0); outer.addWidget(w)
        self.acc = accent()
        self.cfg = self.load_cfg()
        self.targets, self.rows = [], {}
        self.bridge = Bridge(); self.bridge.result.connect(self.on_result)
        self.conn = None

        # connection
        self.conn_card = Card("Connection")
        self.conn_box = QVBoxLayout(); self.conn_card.lay.addLayout(self.conn_box)
        lay.addWidget(self.conn_card)

        # ping
        pc = Card("Ping to game servers", "Lower is better. Jitter = how much the ping jumps, loss = packets that never came back. "
                  "Both matter more than the ping itself for online games.")
        top = QHBoxLayout()
        self.run_btn = QPushButton("Pause"); self.run_btn.clicked.connect(self.toggle_run)
        self.add_pop = QComboBox(); self.add_pop.setMinimumWidth(220); self.add_pop.activated.connect(self.add_pop_chosen)
        self.custom = QLineEdit(); self.custom.setPlaceholderText("Add a server (name or IP)…"); self.custom.setMaximumWidth(240)
        self.custom.returnPressed.connect(self.add_custom)
        reset = QPushButton("Default list"); reset.clicked.connect(self.default_targets)
        top.addWidget(self.run_btn); top.addWidget(self.add_pop); top.addWidget(self.custom); top.addWidget(reset); top.addStretch()
        pc.lay.addLayout(top)
        self.table = QGridLayout(); self.table.setHorizontalSpacing(16); self.table.setVerticalSpacing(6)
        pc.lay.addLayout(self.table)
        self.graph = LineGraph(190); pc.lay.addWidget(self.graph)
        self.graph_note = dim(""); pc.lay.addWidget(self.graph_note)
        pc.lay.addWidget(dim("Riot (Valorant, LoL), FACEIT and Istanbul servers don't answer pings, so they are not listed - "
                             "the nearest Steam region is a good guide. Steam regions come live from Valve's network list."))
        lay.addWidget(pc)

        # DNS
        dc = Card("DNS (name lookups)", "DNS turns names like steamcommunity.com into addresses. A fast DNS makes pages and "
                  "game launchers start quicker; it does not change your in-game ping.")
        self.dns_grid = QGridLayout(); self.dns_grid.setHorizontalSpacing(14); self.dns_grid.setVerticalSpacing(6)
        dc.lay.addLayout(self.dns_grid)
        drow = QHBoxLayout()
        self.dns_test_btn = QPushButton("Test DNS speed"); self.dns_test_btn.clicked.connect(self.test_dns)
        self.dns_auto_btn = QPushButton("Use the fastest"); self.dns_auto_btn.setObjectName("primary")
        self.dns_auto_btn.clicked.connect(self.use_fastest)
        self.dns_undo = QPushButton("Undo last change"); self.dns_undo.clicked.connect(self.undo_dns)
        drow.addWidget(self.dns_test_btn); drow.addWidget(self.dns_auto_btn); drow.addWidget(self.dns_undo); drow.addStretch()
        dc.lay.addLayout(drow)
        self.dns_note = dim(""); dc.lay.addWidget(self.dns_note)
        lay.addWidget(dc)
        self.dns_ms = {}

        # speed test
        sc = Card("Speed test")
        self.speed = QHBoxLayout()
        self.speed_vals = {}
        for k, label in (("down", "Download"), ("up", "Upload"), ("ping", "Ping"), ("jitter", "Jitter")):
            box = QVBoxLayout(); a = QLabel("–"); a.setStyleSheet("font-size:24px;font-weight:700;")
            b = QLabel(label); b.setObjectName("dim"); box.addWidget(a); box.addWidget(b)
            self.speed_vals[k] = a; self.speed.addLayout(box); self.speed.addSpacing(26)
        self.speed.addStretch(); sc.lay.addLayout(self.speed)
        srow = QHBoxLayout()
        self.speed_btn = QPushButton("Start speed test"); self.speed_btn.setObjectName("primary"); self.speed_btn.clicked.connect(self.speedtest)
        self.speed_inst = QPushButton("Install full speed test"); self.speed_inst.clicked.connect(self.install_librespeed)
        self.speed_inst.setVisible(not DEMO and shutil.which("librespeed-cli") is None)
        srow.addWidget(self.speed_btn); srow.addWidget(self.speed_inst); srow.addStretch(); sc.lay.addLayout(srow)
        self.speed_note = dim("Uses LibreSpeed (open-source, nearest server, nothing is shared)." if (DEMO or shutil.which("librespeed-cli"))
                              else "LibreSpeed is not installed: the quick test measures download only, over one connection to "
                                   "Cloudflare - your real speed can be higher.")
        sc.lay.addWidget(self.speed_note)
        lay.addWidget(sc); lay.addStretch()

        self.timer = QTimer(self); self.timer.setInterval(1000); self.timer.timeout.connect(self.refresh_ping)
        self.slow = QTimer(self); self.slow.setInterval(15000); self.slow.timeout.connect(self.refresh_conn)
        self.pops, self.shown_once, self.paused, self.selected = {}, False, False, ""
        self.fill_dns()

    # ---------------------------------------------------------------- lifecycle: ping only while the page is visible
    def showEvent(self, e):
        super().showEvent(e)
        if not self.shown_once:
            self.shown_once = True
            self.refresh_conn()
            threading.Thread(target=lambda: self.bridge.result.emit(("pops", sdr_pops())), daemon=True).start()
        elif not self.paused:
            for t in self.targets:
                t.start()
        self.timer.start(); self.slow.start()

    def hideEvent(self, e):
        super().hideEvent(e)
        self.timer.stop(); self.slow.stop()
        for t in self.targets:
            t.stop()

    def on_result(self, r):
        kind, val = r
        if kind == "pops":
            self.pops = val
            self.add_pop.clear(); self.add_pop.addItem("Add a Steam region…", "")
            for code, (desc, _ip) in sorted(val.items(), key=lambda x: x[1][0]):
                self.add_pop.addItem(desc, code)
            self.build_targets(self.cfg.get("targets"))
        elif kind == "dns":
            self.dns_ms = val
            self.dns_test_btn.setEnabled(True); self.dns_test_btn.setText("Test DNS speed")
            self.fill_dns()
        elif kind == "speed":
            self.show_speed(val)

    # ---------------------------------------------------------------- config
    def load_cfg(self):
        try:
            return json.loads(CFGF.read_text())
        except Exception:
            return {}

    def save_cfg(self):
        if DEMO:
            return
        try:
            CFGF.parent.mkdir(parents=True, exist_ok=True); CFGF.write_text(json.dumps(self.cfg, indent=1))
        except OSError:
            pass

    # ---------------------------------------------------------------- connection
    def refresh_conn(self):
        self.conn = connection()
        while self.conn_box.count():
            it = self.conn_box.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
            elif it.layout():
                _clear(it.layout())
        c = self.conn
        row = QHBoxLayout()
        if not c:
            row.addWidget(dot(RED)); row.addWidget(QLabel("Not connected to a network.")); row.addStretch()
            self.conn_box.addLayout(row); return
        if c["kind"] == "wifi":
            sig = c.get("signal", 0)
            bars = Bars(sig, GREEN if sig >= 60 else YELLOW if sig >= 40 else RED); row.addWidget(bars)
            band = "5 GHz" if c.get("freq", 0) >= 4900 and c.get("freq", 0) < 5925 else "6 GHz" if c.get("freq", 0) >= 5925 else "2.4 GHz"
            t = QLabel(f"<b>Wi-Fi: {c.get('ssid') or c['name']}</b>  ·  signal {sig}%  ·  {band}, channel {c.get('chan', '?')}"
                       f"  ·  {c.get('rate', '')}")
        else:
            row.addWidget(dot(GREEN)); t = QLabel(f"<b>Ethernet (cable)</b>  ·  {c['name']}" + (f"  ·  {c['speed']}" if c["speed"] else ""))
        row.addWidget(t); row.addStretch(); self.conn_box.addLayout(row)
        self.conn_box.addWidget(dim(f"IP {c['ip'] or '-'}   ·   router {c['gateway'] or '-'}   ·   DNS {', '.join(c['dns']) or '-'}"))
        hints = wifi_hints(c)
        if c["kind"] == "ethernet":
            hints = ["Cable connection - the best choice for online games."]
        for h in hints:
            self.conn_box.addWidget(dim("• " + h))
        self.fill_dns()

    # ---------------------------------------------------------------- targets
    def default_target_specs(self):
        specs = []
        gw = (self.conn or {}).get("gateway")
        if gw:
            specs.append(["gw", "Your router", gw, "icmp"])
        for code in DEFAULT_POPS:
            if code in self.pops:
                specs.append([code, "Steam " + self.pops[code][0].split(" (")[0], self.pops[code][1], "icmp"])
        specs += [["aws-fra", "AWS Frankfurt (game servers)", "dynamodb.eu-central-1.amazonaws.com", "tcp"],
                  ["cf", "Cloudflare", "1.1.1.1", "icmp"], ["g", "Google", "8.8.8.8", "icmp"]]
        return specs

    def build_targets(self, specs=None):
        for t in self.targets:
            t.stop()
        specs = specs or self.default_target_specs()
        if specs and specs[0][0] != "gw" and (self.conn or {}).get("gateway"):   # router first, always current
            specs = [s for s in specs if s[0] != "gw"]
            specs.insert(0, ["gw", "Your router", self.conn["gateway"], "icmp"])
        self.targets = [Target(k, label, host, mode) for k, label, host, mode in specs]
        self.selected = self.targets[1].key if len(self.targets) > 1 else (self.targets[0].key if self.targets else "")
        self.build_table()
        if not self.paused:
            for t in self.targets:
                t.start()

    def default_targets(self):
        self.cfg.pop("targets", None); self.save_cfg(); self.build_targets()

    def remember(self):
        self.cfg["targets"] = [[t.key, t.label, t.host, t.mode] for t in self.targets if t.key != "gw"]; self.save_cfg()

    def add_pop_chosen(self, i):
        code = self.add_pop.itemData(i)
        self.add_pop.setCurrentIndex(0)
        if not code or any(t.key == code for t in self.targets):
            return
        desc, ip = self.pops[code]
        t = Target(code, "Steam " + desc.split(" (")[0], ip); self.targets.append(t)
        if not self.paused:
            t.start()
        self.build_table(); self.remember()

    def add_custom(self):
        host = self.custom.text().strip()
        if not host or not re.fullmatch(r"[A-Za-z0-9.:-]+", host):
            return
        self.custom.clear()
        t = Target("c-" + host, host, host); self.targets.append(t)
        if not self.paused:
            t.start()
        self.build_table(); self.remember()

    def remove_target(self, key):
        for t in [t for t in self.targets if t.key == key]:
            t.stop(); self.targets.remove(t)
        self.build_table(); self.remember()

    def toggle_run(self):
        self.paused = not self.paused
        self.run_btn.setText("Resume" if self.paused else "Pause")
        for t in self.targets:
            (t.stop if self.paused else t.start)()

    def build_table(self):
        _clear(self.table)
        for c, h in enumerate(["", "Server", "Ping", "Average", "Jitter", "Loss", "", ""]):
            l = QLabel(h); l.setObjectName("dim"); self.table.addWidget(l, 0, c)
        self.rows = {}
        for i, t in enumerate(self.targets, 1):
            color = COLORS[(i - 1) % len(COLORS)]
            sw = QPushButton(); sw.setFixedSize(14, 14); sw.setFlat(True); sw.setCursor(Qt.PointingHandCursor)
            sw.setToolTip("Show in the graph")
            sw.clicked.connect(lambda _=False, k=t.key: self.select(k))
            name = QPushButton(t.label); name.setFlat(True); name.setCursor(Qt.PointingHandCursor)
            name.setStyleSheet("text-align:left; padding:2px 4px;"); name.clicked.connect(lambda _=False, k=t.key: self.select(k))
            name.setToolTip(f"{t.host} ({'ICMP ping' if t.mode == 'icmp' else 'TCP connect time'})")
            cells = [QLabel("–") for _ in range(4)]
            light = dot(GREY, 10)
            verdict = QLabel(""); verdict.setObjectName("dim")
            rm = QPushButton("✕"); rm.setFlat(True); rm.setFixedWidth(28); rm.setToolTip("Remove")
            rm.clicked.connect(lambda _=False, k=t.key: self.remove_target(k))
            self.table.addWidget(sw, i, 0); self.table.addWidget(name, i, 1)
            for c, cell in enumerate(cells, 2):
                cell.setAlignment(Qt.AlignRight | Qt.AlignVCenter); self.table.addWidget(cell, i, c)
            vb = QHBoxLayout(); vb.setSpacing(8); vb.addWidget(light); vb.addWidget(verdict); vb.addStretch()
            self.table.addLayout(vb, i, 6); self.table.addWidget(rm, i, 7)
            self.rows[t.key] = dict(sw=sw, color=color, cells=cells, light=light, verdict=verdict, name=name)
        self.table.setColumnStretch(6, 1)
        self.refresh_ping()

    def select(self, key):
        self.selected = key
        self.refresh_ping()

    def refresh_ping(self):
        series = []
        for t in self.targets:
            r = self.rows.get(t.key)
            if not r:
                continue
            st = t.stats()
            sel = t.key == self.selected
            r["sw"].setStyleSheet(f"background:{r['color']}; border-radius:7px; border:{'2px solid white' if sel else 'none'};")
            r["name"].setStyleSheet("text-align:left; padding:2px 4px;" + ("font-weight:700;" if sel else ""))
            if st:
                now = st["now"]
                r["cells"][0].setText("lost" if now is None else f"{now:.0f} ms")
                r["cells"][1].setText("–" if st["avg"] is None else f"{st['avg']:.0f} ms")
                r["cells"][2].setText(f"{st['jitter']:.1f} ms")
                r["cells"][3].setText(f"{st['loss']:.0f} %")
                r["cells"][3].setStyleSheet(f"color:{RED};" if st["loss"] > 0 else "")
            col, words = quality(st)
            if t.error and not st:
                col, words = GREY, "no reply (" + t.error[:40] + ")"
            r["light"].setStyleSheet(f"background:{col}; border-radius:5px;"); r["verdict"].setText(words)
            if sel:
                series.append((t.label, r["color"], list(t.samples)))
        self.graph.set_series(series)
        sel = next((t for t in self.targets if t.key == self.selected), None)
        if sel:
            st = sel.stats()
            self.graph_note.setText(f"{sel.label} - {sel.host}" + (f"  ·  best {st['min']:.0f} ms" if st and st["min"] else "")
                                    + "  ·  click a server to show it here. Red ticks = lost packets.")

    # ---------------------------------------------------------------- DNS
    def current_dns_choice(self):
        if not self.conn:
            return None
        cur = set(self.conn.get("dns") or [])
        for name, _d, v4, _v6 in DNS[1:]:
            if cur and cur <= set(v4):
                return name
        return "Automatic"

    def fill_dns(self):
        if not hasattr(self, "dns_grid"):
            return
        _clear(self.dns_grid)
        cur = self.current_dns_choice()
        best = min((v, k) for k, v in self.dns_ms.items() if v is not None)[1] if any(v is not None for v in self.dns_ms.values()) else None
        for i, (name, desc, v4, _v6) in enumerate(DNS):
            b = QPushButton(name + ("  ✓" if name == cur else "")); b.setMinimumWidth(130)
            if name == cur:
                b.setObjectName("primary")
            b.setEnabled(bool(self.conn) and name != cur)
            b.clicked.connect(lambda _=False, n=name: self.set_dns(n))
            self.dns_grid.addWidget(b, i, 0)
            self.dns_grid.addWidget(dim(desc), i, 1)
            ms = self.dns_ms.get(name, "–")
            txt = "–" if ms == "–" else ("no answer" if ms is None else f"{ms:.0f} ms")
            l = QLabel(txt + ("  fastest" if name == best else "")); l.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            if name == best:
                l.setStyleSheet(f"color:{GREEN}; font-weight:600;")
            self.dns_grid.addWidget(l, i, 2)
        self.dns_grid.setColumnStretch(1, 1)
        self.dns_undo.setEnabled(bool(self.load_cfg().get("dns_backup")) or DEMO)
        self.dns_auto_btn.setEnabled(bool(self.dns_ms))
        if self.conn:
            self.dns_note.setText(f"Applies to \"{self.conn['name']}\" only (other networks keep their own setting). "
                                  "Automatic = what your router or provider gives.")

    def test_dns(self):
        self.dns_test_btn.setEnabled(False); self.dns_test_btn.setText("Testing…")
        auto = ((self.conn or {}).get("dns") or [])[:1] if self.current_dns_choice() == "Automatic" else []

        def work():
            res = {}
            for name, _d, v4, _v6 in DNS:
                servers = v4 if name != "Automatic" else auto
                if servers:                 # "Automatic" can only be measured while it is the one in use
                    res[name] = dns_best(servers[0])
            self.bridge.result.emit(("dns", res))
        threading.Thread(target=work, daemon=True).start()

    def use_fastest(self):
        ok = {k: v for k, v in self.dns_ms.items() if v is not None}
        if ok:
            self.set_dns(min(ok, key=ok.get))

    def set_dns(self, name):
        c = self.conn
        if not c or not c.get("uuid"):
            return
        entry = next(d for d in DNS if d[0] == name)
        cfg = self.load_cfg()
        if not cfg.get("dns_backup", {}).get(c["uuid"]):
            prev = sh(["nmcli", "-g", "ipv4.dns,ipv4.ignore-auto-dns,ipv6.dns,ipv6.ignore-auto-dns", "con", "show", c["uuid"]]).splitlines()
            if len(prev) >= 4:
                cfg.setdefault("dns_backup", {})[c["uuid"]] = prev[:4]
                self.cfg["dns_backup"] = cfg["dns_backup"]; self.save_cfg()
        if name == "Automatic":
            args = ["ipv4.dns", "", "ipv4.ignore-auto-dns", "no", "ipv6.dns", "", "ipv6.ignore-auto-dns", "no"]
        else:
            args = ["ipv4.dns", " ".join(entry[2]), "ipv4.ignore-auto-dns", "yes", "ipv6.dns", " ".join(entry[3]), "ipv6.ignore-auto-dns", "yes"]
        self.apply_nm(c, args)

    def apply_nm(self, c, args):
        if DEMO:
            return
        # nmcli asks for the password itself (polkit) when the connection belongs to the whole system
        self.center.runner.run("sh", ["-c", 'u=$1; d=$2; shift 2; nmcli con mod "$u" "$@" && (nmcli dev reapply "$d" || nmcli con up "$u")',
                                      "sh", c["uuid"], c["device"], *args], lambda code: QTimer.singleShot(1500, self.refresh_conn))

    def undo_dns(self):
        c = self.conn
        b = self.load_cfg().get("dns_backup", {}).get((c or {}).get("uuid", ""))
        if not c or not b:
            return
        v4, ig4, v6, ig6 = (b + ["", "", "", ""])[:4]
        self.apply_nm(c, ["ipv4.dns", v4.replace(",", " "), "ipv4.ignore-auto-dns", ig4 or "no",
                          "ipv6.dns", v6.replace(",", " "), "ipv6.ignore-auto-dns", ig6 or "no"])
        self.cfg.get("dns_backup", {}).pop(c["uuid"], None); self.save_cfg()

    # ---------------------------------------------------------------- speed test
    def speedtest(self):
        self.speed_btn.setEnabled(False); self.speed_btn.setText("Testing… (about 30 s)")
        for v in self.speed_vals.values():
            v.setText("…")
        threading.Thread(target=lambda: self.bridge.result.emit(("speed", run_speedtest())), daemon=True).start()

    def show_speed(self, r):
        self.speed_btn.setEnabled(True); self.speed_btn.setText("Run again")
        if r.get("error"):
            for v in self.speed_vals.values():
                v.setText("–")
            self.speed_note.setText("Speed test failed: " + r["error"]); return
        f = lambda x, u: "–" if x is None else f"{x:.0f} {u}" if x >= 10 else f"{x:.1f} {u}"  # noqa: E731
        self.speed_vals["down"].setText(f(r.get("down"), "Mbit/s")); self.speed_vals["up"].setText(f(r.get("up"), "Mbit/s"))
        self.speed_vals["ping"].setText(f(r.get("ping"), "ms")); self.speed_vals["jitter"].setText(f(r.get("jitter"), "ms"))
        self.speed_note.setText(r.get("note", ""))

    def install_librespeed(self):
        def done(code):
            if code == 0:
                self.speed_inst.hide(); self.speed_note.setText("LibreSpeed installed - run the test again for download and upload.")
        self.center.runner.root("/usr/lib/phoenixge/apt-install.sh", ["librespeed-cli"], done)


def run_speedtest():
    if DEMO:
        time.sleep(0.2)
        return dict(down=287.4, up=46.2, ping=11.0, jitter=1.8, note="Server: Frankfurt, Germany (LibreSpeed). Measured just now.")
    if shutil.which("librespeed-cli"):
        try:
            out = subprocess.run(["librespeed-cli", "--json", "--secure", "--no-icmp", "--duration", "10"], capture_output=True,
                                 text=True, timeout=120).stdout
            d = json.loads(out)
            d = d[0] if isinstance(d, list) else d
            mb = lambda v: None if v is None else (v / 1e6 if v > 10000 else float(v))  # noqa: E731  (bit/s in newer, Mbit/s in older)
            srv = (d.get("server") or {}).get("name", "")
            return dict(down=mb(d.get("download")), up=mb(d.get("upload")), ping=d.get("ping"), jitter=d.get("jitter"),
                        note=f"Server: {srv} (LibreSpeed). Results are not shared anywhere.")
        except Exception as e:
            first = f"LibreSpeed failed: {e}"
    else:
        first = ""
    # fallback: one HTTPS download from Cloudflare's speed endpoint for up to 10 s
    try:
        url = "https://speed.cloudflare.com/__down?bytes=200000000"
        t0 = time.perf_counter(); got = 0
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "PhoenixGe"}), timeout=10) as r:
            ttfb = (time.perf_counter() - t0) * 1000
            t1 = time.perf_counter()
            while time.perf_counter() - t1 < 10:
                b = r.read(256 * 1024)
                if not b:
                    break
                got += len(b)
            dt = time.perf_counter() - t1
        return dict(down=got * 8 / dt / 1e6 if dt else None, up=None, ping=ttfb, jitter=None,
                    note="Quick test: download only, one connection to Cloudflare (ping = time to first byte). "
                         "Install the full speed test for upload and a more exact result." + (f" ({first})" if first else ""))
    except Exception as e:
        return dict(error=str(e) or "no internet?")


def _clear(layout):
    while layout.count():
        it = layout.takeAt(0)
        if it.widget():
            it.widget().deleteLater()
        elif it.layout():
            _clear(it.layout())


def build(center):
    return NetworkPage(center)


if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication, QPlainTextEdit
    app = QApplication(sys.argv)

    class _Host(QWidget):
        def __init__(self):
            super().__init__()
            lay = QVBoxLayout(self); self.log = QPlainTextEdit(); self.log.setMaximumHeight(120); self.log.hide()
            import center as cmod
            self.runner = cmod.Runner(self.log)
            lay.addWidget(build(self)); lay.addWidget(self.log)
    h = _Host(); h.resize(1100, 800); h.show()
    sys.exit(app.exec())
