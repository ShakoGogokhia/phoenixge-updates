"""PhoenixGe Center - "Laptop" section for the Devices page.

    import laptop
    lay.addWidget(laptop.build(self))      # in Center.p_devices()

Smart battery, battery protection (charge limit) and graphics mode, each with Automatic (default) / Manual.
Returns an empty hidden widget on computers without a laptop battery. Logic lives in laptop_data.py,
root changes go through /usr/bin/phoenixge-laptop -> pkexec /usr/lib/phoenixge/laptop-root.sh.
"""
import sys
from pathlib import Path

from PySide6.QtCore import QProcess, Qt
from PySide6.QtWidgets import (QCheckBox, QComboBox, QFrame, QGridLayout, QHBoxLayout, QLabel, QMessageBox, QPushButton,
                               QSizePolicy, QSlider, QVBoxLayout, QWidget)

sys.path.insert(0, str(Path(__file__).resolve().parent))
import laptop_data as ld  # noqa: E402

CLI = "/usr/bin/phoenixge-laptop"


def _ui(center):
    """Card from the running Center (center.py runs as __main__, so take it from the Center's own module)."""
    mod = sys.modules.get(type(center).__module__)
    card = getattr(mod, "Card", None)
    if card is None:
        class card(QFrame):  # noqa: N801 - fallback with the same interface
            def __init__(self, title="", text=""):
                super().__init__()
                self.setObjectName("card")
                self.lay = QVBoxLayout(self)
                if title:
                    t = QLabel(title); t.setObjectName("cardTitle"); self.lay.addWidget(t)
                if text:
                    x = QLabel(text); x.setWordWrap(True); x.setObjectName("dim"); self.lay.addWidget(x)
    return card


def badge(mode):
    text = {"auto": "Automatic", "manual": "Manual", "off": "Off"}.get(mode, mode)
    b = QLabel(text)
    color = {"auto": "#3fb950", "manual": "#ff7a2e", "off": "#8b949e"}.get(mode, "#8b949e")
    b.setStyleSheet(f"QLabel {{ color: {color}; border: 1px solid {color}; border-radius: 9px; padding: 1px 9px; "
                    f"font-size: 11px; font-weight: 600; }}")
    b.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
    return b


def dim(text):
    x = QLabel(text); x.setWordWrap(True); x.setObjectName("dim")
    return x


def combo(items, current):
    """items: [(value, label)]"""
    c = QComboBox()
    for v, label in items:
        c.addItem(label, v)
    i = c.findData(current)
    c.setCurrentIndex(i if i >= 0 else 0)
    return c


class LaptopSection(QWidget):
    def __init__(self, center):
        super().__init__()
        self.center, self.Card = center, _ui(center)
        self.lay = QVBoxLayout(self); self.lay.setContentsMargins(0, 0, 0, 0); self.lay.setSpacing(16)
        self.render()

    # ------------------------------------------------------------ helpers
    def run(self, args, done=None):
        """phoenixge-laptop via the Center's runner (log box), then re-read the state."""
        def end(code):
            if done:
                done(code)
            self.render()
        self.center.runner.run("python3", [CLI, *args], end)

    def set_user(self, key, value):
        if key == "mode":
            ld.save_user_conf({"mode": value})
            if value == "auto":
                st = ld.load_state(); st.pop("learned", None); ld.save_state(st)
        else:
            ld.save_user_conf({key: value, "mode": "manual"})
        self.render()

    def clear(self):
        while self.lay.count():
            it = self.lay.takeAt(0)
            if it.widget():
                it.widget().deleteLater()

    def header(self, card, title, mode):
        row = QHBoxLayout()
        t = QLabel(title); t.setObjectName("cardTitle")
        row.addWidget(t); row.addWidget(badge(mode), 0, Qt.AlignVCenter); row.addStretch()
        card.lay.insertLayout(0, row)

    # ------------------------------------------------------------ build
    def render(self):
        self.clear()
        try:
            st = ld.status()
        except Exception as e:  # never break the Devices page
            self.lay.addWidget(self.Card("Laptop", f"Could not read the laptop state: {e}"))
            return
        if not st.get("laptop"):
            self.hide()
            return
        self.show()
        self.lay.addWidget(self.smart_card(st))
        self.lay.addWidget(self.charge_card(st))
        self.lay.addWidget(self.gpu_card(st))
        row = QHBoxLayout()
        if not st.get("automatic"):
            r = QPushButton("Reset all to automatic")
            r.clicked.connect(lambda: self.run(["reset"]))
            row.addWidget(r)
            row.addWidget(dim("Smart battery, battery protection and graphics go back to the recommended automatic behaviour."), 1)
        else:
            row.addWidget(dim("✓ Everything is on Automatic (recommended)."), 1)
        holder = QWidget(); holder.setLayout(row)
        self.lay.addWidget(holder)

    # ---- 1. smart battery
    def smart_card(self, st):
        s = st["smart"]
        c = self.Card()
        self.header(c, "Smart battery", s["mode"])
        b = st.get("battery", {})
        now = f"{b.get('percent', '?')}%, {b.get('state', '')}" + (f", {b['time']} left" if b.get("time") and b.get("state") == "discharging" else "")
        c.lay.addWidget(dim(f"Battery: {now}. " + ("Running on battery." if st["on_battery"] else "On the charger.")))
        mode = combo([("auto", "Automatic (recommended)"), ("manual", "Manual"), ("off", "Off")], s["mode"])
        mode.currentIndexChanged.connect(lambda _i: self.set_user("mode", mode.currentData()))
        r = QHBoxLayout(); r.addWidget(QLabel("Mode")); r.addWidget(mode); r.addStretch(); c.lay.addLayout(r)
        pnl = s.get("panel")
        g = st["gpu"]
        if s["mode"] == "auto":
            hz = "the screen drops to 60 Hz" if pnl and pnl["options"] and max(pnl["options"]) > 60 else "the screen stays as it is"
            c.lay.addWidget(dim(f"Unplugged: Battery saver power mode, {hz}, a notice with the time left. Plugged in: your previous "
                                "power mode and refresh rate come back. If you change them while on battery, PhoenixGe remembers "
                                "that for next time."))
        elif s["mode"] == "off":
            c.lay.addWidget(dim("Nothing changes when you unplug the charger."))
        else:
            grid = QGridLayout(); grid.setHorizontalSpacing(12)
            profiles = [(p, ld.PROFILE_NAMES[p]) for p in ld.PROFILES]
            opts = pnl["options"] if pnl else []
            grid.addWidget(QLabel("<b>On battery</b>"), 0, 1); grid.addWidget(QLabel("<b>On the charger</b>"), 0, 2)
            grid.addWidget(QLabel("Power mode"), 1, 0)
            bp = combo([("keep", "Don't change")] + profiles, s["bat_profile"])
            ap = combo([("restore", "Back to previous"), ("keep", "Don't change")] + profiles, s["ac_profile"])
            bp.currentIndexChanged.connect(lambda _i: self.set_user("bat_profile", bp.currentData()))
            ap.currentIndexChanged.connect(lambda _i: self.set_user("ac_profile", ap.currentData()))
            grid.addWidget(bp, 1, 1); grid.addWidget(ap, 1, 2)
            grid.addWidget(QLabel("Screen refresh"), 2, 0)
            if opts:
                br = combo([("keep", "Don't change")] + [(str(h), f"{h} Hz") for h in opts], s["bat_refresh"])
                ar = combo([("restore", "Back to previous"), ("max", f"Highest ({max(opts)} Hz)"), ("keep", "Don't change")]
                           + [(str(h), f"{h} Hz") for h in opts], s["ac_refresh"])
                br.currentIndexChanged.connect(lambda _i: self.set_user("bat_refresh", br.currentData()))
                ar.currentIndexChanged.connect(lambda _i: self.set_user("ac_refresh", ar.currentData()))
                grid.addWidget(br, 2, 1); grid.addWidget(ar, 2, 2)
            else:
                grid.addWidget(dim("The built-in screen's refresh rates can't be read (no kscreen-doctor or no internal panel)."), 2, 1, 1, 2)
            if g["has_nvidia"] and g["driver"] and not g["integrated_active"]:
                grid.addWidget(QLabel("NVIDIA sleeps when idle"), 3, 0)
                for col, key, val in ((1, "battery", g["nv_sleep_bat"]), (2, "ac", g["nv_sleep_ac"])):
                    cb = QCheckBox("Yes (saves power)"); cb.setChecked(val)
                    cb.toggled.connect(lambda on, k=key: self.run(["set", "nv-sleep", k, "on" if on else "off"]))
                    grid.addWidget(cb, 3, col)
            note = QCheckBox("Show a notice with the battery time when unplugged"); note.setChecked(s["notify"] == "true")
            note.toggled.connect(lambda on: self.set_user("notify", "true" if on else "false"))
            c.lay.addLayout(grid); c.lay.addWidget(note)
        if s["mode"] != "off" and not s.get("running"):
            c.lay.addWidget(dim("The smart battery helper starts at login - log out and back in once after an update."))
        return c

    # ---- 2. battery protection
    def charge_card(self, st):
        ch = st["charge"]
        c = self.Card()
        self.header(c, "Battery protection", ch["mode"] if ch["supported"] else "off")
        if not ch["supported"]:
            c.lay.addWidget(dim("This laptop doesn't let Linux limit charging (no conservation mode or charge threshold in its "
                                "driver). Some models offer it in the BIOS/UEFI setup or in the manufacturer's Windows app instead."))
            return c
        ideapad = ch["kind"] == "ideapad"
        if ch["once"]:
            state = "Charging to 100% once - protection comes back when the battery is full or the charger is unplugged."
        elif ch["protect"]:
            state = ("On: Lenovo conservation mode - the battery stops charging at " + ch["stop_text"] + "." if ideapad
                     else f"On: charging stops at {ch['stop_text']}.")
        else:
            state = "Off: the battery charges to 100%."
        c.lay.addWidget(dim(state + " Keeping a battery below full when the laptop mostly sits on the charger makes it last years longer."))
        mode = combo([("auto", "Automatic (recommended)"), ("manual", "Manual")], ch["mode"])
        mode.currentIndexChanged.connect(lambda _i: self.run(["set", "charge", "auto" if mode.currentData() == "auto" else "on"]))
        r = QHBoxLayout(); r.addWidget(QLabel("Mode")); r.addWidget(mode); r.addStretch(); c.lay.addLayout(r)
        if ch["mode"] == "auto":
            c.lay.addWidget(dim("Automatic: protection is always on" + (" (conservation mode)." if ideapad else " (stops at 80%).")))
        elif ideapad:
            cb = QCheckBox("Protect the battery (conservation mode)"); cb.setChecked(bool(ch["protect"]) and not ch["once"])
            cb.toggled.connect(lambda on: self.run(["set", "charge", "on" if on else "off"]))
            c.lay.addWidget(cb)
        else:
            row = QHBoxLayout()
            sl = QSlider(Qt.Horizontal); sl.setRange(60, 100); sl.setSingleStep(5); sl.setPageStep(5); sl.setTickInterval(10)
            sl.setTickPosition(QSlider.TicksBelow); sl.setValue(ch.get("limit", 80) if ch["protect"] else 100)
            val = QLabel(f"{sl.value()}%"); val.setMinimumWidth(44)
            sl.valueChanged.connect(lambda v: val.setText(f"{v}%" + (" (no limit)" if v == 100 else "")))
            ap = QPushButton("Apply"); ap.clicked.connect(lambda: self.run(["set", "charge", str(sl.value())]))
            row.addWidget(QLabel("Stop charging at")); row.addWidget(sl, 1); row.addWidget(val); row.addWidget(ap)
            c.lay.addLayout(row)
        row = QHBoxLayout()
        if ch["once"]:
            b = QPushButton("Cancel - protect again now"); b.clicked.connect(lambda: self.run(["set", "charge-once-cancel"]))
            row.addWidget(b)
        elif ch["protect"]:
            b = QPushButton("Charge to 100% once"); b.setObjectName("primary")
            b.setToolTip("For a trip: charges fully this time, protection turns back on by itself.")
            b.clicked.connect(lambda: self.run(["set", "charge-once"]))
            row.addWidget(b)
        row.addStretch(); c.lay.addLayout(row)
        if ch.get("external_change"):
            c.lay.addWidget(dim("The value was changed outside PhoenixGe (e.g. System Settings > Power). PhoenixGe sets its own "
                                "value again at the next start - change it here to keep it."))
        if not ideapad:
            c.lay.addWidget(dim("System Settings > Power has a charge limit too; PhoenixGe re-applies the value from this page at "
                                "every start, so set it here."))
        return c

    # ---- 3. graphics
    def gpu_card(self, st):
        g = st["gpu"]
        c = self.Card()
        if not (g["hybrid"] or g["integrated_active"] or g["effective"] == "nvidia"):
            self.header(c, "Graphics", "auto")
            c.lay.addWidget(dim(f"{g['igpu'] or g['dgpu'] or 'One graphics chip'} - nothing to switch on this laptop."))
            return c
        self.header(c, "Graphics", "auto" if g["mode"] == "auto" else "manual")
        names = " + ".join(x for x in (g["igpu"], g["dgpu"]) if x)
        eff = {"hybrid": "Hybrid", "integrated": "Integrated only (NVIDIA off)", "nvidia": "NVIDIA only (set in the BIOS)"}.get(g["effective"], g["effective"])
        nv = {"asleep": "NVIDIA is asleep (saving power).", "awake": "NVIDIA is awake (a program is using it).",
              "off": "NVIDIA is switched off."}.get(g["dgpu_state"], "")
        c.lay.addWidget(dim(f"{names}. Now: {eff}. {nv}"))
        if g["reboot_pending"]:
            row = QHBoxLayout()
            row.addWidget(QLabel("<b>Restart needed</b> to finish switching the graphics mode."))
            rb = QPushButton("Restart now"); rb.setObjectName("primary")
            rb.clicked.connect(lambda: QProcess.startDetached("systemctl", ["reboot"]))
            row.addWidget(rb); row.addStretch(); c.lay.addLayout(row)
        if g["live"]:
            c.lay.addWidget(dim("Graphics modes can be changed after PhoenixGe is installed."))
            return c
        if g["effective"] == "nvidia":
            c.lay.addWidget(dim("The BIOS runs this laptop on the NVIDIA card only (best for gaming on the charger, shortest battery "
                                "life). To get Hybrid back: restart, press F2 and set 'GPU Working Mode' to 'Hybrid'/'Dynamic'."))
            return c
        items = [("auto", "Automatic - Hybrid (recommended)"), ("hybrid", "Hybrid (keep)")]
        if g["can_integrated"]:
            items.append(("integrated", "Integrated only - NVIDIA off"))
        mode = combo(items, g["mode"])
        apply_b = QPushButton("Apply")
        apply_b.clicked.connect(lambda: self.apply_gpu(mode.currentData(), g))
        r = QHBoxLayout(); r.addWidget(QLabel("Mode")); r.addWidget(mode); r.addWidget(apply_b); r.addStretch(); c.lay.addLayout(r)
        if not g["driver"]:
            c.lay.addWidget(dim("The NVIDIA driver is not installed yet (Center > Drivers). Until then only Hybrid and Integrated are possible."))
        c.lay.addWidget(dim("Hybrid: the desktop runs on the integrated chip, games run on NVIDIA, and NVIDIA switches itself off "
                            "when nothing uses it. Integrated only: NVIDIA is fully off - longest battery life, but games are slow "
                            "and HDMI/USB-C ports wired to NVIDIA (common on gaming laptops) stop working."))
        c.lay.addWidget(dim("NVIDIA only: " + g["nvidia_hint"]))
        c.lay.addWidget(dim("Games from Steam and Heroic start on NVIDIA by themselves. Any other app: right-click it in the start "
                            "menu > 'Run using dedicated graphics card', or in a terminal: phoenixge-laptop run-dgpu <app>."))
        return c

    def apply_gpu(self, value, g):
        if value == g["mode"] and (value == "integrated") == g["integrated_active"]:
            return   # nothing to change
        if value in ("auto", "hybrid") and g["mode"] in ("auto", "hybrid") and not g["integrated_active"]:
            self.run(["set", "gpu", value])   # just the Auto/Manual choice, nothing to restart
            return
        if value == "integrated":
            ok = QMessageBox.question(self.center, "Integrated graphics only",
                                      "The NVIDIA card will be switched off after a restart. Games will run on the integrated chip "
                                      "and HDMI/USB-C ports wired to NVIDIA may stop working.\n\nYou can switch back here at any time. "
                                      "Continue?")
            if ok != QMessageBox.Yes:
                return

        def done(code):
            if code == 0 and QMessageBox.question(self.center, "Restart needed",
                                                  "The graphics mode changes after a restart. Restart now?") == QMessageBox.Yes:
                QProcess.startDetached("systemctl", ["reboot"])
        self.run(["set", "gpu", value], done)


def build(center):
    """Section for Center.p_devices(). Hidden (empty) on computers without a laptop battery."""
    try:
        if not ld.is_laptop():
            w = QWidget(); w.hide()
            return w
        return LaptopSection(center)
    except Exception as e:  # a hardware oddity must never break the Center
        w = QLabel(f"Laptop features unavailable: {e}"); w.setObjectName("dim"); w.setWordWrap(True)
        return w
