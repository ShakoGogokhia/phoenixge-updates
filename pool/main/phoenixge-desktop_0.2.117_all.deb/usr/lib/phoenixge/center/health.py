"""PhoenixGe Center > Health: drive health, disk space, battery wear, temperatures, memory - with a traffic light and a
plain-language explanation for each - plus a one-button Clean up that shows what it will free first.

build(center) -> QWidget   (center = the PhoenixGe Center main window: uses center.runner and center.log)
Run alone for testing:  python3 health.py
"""
import json
import sys
import threading
import time
from pathlib import Path

from PySide6.QtCore import QObject, QProcess, Qt, QTimer, Signal
from PySide6.QtWidgets import (QCheckBox, QFrame, QGridLayout, QHBoxLayout, QLabel, QMessageBox, QPushButton, QScrollArea,
                               QVBoxLayout, QWidget)

sys.path.insert(0, str(Path(__file__).resolve().parent))
import health_data as hd  # noqa: E402

CACHE = Path.home() / ".cache/phoenixge/health-disks.json"


def _ui():
    """Card / page from center.py when we run inside it (same look), small copies otherwise."""
    main = sys.modules.get("__main__")
    if hasattr(main, "Card") and hasattr(main, "page"):
        return main.Card, main.page

    class Card(QFrame):
        def __init__(self, title="", text=""):
            super().__init__()
            self.setObjectName("card")
            self.lay = QVBoxLayout(self); self.lay.setContentsMargins(18, 16, 18, 16); self.lay.setSpacing(8)
            if title:
                t = QLabel(title); t.setObjectName("cardTitle"); self.lay.addWidget(t)
            if text:
                x = QLabel(text); x.setWordWrap(True); x.setObjectName("dim"); self.lay.addWidget(x)

    def page(title, subtitle=""):
        w = QWidget(); outer = QVBoxLayout(w); outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame)
        inner = QWidget(); lay = QVBoxLayout(inner); lay.setContentsMargins(36, 30, 36, 30); lay.setSpacing(16)
        h = QLabel(title); h.setObjectName("h1"); lay.addWidget(h)
        if subtitle:
            s = QLabel(subtitle); s.setObjectName("dim"); s.setWordWrap(True); lay.addWidget(s)
        scroll.setWidget(inner); outer.addWidget(scroll)
        return w, lay
    return Card, page


def dot(state, size=12):
    d = QLabel(); d.setFixedSize(size, size)
    d.setStyleSheet(f"background:{hd.COLORS[state]}; border-radius:{size // 2}px;")
    d.setToolTip({"green": "Good", "yellow": "Needs attention", "red": "Problem", "grey": "Not checked"}[state])
    return d


def item_row(it):
    w = QWidget(); g = QGridLayout(w); g.setContentsMargins(0, 4, 0, 4); g.setHorizontalSpacing(10); g.setVerticalSpacing(2)
    g.addWidget(dot(it["state"]), 0, 0, Qt.AlignVCenter)
    t = QLabel(it["title"]); t.setStyleSheet("font-weight:600;"); t.setTextInteractionFlags(Qt.TextSelectableByMouse)
    g.addWidget(t, 0, 1)
    v = QLabel(it["value"]); v.setAlignment(Qt.AlignRight | Qt.AlignVCenter); g.addWidget(v, 0, 2)
    x = QLabel(it["text"]); x.setWordWrap(True); x.setObjectName("dim"); g.addWidget(x, 1, 1, 1, 2)
    g.setColumnStretch(1, 1)
    return w


class Section:
    """A card whose item rows can be replaced."""

    def __init__(self, Card, title, text=""):
        self.card = Card(title, text)
        self.box = QVBoxLayout(); self.box.setSpacing(2); self.card.lay.addLayout(self.box)
        self.items = []

    def set_items(self, items):
        while self.box.count():
            w = self.box.takeAt(0).widget()
            if w:
                w.deleteLater()
        self.items = list(items)
        for it in self.items:
            self.box.addWidget(item_row(it))


class _Bridge(QObject):
    estimates = Signal(object)


class HealthPage(QWidget):
    def __init__(self, center):
        super().__init__()
        self.center = center
        Card, page = _ui()
        w, lay = page("Health", "How your computer is doing - drives, space, battery, temperatures and memory. "
                                "Green is fine, yellow needs attention, red is a problem.")
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0); outer.addWidget(w)

        self.summary = Card()
        srow = QHBoxLayout(); self.sdot = QLabel(); self.sdot.setFixedSize(22, 22)
        self.stext = QLabel("Checking…"); self.stext.setStyleSheet("font-size:16px;font-weight:600;"); self.stext.setWordWrap(True)
        refresh = QPushButton("Refresh"); refresh.clicked.connect(self.refresh_all)
        srow.addWidget(self.sdot); srow.addWidget(self.stext, 1); srow.addWidget(refresh)
        self.summary.lay.addLayout(srow); lay.addWidget(self.summary)

        self.drives = Section(Card, "Drives", "Your drives report their own health (SMART). Reading it needs your password.")
        drow = QHBoxLayout()
        self.dbtn = QPushButton("Check drive health"); self.dbtn.setObjectName("primary"); self.dbtn.clicked.connect(self.check_disks)
        self.dlast = QLabel(""); self.dlast.setObjectName("dim")
        drow.addWidget(self.dbtn); drow.addWidget(self.dlast); drow.addStretch()
        self.drives.card.lay.addLayout(drow)
        self.space = Section(Card, "Disk space")
        self.battery = Section(Card, "Battery")
        self.temps = Section(Card, "Temperatures")
        self.ram = Section(Card, "Memory")
        for s in (self.drives, self.space, self.battery, self.temps, self.ram):
            lay.addWidget(s.card)

        # clean-up
        self.clean = Card("Clean up", "Frees space without touching your documents, photos, games or settings. "
                                      "Pick what to delete - the size is shown first.")
        self.cbox = QVBoxLayout(); self.clean.lay.addLayout(self.cbox)
        crow = QHBoxLayout()
        self.ctotal = QLabel("Measuring…"); self.ctotal.setStyleSheet("font-weight:600;")
        self.cbtn = QPushButton("Clean up"); self.cbtn.setObjectName("primary"); self.cbtn.setEnabled(False)
        self.cbtn.clicked.connect(self.do_clean)
        crow.addWidget(self.ctotal); crow.addStretch(); crow.addWidget(self.cbtn)
        self.clean.lay.addLayout(crow)
        lay.addWidget(self.clean); lay.addStretch()

        self.checks, self.est = [], []
        self.bridge = _Bridge(); self.bridge.estimates.connect(self.show_estimates)
        self.proc = None
        self.shown_once = False
        self.timer = QTimer(self); self.timer.setInterval(5000); self.timer.timeout.connect(self.refresh_live)
        self.load_cached_disks()

    # pages are built when the Center starts - do the work only when the page is actually opened
    def showEvent(self, e):
        super().showEvent(e)
        self.timer.start()
        if not self.shown_once:
            self.shown_once = True
            self.refresh_all()

    def hideEvent(self, e):
        super().hideEvent(e)
        self.timer.stop()

    def refresh_all(self):
        self.space.set_items(hd.space_items())
        bat = hd.battery_items()
        self.battery.set_items(bat or [hd.item("No battery", hd.GREEN, "", "This computer runs on mains power.")])
        self.refresh_live()
        self.measure()

    def refresh_live(self):
        self.temps.set_items(hd.temp_items())
        self.ram.set_items(hd.ram_items())
        self.update_summary()

    def update_summary(self):
        allitems = self.drives.items + self.space.items + self.battery.items + self.temps.items + self.ram.items
        st = hd.worst(i["state"] for i in allitems if i["state"] != hd.GREY) if allitems else hd.GREY
        self.sdot.setStyleSheet(f"background:{hd.COLORS[st]}; border-radius:11px;")
        bad = [i["title"] for i in allitems if i["state"] in (hd.RED, hd.YELLOW)]
        self.stext.setText({hd.GREEN: "Everything looks good.",
                            hd.YELLOW: "Mostly fine - a few things need attention: " + ", ".join(bad) + ".",
                            hd.RED: "There is a problem: " + ", ".join(i["title"] for i in allitems if i["state"] == hd.RED) + "."
                            }.get(st, "Checking…"))

    # ---------------------------------------------------------------- drives (pkexec)
    def load_cached_disks(self):
        try:
            data = json.loads(CACHE.read_text())
            self.drives.set_items(data["items"])
            self.dlast.setText("Last checked " + time.strftime("%d %b %Y %H:%M", time.localtime(data["time"])))
        except Exception:
            self.drives.set_items([hd.item("Not checked yet", hd.GREY, "", "Press \"Check drive health\".")])

    def check_disks(self):
        if self.proc:
            return
        self.dbtn.setEnabled(False); self.dlast.setText("Checking…")
        p = QProcess(self); buf = []
        p.readyReadStandardOutput.connect(lambda: buf.append(bytes(p.readAllStandardOutput()).decode(errors="replace")))

        def done(code, _s=None):
            self.proc = None
            self.dbtn.setEnabled(True)
            if code != 0:
                self.dlast.setText("Cancelled." if code in (126, 127) else f"Check failed ({code}).")
                return
            items = hd.parse_disk_report("".join(buf))
            self.drives.set_items(items)
            self.dlast.setText("Checked just now")
            try:
                CACHE.parent.mkdir(parents=True, exist_ok=True)
                CACHE.write_text(json.dumps(dict(time=time.time(), items=items)))
            except OSError:
                pass
            self.update_summary()
        p.finished.connect(done)
        p.errorOccurred.connect(lambda err: err == QProcess.ProcessError.FailedToStart and done(-1))
        self.proc = p
        p.start("pkexec", ["/bin/sh", hd.DISK_HELPER])

    # ---------------------------------------------------------------- clean-up
    def measure(self):
        self.ctotal.setText("Measuring…"); self.cbtn.setEnabled(False)
        threading.Thread(target=lambda: self.bridge.estimates.emit(hd.cleanup_estimates()), daemon=True).start()

    def show_estimates(self, est):
        self.est = est
        while self.cbox.count():
            w = self.cbox.takeAt(0).widget()
            if w:
                w.deleteLater()
        self.checks = []
        for e in est:
            row = QWidget(); v = QVBoxLayout(row); v.setContentsMargins(0, 2, 0, 2); v.setSpacing(0)
            cb = QCheckBox(f"{e['title']}  -  {hd.human(e['bytes']) if e['bytes'] else 'nothing to free'}")
            cb.setEnabled(e["enabled"]); cb.setChecked(e["enabled"] and e["key"] != "trash")  # emptying trash is opt-in
            cb.toggled.connect(self.update_total)
            d = QLabel(e["detail"]); d.setObjectName("dim"); d.setWordWrap(True); d.setContentsMargins(26, 0, 0, 0)
            v.addWidget(cb); v.addWidget(d)
            self.cbox.addWidget(row)
            self.checks.append((cb, e))
        self.update_total()

    def selected(self):
        return [e for cb, e in self.checks if cb.isChecked() and cb.isEnabled()]

    def update_total(self):
        sel = self.selected()
        total = sum(e["bytes"] for e in sel)
        self.ctotal.setText(f"Will free about {hd.human(total)}" if sel else "Nothing selected")
        self.cbtn.setEnabled(bool(sel))

    def do_clean(self):
        sel = self.selected()
        if not sel:
            return
        lines = "".join(f"<li>{e['title']} - {hd.human(e['bytes'])}</li>" for e in sel)
        if QMessageBox.question(self, "Clean up", f"Delete these?<ul>{lines}</ul>"
                                f"About <b>{hd.human(sum(e['bytes'] for e in sel))}</b> will be freed.") != QMessageBox.Yes:
            return
        self.cbtn.setEnabled(False)
        log = self.center.log
        log.show()
        home = Path.home()
        for e in sel:
            if e["key"] == "cache":
                n = sum(hd.clear_dir(p, home / ".cache") for p in hd.user_cache_paths())
                log.appendPlainText(f"Caches: freed {hd.human(n)}")
            elif e["key"] == "trash":
                n = sum(hd.clear_dir(p, home / ".local/share/Trash") for p in hd.trash_paths())
                try:
                    (home / ".local/share/Trash/directorysizes").unlink(missing_ok=True)
                except OSError:
                    pass
                log.appendPlainText(f"Trash emptied: {hd.human(n)}")
        keys = [e["key"] for e in sel if e["root"]]
        if "flatpak" in keys:  # the user's own Flatpak installation needs no password
            self.center.runner.run("flatpak", ["uninstall", "--user", "--unused", "-y", "--noninteractive"])
        if keys:
            self.center.runner.root(hd.CLEAN_HELPER, keys, lambda _code: self.refresh_all())
        else:
            self.refresh_all()


def build(center):
    return HealthPage(center)


if __name__ == "__main__":  # standalone test window
    from PySide6.QtWidgets import QApplication, QPlainTextEdit
    app = QApplication(sys.argv)

    class _Fake(QWidget):
        def __init__(self):
            super().__init__()
            lay = QVBoxLayout(self); self.log = QPlainTextEdit(); self.log.setMaximumHeight(150)
            main = sys.modules.get("center") or __import__("center")
            self.runner = main.Runner(self.log)
            lay.addWidget(build(self)); lay.addWidget(self.log)
    f = _Fake(); f.resize(1000, 760); f.show()
    sys.exit(app.exec())
