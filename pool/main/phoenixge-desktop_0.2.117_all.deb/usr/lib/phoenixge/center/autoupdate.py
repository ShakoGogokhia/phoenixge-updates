"""PhoenixGe Center > Auto updates: updates in the background, with full manual control.

Automatic (default): daily; security + PhoenixGe updates install by themselves, everything else is downloaded and you
get a notification; never on metered connections, on battery, or while a game runs (postponed, retried hourly).
Manual: what (system packages per kind, PhoenixGe, Flatpak apps, firmware), when (any time / time window / at shutdown),
conditions, download limit, restart notice, old kernel cleanup. Status: last/next run, what was updated, Update now,
Pause for 1 day / 1 week.

build(center) -> QWidget        root work: pkexec /bin/sh /usr/lib/phoenixge/autoupdate.sh set|pause|resume|run --now
python3 autoupdate.py [--demo]
"""
import json
import os
import sys
import time
from pathlib import Path

from PySide6.QtCore import QProcess
from PySide6.QtWidgets import (QButtonGroup, QCheckBox, QComboBox, QGridLayout, QHBoxLayout, QLabel, QPlainTextEdit,
                               QPushButton, QRadioButton, QSpinBox, QToolButton, QVBoxLayout, QWidget)

sys.path.insert(0, str(Path(__file__).resolve().parent))
from systools_ui import DEMO, GREEN, GREY, RED, YELLOW, dim, dot, facts, sh, ui  # noqa: E402

HELPER = "/usr/lib/phoenixge/autoupdate.sh"
STATUS = Path("/var/lib/phoenixge/autoupdate-status.json")
LOG = Path("/var/log/phoenixge-autoupdate.log")
USER_STATE = Path(os.environ.get("XDG_STATE_HOME") or Path.home() / ".local/state") / "phoenixge"
KINDS = [("SECURITY", "Security updates", "Fixes for security problems from Debian."),
         ("PHOENIXGE", "PhoenixGe updates", "Themes, tools and fixes from PhoenixGe."),
         ("SYSTEM", "Other system packages", "New versions of programs and libraries (Debian)."),
         ("FLATPAK", "Flatpak apps", "Apps from the Store / Flathub (yours and the shared ones).")]
CHOICES = [("install", "Install automatically"), ("download", "Download, then ask me"), ("off", "Off")]
DEFAULTS = dict(MODE="auto", FREQ="daily", SECURITY="install", PHOENIXGE="install", SYSTEM="download", FLATPAK="download",
                FIRMWARE="notify", WHEN="anytime", WIN_START="3", WIN_END="6", UNMETERED="1", AC="1", NOGAME="1",
                DL_LIMIT="0", REBOOT_NOTIFY="1", KERNEL_CLEANUP="1", PAUSED_UNTIL="0")


def load_config():
    if DEMO:
        return dict(DEFAULTS)
    cfg = dict(DEFAULTS)
    for line in sh(["sh", HELPER, "config"]).splitlines():
        if "=" in line:
            k, v = line.split("=", 1)
            cfg[k] = v
    return cfg


def load_status():
    if DEMO:
        now = int(time.time())
        return dict(time=now - 3 * 3600, result="ok", message="6 installed, 14 downloaded", trigger="timer", last_ok=now - 3 * 3600,
                    installed=["libssl3t64", "openssl", "libxml2", "firefox-esr", "phoenixge-desktop", "phoenixge-wallpaper-ember"],
                    downloaded=["mesa-vulkan-drivers", "libgl1-mesa-dri", "libegl-mesa0", "kwin-wayland", "plasma-workspace",
                                "linux-image-6.12.57+deb13-amd64", "linux-image-amd64", "firmware-misc-nonfree", "curl", "libcurl4t64",
                                "vlc", "vlc-bin", "vlc-plugin-base", "libvlc5"],
                    held=[], firmware=1, flatpak="download", reboot=True), \
            dict(time=now - 2 * 3600, result="ok", message="3 app update(s) downloaded")
    try:
        st = json.loads(STATUS.read_text())
    except (OSError, ValueError):
        st = {}
    try:
        ust = json.loads((USER_STATE / "autoupdate-user.json").read_text())
    except (OSError, ValueError):
        ust = {}
    return st, ust


def when_text(ts):
    if not ts:
        return "never"
    d = time.localtime(ts)
    today = time.localtime()
    day = "today" if d[:3] == today[:3] else "yesterday" if time.localtime(time.time() - 86400)[:3] == d[:3] else time.strftime("%a %d %b", d)
    return f"{day}, {time.strftime('%H:%M', d)}"


def next_run(cfg, st):
    now = time.time()
    paused = int(cfg.get("PAUSED_UNTIL", "0") or 0)
    iv = 6.5 * 86400 if cfg["FREQ"] == "weekly" else 20 * 3600
    t = max(now, (st.get("last_ok") or 0) + iv, paused)
    if cfg["WHEN"] == "window":
        s, e = int(cfg["WIN_START"]), int(cfg["WIN_END"])
        for _ in range(48):
            h = time.localtime(t).tm_hour
            inside = (s <= h < e) if s < e else (h >= s or h < e) if s > e else True
            if inside:
                break
            lt = time.localtime(t)
            t = time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, lt.tm_hour + 1, 0, 0, 0, 0, -1))
    if t <= now + 60:
        return "within the next hour"
    return "around " + when_text(t)


def names(lst, n=10):
    if not lst:
        return "-"
    return ", ".join(lst[:n]) + (f" and {len(lst) - n} more" if len(lst) > n else "")


class AutoUpdatePage(QWidget):
    def __init__(self, center):
        super().__init__()
        self.center = center
        Card, page, _F = ui(center)
        w, lay = page("Auto updates", "PhoenixGe keeps itself up to date in the background - security fixes arrive within a "
                                      "day, and nothing big happens while you play, travel on battery or use a phone hotspot.")
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0); outer.addWidget(w)
        self.status = Card(); lay.addWidget(self.status)

        # ---- mode
        mode = Card("How updates are installed")
        self.mode = QButtonGroup(self)
        for i, (title, text) in enumerate((
                ("Automatic (recommended)", "Daily. Security and PhoenixGe updates install by themselves; everything else is "
                                            "downloaded and you get a notification. Only on normal (not metered) networks, on "
                                            "AC power, never during a game. A restore point is saved before each update."),
                ("Manual - I choose", "Pick what is installed, when, and under which conditions below."))):
            rb = QRadioButton(title); rb.setStyleSheet("font-weight:600;")
            self.mode.addButton(rb, i); mode.lay.addWidget(rb)
            d = dim(text); d.setContentsMargins(26, 0, 0, 6); mode.lay.addWidget(d)
        self.mode.idToggled.connect(lambda _i, _on: self.changed())
        lay.addWidget(mode)

        # ---- manual settings
        self.manual = Card("Manual settings")
        g = QGridLayout(); g.setHorizontalSpacing(14); g.setVerticalSpacing(8)
        self.kind = {}
        for r, (key, title, tip) in enumerate(KINDS):
            t = QLabel(title); t.setToolTip(tip); g.addWidget(t, r, 0)
            cb = QComboBox()
            for val, text in CHOICES:
                cb.addItem(text, val)
            cb.currentIndexChanged.connect(self.changed)
            g.addWidget(cb, r, 1); g.addWidget(dim(tip), r, 2)
            self.kind[key] = cb
        r = len(KINDS)
        g.addWidget(QLabel("Firmware (BIOS, SSD, …)"), r, 0)
        self.fw = QComboBox(); self.fw.addItem("Tell me when there is an update", "notify"); self.fw.addItem("Off", "off")
        self.fw.currentIndexChanged.connect(self.changed)
        g.addWidget(self.fw, r, 1); g.addWidget(dim("Never flashed automatically - install it in Discover."), r, 2)
        g.setColumnStretch(2, 1)
        self.manual.lay.addLayout(g)

        self.manual.lay.addWidget(self.section("When"))
        row = QHBoxLayout()
        row.addWidget(QLabel("Check"))
        self.freq = QComboBox(); self.freq.addItem("Daily", "daily"); self.freq.addItem("Weekly", "weekly")
        row.addWidget(self.freq)
        row.addWidget(QLabel("and install"))
        self.when = QComboBox()
        for val, text in (("anytime", "any time of day"), ("window", "only between"), ("shutdown", "when I shut down")):
            self.when.addItem(text, val)
        row.addWidget(self.when)
        self.ws, self.we = QComboBox(), QComboBox()
        for h in range(24):
            self.ws.addItem(f"{h:02d}:00", str(h)); self.we.addItem(f"{h:02d}:00", str(h))
        self.and_lbl = QLabel("and")
        for x in (self.ws, self.and_lbl, self.we):
            row.addWidget(x)
        row.addStretch()
        for c in (self.freq, self.when, self.ws, self.we):
            c.currentIndexChanged.connect(self.changed)
        self.manual.lay.addLayout(row)
        self.when_note = dim("")
        self.manual.lay.addWidget(self.when_note)

        self.manual.lay.addWidget(self.section("Only when"))
        self.cond = {}
        for key, text in (("UNMETERED", "the network isn't metered (phone hotspot, mobile data)"),
                          ("AC", "the computer is plugged in"), ("NOGAME", "no game is running (postponed, retried every hour)")):
            c = QCheckBox(text); c.toggled.connect(self.changed); self.manual.lay.addWidget(c); self.cond[key] = c

        self.manual.lay.addWidget(self.section("More"))
        row = QHBoxLayout()
        self.limit_on = QCheckBox("Limit download speed to"); self.limit = QSpinBox()
        self.limit.setRange(50, 1_000_000); self.limit.setSingleStep(250); self.limit.setSuffix(" KB/s"); self.limit.setValue(2000)
        self.limit_on.toggled.connect(self.changed); self.limit.valueChanged.connect(self.changed)
        row.addWidget(self.limit_on); row.addWidget(self.limit)
        row.addWidget(dim("system packages only - Flatpak has no speed limit")); row.addStretch()
        self.manual.lay.addLayout(row)
        self.reboot_cb = QCheckBox("Tell me when a restart is needed (new kernel, drivers, system libraries)")
        self.kernel_cb = QCheckBox("Remove old kernels (keeps the running one and the newest - frees ~300 MB each)")
        for c in (self.reboot_cb, self.kernel_cb):
            c.toggled.connect(self.changed); self.manual.lay.addWidget(c)
        lay.addWidget(self.manual)

        save_row = QHBoxLayout()
        self.save_btn = QPushButton("Save settings"); self.save_btn.setObjectName("primary"); self.save_btn.clicked.connect(self.save)
        self.revert_btn = QPushButton("Undo changes"); self.revert_btn.clicked.connect(self.refresh)
        self.save_note = dim("")
        save_row.addWidget(self.save_btn); save_row.addWidget(self.revert_btn); save_row.addWidget(self.save_note, 1)
        lay.addLayout(save_row)

        # ---- log
        logc = Card("History")
        self.logbox = QPlainTextEdit(); self.logbox.setReadOnly(True); self.logbox.setMinimumHeight(160)
        self.logbox.setStyleSheet("font-family: monospace; font-size: 11px;")
        logc.lay.addWidget(self.logbox)
        lay.addWidget(logc)
        lay.addStretch()
        self.cfg, self.loading, self.shown_once = dict(DEFAULTS), False, False

    @staticmethod
    def section(text):
        x = QLabel(text); x.setStyleSheet("font-weight:600; margin-top:8px;")
        return x

    def showEvent(self, e):
        super().showEvent(e)
        if not self.shown_once:
            self.shown_once = True
            self.refresh()

    # ------------------------------------------------------------ state -> widgets
    def refresh(self, *_):
        self.loading = True
        self.cfg = c = load_config()
        st, ust = load_status()
        self.mode.button(0 if c["MODE"] == "auto" else 1).setChecked(True)
        for key, cb in self.kind.items():
            cb.setCurrentIndex(max(0, cb.findData(c[key])))
        self.fw.setCurrentIndex(max(0, self.fw.findData(c["FIRMWARE"])))
        self.freq.setCurrentIndex(max(0, self.freq.findData(c["FREQ"])))
        self.when.setCurrentIndex(max(0, self.when.findData(c["WHEN"])))
        self.ws.setCurrentIndex(int(c["WIN_START"])); self.we.setCurrentIndex(int(c["WIN_END"]))
        for key, cb in self.cond.items():
            cb.setChecked(c[key] == "1")
        lim = int(c["DL_LIMIT"] or 0)
        self.limit_on.setChecked(lim > 0)
        if lim:
            self.limit.setValue(lim)
        self.reboot_cb.setChecked(c["REBOOT_NOTIFY"] == "1"); self.kernel_cb.setChecked(c["KERNEL_CLEANUP"] == "1")
        self.loading = False
        self.sync_enabled()
        self.save_btn.setEnabled(False); self.revert_btn.setEnabled(False); self.save_note.setText("")
        self.fill_status(c, st, ust)
        self.fill_log()

    def sync_enabled(self):
        manual = self.mode.checkedId() == 1
        self.manual.setEnabled(manual)
        win = self.when.currentData() == "window"
        for x in (self.ws, self.and_lbl, self.we):
            x.setVisible(win)
        self.limit.setEnabled(self.limit_on.isChecked())
        notes = {"anytime": "Updates install as soon as they are due (within an hour of the check).",
                 "window": "Updates wait for this time window. The computer must be on (or asleep) then.",
                 "shutdown": "Downloaded during the day, installed when you shut down or restart (that takes a little "
                             "longer then). Your own Flatpak apps update at the next login."}
        self.when_note.setText(notes[self.when.currentData() or "anytime"])

    def changed(self, *_):
        if self.loading:
            return
        self.sync_enabled()
        self.save_btn.setEnabled(True); self.revert_btn.setEnabled(True)
        self.save_note.setText("Not saved yet.")

    def fill_status(self, c, st, ust):
        lay = self.status.lay
        _clear(lay)
        now = time.time()
        paused = int(c.get("PAUSED_UNTIL", "0") or 0) > now
        timer_on = DEMO or sh(["systemctl", "is-enabled", "phoenixge-autoupdate.timer"]) in ("enabled", "static")
        live = Path("/run/live").exists() and not DEMO
        res = st.get("result", "")
        if live:
            col, head = GREY, "Auto updates start after PhoenixGe is installed (this is the live session)"
        elif not timer_on:
            col, head = RED, "Auto updates are switched off (the update timer is disabled)"
        elif paused:
            col, head = YELLOW, "Paused until " + when_text(int(c["PAUSED_UNTIL"]))
        elif res in ("failed", "partial"):
            col, head = RED, "The last update run had problems"
        elif res == "postponed":
            col, head = YELLOW, st.get("message", "Postponed")
        else:
            col, head = GREEN, ("Automatic updates are on" if c["MODE"] == "auto" else "Updates follow your manual settings")
        top = QHBoxLayout(); top.addWidget(dot(col, 18))
        t = QLabel(head); t.setStyleSheet("font-size:16px;font-weight:600;"); t.setWordWrap(True); top.addWidget(t, 1)
        lay.addLayout(top)
        rows = [("Last check", f"{when_text(st.get('time'))} - {st.get('message', 'no run yet')}" if st else "no run yet")]
        if not paused and timer_on:
            rows.append(("Next check", next_run(c, st)))
        rows.append(("Installed", names(st.get("installed", []))))
        if st.get("downloaded"):
            rows.append(("Ready to install", names(st.get("downloaded", []))))
        if st.get("held"):
            rows.append(("Needs your OK", names(st["held"]) + " (would remove packages)"))
        if st.get("firmware"):
            rows.append(("Firmware", f"updates for {st['firmware']} device(s) - install them in Discover > Updates"))
        if ust:
            rows.append(("Your Flatpak apps", f"{when_text(ust.get('time'))} - {ust.get('message', '')}"))
        lay.addWidget(facts(rows))
        reboot = st.get("reboot") or Path("/run/reboot-required").exists()
        if reboot:
            rr = QHBoxLayout(); rr.addWidget(dot(YELLOW, 12))
            rr.addWidget(QLabel("Restart to finish: a new kernel, driver or system library was installed."), 1)
            rb = QPushButton("Restart now"); rb.clicked.connect(_restart); rr.addWidget(rb)
            lay.addLayout(rr)
        row = QHBoxLayout()
        up = QPushButton("Update now"); up.setObjectName("primary"); up.clicked.connect(self.update_now)
        up.setToolTip("Installs every update that isn't switched off - ignores the time window and the conditions.")
        row.addWidget(up)
        if not timer_on and not live:
            on = QPushButton("Turn auto updates on"); on.clicked.connect(self.enable_timer); row.addWidget(on)
        if paused:
            r = QPushButton("Resume"); r.clicked.connect(lambda: self.root(["resume"])); row.addWidget(r)
        else:
            for text, sec in (("Pause for 1 day", 86400), ("Pause for 1 week", 7 * 86400)):
                b = QPushButton(text); b.clicked.connect(lambda _=False, s=sec: self.root(["pause", str(s)])); row.addWidget(b)
        disc = QToolButton(); disc.setText("Open Discover"); disc.setAutoRaise(True)
        disc.clicked.connect(lambda: QProcess.startDetached("plasma-discover", ["--mode", "update"]))
        row.addStretch(); row.addWidget(disc)
        lay.addLayout(row)
        for b in (up,):
            b.setEnabled(not live)

    def fill_log(self):
        if DEMO:
            text = ("2026-11-13 03:12:40 === update run (timer, mode auto)\n"
                    "2026-11-13 03:13:02 security: installing 3 update(s): libssl3t64 openssl libxml2\n"
                    "2026-11-13 03:13:55 phoenixge: installing 2 update(s): phoenixge-desktop phoenixge-wallpaper-ember\n"
                    "2026-11-13 03:14:10 system: downloading 14 update(s): mesa-vulkan-drivers libgl1-mesa-dri …\n"
                    "2026-11-13 03:16:31 firmware: updates for 1 device(s) available (not installed automatically)\n"
                    "2026-11-13 03:16:32 === done: 6 installed, 14 downloaded\n"
                    "2026-11-13 14:05:00 postponed: a game is running\n")
        else:
            try:
                lines = LOG.read_text(errors="replace").splitlines()
            except OSError:
                lines = []
            # the short lines only (apt output is in the log too)
            short = [l for l in lines if len(l) > 20 and l[4] == "-" and l[19] == " "]
            text = "\n".join(short[-60:]) or "No update runs yet."
        self.logbox.setPlainText(text)
        self.logbox.verticalScrollBar().setValue(self.logbox.verticalScrollBar().maximum())

    # ------------------------------------------------------------ actions
    def values(self):
        v = {"MODE": "auto" if self.mode.checkedId() == 0 else "manual"}
        if v["MODE"] == "manual":
            for key, cb in self.kind.items():
                v[key] = cb.currentData()
            v.update(FIRMWARE=self.fw.currentData(), FREQ=self.freq.currentData(), WHEN=self.when.currentData(),
                     WIN_START=self.ws.currentData(), WIN_END=self.we.currentData(),
                     DL_LIMIT=str(self.limit.value() if self.limit_on.isChecked() else 0),
                     REBOOT_NOTIFY="1" if self.reboot_cb.isChecked() else "0", KERNEL_CLEANUP="1" if self.kernel_cb.isChecked() else "0")
            for key, cb in self.cond.items():
                v[key] = "1" if cb.isChecked() else "0"
        return v

    def save(self):
        v = self.values()
        if v["MODE"] == "manual" and v.get("SECURITY") == "off":
            from PySide6.QtWidgets import QMessageBox
            if QMessageBox.warning(self, "Security updates off", "Without security updates, known holes in the browser, "
                                   "network and system stay open. Turn them off anyway?",
                                   QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
                return
        self.root(["set", *(f"{k}={val}" for k, val in v.items())])

    def root(self, args, done=None):
        if DEMO:
            return
        self.save_note.setText("Asking for your password …")
        self.center.runner.root(HELPER, args, done or (lambda _code: self.refresh()))

    def update_now(self):
        if DEMO:
            return

        def user_part(_code):
            # your own Flatpak apps (no password), then show the result
            self.center.runner.run("/bin/sh", [HELPER, "user-flatpak", "--now"], lambda _c: self.refresh())
        self.center.runner.root(HELPER, ["run", "--now"], user_part)

    def enable_timer(self):
        self.center.runner.run("pkexec", ["systemctl", "enable", "--now", "phoenixge-autoupdate.timer",
                                          "phoenixge-autoupdate-shutdown.service"], lambda _c: self.refresh())


def _restart():
    sh("qdbus6 org.kde.LogoutPrompt /LogoutPrompt promptReboot 2>/dev/null || systemctl reboot")


def _clear(layout):
    while layout.count():
        it = layout.takeAt(0)
        if it.widget():
            it.widget().deleteLater()
        elif it.layout():
            _clear(it.layout())


def build(center):
    return AutoUpdatePage(center)


if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication
    app = QApplication(sys.argv)

    class _Host(QWidget):
        def __init__(self):
            super().__init__()
            lay = QVBoxLayout(self); self.log = QPlainTextEdit(); self.log.setMaximumHeight(120); self.log.hide()
            import center as cmod
            self.runner = cmod.Runner(self.log)
            lay.addWidget(build(self)); lay.addWidget(self.log)
    h = _Host(); h.resize(1000, 760); h.show()
    sys.exit(app.exec())
