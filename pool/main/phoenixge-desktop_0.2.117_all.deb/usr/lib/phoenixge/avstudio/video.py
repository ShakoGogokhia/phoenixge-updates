#!/usr/bin/env python3
"""PhoenixGe Sound & camera - video part (phone as webcam/mic, webcam background blur).

Virtual cameras: v4l2loopback (installed on demand by avstudio-root.sh camera-driver) with two devices:
    /dev/video40  "PhoenixGe Camera"        - output of the background blur (OBS virtual camera)
    /dev/video41  "PhoenixGe Phone Camera"  - Android phone camera via scrcpy
Phone:   scrcpy (Debian trixie-backports, contrib) + adb. Camera -> --v4l2-sink, phone mic -> SDL/pulse playback into
         a pw-loopback pair whose source side is the microphone "PhoenixGe Phone Mic". Needs Android 12+ (camera)
         and USB debugging; Wi-Fi via "adb pair" (Android 11+) or adb tcpip.
Blur:    OBS Studio (Flathub) + the Background Removal plugin (Flathub extension). We write our own OBS profile and
         scene collection "PhoenixGe Camera" (webcam + background-removal filter in blur mode) and start OBS minimized
         with --startvirtualcam, so apps see "PhoenixGe Camera". Strength = the plugin's blur_background (1-20).
Long-running parts run as transient user units (systemd-run), so they survive closing the Center.

    video.py status                       JSON
    video.py phone start|stop             (settings from ~/.config/phoenixge/avstudio.json "camera")
    video.py phone pair HOST:PORT CODE | connect HOST:PORT | wireless
    video.py blur start|stop|apply        apply = restart OBS with the new settings if it is running
"""
import configparser
import json
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import audio  # noqa: E402  (state file + run helper)

DEMO = audio.DEMO
HOME = Path.home()
CAM_NR, PHONE_NR = 40, 41
CAM_LABEL, PHONE_LABEL = "PhoenixGe Camera", "PhoenixGe Phone Camera"
PHONE_UNIT, PHONE_MIC_UNIT, BLUR_UNIT = "phoenixge-phonecam", "phoenixge-phonemic", "phoenixge-blurcam"
OBS = "com.obsproject.Studio"
OBS_PLUGIN = "com.obsproject.Studio.Plugin.BackgroundRemoval"
OBS_CFG = HOME / ".var/app" / OBS / "config/obs-studio"
COLLECTION = "PhoenixGe Camera"
ROOT_HELPER = "/usr/lib/phoenixge/avstudio/avstudio-root.sh"
CAM_DEFAULTS = {"device": "", "blur": True, "strength": 10, "facing": "front", "quality": "720", "phone_mic": True,
                "conn": "usb", "addr": "", "serial": ""}


def cam_state(st=None):
    st = st or audio.load()
    c = dict(CAM_DEFAULTS); c.update(st.get("camera") or {})
    st["camera"] = c
    return st, c


# ------------------------------------------------------------------ devices
def v4l_devices():
    """[{dev, name, loopback}] for capture video nodes (metadata nodes skipped)."""
    if DEMO:
        return [dict(dev="/dev/video0", name="Integrated Camera", loopback=False),
                dict(dev="/dev/video2", name="Logitech BRIO", loopback=False),
                dict(dev=f"/dev/video{CAM_NR}", name=CAM_LABEL, loopback=True),
                dict(dev=f"/dev/video{PHONE_NR}", name=PHONE_LABEL, loopback=True)]
    out = []
    for d in sorted(Path("/sys/class/video4linux").glob("video*"), key=lambda p: int(re.sub(r"\D", "", p.name) or 0)):
        try:
            name = (d / "name").read_text().strip()
            index = (d / "index").read_text().strip() if (d / "index").exists() else "0"
        except Exception:
            continue
        real = os.path.realpath(d / "device") if (d / "device").exists() else ""
        loop = name in (CAM_LABEL, PHONE_LABEL) or "virtual" in real or not real
        if index != "0" and not loop:
            continue
        out.append(dict(dev="/dev/" + d.name, name=name, loopback=loop))
    return out


def webcams():
    """Real cameras + the phone camera (so the blur can use the phone too). Excludes the blur output itself."""
    return [d for d in v4l_devices() if not d["loopback"] or d["name"] == PHONE_LABEL]


def driver_ready():
    if DEMO:
        return True
    return Path(f"/dev/video{CAM_NR}").exists() and Path(f"/dev/video{PHONE_NR}").exists()


def driver_installed():
    return DEMO or bool(audio.run(["modinfo", "v4l2loopback"], 5)[0] == 0)


def unit_active(unit):
    if DEMO:
        return unit == BLUR_UNIT
    return audio.run(["systemctl", "--user", "is-active", unit + ".service"])[1].strip() == "active"


def stop_unit(unit):
    audio.run(["systemctl", "--user", "stop", unit + ".service"], 30)
    audio.run(["systemctl", "--user", "reset-failed", unit + ".service"], 5)


def transient(unit, cmd, env=None):
    stop_unit(unit)
    args = ["systemd-run", "--user", "--collect", "--quiet", f"--unit={unit}", "--property=KillSignal=SIGINT"]
    for k, v in (env or {}).items():
        args.append(f"--setenv={k}={v}")
    code, out = audio.run(args + cmd, 20)
    return code == 0, out


# ------------------------------------------------------------------ phone (Android, scrcpy)
def phone_tools():
    return {"scrcpy": bool(shutil.which("scrcpy")) or DEMO, "adb": bool(shutil.which("adb")) or DEMO}


def phones():
    """[(serial, description)] from adb devices -l (only 'device' state; 'unauthorized' is reported separately)."""
    if DEMO:
        return [("R5CT21ABCDE", "Samsung SM-S911B (USB)")], []
    if not shutil.which("adb"):
        return [], []
    code, out = audio.run(["adb", "devices", "-l"], 10)
    ok, unauth = [], []
    for line in out.splitlines()[1:]:
        parts = line.split()
        if len(parts) < 2:
            continue
        serial, state = parts[0], parts[1]
        model = next((p.split(":", 1)[1].replace("_", " ") for p in parts if p.startswith("model:")), serial)
        how = "Wi-Fi" if ":" in serial or "._adb-tls-connect" in serial else "USB"
        (ok if state == "device" else unauth).append((serial, f"{model} ({how})" if state == "device" else f"{serial} ({state})"))
    return ok, unauth


def phone_start():
    st, c = cam_state()
    if not shutil.which("scrcpy"):
        print("scrcpy is not installed - press \"Set up\" first."); return 1
    if not Path(f"/dev/video{PHONE_NR}").exists():
        print("The virtual camera driver is not loaded - press \"Set up\" first."); return 1
    ok, unauth = phones()
    if not ok:
        print("No phone found." + (" Unlock the phone and allow USB debugging (tick \"Always allow\")." if unauth else
                                   " Connect it with USB (USB debugging on) or pair it over Wi-Fi."))
        return 1
    serial = c.get("serial") if c.get("serial") in [s for s, _ in ok] else ok[0][0]
    size = "1920" if c.get("quality") == "1080" else "1280"
    cmd = ["scrcpy", "-s", serial, "--video-source=camera", f"--camera-facing={c.get('facing', 'front')}",
           f"--max-size={size}", "--camera-fps=30", f"--v4l2-sink=/dev/video{PHONE_NR}", "--no-window"]
    env = {}
    if c.get("phone_mic"):
        transient(PHONE_MIC_UNIT, [
            "pw-loopback", "--name=phoenixge-phone-mic", "--channels=1", "--channel-map=[ MONO ]",
            "--capture-props=media.class=Audio/Sink node.name=phoenixge_phone_mic_in "
            "node.description=\"PhoenixGe Phone Mic (input)\"",
            "--playback-props=media.class=Audio/Source node.name=phoenixge_phone_mic "
            "node.description=\"PhoenixGe Phone Mic\""])
        audio.wait_node("phoenixge_phone_mic_in", 5)
        cmd += ["--audio-source=mic", "--audio-buffer=40"]
        env = {"SDL_AUDIODRIVER": "pulseaudio", "PULSE_SINK": "phoenixge_phone_mic_in"}
    else:
        cmd += ["--no-audio"]
        stop_unit(PHONE_MIC_UNIT)
    started, out = transient(PHONE_UNIT, cmd, env)
    if not started:
        print("Could not start scrcpy: " + out.strip()); return 1
    time.sleep(3)
    if not unit_active(PHONE_UNIT):
        print("scrcpy stopped right away. Phone camera needs Android 12 or newer; the phone mic needs Android 11+.")
        print(audio.run(["journalctl", "--user", "-u", PHONE_UNIT, "-n", "15", "--no-pager", "-o", "cat"], 10)[1])
        stop_unit(PHONE_MIC_UNIT)
        return 1
    print(f"Phone camera is on: pick \"{PHONE_LABEL}\" as the camera in Discord, Zoom, OBS or the browser."
          + (" Phone microphone: \"PhoenixGe Phone Mic\"." if c.get("phone_mic") else ""))
    return 0


def phone_stop():
    stop_unit(PHONE_UNIT); stop_unit(PHONE_MIC_UNIT)
    print("Phone camera stopped.")
    return 0


def adb(*args, timeout=20):
    code, out = audio.run(["adb", *args], timeout)
    print(out.strip())
    return code


def phone_wireless():
    """Phone connected with USB now -> switch adb to Wi-Fi (port 5555) and connect; the cable can go afterwards."""
    ok, _ = phones()
    usb = [s for s, d in ok if "(USB)" in d]
    if not usb:
        print("Connect the phone with USB first (USB debugging on), then press this again."); return 1
    serial = usb[0]
    _c, out = audio.run(["adb", "-s", serial, "shell", "ip", "-f", "inet", "addr", "show", "wlan0"], 10)
    m = re.search(r"inet (\d+\.\d+\.\d+\.\d+)", out)
    if not m:
        print("The phone is not on Wi-Fi - connect it to the same network as this PC."); return 1
    adb("-s", serial, "tcpip", "5555")
    time.sleep(2)
    code = adb("connect", f"{m.group(1)}:5555")
    st, c = cam_state(); c["addr"] = f"{m.group(1)}:5555"; c["conn"] = "wifi"; audio.save(st)
    print("You can unplug the cable now." if code == 0 else "")
    return code


# ------------------------------------------------------------------ background blur (OBS)
def obs_status():
    if DEMO:
        return {"obs": True, "plugin": True}
    if not shutil.which("flatpak"):
        return {"obs": False, "plugin": False}
    code, out = audio.run(["flatpak", "list", "--columns=application"], 20)
    ids = set(out.split())
    return {"obs": OBS in ids, "plugin": OBS_PLUGIN in ids}


def fourcc(s):
    return sum(ord(ch) << (8 * i) for i, ch in enumerate(s))


def camera_format(dev):
    """MJPG 1280x720 when the camera offers it (YUYV at full size is often only 5-10 fps)."""
    if not shutil.which("v4l2-ctl"):
        return {}
    code, out = audio.run(["v4l2-ctl", "-d", dev, "--list-formats-ext"], 6)
    sect = re.split(r"\[\d+\]: ", out)
    for s in sect:
        if s.startswith("'MJPG'") and "1280x720" in s:
            return {"pixelformat": fourcc("MJPG"), "resolution": (1280 << 16) | 720}
    return {}


def ini_set(path, values):
    """Merge {section: {key: value}} into an OBS ini file (keeps everything else)."""
    cp = configparser.RawConfigParser(strict=False)
    cp.optionxform = str
    try:
        cp.read(path, encoding="utf-8-sig")
    except Exception:
        pass
    for sec, kv in values.items():
        if not cp.has_section(sec):
            cp.add_section(sec)
        for k, v in kv.items():
            cp.set(sec, k, str(v))
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        cp.write(f, space_around_delimiters=False)


def write_obs(c):
    dev = c.get("device") or next((d["dev"] for d in webcams() if d["name"] != PHONE_LABEL), "") or \
        next((d["dev"] for d in webcams()), "")
    if not dev:
        return ""
    src_uuid, scene_uuid = str(uuid.uuid5(uuid.NAMESPACE_URL, "phoenixge-cam")), str(uuid.uuid5(uuid.NAMESPACE_URL, "phoenixge-scene"))
    settings = {"device_id": dev, "auto_reset": True}
    settings.update(camera_format(dev))
    strength = max(1, min(20, int(c.get("strength", 10))))
    filt = {"id": "background_removal", "versioned_id": "background_removal", "name": "PhoenixGe background blur",
            "enabled": bool(c.get("blur", True)),
            "settings": {"blur_background": strength, "model_select": "models/mediapipe.onnx", "useGPU": "cpu",
                         "enable_threshold": True, "threshold": 0.5, "numThreads": 2, "smooth_contour": 0.5,
                         "enable_image_similarity": True}}
    coll = {
        "name": COLLECTION, "current_scene": "Camera", "current_program_scene": "Camera",
        "scene_order": [{"name": "Camera"}], "groups": [], "transition_duration": 300, "current_transition": "Fade",
        "sources": [
            {"id": "v4l2_input", "versioned_id": "v4l2_input", "name": "Webcam", "uuid": src_uuid, "enabled": True,
             "settings": settings, "filters": [filt], "mixers": 0, "volume": 1.0, "muted": True},
            {"id": "scene", "versioned_id": "scene", "name": "Camera", "uuid": scene_uuid, "enabled": True,
             "settings": {"id_counter": 1, "custom_size": False, "items": [
                 {"name": "Webcam", "source_uuid": src_uuid, "visible": True, "locked": True, "id": 1, "align": 5,
                  "pos": {"x": 0.0, "y": 0.0}, "scale": {"x": 1.0, "y": 1.0}, "rot": 0.0,
                  "bounds_type": 2, "bounds_align": 0, "bounds": {"x": 1280.0, "y": 720.0}}]}},
        ],
    }
    scenes = OBS_CFG / "basic/scenes"
    scenes.mkdir(parents=True, exist_ok=True)
    (scenes / "PhoenixGe_Camera.json").write_text(json.dumps(coll, indent=1))
    ini_set(OBS_CFG / "basic/profiles/PhoenixGe_Camera/basic.ini", {
        "General": {"Name": COLLECTION},
        "Video": {"BaseCX": 1280, "BaseCY": 720, "OutputCX": 1280, "OutputCY": 720, "FPSType": 0, "FPSCommon": 30},
        "Output": {"Mode": "Simple"}})
    first = {"General": {"FirstRun": "true"}, "BasicWindow": {"SysTrayEnabled": "true", "SysTrayWhenStarted": "true"}}
    for name in ("global.ini", "user.ini"):  # OBS 30 reads global.ini, OBS 31+ user.ini
        ini_set(OBS_CFG / name, first)
    return dev


def blur_start():
    st, c = cam_state()
    s = obs_status()
    if not (s["obs"] and s["plugin"]):
        print("OBS Studio and its Background Removal plugin are not installed - press \"Install\" first."); return 1
    if not Path(f"/dev/video{CAM_NR}").exists():
        print("The virtual camera driver is not loaded - press \"Set up\" first."); return 1
    stop_unit(BLUR_UNIT)
    dev = write_obs(c)
    if not dev:
        print("No webcam found."); return 1
    ok, out = transient(BLUR_UNIT, ["flatpak", "run", OBS, "--collection", COLLECTION, "--profile", COLLECTION,
                                    "--scene", "Camera", "--startvirtualcam", "--minimize-to-tray",
                                    "--disable-shutdown-check"])
    if not ok:
        print("Could not start OBS: " + out.strip()); return 1
    print(f"PhoenixGe Camera is starting (webcam {dev}, blur {'on' if c.get('blur') else 'off'}). "
          f"Pick \"{CAM_LABEL}\" in Discord, Zoom or the browser. OBS runs in the tray.")
    return 0


def blur_stop():
    stop_unit(BLUR_UNIT)
    print("PhoenixGe Camera stopped.")
    return 0


def status():
    st, c = cam_state()
    ok, unauth = phones()
    return {"camera": c, "driver_installed": driver_installed(), "driver_ready": driver_ready(), "phone_tools": phone_tools(),
            "phones": ok, "phones_unauthorized": unauth, "phone_active": unit_active(PHONE_UNIT),
            "obs": obs_status(), "blur_active": unit_active(BLUR_UNIT), "webcams": webcams()}


def main(argv):
    a = [x for x in argv if x != "--demo"]
    if not a or a[0] == "status":
        print(json.dumps(status(), indent=1)); return 0
    if a[0] == "phone" and len(a) > 1:
        if a[1] == "start":
            return phone_start()
        if a[1] == "stop":
            return phone_stop()
        if a[1] == "pair" and len(a) > 3:
            return adb("pair", a[2], a[3])
        if a[1] == "connect" and len(a) > 2:
            return adb("connect", a[2])
        if a[1] == "wireless":
            return phone_wireless()
    if a[0] == "blur" and len(a) > 1:
        if a[1] == "start":
            return blur_start()
        if a[1] == "stop":
            return blur_stop()
        if a[1] == "apply":
            return blur_start() if unit_active(BLUR_UNIT) else 0
    print(__doc__); return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
