#!/usr/bin/env python3
"""PhoenixGe Sound & camera - audio part (Clean Mic + PhoenixGe Sound). Used by Center > Sound & camera.

Clean Mic   = PipeWire echo-cancel module with the WebRTC audio processor (noise suppression, echo removal,
              high-pass, optional auto gain; ships with PipeWire, nothing extra) -> optional noise gate
              (swh-plugins LADSPA "gate", its threshold is the Strength slider) -> virtual source
              "PhoenixGe Clean Mic", made the default microphone. Off -> previous default comes back.
Sound       = PipeWire filter-chain sink "PhoenixGe Sound": 10-band EQ (builtin biquads) and, optional, 3D sound for
              headphones (7.1 sink, every channel through the "sofa" spatializer with the MIT KEMAR HRTF that
              libmysofa1 ships). It is a WirePlumber *smart filter*: it sits in front of whatever the default
              output is (speakers, USB or Bluetooth headphones) and follows it - the default device never changes.

Each runs as its own small `pipewire -c <conf>` user service (like PipeWire's filter-chain.service), so turning
one on or off never restarts the sound server. Slider changes are applied live with `pw-cli set-param`.

    audio.py status                     JSON state + what is running
    audio.py mic on|off|apply|live      apply = rewrite config + restart if running; live = push the slider values
    audio.py sound on|off|apply|live
    audio.py mic-test [seconds]         record from the microphone in use, then play it back
    audio.py regen                      (service ExecStartPre) re-resolve the automatic microphone, rewrite configs
"""
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

HOME = Path.home()
CFG = HOME / ".config/phoenixge"
STATE = CFG / "avstudio.json"
CONF_DIR = CFG / "avstudio"
UNIT_DIR = HOME / ".config/systemd/user"
SELF = str(Path(__file__).resolve())
DEMO = "--demo" in sys.argv or bool(os.environ.get("PHOENIXGE_DEMO"))

MIC_UNIT, SOUND_UNIT = "phoenixge-cleanmic.service", "phoenixge-sound.service"
MIC_NODE, MIC_STAGE1, MIC_GATE_IN = "phoenixge_clean_mic", "phoenixge_mic_stage1", "phoenixge_clean_mic_in"
SOUND_NODE, SOUND_OUT = "phoenixge_sound", "phoenixge_sound_out"
OURS = ("phoenixge_", "effect_", "echo-cancel")
GATE_SO = "/usr/lib/ladspa/gate_1410.so"
SOFA = "/usr/share/libmysofa/default.sofa"

BANDS = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000]
PRESETS = {  # dB per band - moderate curves, the automatic preamp keeps them from clipping
    "flat": ("Flat", [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
    "fps": ("FPS games (footsteps)", [-4, -3, -2, -1, 0, 1, 3, 4, 2, 0]),
    "music": ("Music", [3, 2, 1, 0, -1, 0, 1, 2, 3, 3]),
    "movie": ("Movie", [3, 2, 0, 0, 1, 2, 2, 1, 1, 0]),
    "bass": ("Bass boost", [6, 5, 4, 2, 0, 0, 0, 0, 0, 0]),
    "voice": ("Voice", [-4, -3, -1, 1, 3, 4, 3, 1, -1, -2]),
}
# 7.1 speaker positions for the spatializer (SOFA azimuth: counter-clockwise from the front, left = +90)
SPEAKERS = [("FL", 30, 0.7), ("FR", 330, 0.7), ("FC", 0, 0.6), ("LFE", None, 0.5),
            ("RL", 150, 0.5), ("RR", 210, 0.5), ("SL", 90, 0.55), ("SR", 270, 0.55)]

DEFAULTS = {
    "mic": {"enabled": False, "device": "", "strength": 50, "agc": False, "prev_default": "", "target": ""},
    "sound": {"enabled": False, "preset": "flat", "bands": [0] * 10, "auto_preamp": True, "preamp": 0.0,
              "surround": False},
}


# ------------------------------------------------------------------ state
def load():
    st = json.loads(json.dumps(DEFAULTS))
    try:
        data = json.loads(STATE.read_text())
        for k in st:
            if isinstance(data.get(k), dict):
                st[k].update(data[k])
        for k, v in data.items():  # keep other sections (camera, ...)
            st.setdefault(k, v)
    except Exception:
        pass
    b = st["sound"].get("bands") or []
    st["sound"]["bands"] = [float(x) for x in (list(b) + [0] * 10)[:10]]
    return st


def save(st):
    CFG.mkdir(parents=True, exist_ok=True)
    tmp = STATE.with_suffix(".tmp")
    tmp.write_text(json.dumps(st, indent=1))
    tmp.replace(STATE)


def run(cmd, timeout=8):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout
    except Exception as e:
        return 1, str(e)


# ------------------------------------------------------------------ PipeWire graph
def nodes():
    """[{id, name, desc, cls, props}] from pw-dump (works without pipewire-pulse)."""
    if DEMO:
        return [dict(id=40, name="alsa_input.pci-0000_00_1f.3.analog-stereo", desc="Built-in Audio Analog Stereo",
                     cls="Audio/Source", props={}),
                dict(id=41, name="alsa_input.usb-HyperX_QuadCast_S-00.analog-stereo", desc="HyperX QuadCast S",
                     cls="Audio/Source", props={}),
                dict(id=50, name="alsa_output.pci-0000_00_1f.3.analog-stereo", desc="Built-in Audio Headphones",
                     cls="Audio/Sink", props={"device.profile.description": "Headphones"})]
    code, out = run(["pw-dump"], 6)
    if code != 0:
        return []
    try:
        objs = json.loads(out)
    except Exception:
        return []
    res = []
    for o in objs:
        if o.get("type") != "PipeWire:Interface:Node":
            continue
        p = (o.get("info") or {}).get("props") or {}
        res.append(dict(id=o.get("id"), name=p.get("node.name", ""), desc=p.get("node.description") or p.get("node.nick") or
                        p.get("node.name", ""), cls=p.get("media.class", ""), props=p))
    return res


def devices(kind):
    """Physical (non-PhoenixGe) microphones ('source') or outputs ('sink'): [(name, description)]."""
    cls = "Audio/Source" if kind == "source" else "Audio/Sink"
    return [(n["name"], n["desc"]) for n in nodes()
            if n["cls"] == cls and n["name"] and not n["name"].startswith(OURS)]


def default(kind):
    """Configured default device name for 'source' / 'sink'."""
    if DEMO:
        return {"source": "alsa_input.usb-HyperX_QuadCast_S-00.analog-stereo",
                "sink": "alsa_output.pci-0000_00_1f.3.analog-stereo"}[kind]
    code, out = run(["pw-dump"], 6)
    try:
        for o in json.loads(out):
            if o.get("type") == "PipeWire:Interface:Metadata" and (o.get("props") or {}).get("metadata.name") == "default":
                vals = {m.get("key"): m.get("value") for m in o.get("metadata") or []}
                for key in (f"default.configured.audio.{kind}", f"default.audio.{kind}"):
                    v = vals.get(key)
                    if isinstance(v, str):
                        v = json.loads(v)
                    if isinstance(v, dict) and v.get("name"):
                        return v["name"]
    except Exception:
        pass
    return ""


def set_default(kind, name):
    if not name:
        return False
    if shutil.which("pactl"):
        code, _ = run(["pactl", f"set-default-{kind}", name])
        if code == 0:
            return True
    code, _ = run(["pw-metadata", "-n", "default", "0", f"default.configured.audio.{kind}",
                   json.dumps({"name": name}), "Spa:String:JSON"])
    return code == 0


def wait_node(name, secs=6.0):
    end = time.time() + secs
    while time.time() < end:
        if any(n["name"] == name for n in nodes()):
            return True
        time.sleep(0.3)
    return False


def headphones():
    """Best guess whether the current output is headphones (for the 3D hint)."""
    d = default("sink")
    for n in nodes():
        if n["name"] == d:
            p = n["props"]
            text = " ".join(str(p.get(k, "")) for k in ("node.description", "device.profile.description", "device.form-factor",
                                                        "device.icon-name", "api.bluez5.profile", "device.bus"))
            text = text.lower()
            return any(w in text for w in ("headphone", "headset", "a2dp", "bluez", "bluetooth", "handsfree"))
    return False


# ------------------------------------------------------------------ helpers
def q(s):
    return json.dumps(str(s))


def have_gate():
    return Path(GATE_SO).exists()


def have_3d():
    return Path(SOFA).exists() and any(Path(d).glob("spa-0.2/filter-graph/libspa-filter-graph-plugin-sofa.so")
                                       for d in ("/usr/lib/x86_64-linux-gnu", "/usr/lib/aarch64-linux-gnu", "/usr/lib64",
                                                 "/usr/lib"))


def gate_values(strength):
    s = max(0, min(100, int(strength)))
    return -70.0 + 0.4 * s, -(20.0 + 0.6 * s)  # threshold dB, range dB


def preamp(snd):
    if snd.get("auto_preamp", True):
        return -max(0.0, max(snd["bands"]))
    return float(snd.get("preamp", 0.0))


def lin(db):
    return round(10 ** (db / 20.0), 5)


BASE = """# Generated by PhoenixGe (Center > Sound & camera) - changes are overwritten.
context.properties = {{ log.level = 0 }}
context.spa-libs = {{
    audio.convert.* = audioconvert/libspa-audioconvert
    support.*       = support/libspa-support
}}
context.modules = [
    {{ name = libpipewire-module-rt args = {{ }} flags = [ ifexists nofail ] }}
    {{ name = libpipewire-module-protocol-native }}
    {{ name = libpipewire-module-client-node }}
    {{ name = libpipewire-module-adapter }}
{modules}
]
"""


def mic_conf(st):
    m = st["mic"]
    target = m.get("target") or ""
    gate = have_gate()
    out_name = MIC_STAGE1 if gate else MIC_NODE
    out_desc = "PhoenixGe Mic (processing)" if gate else "PhoenixGe Clean Mic"
    tgt = f"target.object = {q(target)}\n                node.dont-fallback = true" if target else ""
    mods = f"""    {{ name = libpipewire-module-echo-cancel
        args = {{
            library.name  = aec/libspa-aec-webrtc
            monitor.mode  = true
            audio.channels = 1
            audio.position = [ MONO ]
            aec.args = {{
                webrtc.noise_suppression     = true
                webrtc.transient_suppression = true
                webrtc.high_pass_filter      = true
                webrtc.voice_detection       = true
                webrtc.gain_control          = {"true" if m.get("agc") else "false"}
            }}
            capture.props = {{
                node.name = "phoenixge_mic_capture"
                node.description = "PhoenixGe Clean Mic (input)"
                {tgt}
            }}
            sink.props = {{
                node.name = "phoenixge_mic_echo_ref"
                node.description = "PhoenixGe Clean Mic (echo reference)"
            }}
            source.props = {{
                node.name = {q(out_name)}
                node.description = {q(out_desc)}
                priority.session = 0
            }}
        }}
    }}
"""
    if gate:
        thr, rng = gate_values(m.get("strength", 50))
        mods += f"""    {{ name = libpipewire-module-filter-chain
        args = {{
            node.description = "PhoenixGe Clean Mic"
            media.name       = "PhoenixGe Clean Mic"
            audio.channels   = 1
            audio.position   = [ MONO ]
            filter.graph = {{
                nodes = [
                    {{ type = ladspa name = gate plugin = {q(GATE_SO)} label = gate
                      control = {{ "LF key filter (Hz)" = 80.0 "HF key filter (Hz)" = 8000.0 "Threshold (dB)" = {thr:.1f}
                                  "Attack (ms)" = 5.0 "Hold (ms)" = 250.0 "Decay (ms)" = 200.0 "Range (dB)" = {rng:.1f} }} }}
                ]
            }}
            capture.props = {{
                node.name = {q(MIC_GATE_IN)}
                node.passive = true
                target.object = {q(MIC_STAGE1)}
                node.dont-fallback = true
            }}
            playback.props = {{
                node.name = {q(MIC_NODE)}
                node.description = "PhoenixGe Clean Mic"
                media.class = Audio/Source
                device.icon-name = "audio-input-microphone"
            }}
        }}
    }}
"""
    return BASE.format(modules=mods)


def eq_nodes(prefix, bands):
    out = []
    for i, (f, g) in enumerate(zip(BANDS, bands), 1):
        label = "bq_lowshelf" if i == 1 else "bq_highshelf" if i == len(BANDS) else "bq_peaking"
        out.append(f'{{ type = builtin name = {prefix}{i} label = {label} '
                   f'control = {{ "Freq" = {float(f)} "Q" = {1.0 if label != "bq_peaking" else 1.41} "Gain" = {float(g)} }} }}')
    links = [f'{{ output = "{prefix}{i}:Out" input = "{prefix}{i + 1}:In" }}' for i in range(1, len(BANDS))]
    return out, links


def sound_conf(st):
    s = st["sound"]
    pre = lin(preamp(s))
    surround = s.get("surround") and have_3d()
    nodes_, links = [], []
    if not surround:  # stereo: one chain, PipeWire duplicates it for L and R
        nodes_.append(f'{{ type = builtin name = pre label = mixer control = {{ "Gain 1" = {pre} }} }}')
        n, l = eq_nodes("eq", s["bands"]); nodes_ += n; links += l
        links.append('{ output = "pre:Out" input = "eq1:In" }')
        inputs, outputs = '[ "pre:In 1" ]', f'[ "eq{len(BANDS)}:Out" ]'
        ch, pos = 2, "[ FL FR ]"
    else:
        ins = []
        for k, (sp, az, gain) in enumerate(SPEAKERS, 1):
            if az is None:
                nodes_.append(f'{{ type = builtin name = sp{sp} label = copy }}')
                links += [f'{{ output = "sp{sp}:Out" input = "mixL:In {k}" }}', f'{{ output = "sp{sp}:Out" input = "mixR:In {k}" }}']
            else:
                nodes_.append(f'{{ type = sofa name = sp{sp} label = spatializer config = {{ filename = {q(SOFA)} }} '
                              f'control = {{ "Azimuth" = {float(az)} "Elevation" = 0.0 "Radius" = 1.4 }} }}')
                links += [f'{{ output = "sp{sp}:Out L" input = "mixL:In {k}" }}', f'{{ output = "sp{sp}:Out R" input = "mixR:In {k}" }}']
            ins.append(f'"sp{sp}:In"')
        gains = " ".join(f'"Gain {k}" = {g}' for k, (_s, _a, g) in enumerate(SPEAKERS, 1))
        for side in "LR":
            nodes_.append(f'{{ type = builtin name = mix{side} label = mixer control = {{ {gains} }} }}')
            nodes_.append(f'{{ type = builtin name = pre{side} label = mixer control = {{ "Gain 1" = {pre} }} }}')
            links.append(f'{{ output = "mix{side}:Out" input = "pre{side}:In 1" }}')
            n, l = eq_nodes(f"eq{side}", s["bands"]); nodes_ += n; links += l
            links.append(f'{{ output = "pre{side}:Out" input = "eq{side}1:In" }}')
        inputs, outputs = "[ " + " ".join(ins) + " ]", f'[ "eqL{len(BANDS)}:Out" "eqR{len(BANDS)}:Out" ]'
        ch, pos = 8, "[ FL FR FC LFE RL RR SL SR ]"
    ind = "\n                    "
    mods = f"""    {{ name = libpipewire-module-filter-chain
        args = {{
            node.description = "PhoenixGe Sound"
            media.name       = "PhoenixGe Sound"
            filter.graph = {{
                nodes = [{ind}{ind.join(nodes_)}
                ]
                links = [{ind}{ind.join(links)}
                ]
                inputs  = {inputs}
                outputs = {outputs}
            }}
            capture.props = {{
                node.name      = {q(SOUND_NODE)}
                media.class    = Audio/Sink
                audio.channels = {ch}
                audio.position = {pos}
                filter.smart      = true
                filter.smart.name = "phoenixge-sound"
                device.icon-name  = "audio-headphones"
            }}
            playback.props = {{
                node.name      = {q(SOUND_OUT)}
                node.passive   = true
                stream.dont-remix = true
                audio.channels = 2
                audio.position = [ FL FR ]
            }}
        }}
    }}
"""
    return BASE.format(modules=mods)


# ------------------------------------------------------------------ services
def unit_text(desc, conf):
    return f"""# Generated by PhoenixGe (Center > Sound & camera)
[Unit]
Description={desc}
After=pipewire.service wireplumber.service
BindsTo=pipewire.service

[Service]
Type=simple
ExecStartPre=-/usr/bin/python3 {SELF} regen
ExecStart=/usr/bin/pipewire -c {conf}
Restart=on-failure
RestartSec=2
Slice=session.slice

[Install]
WantedBy=pipewire.service
"""


def systemctl(*args):
    return run(["systemctl", "--user", *args], 20)


def active(unit):
    if DEMO:
        return True
    return systemctl("is-active", unit)[1].strip() == "active"


def write_files(st):
    CONF_DIR.mkdir(parents=True, exist_ok=True)
    UNIT_DIR.mkdir(parents=True, exist_ok=True)
    (CONF_DIR / "clean-mic.conf").write_text(mic_conf(st))
    (CONF_DIR / "sound.conf").write_text(sound_conf(st))
    changed = False
    for unit, desc, conf in [(MIC_UNIT, "PhoenixGe Clean Mic (noise removal)", CONF_DIR / "clean-mic.conf"),
                             (SOUND_UNIT, "PhoenixGe Sound (equalizer + 3D)", CONF_DIR / "sound.conf")]:
        f, text = UNIT_DIR / unit, unit_text(desc, conf)
        if not f.exists() or f.read_text() != text:
            f.write_text(text); changed = True
    if changed:
        systemctl("daemon-reload")


def resolve_mic(st):
    """Pick the physical microphone the Clean Mic listens to (Automatic = the default before Clean Mic)."""
    m = st["mic"]
    phys = [n for n, _d in devices("source")]
    if m.get("device"):
        m["target"] = m["device"]
        return
    cur = default("source")
    if cur and not cur.startswith(OURS):
        m["prev_default"] = cur
    for cand in (m.get("prev_default"), m.get("target")):
        if cand and (cand in phys or not phys):
            m["target"] = cand
            return
    m["target"] = phys[0] if phys else m.get("target", "")


# ------------------------------------------------------------------ live control
def set_props(names, params):
    """pw-cli set-param Props on our filter nodes (all nodes whose name is in `names`)."""
    body = " ".join(f"{q(k)} {float(v)}" for k, v in params.items())
    for n in nodes():
        if n["name"] in names:
            run(["pw-cli", "set-param", str(n["id"]), "Props", "{ params = [ " + body + " ] }"])


def live_mic(st):
    if not have_gate():
        return
    thr, rng = gate_values(st["mic"].get("strength", 50))
    set_props({MIC_NODE, MIC_GATE_IN}, {"gate:Threshold (dB)": thr, "gate:Range (dB)": rng})


def live_sound(st):
    s = st["sound"]
    params = {}
    sides = ["L", "R"] if s.get("surround") and have_3d() else [""]
    for side in sides:
        for i, g in enumerate(s["bands"], 1):
            params[f"eq{side}{i}:Gain"] = g
        params[f"pre{side}:Gain 1"] = lin(preamp(s))
    set_props({SOUND_NODE, SOUND_OUT}, params)


# ------------------------------------------------------------------ actions
def mic(action, st):
    m = st["mic"]
    if action == "on":
        resolve_mic(st)
        if not m.get("target"):
            print("No microphone found - plug one in and try again."); return 1
        m["enabled"] = True; save(st); write_files(st)
        systemctl("enable", MIC_UNIT); systemctl("restart", MIC_UNIT)
        if not wait_node(MIC_NODE, 8):
            print("Clean Mic did not start - see: journalctl --user -u " + MIC_UNIT); return 1
        set_default("source", MIC_NODE)
        print(f"Clean Mic is on (listening to {m['target']}) and is now the default microphone.")
    elif action == "off":
        m["enabled"] = False; save(st)
        systemctl("disable", "--now", MIC_UNIT)
        if m.get("prev_default"):
            set_default("source", m["prev_default"])
        print("Clean Mic is off" + (f" - default microphone is back to {m['prev_default']}." if m.get("prev_default") else "."))
    elif action == "apply":
        if m.get("enabled"):
            resolve_mic(st)
        save(st); write_files(st)
        if active(MIC_UNIT):
            systemctl("restart", MIC_UNIT)
            if wait_node(MIC_NODE, 8):
                set_default("source", MIC_NODE)
    elif action == "live":
        save(st); write_files(st); live_mic(st)
    return 0


def sound(action, st):
    s = st["sound"]
    if action == "on":
        s["enabled"] = True; save(st); write_files(st)
        systemctl("enable", SOUND_UNIT); systemctl("restart", SOUND_UNIT)
        if not wait_node(SOUND_NODE, 8):
            print("PhoenixGe Sound did not start - see: journalctl --user -u " + SOUND_UNIT); return 1
        print("PhoenixGe Sound is on - it follows your output device (speakers, USB or Bluetooth headphones).")
    elif action == "off":
        s["enabled"] = False; save(st)
        systemctl("disable", "--now", SOUND_UNIT)
        print("PhoenixGe Sound is off.")
    elif action == "apply":
        save(st); write_files(st)
        if active(SOUND_UNIT):
            systemctl("restart", SOUND_UNIT)
    elif action == "live":
        save(st); write_files(st); live_sound(st)
    return 0


def mic_test(secs=5):
    src = MIC_NODE if active(MIC_UNIT) else (default("source") or "")
    wav = Path(os.environ.get("XDG_RUNTIME_DIR", "/tmp")) / "phoenixge-mic-test.wav"
    print(f"Recording {secs} s from {src or 'the default microphone'} - say something…", flush=True)
    args = ["pw-record"] + (["--target", src] if src else []) + [str(wav)]
    try:
        subprocess.run(args, timeout=secs)
    except subprocess.TimeoutExpired:
        pass
    except FileNotFoundError:
        print("pw-record is missing (package pipewire-bin)."); return 1
    print("Playing it back…", flush=True)
    code = subprocess.run(["pw-play", str(wav)]).returncode
    wav.unlink(missing_ok=True)
    return code


def status():
    st = load()
    return {"state": st, "mic_active": active(MIC_UNIT), "sound_active": active(SOUND_UNIT), "gate": have_gate() or DEMO,
            "surround_available": have_3d() or DEMO, "pipewire": bool(shutil.which("pw-dump")) or DEMO}


def main(argv):
    args = [a for a in argv if a != "--demo"]
    if not args or args[0] == "status":
        print(json.dumps(status(), indent=1)); return 0
    st = load()
    if args[0] == "mic" and len(args) > 1:
        return mic(args[1], st)
    if args[0] == "sound" and len(args) > 1:
        return sound(args[1], st)
    if args[0] == "mic-test":
        return mic_test(int(args[1]) if len(args) > 1 else 5)
    if args[0] == "regen":
        if st["mic"].get("enabled"):
            resolve_mic(st); save(st)
        write_files(st); return 0
    print(__doc__); return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
