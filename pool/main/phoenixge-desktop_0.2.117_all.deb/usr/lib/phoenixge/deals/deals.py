#!/usr/bin/env python3
"""PhoenixGe Deals - free games and price drops (backend, no Qt).

Sources (all public, no account or API key):
  Epic      store-site-backend-static.ak.epicgames.com/freeGamesPromotions   weekly free games, current + upcoming
  Steam     store.steampowered.com/search/results?maxprice=free&specials=1  "free to keep" (100 % off) promotions
            store.steampowered.com/api/featuredcategories                  Steam specials (with native-Linux flag)
  GOG       catalog.gog.com/v1/catalog?price=between:0,0&discounted=eq:true  games at -100 % (GOG's giveaway banner
            itself is behind a login, so a giveaway that is not a -100 % catalog price is not seen)
  CheapShark www.cheapshark.com/api/1.0  cross-store deals (Steam, GOG, Epic, Humble, Fanatical, ...), free deals,
            game search, historical lowest price. Prices are in USD.
  ProtonDB  www.protondb.com/api/v1/reports/summaries/<appid>.json  Linux compatibility tier
  Steam wishlist  api.steampowered.com/IWishlistService/GetWishlist/v1?steamid=  (public profiles only)

Everything is cached in ~/.cache/phoenixge/deals (stale cache is used when offline). Settings and the wishlist are in
~/.config/phoenixge/deals.json, what was already notified in ~/.local/state/phoenixge/deals-notified.json.

  deals.py --check            background run (systemd user timer): refresh, notify new free games / wishlist drops
  deals.py --check --dry-run  same, print instead of notifying, nothing is remembered
  deals.py --json             print free games, upcoming, deals and wishlist as JSON
  deals.py --prefetch         fill the cache (incl. cover images) - used to make offline screenshots
  deals.py --apply-timer      write the user's check interval into the systemd user timer and enable it
  deals.py --login            (autostart) enable the timer once for a new user
Env: PHOENIXGE_DEALS_OFFLINE=1 never touches the network (cache only), PHOENIXGE_DEALS_CACHE=<dir> other cache dir.
"""
import hashlib
import html
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

HOME = Path.home()
CACHE = Path(os.environ.get("PHOENIXGE_DEALS_CACHE") or HOME / ".cache/phoenixge/deals")
COVERS = CACHE / "covers"
CONF = HOME / ".config/phoenixge/deals.json"
NOTIFIED = HOME / ".local/state/phoenixge/deals-notified.json"
RUNTIME = Path(os.environ.get("XDG_RUNTIME_DIR") or f"/run/user/{os.getuid() if hasattr(os, 'getuid') else 0}") / "phoenixge"
GAMING = RUNTIME / "gaming-session.json"
UA = "PhoenixGe-Deals/1.0 (+https://shakogogokhia.github.io/phoenixge-updates)"
OFFLINE = os.environ.get("PHOENIXGE_DEALS_OFFLINE") == "1"
ICON = "/usr/share/icons/hicolor/scalable/apps/phoenixge-deals.svg"

HOUR = 3600
TTL = {"epic": 3 * HOUR, "steamfree": 3 * HOUR, "gog": 3 * HOUR, "csfree": 3 * HOUR, "csdeals": 2 * HOUR,
       "steamspecials": 2 * HOUR, "csstores": 7 * 24 * HOUR, "protondb": 7 * 24 * HOUR, "csgames": HOUR,
       "cssearch": 24 * HOUR}
# polite per-host spacing (CheapShark asks clients not to hammer it; it answers 429 when they do)
MIN_GAP = {"www.cheapshark.com": 1.2, "www.protondb.com": 0.5, "store.steampowered.com": 1.0,
           "api.steampowered.com": 1.0, "steamcommunity.com": 1.0}
_last_hit, _lock = {}, threading.Lock()

# CheapShark store ids (used until the live /stores list has been fetched once)
STORES = {"1": "Steam", "2": "GamersGate", "3": "GreenManGaming", "7": "GOG", "8": "Origin", "11": "Humble Store",
          "13": "Uplay", "15": "Fanatical", "21": "WinGameStore", "23": "GameBillet", "24": "Voidu",
          "25": "Epic Games Store", "27": "Gamesplanet", "28": "Gamesload", "29": "2Game", "30": "IndieGala",
          "31": "Blizzard Shop", "33": "DLGamer", "34": "Noctre", "35": "DreamGame"}
DEFAULT_STORES = ["1", "7", "25", "11", "15", "3", "27", "23"]

DEFAULTS = {
    "mode": "auto",            # auto = the defaults below; manual = the user's own choices
    "notify": True,            # master switch for notifications
    "notify_free": True,       # free-to-keep games (Epic / Steam / GOG / other stores)
    "notify_wishlist": True,   # wishlist below target / at historical low
    "notify_deals": False,     # any deal that matches the filters below (manual mode)
    "stores": DEFAULT_STORES,  # CheapShark store ids for the deals list
    "min_discount": 50,        # %
    "max_price": 30,           # USD, 0 = no limit
    "interval_hours": 6,
    "hide_owned": True,
    "country": "GE",           # Epic shows the free games of this country
    "wishlist": [],            # [{id (CheapShark gameID), title, steam_appid, thumb, target, added}]
    "steam_profile": "",
}
AUTO = {k: DEFAULTS[k] for k in ("notify", "notify_free", "notify_wishlist", "notify_deals", "stores", "min_discount",
                                  "max_price", "interval_hours", "hide_owned")}


# ------------------------------------------------------------------ small helpers
def now():
    return time.time()


def read_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(data, indent=1), encoding="utf-8")
    os.replace(tmp, path)


def norm(title):
    """'The Witcher® 3: Wild Hunt - GOTY' -> 'witcher3wildhuntgoty' (for matching titles across stores)."""
    t = (title or "").lower().replace("&", "and")
    t = re.sub(r"[™®©]", "", t)
    t = re.sub(r"^the\s+", "", t)
    return re.sub(r"[^a-z0-9]+", "", t)


def money(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def iso(ts):
    """'2026-11-19T16:00:00.000Z' -> unix time."""
    if not ts:
        return None
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def left_text(end, t=None):
    """Seconds until `end` as '3d 4h' / '5h 12m' / '12m'."""
    if not end:
        return ""
    s = int(end - (t or now()))
    if s <= 0:
        return "ended"
    d, h, m = s // 86400, s % 86400 // 3600, s % 3600 // 60
    return f"{d}d {h}h" if d else (f"{h}h {m}m" if h else f"{max(m, 1)}m")


def date_text(ts):
    return time.strftime("%a %d %b, %H:%M", time.localtime(ts)) if ts else ""


# ------------------------------------------------------------------ network + cache
def _wait_turn(host):
    gap = MIN_GAP.get(host, 0.3)
    with _lock:
        t = now()
        wait = _last_hit.get(host, 0) + gap - t
        _last_hit[host] = max(t, _last_hit.get(host, 0) + gap)
    if wait > 0:
        time.sleep(wait)


def fetch(url, timeout=20):
    """GET -> bytes (raises on error)."""
    if OFFLINE:
        raise OSError("offline mode")
    _wait_turn(urllib.parse.urlsplit(url).hostname or "")
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json, text/html;q=0.8, */*;q=0.5"})
    for attempt in range(2):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read()
        except urllib.error.HTTPError as e:
            if e.code == 429 and attempt == 0:  # rate limited: back off once, then give up
                time.sleep(int(e.headers.get("Retry-After") or 5))
                continue
            raise
    raise OSError("rate limited")


def cache_file(key):
    return CACHE / f"{key}.json"


def cached(key, url, ttl, parse=json.loads, force=False):
    """Fresh cache -> it; else download (and cache); on failure the stale cache, else None."""
    f = cache_file(key)
    try:
        fresh = (now() - f.stat().st_mtime) < ttl
    except OSError:
        fresh = False
    if f.exists() and (fresh or OFFLINE) and not force:
        data = read_json(f)
        if data is not None:
            return data
    try:
        data = parse(fetch(url).decode("utf-8", errors="replace"))
        write_json(f, data)
        return data
    except Exception as e:  # noqa: BLE001 - network, JSON, HTTP
        print(f"deals: {key}: {e}", file=sys.stderr)
        return read_json(f)


def last_update():
    """Newest cache time of the main sources (for 'updated 5 min ago')."""
    ts = [cache_file(k).stat().st_mtime for k in ("epic", "csdeals", "steamfree") if cache_file(k).exists()]
    return max(ts) if ts else 0


def cover_path(url):
    if not url:
        return None
    ext = ".png" if url.lower().split("?")[0].endswith(".png") else ".jpg"
    return COVERS / (hashlib.sha1(url.encode()).hexdigest()[:20] + ext)


def get_cover(url):
    """Local file of an image URL, downloaded once (None when it can't be had)."""
    f = cover_path(url)
    if not f:
        return None
    if f.exists() and f.stat().st_size > 0:
        return str(f)
    try:
        data = fetch(url, timeout=25)
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_bytes(data)
        return str(f)
    except Exception as e:  # noqa: BLE001
        print(f"deals: cover {url[:80]}: {e}", file=sys.stderr)
        return None


# ------------------------------------------------------------------ settings + wishlist
def load_settings():
    s = dict(DEFAULTS)
    s.update(read_json(CONF, {}) or {})
    return s


def save_settings(s):
    write_json(CONF, s)


def effective(s):
    """Settings with the Automatic defaults applied (wishlist and country always stay the user's)."""
    if s.get("mode") != "manual":
        s = dict(s)
        s.update(AUTO)
    return s


# ------------------------------------------------------------------ owned games (Steam + Heroic, local files only)
def _vdf_values(text, key):
    return re.findall(r'"%s"\s+"([^"]*)"' % key, text, re.I)


def owned_games():
    """{'steam': {appid,...}, 'titles': {normalised title,...}} from local launcher files (no login, no network)."""
    appids, titles = set(), set()
    roots = [HOME / ".var/app/com.valvesoftware.Steam/.local/share/Steam", HOME / ".local/share/Steam", HOME / ".steam/steam"]
    for root in roots:
        if not root.is_dir():
            continue
        libs = {root}
        try:
            libs |= {Path(p) for p in _vdf_values((root / "steamapps/libraryfolders.vdf").read_text(errors="ignore"), "path")}
        except OSError:
            pass
        for lib in libs:
            for acf in (lib / "steamapps").glob("appmanifest_*.acf"):
                try:
                    t = acf.read_text(errors="ignore")
                except OSError:
                    continue
                appids.update(_vdf_values(t, "appid")[:1])
                titles.update(norm(n) for n in _vdf_values(t, "name")[:1])
        # every game the user has ever started on this PC (installed or not)
        for lc in (root / "userdata").glob("*/config/localconfig.vdf"):
            try:
                t = lc.read_text(errors="ignore")
            except OSError:
                continue
            m = re.search(r'"apps"\s*\{', t, re.I)
            if m:
                appids.update(re.findall(r'^\s*"(\d{2,9})"\s*$', t[m.end():m.end() + 2_000_000], re.M))
    base = HOME / ".var/app/com.heroicgameslauncher.hgl/config/heroic"
    if not base.exists():
        base = HOME / ".config/heroic"
    for lib in ("store_cache/legendary_library.json", "store_cache/gog_library.json", "store_cache/nile_library.json"):
        data = read_json(base / lib)
        games = (data.get("library") or data.get("games") or []) if isinstance(data, dict) else (data or [])
        for g in games if isinstance(games, list) else []:
            if isinstance(g, dict) and g.get("title"):
                titles.add(norm(g["title"]))
    titles.discard("")
    return {"steam": appids, "titles": titles}


def is_owned(item, owned):
    if item.get("steam_appid") and str(item["steam_appid"]) in owned["steam"]:
        return True
    return norm(item.get("title")) in owned["titles"]


# ------------------------------------------------------------------ free games
def _epic_image(e, kinds):
    imgs = {k.get("type"): k.get("url") for k in e.get("keyImages") or []}
    for k in kinds:
        if imgs.get(k):
            u = imgs[k]
            # Epic's CDN resizes on request -> small download
            return u + ("&" if "?" in u else "?") + "h=480&w=360&resize=1&quality=medium" if "Tall" in k or k == "Thumbnail" else u
    return None


def _epic_url(e):
    slug = None
    for m in (e.get("catalogNs") or {}).get("mappings") or []:
        if m.get("pageType") == "productHome" and m.get("pageSlug"):
            slug = m["pageSlug"]
            break
    if not slug:
        slug = next((m.get("pageSlug") for m in e.get("offerMappings") or [] if m.get("pageSlug")), None)
    if not slug:
        slug = (e.get("productSlug") or "").split("/")[0] or None
    if not slug:
        return "https://store.epicgames.com/en-US/free-games"
    kind = "bundles" if e.get("offerType") == "BUNDLE" else "p"
    return f"https://store.epicgames.com/en-US/{kind}/{slug}"


def epic_free(country="GE", force=False):
    url = ("https://store-site-backend-static.ak.epicgames.com/freeGamesPromotions?locale=en-US"
           f"&country={country}&allowCountries={country}")
    data = cached("epic", url, TTL["epic"], force=force) or {}
    try:
        elements = data["data"]["Catalog"]["searchStore"]["elements"] or []
    except (KeyError, TypeError):
        elements = []
    cur, up, t = [], [], now()
    for e in elements:
        p = e.get("promotions") or {}
        base = dict(store="Epic", title=e.get("title") or "?", url=_epic_url(e), steam_appid=None,
                    image=_epic_image(e, ("OfferImageTall", "DieselStoreFrontTall", "Thumbnail", "OfferImageWide")),
                    wide=_epic_image(e, ("OfferImageWide", "DieselStoreFrontWide")),
                    description=(e.get("description") or "").strip(),
                    normal=((e.get("price") or {}).get("totalPrice") or {}).get("fmtPrice", {}).get("originalPrice", ""),
                    mystery="mystery" in (e.get("title") or "").lower())
        for group, out in (("promotionalOffers", cur), ("upcomingPromotionalOffers", up)):
            for g in p.get(group) or []:
                for o in g.get("promotionalOffers") or []:
                    if (o.get("discountSetting") or {}).get("discountPercentage") != 0:
                        continue  # a normal sale, not a free game
                    start, end = iso(o.get("startDate")), iso(o.get("endDate"))
                    if out is cur and ((start and start > t) or (end and end < t)):
                        continue
                    if out is cur and ((e.get("price") or {}).get("totalPrice") or {}).get("discountPrice", 0) != 0:
                        continue  # promotion listed, but not free in this country
                    out.append(dict(base, id=f"epic:{e.get('namespace')}:{e.get('id')}:{int(start or 0)}",
                                    start=start, end=end))
    return cur, up


def _steam_search_rows(html_text):
    rows = []
    for chunk in html_text.split('<a href="')[1:]:
        if "search_result_row" not in chunk[:2000]:
            continue
        appid = re.search(r'data-ds-appid="(\d+)"', chunk)
        title = re.search(r'<span class="title">(.*?)</span>', chunk, re.S)
        if not appid or not title:
            continue  # bundles / packages
        href = chunk.split('"', 1)[0]
        img = re.search(r'<div class="search_capsule"><img src="([^"]+)"', chunk)
        pct = re.search(r'discount_pct[^>]*>\s*-?(\d+)%', chunk)
        orig = re.search(r'discount_original_price">([^<]+)<', chunk)
        final = re.search(r'discount_final_price[^>]*>([^<]+)<', chunk)
        rows.append(dict(steam_appid=appid.group(1).split(",")[0], title=html.unescape(title.group(1)).strip(),
                         url=html.unescape(href).split("?")[0], thumb=img.group(1) if img else None,
                         discount=int(pct.group(1)) if pct else 0, normal=(orig.group(1).strip() if orig else ""),
                         final=(final.group(1).strip() if final else ""), linux="platform_img linux" in chunk))
    return rows


def steam_free(force=False):
    url = ("https://store.steampowered.com/search/results/?query&start=0&count=25&maxprice=free&specials=1"
           "&infinite=1&cc=us&l=english&category1=998")
    data = cached("steamfree", url, TTL["steamfree"], force=force) or {}
    out = []
    for r in _steam_search_rows(data.get("results_html") or "") if isinstance(data, dict) else []:
        if r["discount"] < 100:
            continue
        a = r["steam_appid"]
        out.append(dict(id=f"steam:{a}", store="Steam", title=r["title"], url=f"https://store.steampowered.com/app/{a}/",
                        steam_appid=a, normal=r["normal"], start=None, end=None, linux=r["linux"], description="",
                        image=f"https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/{a}/library_600x900.jpg",
                        wide=f"https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/{a}/header.jpg",
                        fallback=r["thumb"]))
    return out


def gog_free(force=False):
    url = ("https://catalog.gog.com/v1/catalog?limit=24&price=between:0,0&discounted=eq:true&order=desc:trending"
           "&productType=in:game,pack&page=1&countryCode=US&locale=en-US&currencyCode=USD")
    data = cached("gog", url, TTL["gog"], force=force) or {}
    out = []
    for p in data.get("products") or [] if isinstance(data, dict) else []:
        price = p.get("price") or {}
        if (price.get("finalMoney") or {}).get("amount") not in ("0.00", "0", 0) or not price.get("discount"):
            continue
        out.append(dict(id=f"gog:{p.get('id')}", store="GOG", title=p.get("title") or "?",
                        url=p.get("storeLink") or f"https://www.gog.com/en/game/{p.get('slug')}", steam_appid=None,
                        normal=price.get("base", ""), start=None, end=None, description="",
                        image=p.get("coverVertical"), wide=p.get("coverHorizontal")))
    return out


def store_names(force=False):
    data = cached("csstores", "https://www.cheapshark.com/api/1.0/stores", TTL["csstores"], force=force)
    names = dict(STORES)
    for s in data or []:
        if isinstance(s, dict) and s.get("storeID"):
            names[str(s["storeID"])] = s.get("storeName") or names.get(str(s["storeID"]), "?")
    return names


def active_stores():
    """[(id, name)] of the stores CheapShark currently lists as active."""
    data = read_json(cache_file("csstores")) or []
    act = [(str(s["storeID"]), s["storeName"]) for s in data if isinstance(s, dict) and s.get("isActive")]
    return act or sorted(STORES.items(), key=lambda kv: int(kv[0]))


def cheapshark_free(force=False):
    data = cached("csfree", "https://www.cheapshark.com/api/1.0/deals?upperPrice=0&pageSize=30",
                  TTL["csfree"], force=force) or []
    names, out = store_names(), []
    for d in data if isinstance(data, list) else []:
        if money(d.get("salePrice")) != 0 or not money(d.get("normalPrice")):
            continue
        a = d.get("steamAppID") or None
        out.append(dict(id=f"cs:{d.get('dealID')}", store=names.get(str(d.get("storeID")), "Store"),
                        title=d.get("title") or "?", steam_appid=a, normal=f"${money(d.get('normalPrice')):.2f}",
                        url="https://www.cheapshark.com/redirect?dealID=" + (d.get("dealID") or ""),
                        start=None, end=None, description="",
                        image=(f"https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/{a}/library_600x900.jpg"
                               if a else None), wide=d.get("thumb"), fallback=d.get("thumb")))
    return out


def free_games(settings=None, force=False):
    """(current, upcoming) free-to-keep games from every source, without duplicates, owned ones marked."""
    s = effective(settings or load_settings())
    cur, up = [], []
    try:
        cur, up = epic_free(s.get("country") or "GE", force)
    except Exception as e:  # noqa: BLE001
        print("deals: epic", e, file=sys.stderr)
    for fn in (steam_free, gog_free, cheapshark_free):
        try:
            cur += fn(force)
        except Exception as e:  # noqa: BLE001
            print("deals:", fn.__name__, e, file=sys.stderr)
    seen, merged = set(), []
    for g in cur:  # Epic / Steam / GOG first: their own links beat CheapShark's redirect
        k = (norm(g["title"]), g["store"] if g["store"] != "Epic Games Store" else "Epic")
        if k in seen:
            continue
        seen.add(k)
        merged.append(g)
    owned = owned_games()
    for g in merged + up:
        g["owned"] = is_owned(g, owned)
    merged.sort(key=lambda g: (g["owned"], g.get("end") or 9e12))
    up.sort(key=lambda g: g.get("start") or 9e12)
    return merged, up


# ------------------------------------------------------------------ deals
def protondb(appids, limit=25):
    """{appid: tier} - cached for a week, at most `limit` new lookups per call."""
    f = cache_file("protondb")
    db = read_json(f, {}) or {}
    t, new, changed = now(), 0, False
    for a in appids:
        a = str(a or "")
        if not a or (a in db and t - db[a].get("t", 0) < TTL["protondb"]):
            continue
        if new >= limit or OFFLINE:
            continue
        new += 1
        try:
            d = json.loads(fetch(f"https://www.protondb.com/api/v1/reports/summaries/{a}.json", timeout=10))
            db[a] = {"tier": d.get("tier") or d.get("trendingTier") or "pending", "t": t}
        except urllib.error.HTTPError as e:
            db[a] = {"tier": "none" if e.code == 404 else None, "t": t if e.code == 404 else t - TTL["protondb"] + HOUR}
        except Exception:  # noqa: BLE001
            continue
        changed = True
    if changed:
        write_json(f, db)
    return {a: v.get("tier") for a, v in db.items() if v.get("tier")}


def linux_badge(item, tiers):
    """('Native', colour) / ('Platinum', colour) / None."""
    if item.get("linux"):
        return "Linux: native", "#3ec46d"
    tier = tiers.get(str(item.get("steam_appid") or ""))
    colours = {"platinum": "#b4c7dc", "gold": "#cfb53b", "silver": "#a6a6a6", "bronze": "#cd7f32", "borked": "#ff4545",
               "native": "#3ec46d"}
    if tier in colours:
        return ("Linux: " + tier, colours[tier])  # ProtonDB tier
    return None


def steam_specials(force=False):
    data = cached("steamspecials", "https://store.steampowered.com/api/featuredcategories?cc=us&l=english",
                  TTL["steamspecials"], force=force) or {}
    out = []
    for i in ((data.get("specials") or {}).get("items") or []) if isinstance(data, dict) else []:
        if not i.get("discounted") or not i.get("final_price"):
            continue
        a = str(i.get("id"))
        out.append(dict(id=f"steam:{a}", title=i.get("name") or "?", store="Steam", steam_appid=a,
                        price=i["final_price"] / 100, normal=(i.get("original_price") or 0) / 100,
                        discount=int(i.get("discount_percent") or 0), url=f"https://store.steampowered.com/app/{a}/",
                        thumb=i.get("small_capsule_image") or i.get("header_image"), linux=bool(i.get("linux_available")),
                        end=i.get("discount_expiration"), rating=None))
    return out


def deals(settings=None, force=False):
    """Current deals (USD) that match the user's filters, best first."""
    s = effective(settings or load_settings())
    stores = [str(x) for x in s.get("stores") or DEFAULT_STORES]
    maxp = float(s.get("max_price") or 0)
    q = {"pageSize": 60, "sortBy": "Deal Rating", "onSale": 1, "storeID": ",".join(stores)}
    if maxp > 0:
        q["upperPrice"] = int(maxp) if maxp == int(maxp) else maxp
    key = "csdeals"
    url = "https://www.cheapshark.com/api/1.0/deals?" + urllib.parse.urlencode(q)
    meta = read_json(cache_file("csdeals-query"), {}) or {}
    if meta.get("url") != url:
        force = True  # filters changed -> the cached list is for other stores / prices
    data = cached(key, url, TTL["csdeals"], force=force and not OFFLINE) or []
    if not OFFLINE:
        write_json(cache_file("csdeals-query"), {"url": url})
    names = store_names()
    out = []
    for d in data if isinstance(data, list) else []:
        price, normal = money(d.get("salePrice")), money(d.get("normalPrice"))
        if price is None or not normal or price <= 0:
            continue  # free ones are in the "Free right now" list
        out.append(dict(id=f"cs:{d.get('dealID')}", title=d.get("title") or "?",
                        store=names.get(str(d.get("storeID")), "Store"), store_id=str(d.get("storeID")),
                        steam_appid=d.get("steamAppID") or None, price=price, normal=normal,
                        discount=int(round(money(d.get("savings")) or 0)), game_id=d.get("gameID"),
                        url="https://www.cheapshark.com/redirect?dealID=" + (d.get("dealID") or ""),
                        thumb=d.get("thumb"), linux=False, end=None,
                        rating=d.get("steamRatingText") if d.get("steamRatingText") not in (None, "null") else None))
    if "1" in stores:  # Steam's own front-page specials (carry the native-Linux flag)
        have = {x["steam_appid"] for x in out if x["steam_appid"]}
        for sp in steam_specials(force):
            if sp["steam_appid"] in have:
                for x in out:
                    if x["steam_appid"] == sp["steam_appid"]:
                        x["linux"] = x["linux"] or sp["linux"]
            elif not maxp or sp["price"] <= maxp:
                out.append(sp)
    mind = int(s.get("min_discount") or 0)
    out = [d for d in out if d["discount"] >= mind]
    # one row per game: the cheapest store
    best = {}
    for d in out:
        k = norm(d["title"])
        if k not in best or d["price"] < best[k]["price"]:
            best[k] = d
    out = list(best.values())
    owned = owned_games()
    for d in out:
        d["owned"] = is_owned(d, owned)
    if s.get("hide_owned"):
        out = [d for d in out if not d["owned"]]
    tiers = protondb([d["steam_appid"] for d in out if d.get("steam_appid") and not d.get("linux")])
    for d in out:
        d["badge"] = linux_badge(d, tiers)
    out.sort(key=lambda d: (-d["discount"], d["price"]))
    return out


# ------------------------------------------------------------------ wishlist
def search_games(title):
    """CheapShark game search -> [{id, title, steam_appid, thumb, cheapest}]."""
    q = urllib.parse.urlencode({"title": title, "limit": 20})
    data = cached("cssearch-" + hashlib.sha1(title.lower().encode()).hexdigest()[:12],
                  "https://www.cheapshark.com/api/1.0/games?" + q, TTL["cssearch"]) or []
    return [dict(id=str(g.get("gameID")), title=g.get("external") or "?", steam_appid=g.get("steamAppID") or None,
                 thumb=g.get("thumb"), cheapest=money(g.get("cheapest"))) for g in data if isinstance(g, dict)]


def wishlist_add(game, target=None, settings=None):
    s = settings or load_settings()
    wl = s.setdefault("wishlist", [])
    if any(str(w["id"]) == str(game["id"]) for w in wl):
        return False
    wl.append(dict(id=str(game["id"]), title=game.get("title") or "?", steam_appid=game.get("steam_appid"),
                   thumb=game.get("thumb"), target=target, added=int(now())))
    save_settings(s)
    return True


def wishlist_remove(game_id, settings=None):
    s = settings or load_settings()
    s["wishlist"] = [w for w in s.get("wishlist", []) if str(w["id"]) != str(game_id)]
    save_settings(s)


def wishlist_set_target(game_id, target, settings=None):
    s = settings or load_settings()
    for w in s.get("wishlist", []):
        if str(w["id"]) == str(game_id):
            w["target"] = target
    save_settings(s)


def wishlist_prices(settings=None, force=False):
    """Wishlist with current best price, store, deal URL and historical low (CheapShark /games?ids=, 25 per call)."""
    s = settings or load_settings()
    wl = s.get("wishlist") or []
    names, info = store_names(), {}
    ids = [str(w["id"]) for w in wl]
    for i in range(0, len(ids), 25):
        chunk = ids[i:i + 25]
        key = "csgames-" + hashlib.sha1(",".join(chunk).encode()).hexdigest()[:12]
        data = cached(key, "https://www.cheapshark.com/api/1.0/games?ids=" + ",".join(chunk), TTL["csgames"], force=force)
        if isinstance(data, dict):
            info.update(data)
    out = []
    for w in wl:
        g = info.get(str(w["id"])) or {}
        best = None
        for d in g.get("deals") or []:
            p = money(d.get("price"))
            if p is not None and (best is None or p < best["price"]):
                best = dict(price=p, normal=money(d.get("retailPrice")), store=names.get(str(d.get("storeID")), "Store"),
                            discount=int(round(money(d.get("savings")) or 0)),
                            url="https://www.cheapshark.com/redirect?dealID=" + (d.get("dealID") or ""))
        low = (g.get("cheapestPriceEver") or {})
        row = dict(w, best=best, low=money(low.get("price")), low_date=low.get("date"))
        target = money(w.get("target"))
        row["hit_target"] = bool(best and target is not None and best["price"] <= target)
        row["hit_low"] = bool(best and row["low"] is not None and best["price"] <= row["low"] + 0.005 and best["discount"] > 0)
        out.append(row)
    return out


def resolve_steam_id(profile):
    """SteamID64 from '7656119...', a profile URL, or a custom URL name (via the public profile XML)."""
    p = (profile or "").strip().rstrip("/")
    m = re.search(r"(7656119\d{10})", p)
    if m:
        return m.group(1)
    m = re.search(r"steamcommunity\.com/id/([^/?#]+)", p)
    name = m.group(1) if m else p
    if not re.fullmatch(r"[A-Za-z0-9_-]{2,64}", name or ""):
        raise ValueError("That doesn't look like a Steam profile link or name.")
    xml = fetch(f"https://steamcommunity.com/id/{urllib.parse.quote(name)}/?xml=1").decode("utf-8", "replace")
    m = re.search(r"<steamID64>(\d+)</steamID64>", xml)
    if not m:
        raise ValueError(f"No Steam profile called \"{name}\" was found.")
    return m.group(1)


def steam_wishlist_import(profile, limit=60, progress=None):
    """Adds the games of a PUBLIC Steam wishlist. -> (added, not_found) ; raises ValueError with a readable reason."""
    sid = resolve_steam_id(profile)
    try:
        data = json.loads(fetch(f"https://api.steampowered.com/IWishlistService/GetWishlist/v1/?steamid={sid}"))
    except urllib.error.HTTPError as e:
        raise ValueError(f"Steam answered {e.code} - try again later.") from e
    items = (data.get("response") or {}).get("items") or []
    if not items:
        raise ValueError("The wishlist is empty or private. In Steam: Profile > Edit Profile > Privacy Settings > "
                         "Game details: Public.")
    items.sort(key=lambda i: i.get("priority") or 9999)
    s = load_settings()
    s["steam_profile"] = profile
    have = {str(w.get("steam_appid")) for w in s.get("wishlist", [])}
    added, missing = 0, []
    for n, it in enumerate(items[:limit]):
        a = str(it.get("appid"))
        if progress:
            progress(n + 1, min(len(items), limit))
        if a in have:
            continue
        try:
            res = json.loads(fetch("https://www.cheapshark.com/api/1.0/games?steamAppID=" + a))
        except Exception:  # noqa: BLE001
            res = []
        if not res:
            missing.append(a)
            continue
        g = res[0]
        s.setdefault("wishlist", []).append(dict(id=str(g["gameID"]), title=g.get("external") or a, steam_appid=a,
                                                 thumb=g.get("thumb"), target=None, added=int(now())))
        have.add(a)
        added += 1
    save_settings(s)
    return added, missing


# ------------------------------------------------------------------ background check + notifications
def gaming_now():
    return GAMING.exists()


def notify(title, body, url, image=None, key=None):
    """Desktop notification with Claim / Open actions (notify-send >= 0.8). Runs detached, never blocks."""
    if not shutil.which("notify-send"):
        print("notify:", title, body, url)
        return
    icon = image if image and Path(image).exists() else (ICON if Path(ICON).exists() else "emblem-favorite")
    script = ('a=$(timeout 12h notify-send --app-name="PhoenixGe Deals" -i "$1" --wait '
              '-A open="$4" -A all="See all deals" "$2" "$3" 2>/dev/null); '
              'case "$a" in open) xdg-open "$5" ;; all) phoenixge-deals ;; esac')
    try:
        subprocess.Popen(["sh", "-c", script, "sh", icon, title, body, "Claim" if key == "free" else "Open", url],
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)
    except OSError as e:
        print("notify:", e, file=sys.stderr)


def check(dry_run=False, force=True):
    """Refresh everything, notify what is new. Returns the list of (kind, key, title, body, url)."""
    s = load_settings()
    e = effective(s)
    notified = read_json(NOTIFIED, {}) or {}
    t = now()
    notified = {k: v for k, v in notified.items() if t - (v.get("t", 0) if isinstance(v, dict) else 0) < 120 * 86400}
    todo = []
    if e.get("notify") and e.get("notify_free"):
        cur, _up = free_games(s, force)
        for g in cur:
            if g.get("owned") or g.get("mystery"):
                continue
            k = "free:" + g["id"]
            if k in notified:
                continue
            until = f" until {date_text(g['end'])}" if g.get("end") else ""
            was = f" (normally {g['normal']})" if g.get("normal") and g["normal"] not in ("0", "$0.00") else ""
            todo.append(("free", k, f"Free on {g['store']}: {g['title']}",
                         f"Free to keep{until}{was}. Claim it with your {g['store']} account.", g["url"], g.get("image")))
    if e.get("notify") and e.get("notify_wishlist") and s.get("wishlist"):
        for w in wishlist_prices(s, force):
            b = w.get("best")
            if not b or not (w["hit_target"] or w["hit_low"]):
                continue
            k = f"wish:{w['id']}"
            last = notified.get(k, {}).get("price") if isinstance(notified.get(k), dict) else None
            if last is not None and b["price"] >= last - 0.005:
                continue  # already told about this price (or a lower one)
            why = "lowest price ever" if w["hit_low"] else f"below your target ${float(w['target']):.2f}"
            off = f", -{b['discount']}%" if b["discount"] > 0 else ""
            todo.append(("wish", k, f"Wishlist: {w['title']} ${b['price']:.2f}",
                         f"{b['store']}{off} - {why}.", b["url"], None, b["price"]))
    if e.get("notify") and e.get("notify_deals"):
        for d in deals(s, force)[:40]:
            k = f"deal:{d['id']}"
            if k in notified or d.get("owned"):
                continue
            todo.append(("deal", k, f"{d['title']} -{d['discount']}%", f"${d['price']:.2f} on {d['store']} "
                         f"(was ${d['normal']:.2f}).", d["url"], None))
    if dry_run:
        for x in todo:
            print(f"[{x[0]}] {x[2]} - {x[3]} {x[4]}")
        return todo
    if gaming_now():
        print("deals: a game is running - notifications wait for the next check")
        return todo
    deal_rows = [x for x in todo if x[0] == "deal"]
    singles = [x for x in todo if x[0] != "deal"]
    for x in singles[:4]:
        img = get_cover(x[5]) if x[5] else None
        notify(x[2], x[3], x[4], img, x[0])
    if len(singles) > 4:
        notify(f"{len(singles) - 4} more free games and price drops", "Open PhoenixGe Deals to see them.",
               "https://store.epicgames.com/en-US/free-games")
    if deal_rows:
        notify(f"{len(deal_rows)} new deals match your filters", ", ".join(x[2] for x in deal_rows[:3]) + "…",
               deal_rows[0][4])
    for x in todo:
        notified[x[1]] = {"t": t, **({"price": x[6]} if len(x) > 6 else {})}
    write_json(NOTIFIED, notified)
    return todo


# ------------------------------------------------------------------ systemd user timer
TIMER = "phoenixge-deals.timer"


def apply_timer(settings=None):
    """Interval -> ~/.config/systemd/user/phoenixge-deals.timer.d/interval.conf ; enable or disable the timer."""
    s = effective(settings or load_settings())
    h = max(1, int(s.get("interval_hours") or 6))
    d = HOME / ".config/systemd/user" / (TIMER + ".d")
    try:
        d.mkdir(parents=True, exist_ok=True)
        (d / "interval.conf").write_text(f"[Timer]\nOnUnitActiveSec=\nOnUnitActiveSec={h}h\n")
    except OSError as e:
        print("deals: timer", e, file=sys.stderr)
    if not shutil.which("systemctl"):
        return
    subprocess.run(["systemctl", "--user", "daemon-reload"], capture_output=True, timeout=20)
    on = s.get("notify") and (s.get("notify_free") or s.get("notify_wishlist") or s.get("notify_deals"))
    subprocess.run(["systemctl", "--user", "enable" if on else "disable", "--now", TIMER], capture_output=True, timeout=20)


# ------------------------------------------------------------------ CLI
def prefetch():
    s = load_settings()
    cur, up = free_games(s, force=True)
    ds = deals(s, force=True)
    wl = wishlist_prices(s, force=True)
    imgs = [g.get("image") for g in cur + up] + [g.get("wide") for g in cur + up] + [g.get("fallback") for g in cur]
    imgs += [d.get("thumb") for d in ds] + [w.get("thumb") for w in wl]
    for u in [u for u in imgs if u]:
        get_cover(u)
    print(f"free {len(cur)}, upcoming {len(up)}, deals {len(ds)}, wishlist {len(wl)} -> {CACHE}")


def main(argv):
    if "--check" in argv:
        if not effective(load_settings()).get("notify") and "--dry-run" not in argv:
            return 0
        check(dry_run="--dry-run" in argv)
    elif "--json" in argv:
        s = load_settings()
        cur, up = free_games(s)
        print(json.dumps(dict(free=cur, upcoming=up, deals=deals(s), wishlist=wishlist_prices(s)), indent=1))
    elif "--prefetch" in argv:
        prefetch()
    elif "--apply-timer" in argv:
        apply_timer()
    elif "--login" in argv:  # XDG autostart: switch the timer on once per user (the user can turn it off later)
        mark = HOME / ".config/phoenixge/deals-timer-set"
        if not mark.exists():
            apply_timer()
            mark.parent.mkdir(parents=True, exist_ok=True)
            mark.write_text("1")
    else:
        print(__doc__)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
