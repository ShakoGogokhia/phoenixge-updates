#!/bin/sh
# 3 lines for the PhoenixGe "fetch" desktop board: base OS, kernel, hardware summary
. /etc/os-release
echo "$PRETTY_NAME"
uname -r
echo "$(nproc) cores, $(free -g | awk '/^Mem/{print $2}') GB RAM"
