#!/bin/sh
# Automatic day/night theme (set up in PhoenixGe Center > Themes). Runs from a systemd user timer.
CONF="$HOME/.config/phoenixge/autotheme.conf"
[ -f "$CONF" ] || exit 0
. "$CONF" 2>/dev/null || exit 0
[ "$enabled" = 1 ] || exit 0
H=$(date +%H)
if [ "$H" -ge "${day_start:-07}" ] && [ "$H" -lt "${night_start:-19}" ]; then want=$day; else want=$night; fi
[ -n "$want" ] || exit 0
cur=$(kreadconfig6 --file kdeglobals --group KDE --key LookAndFeelPackage)
[ "$cur" = "$want" ] && exit 0
plasma-apply-lookandfeel -a "$want" --resetLayout && plasma-apply-desktoptheme "phoenixge-${want#org.phoenixge.}"
