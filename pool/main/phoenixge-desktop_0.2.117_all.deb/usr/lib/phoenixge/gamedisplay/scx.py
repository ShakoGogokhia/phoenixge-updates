"""sched_ext gaming scheduler (scx_lavd, scx_bpfland, ...) - status, settings, GameMode hook. No Qt.

Facts (checked Nov 2026):
  * Kernel: CONFIG_SCHED_CLASS_EXT is NOT set in Debian trixie's 6.12 kernel; Debian enabled it from 6.14.3-1~exp1
    (bug #1102639), so every trixie-backports kernel (6.16 ... 7.2, = PhoenixGe's opt-in "gaming kernel") has it.
  * Schedulers: the scx tools (github.com/sched-ext/scx) are NOT packaged in Debian (no "scx" source package in
    trixie, backports or sid; an RFP/ITP was filed on debian-devel in Jan 2026). We therefore only use binaries that
    are already installed in a root-owned path (/usr/bin, /usr/sbin, /usr/local/bin) and offer an apt install only when
    apt has a candidate for one of SCX_PACKAGES.
  * Runtime status: /sys/kernel/sched_ext/state (enabled/disabled/...) and /sys/kernel/sched_ext/root/ops (name).

Config: /etc/phoenixge/scx.conf (written by scx-setup.sh as root, read by everybody)
    MODE=auto|manual|off   auto (default) = SCHED only while a game runs (GameMode -> session.py -> game_start)
                           manual         = SCHED always on (phoenixge-scx.service enabled)
    SCHED=scx_lavd
    FLAGS=
phoenixge-scx.service runs scx-run.sh; the active local user may start/stop it without a password
(polkit rule 50-phoenixge-scx.rules) so the GameMode hook works silently.
"""
import os
import re
import shutil
import subprocess
from pathlib import Path

CONF = Path("/etc/phoenixge/scx.conf")
SYS = Path("/sys/kernel/sched_ext")
UNIT = "phoenixge-scx.service"
HERE = Path(__file__).resolve().parent
SETUP = str(HERE / "scx-setup.sh")
BIN_DIRS = ("/usr/bin", "/usr/sbin", "/usr/local/bin", "/usr/local/sbin")
KNOWN = {  # name: (short description, good for)
    "scx_lavd": ("Latency-aware: keeps the frame-critical threads of a game on time. Made for gaming (Steam Deck).",
                 "gaming"),
    "scx_bpfland": ("Prioritises interactive tasks; good all-round desktop + gaming scheduler.", "desktop"),
    "scx_rusty": ("Load balancing for many-core CPUs.", "throughput"),
    "scx_flash": ("Fair, low-latency; good for audio and steady frame times.", "latency"),
    "scx_cosmos": ("Lightweight, keeps tasks on the same core (cache friendly).", "desktop"),
    "scx_p2dq": ("Pick-two load balancing, general purpose.", "general"),
}
SCX_PACKAGES = ("scx", "scx-scheds", "sched-ext-schedulers")
DEFAULTS = dict(MODE="auto", SCHED="scx_lavd", FLAGS="")


def _read(p):
    try:
        return Path(p).read_text().strip()
    except OSError:
        return ""


def load_conf():
    c = dict(DEFAULTS)
    for line in _read(CONF).splitlines():
        m = re.match(r"^\s*(MODE|SCHED|FLAGS)\s*=\s*\"?([^\"]*)\"?\s*$", line)
        if m:
            c[m.group(1)] = m.group(2).strip()
    if c["MODE"] not in ("auto", "manual", "off"):
        c["MODE"] = "auto"
    return c


def kernel_release():
    return os.uname().release


def kernel_support():
    """True / False / None (unknown)."""
    if SYS.is_dir():
        return True
    cfg = _read(f"/boot/config-{kernel_release()}")
    if cfg:
        return "CONFIG_SCHED_CLASS_EXT=y" in cfg
    return None


def schedulers():
    """{name: path} of installed scx_* binaries in root-owned directories."""
    out = {}
    for d in BIN_DIRS:
        try:
            for f in sorted(Path(d).glob("scx_*")):
                st = f.stat()
                if f.is_file() and os.access(f, os.X_OK) and st.st_uid == 0 and not (st.st_mode & 0o022) \
                        and f.name not in out and re.match(r"^scx_[a-z0-9_]+$", f.name):
                    out[f.name] = str(f)
        except OSError:
            pass
    return out


def apt_candidate():
    """Name of an installable scx package, or ''."""
    if not shutil.which("apt-cache"):
        return ""
    for p in SCX_PACKAGES:
        try:
            out = subprocess.run(["apt-cache", "policy", p], capture_output=True, text=True, timeout=10).stdout
        except (OSError, subprocess.SubprocessError):
            return ""
        m = re.search(r"Candidate:\s*(\S+)", out)
        if m and m.group(1) != "(none)":
            return p
    return ""


def status():
    """{'state': 'enabled'|'disabled'|..., 'ops': name or ''}"""
    return dict(state=_read(SYS / "state") or ("disabled" if SYS.is_dir() else "unavailable"),
                ops=_read(SYS / "root/ops"))


def unit_active():
    try:
        return subprocess.run(["systemctl", "is-active", "--quiet", UNIT], timeout=5).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def usable(conf=None):
    conf = conf or load_conf()
    return bool(kernel_support()) and conf["SCHED"] in schedulers()


def setup_args(mode, sched, flags=""):
    """Arguments for `pkexec /bin/sh scx-setup.sh ...` (validated again there)."""
    if mode not in ("auto", "manual", "off") or not re.match(r"^scx_[a-z0-9_]+$", sched) \
            or not re.match(r"^[-a-zA-Z0-9_ =.,]*$", flags or ""):
        raise ValueError("bad scheduler settings")
    return [SETUP, mode, sched, flags or ""]


# ------------------------------------------------------------------ GameMode hook (called from gaming/session.py)
def game_start():
    """Start the scheduler for this game session in Automatic mode. Returns True when we started it
    (session.py stores that and calls game_end() only then)."""
    conf = load_conf()
    if conf["MODE"] != "auto" or not usable(conf) or status()["state"] == "enabled" or unit_active():
        return False
    try:
        r = subprocess.run(["systemctl", "start", "--no-block", UNIT], capture_output=True, timeout=5)
        return r.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def game_end():
    if load_conf()["MODE"] != "auto":      # switched to Manual during the game: keep it running
        return
    try:
        subprocess.run(["systemctl", "stop", "--no-block", UNIT], capture_output=True, timeout=5)
    except (OSError, subprocess.SubprocessError):
        pass


DEMO = dict(kernel="7.2.12+bpo-amd64", support=True, scheds={"scx_lavd": "/usr/bin/scx_lavd",
                                                              "scx_bpfland": "/usr/bin/scx_bpfland",
                                                              "scx_rusty": "/usr/bin/scx_rusty"},
            status=dict(state="enabled", ops="lavd_1.0.19_g1c2d3e4_x86_64_unknown_linux_gnu"),
            conf=dict(MODE="auto", SCHED="scx_lavd", FLAGS=""), apt="")
