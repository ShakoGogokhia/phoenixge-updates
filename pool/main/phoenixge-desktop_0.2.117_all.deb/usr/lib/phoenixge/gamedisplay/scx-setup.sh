#!/bin/sh
# PhoenixGe Center > Display & performance: gaming scheduler (sched_ext) settings. Run as root (pkexec /bin/sh).
#   scx-setup.sh MODE SCHED [FLAGS]
#     MODE  auto   = the scheduler runs only while a game runs (GameMode hook starts/stops phoenixge-scx.service)
#           manual = always on (service enabled at boot and started now)
#           off    = never
#     SCHED scx_lavd / scx_bpfland / ... (must be installed in /usr/bin, /usr/sbin or /usr/local/bin)
set -eu
PATH=/usr/sbin:/usr/bin:/sbin:/bin
MODE=${1:-}; SCHED=${2:-scx_lavd}; FLAGS=${3:-}
case "$MODE" in auto|manual|off) ;; *) echo "usage: scx-setup.sh auto|manual|off SCHED [FLAGS]"; exit 2 ;; esac
echo "$SCHED" | grep -qE '^scx_[a-z0-9_]+$' || { echo "Bad scheduler name: $SCHED"; exit 2; }
echo "$FLAGS" | grep -qE '^[-a-zA-Z0-9_ =.,]*$' || { echo "Bad flags: $FLAGS"; exit 2; }
mkdir -p /etc/phoenixge
cat > /etc/phoenixge/scx.conf.tmp <<C
# PhoenixGe gaming scheduler (sched_ext) - written by PhoenixGe Center > Display & performance
MODE=$MODE
SCHED=$SCHED
FLAGS="$FLAGS"
C
chmod 644 /etc/phoenixge/scx.conf.tmp
mv /etc/phoenixge/scx.conf.tmp /etc/phoenixge/scx.conf
systemctl daemon-reload 2>/dev/null || true
case "$MODE" in
  manual)
    systemctl enable phoenixge-scx.service
    systemctl restart phoenixge-scx.service
    sleep 2
    echo "sched_ext: $(cat /sys/kernel/sched_ext/state 2>/dev/null || echo unavailable) $(cat /sys/kernel/sched_ext/root/ops 2>/dev/null)"
    echo "Gaming scheduler $SCHED is always on." ;;
  auto)
    systemctl disable phoenixge-scx.service 2>/dev/null || true
    systemctl stop phoenixge-scx.service 2>/dev/null || true
    echo "Automatic: $SCHED runs only while a game runs." ;;
  off)
    systemctl disable phoenixge-scx.service 2>/dev/null || true
    systemctl stop phoenixge-scx.service 2>/dev/null || true
    echo "Gaming scheduler off - the normal Linux scheduler is used." ;;
esac
