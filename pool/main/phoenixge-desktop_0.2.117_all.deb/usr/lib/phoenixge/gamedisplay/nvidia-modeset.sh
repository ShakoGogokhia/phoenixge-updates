#!/bin/sh
# PhoenixGe Center > Display & performance: turn on NVIDIA kernel modesetting (needed for Wayland, VRR, HDR and
# screens wired to the NVIDIA card). Debian's 550 driver does not enable it by default (upstream default is on from 560).
# Run as root (pkexec /bin/sh).   nvidia-modeset.sh on|off
set -eu
PATH=/usr/sbin:/usr/bin:/sbin:/bin
F=/etc/modprobe.d/phoenixge-nvidia-drm.conf
case "${1:-on}" in
  on)  printf '%s\n' "# PhoenixGe: NVIDIA DRM kernel modesetting (Wayland, VRR, HDR)" "options nvidia-drm modeset=1 fbdev=1" "options nvidia-current-drm modeset=1 fbdev=1" > "$F" ;;
  off) rm -f "$F" ;;
  *)   echo "usage: nvidia-modeset.sh on|off"; exit 2 ;;
esac
update-initramfs -u
echo "Done - restart the computer."
