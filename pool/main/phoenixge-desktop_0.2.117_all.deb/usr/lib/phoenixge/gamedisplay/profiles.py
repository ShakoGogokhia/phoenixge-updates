"""PhoenixGe per-game display profiles: HDR, upscaling (FSR / NIS / pixel / integer) - no Qt, used by the Center page
and by phoenix-game-run (gaming/gamerun.py).

Files (per user):
  ~/.config/phoenixge/game-launch.json   {"version": 1, "games": {"<game id>": PROFILE}}   - what the user picked
  ~/.config/phoenixge/game-env.json      {"version": 1, "games": {"<game id>": {"VAR": "value"}}} - derived env
                                         (written on every save; extra keys added by hand are kept)
Game ids are the Phoenix Games ids: steam:<appid>, heroic:<runner>:<app>, lutris:<slug>, desktop:<stem>, ...

PROFILE keys
  name        game name (display only)
  hdr         off | proton | gamescope
                proton    = Wine's native Wayland driver + DXVK HDR (GE-Proton 10+ / Proton 10+):
                            PROTON_ENABLE_WAYLAND=1 PROTON_ENABLE_HDR=1 DXVK_HDR=1 (+ ENABLE_HDR_WSI=1 when the
                            vk-hdr-layer Vulkan layer is installed - needed on KWin 6.3 + Mesa 25.0 / NVIDIA)
                gamescope = gamescope --hdr-enabled (gamescope's own WSI layer, nested in KWin) + DXVK_HDR=1
  upscale     off | fsr | nis | pixel | integer | wine-fsr
                fsr/nis/pixel/integer run the game inside gamescope at `render` and scale it to the screen
                wine-fsr = GE-Proton's WINE_FULLSCREEN_FSR (game in fullscreen below native resolution; X11 path only,
                           not every GE-Proton build still has it)
  render      "1280x720"  resolution the game renders at (gamescope -w/-h)
  output      "native" or "WxH" (gamescope -W/-H)
  sharpness   gamescope FSR/NIS sharpness 0 (sharpest) .. 20
  strength    WINE_FULLSCREEN_FSR_STRENGTH 0 (sharpest) .. 5
  refresh     0 = screen's refresh rate, else gamescope -r
  fullscreen  true/false (gamescope -f)
"""
import json
import os
import re
import shlex
import shutil
from pathlib import Path

HOME = Path.home()
CFG = Path(os.environ.get("XDG_CONFIG_HOME") or HOME / ".config") / "phoenixge"
LAUNCH_FILE = CFG / "game-launch.json"
ENV_FILE = CFG / "game-env.json"
DATA = Path(os.environ.get("XDG_DATA_HOME") or HOME / ".local/share")
STATS = DATA / "phoenixge/games.json"

DEFAULT = dict(name="", hdr="off", upscale="off", render="1280x720", output="native", sharpness=5, strength=2,
               refresh=0, fullscreen=True)
HDR_MODES = ("off", "proton", "gamescope")
UPSCALE_MODES = ("off", "fsr", "nis", "pixel", "integer", "wine-fsr")
GAMESCOPE_UPSCALE = {"fsr": ["-F", "fsr"], "nis": ["-F", "nis"], "pixel": ["-F", "pixel"],
                     "integer": ["-S", "integer", "-F", "nearest"]}
HDR_LAYER_DIRS = [Path("/usr/share/vulkan/implicit_layer.d"), Path("/usr/share/vulkan/explicit_layer.d"),
                  Path("/etc/vulkan/implicit_layer.d"), DATA / "vulkan/implicit_layer.d", DATA / "vulkan/explicit_layer.d"]
_SIZE = re.compile(r"^(\d{3,5})x(\d{3,5})$")


# ------------------------------------------------------------------ files
def _read(path):
    try:
        d = json.loads(path.read_text())
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=1, sort_keys=True))
    tmp.replace(path)


def load_all():
    return {k: {**DEFAULT, **v} for k, v in (_read(LAUNCH_FILE).get("games") or {}).items() if isinstance(v, dict)}


def load(game_id):
    return load_all().get(game_id) or dict(DEFAULT)


def is_default(p):
    return p.get("hdr", "off") == "off" and p.get("upscale", "off") == "off"


def save(game_id, profile):
    """Store the profile (None or all-off = remove) and its derived env."""
    data = _read(LAUNCH_FILE); data["version"] = 1
    games = data.setdefault("games", {})
    envd = _read(ENV_FILE); envd["version"] = 1
    envs = envd.setdefault("games", {})
    ours = set(env_for(load(game_id)))          # keys we wrote last time - user-added keys stay
    if profile is None or is_default(profile):
        games.pop(game_id, None)
        rest = {k: v for k, v in (envs.get(game_id) or {}).items() if k not in ours}
        if rest:
            envs[game_id] = rest
        else:
            envs.pop(game_id, None)
    else:
        p = {k: profile.get(k, DEFAULT[k]) for k in DEFAULT}
        games[game_id] = p
        rest = {k: v for k, v in (envs.get(game_id) or {}).items() if k not in ours}
        envs[game_id] = {**rest, **env_for(p)}
    _write(LAUNCH_FILE, data)
    _write(ENV_FILE, envd)


def env_file_for(game_id):
    """Everything in game-env.json for this game (derived + hand-added)."""
    v = (_read(ENV_FILE).get("games") or {}).get(game_id) or {}
    return {str(k): str(x) for k, x in v.items() if re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", str(k))}


# ------------------------------------------------------------------ what a profile means
def hdr_layer_installed():
    """vk-hdr-layer (github.com/Zamundaaa/VK_hdr_layer) - not packaged in Debian."""
    return any(any(d.glob(pat)) for d in HDR_LAYER_DIRS if d.is_dir() for pat in ("*hdr*wsi*.json", "*hdr_layer*.json"))


def gamescope_path():
    return shutil.which("gamescope")


def uses_gamescope(p):
    return p.get("hdr") == "gamescope" or p.get("upscale") in GAMESCOPE_UPSCALE


def env_for(p):
    env = {}
    if p.get("hdr") == "proton":
        env.update(PROTON_ENABLE_WAYLAND="1", PROTON_ENABLE_HDR="1", DXVK_HDR="1")
        if hdr_layer_installed():
            env["ENABLE_HDR_WSI"] = "1"
    elif p.get("hdr") == "gamescope":
        env["DXVK_HDR"] = "1"
    if p.get("upscale") == "wine-fsr" and p.get("hdr") != "proton":   # fshack is the X11 path only
        env["WINE_FULLSCREEN_FSR"] = "1"
        env["WINE_FULLSCREEN_FSR_STRENGTH"] = str(max(0, min(5, int(p.get("strength", 2)))))
    return env


def _size(s, fallback):
    m = _SIZE.match(str(s or ""))
    return (int(m.group(1)), int(m.group(2))) if m else fallback


def gamescope_args(p, native=(1920, 1080, 60.0)):
    """['gamescope', ..., '--'] or [] when the profile does not need gamescope."""
    if not uses_gamescope(p):
        return []
    nw, nh, nhz = native
    ow, oh = (nw, nh) if p.get("output", "native") == "native" else _size(p.get("output"), (nw, nh))
    a = ["gamescope"]
    up = p.get("upscale", "off")
    if up in GAMESCOPE_UPSCALE:
        rw, rh = _size(p.get("render"), (1280, 720))
        a += ["-w", str(rw), "-h", str(rh)]
    else:
        a += ["-w", str(ow), "-h", str(oh)]
    a += ["-W", str(ow), "-H", str(oh)]
    hz = int(p.get("refresh") or 0) or int(round(nhz or 0))
    if hz:
        a += ["-r", str(hz)]
    if up in GAMESCOPE_UPSCALE:
        a += GAMESCOPE_UPSCALE[up]
        if up in ("fsr", "nis"):
            a += ["--sharpness", str(max(0, min(20, int(p.get("sharpness", 5)))))]
    if p.get("fullscreen", True):
        a.append("-f")
    if p.get("hdr") == "gamescope":
        a.append("--hdr-enabled")
    return a + ["--"]


def launch_option(p, native=(1920, 1080, 60.0)):
    """Exact text for Steam > Properties > Launch options."""
    env = env_for(p)
    parts = [f"{k}={shlex.quote(v)}" for k, v in env.items()] + gamescope_args(p, native) + ["%command%"]
    return " ".join(parts)


def apply(game_id, env, cmd, launcher=False, native=None):
    """For phoenix-game-run: (env, cmd) with this game's display profile applied.
    The env from game-env.json always goes in. gamescope wraps the command only for games started directly
    (a launcher like steam:// hands the game to an already running client, where our env/wrapper can't reach -
    those games use the Steam launch option / Heroic wrapper instead)."""
    extra = env_file_for(game_id)
    if not extra and game_id not in load_all():
        return env, cmd
    env = dict(env); env.update(extra)
    p = load(game_id)
    if not launcher and uses_gamescope(p) and gamescope_path() and os.path.basename(cmd[0]) != "gamescope":
        if native is None:
            try:
                import displays
                native = displays.native_size()
            except Exception:  # noqa: BLE001
                native = (1920, 1080, 60.0)
        cmd = gamescope_args(p, native) + list(cmd)
    return env, cmd


# ------------------------------------------------------------------ games (minimal readers)
STEAM_SKIP = re.compile(r"^(Proton|Steam Linux Runtime|Steamworks Common|SteamVR)", re.I)


def _vdf_values(text, key):
    return re.findall(r'"' + key + r'"\s+"((?:[^"\\]|\\.)*)"', text, re.I)


def steam_games():
    out, seen = [], set()
    for root in (HOME / ".local/share/Steam", HOME / ".steam/steam", HOME / ".var/app/com.valvesoftware.Steam/.local/share/Steam"):
        lf = root / "steamapps/libraryfolders.vdf"
        try:
            libs = [Path(x.replace("\\\\", "\\")) for x in _vdf_values(lf.read_text(errors="replace"), "path")]
        except OSError:
            continue
        for lib in [root] + libs:
            for acf in (lib / "steamapps").glob("appmanifest_*.acf"):
                try:
                    t = acf.read_text(errors="replace")
                except OSError:
                    continue
                ids, names = _vdf_values(t, "appid"), _vdf_values(t, "name")
                if ids and names and ids[0] not in seen and not STEAM_SKIP.match(names[0]):
                    seen.add(ids[0])
                    out.append(dict(id=f"steam:{ids[0]}", name=names[0], source="Steam"))
    return out


def heroic_games():
    base = HOME / ".var/app/com.heroicgameslauncher.hgl/config/heroic"
    if not base.exists():
        base = HOME / ".config/heroic"
    out = []
    leg = _read(base / "legendaryConfig/legendary/installed.json")
    for app, g in leg.items():
        if isinstance(g, dict) and not g.get("is_dlc"):
            out.append(dict(id=f"heroic:legendary:{app}", name=g.get("title") or app, source="Epic"))
    gog = _read(base / "gog_store/installed.json").get("installed") or []
    lib = _read(base / "store_cache/gog_library.json").get("games") or []
    titles = {g.get("app_name"): g.get("title") for g in lib if isinstance(g, dict)}
    for g in gog if isinstance(gog, list) else []:
        app = isinstance(g, dict) and g.get("appName")
        if app:
            out.append(dict(id=f"heroic:gog:{app}", name=titles.get(app) or app, source="GOG"))
    return out


def list_games():
    """[{id, name, source}] - Phoenix Games' own readers when available, these minimal ones otherwise,
    plus everything that has a profile or play time in games.json."""
    games = []
    try:
        import sys
        sys.path.insert(0, "/usr/lib/phoenixge/games")
        import games as pg  # noqa: E402 - Phoenix Games library (same ids)
        games = [dict(id=g["id"], name=g["name"], source=g.get("source", "")) for g in pg.all_games()]
    except Exception:  # noqa: BLE001
        for fn in (steam_games, heroic_games):
            try:
                games += fn()
            except Exception:  # noqa: BLE001
                pass
    known = {g["id"] for g in games}
    for gid, p in load_all().items():
        if gid not in known:
            games.append(dict(id=gid, name=p.get("name") or gid, source=gid.split(":")[0].title())); known.add(gid)
    for gid in _read(STATS):
        if gid not in known:
            games.append(dict(id=gid, name=gid.split(":")[-1], source=gid.split(":")[0].title())); known.add(gid)
    games.sort(key=lambda g: g["name"].lower())
    return games


DEMO_GAMES = [dict(id="steam:730", name="Counter-Strike 2", source="Steam"),
              dict(id="steam:1091500", name="Cyberpunk 2077", source="Steam"),
              dict(id="steam:1245620", name="ELDEN RING", source="Steam"),
              dict(id="steam:413150", name="Stardew Valley", source="Steam"),
              dict(id="heroic:legendary:Hades", name="Hades", source="Epic"),
              dict(id="steam:105600", name="Terraria", source="Steam")]
DEMO_PROFILES = {"steam:1091500": dict(DEFAULT, name="Cyberpunk 2077", hdr="gamescope", upscale="fsr", render="1920x1080",
                                       sharpness=4),
                 "steam:413150": dict(DEFAULT, name="Stardew Valley", upscale="integer", render="1280x720")}
