#!/bin/sh
# ExecStart of phoenixge-scx.service: run the sched_ext scheduler chosen in /etc/phoenixge/scx.conf.
# Only binaries in root-owned system paths are run. When the scheduler exits, the kernel falls back to the normal
# scheduler by itself (sched_ext is designed to be safe to stop or crash).
PATH=/usr/sbin:/usr/bin:/sbin:/bin
MODE=auto; SCHED=scx_lavd; FLAGS=""
[ -r /etc/phoenixge/scx.conf ] && . /etc/phoenixge/scx.conf
[ "$MODE" = off ] && { echo "Gaming scheduler is off."; exit 0; }
[ -d /sys/kernel/sched_ext ] || { echo "This kernel ($(uname -r)) has no sched_ext. Install the PhoenixGe gaming kernel."; exit 0; }
echo "$SCHED" | grep -qE '^scx_[a-z0-9_]+$' || { echo "Bad scheduler name: $SCHED"; exit 1; }
echo "$FLAGS" | grep -qE '^[-a-zA-Z0-9_ =.,]*$' || { echo "Bad flags: $FLAGS"; exit 1; }
for d in /usr/bin /usr/sbin /usr/local/bin /usr/local/sbin; do
  if [ -x "$d/$SCHED" ] && [ "$(stat -c %u "$d/$SCHED")" = 0 ]; then
    # shellcheck disable=SC2086
    exec "$d/$SCHED" $FLAGS
  fi
done
echo "$SCHED is not installed."
exit 0
