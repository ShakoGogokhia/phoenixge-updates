"""PhoenixGe Display & performance - screens (HDR, wide colors, VRR), tearing, NVIDIA checks. No Qt here.

Everything per screen goes through kscreen-doctor (libkscreen-bin), the same backend as System Settings > Display:
    kscreen-doctor -j                                   JSON; a key is only present when the screen supports it
                                                        (libkscreen 6.3 ConfigSerializer: "vrrPolicy", "hdr",
                                                        "sdr-brightness", "wcg")
    kscreen-doctor output.<name>.hdr.enable|disable
    kscreen-doctor output.<name>.wcg.enable|disable
    kscreen-doctor output.<name>.sdr-brightness.<50..10000 nits>
    kscreen-doctor output.<name>.vrrpolicy.never|always|automatic   (vrrPolicy: 0 never, 1 always, 2 automatic)

What KWin 6.3 offers (src/backends/drm/drm_output.cpp, computeCapabilities):
  * VRR       when the connector has vrr_capable=1 (FreeSync / G-Sync compatible / HDMI VRR panels).
  * HDR/WCG   when the screen's EDID supports BT.2020 + PQ and the driver exposes Colorspace + HDR_OUTPUT_METADATA.
              Intel: kernel >= 6.11 (trixie 6.12 is fine). NVIDIA: driver >= 565.57.01, otherwise hidden unless
              KWIN_DRM_ALLOW_NVIDIA_COLORSPACE=1 is in KWin's environment. Debian trixie ships NVIDIA 550 ->
              HDR is hidden on screens wired to the NVIDIA card unless the user opts in (nvidia_hdr_optin()).
  * Tearing   kwinrc [Compositing] AllowTearing (default true); only used when the driver supports atomic async
              page flips and the game asks for "vsync off" in fullscreen.
"""
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

HOME = Path.home()
CFG = Path(os.environ.get("XDG_CONFIG_HOME") or HOME / ".config")
NVIDIA_HDR_ENV = CFG / "environment.d/phoenixge-nvidia-hdr.conf"
VRR_NAMES = {0: "never", 1: "always", 2: "automatic"}


def sh(cmd, timeout=8):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return 127, ""


def read(path, default=""):
    try:
        return Path(path).read_text().strip()
    except OSError:
        return default


# ------------------------------------------------------------------ GPUs
def connector_gpu(name):
    """Kernel driver that drives this connector: i915 / xe / amdgpu / nvidia / ..."""
    for d in Path("/sys/class/drm").glob(f"card*-{name}"):
        try:
            return os.path.basename(os.readlink(d / "device/driver"))
        except OSError:
            pass
    return ""


def gpus():
    """[{driver, name}] for every display GPU (PCI class 03xx)."""
    out = []
    for d in sorted(Path("/sys/bus/pci/devices").glob("*")):
        if not read(d / "class").startswith("0x03"):
            continue
        try:
            drv = os.path.basename(os.readlink(d / "driver"))
        except OSError:
            drv = ""
        vendor = read(d / "vendor")
        out.append(dict(driver=drv, vendor={"0x10de": "NVIDIA", "0x8086": "Intel", "0x1002": "AMD"}.get(vendor, vendor),
                        slot=d.name))
    return out


def nvidia_info():
    """None without an NVIDIA card; else {version, modeset (True/False/None), hdr_native, optin}."""
    if not any(g["vendor"] == "NVIDIA" for g in gpus()):
        return None
    ver = read("/sys/module/nvidia/version")
    ms = read("/sys/module/nvidia_drm/parameters/modeset")
    modeset = True if ms in ("Y", "1") else False if ms in ("N", "0") else None
    try:
        nums = tuple(int(x) for x in ver.split(".")[:3])
    except ValueError:
        nums = ()
    return dict(version=ver or "not loaded", modeset=modeset, hdr_native=bool(nums) and nums >= (565, 57, 1),
                optin=nvidia_hdr_optin())


def nvidia_hdr_optin():
    return "KWIN_DRM_ALLOW_NVIDIA_COLORSPACE=1" in read(NVIDIA_HDR_ENV)


def set_nvidia_hdr_optin(on):
    """KWin (a systemd user service in Plasma 6) reads ~/.config/environment.d at login."""
    if on:
        NVIDIA_HDR_ENV.parent.mkdir(parents=True, exist_ok=True)
        NVIDIA_HDR_ENV.write_text("# PhoenixGe Center > Display & performance: show HDR on NVIDIA screens (driver < 565)\n"
                                  "KWIN_DRM_ALLOW_NVIDIA_COLORSPACE=1\n")
    else:
        NVIDIA_HDR_ENV.unlink(missing_ok=True)


# ------------------------------------------------------------------ screens
def _mode(o):
    cur = str(o.get("currentModeId", ""))
    modes = o.get("modes") or []
    m = next((m for m in modes if str(m.get("id")) == cur), None)
    maxhz = max((float(x.get("refreshRate") or 0) for x in modes), default=0.0)
    if not m:
        return 0, 0, 0.0, maxhz
    s = m.get("size") or {}
    return int(s.get("width", 0)), int(s.get("height", 0)), float(m.get("refreshRate") or 0), maxhz


def parse_outputs(data):
    out = []
    for o in (data or {}).get("outputs") or []:
        if not o.get("connected"):
            continue
        name = o.get("name", "?")
        w, h, hz, maxhz = _mode(o)
        out.append(dict(
            id=o.get("id"), name=name, enabled=bool(o.get("enabled")), internal=bool(re.match(r"(eDP|LVDS|DSI)", name)),
            width=w, height=h, hz=hz, maxhz=maxhz, scale=o.get("scale", 1),
            vrr_capable="vrrPolicy" in o, vrr=VRR_NAMES.get(o.get("vrrPolicy"), "never"),
            hdr_capable="hdr" in o, hdr=bool(o.get("hdr")),
            wcg_capable="wcg" in o, wcg=bool(o.get("wcg")),
            sdr_brightness=int(o.get("sdr-brightness") or 200),
            priority=o.get("priority", 0), gpu=connector_gpu(name)))
    out.sort(key=lambda x: (x["priority"] or 99, x["name"]))
    return out


def outputs():
    """(screens, error)."""
    if not shutil.which("kscreen-doctor"):
        return [], "kscreen-doctor is missing (package libkscreen-bin)."
    if os.environ.get("XDG_SESSION_TYPE") == "x11":
        return [], "HDR and per-screen VRR need the Plasma (Wayland) session."
    code, txt = sh(["kscreen-doctor", "-j"])
    if code != 0 or not txt:
        return [], "Could not read the screens (kscreen-doctor failed)."
    try:
        return parse_outputs(json.loads(txt[txt.find("{"):])), ""
    except ValueError:
        return [], "Could not read the screens (unexpected kscreen-doctor output)."


def set_args(name, key, value):
    """kscreen-doctor argument for one change."""
    if key in ("hdr", "wcg"):
        return [f"output.{name}.{key}.{'enable' if value else 'disable'}"]
    if key == "sdr-brightness":
        return [f"output.{name}.sdr-brightness.{max(50, min(10000, int(value)))}"]
    if key == "vrr":
        assert value in ("never", "always", "automatic")
        return [f"output.{name}.vrrpolicy.{value}"]
    raise ValueError(key)


def native_size():
    """(w, h) of the main screen, for gamescope -W/-H."""
    scr, _ = outputs()
    for s in scr:
        if s["enabled"] and s["width"]:
            return s["width"], s["height"], s["hz"]
    return 1920, 1080, 60.0


# ------------------------------------------------------------------ KWin tearing
def tearing_allowed():
    code, v = sh(["kreadconfig6", "--file", "kwinrc", "--group", "Compositing", "--key", "AllowTearing", "--default", "true"])
    return v.lower() != "false"


def set_tearing(on):
    sh(["kwriteconfig6", "--file", "kwinrc", "--group", "Compositing", "--key", "AllowTearing", "true" if on else "false"])
    sh(["dbus-send", "--session", "--type=method_call", "--dest=org.kde.KWin", "/KWin", "org.kde.KWin.reconfigure"])


def session_type():
    return os.environ.get("XDG_SESSION_TYPE", "")


# ------------------------------------------------------------------ demo
DEMO_SCREENS = [
    dict(id=2, name="DP-1", enabled=True, internal=False, width=2560, height=1440, hz=164.96, maxhz=164.96, scale=1,
         vrr_capable=True, vrr="automatic", hdr_capable=True, hdr=True, wcg_capable=True, wcg=True, sdr_brightness=240,
         priority=1, gpu="nvidia"),
    dict(id=1, name="eDP-1", enabled=True, internal=True, width=2560, height=1600, hz=165.0, maxhz=165.0, scale=1.5,
         vrr_capable=True, vrr="automatic", hdr_capable=False, hdr=False, wcg_capable=False, wcg=False, sdr_brightness=200,
         priority=2, gpu="i915"),
]
DEMO_NVIDIA = dict(version="550.163.01", modeset=True, hdr_native=False, optin=True)
DEMO_GPUS = [dict(driver="i915", vendor="Intel", slot="0000:00:02.0"), dict(driver="nvidia", vendor="NVIDIA", slot="0000:01:00.0")]
