#!/usr/bin/env python3
"""phoenixge-gestured - recognises 3/4-finger swipes and pinches on TOUCHPADS ONLY and tells the desktop session.

Runs as root (systemd: phoenixge-gestured.service, started by udev when a touchpad exists) because reading
/dev/input needs root. Security: it never opens keyboards or other devices - only event nodes that udev marks
ID_INPUT_TOUCHPAD=1 - and the only thing it ever sends out is a gesture name like "swipe 3 up".
That is why users do NOT need to be in the "input" group (which would let every program read the keyboard).

Protocol: unix stream socket /run/phoenixge-gestures.sock (world-readable, gesture names only), one line per gesture:
  swipe <fingers> up|down|left|right
  pinch <fingers> in|out
Needs `libinput` from the libinput-tools package.
"""
import glob
import os
import re
import select
import socket
import subprocess
import sys
import time

SOCK = "/run/phoenixge-gestures.sock"
SWIPE_MIN = 70.0       # unaccelerated libinput units (~mm * 3) before a swipe counts
PINCH_IN, PINCH_OUT = 0.72, 1.35
RESCAN = 10            # seconds between touchpad re-scans (USB / Bluetooth touchpads)

LINE = re.compile(r"(GESTURE_(?:SWIPE|PINCH)_(?:BEGIN|UPDATE|END))\s+\+?[\d.]+s\s+(\d+)\s*(.*)")
DELTA = re.compile(r"\(\s*(-?[\d.]+)/\s*(-?[\d.]+)\s+unaccelerated\)")
SCALE = re.compile(r"(-?[\d.]+)\s*@")


def touchpad_nodes():
    res = []
    for dev in glob.glob("/dev/input/event*"):
        try:
            st = os.stat(dev)
            data = open(f"/run/udev/data/c{os.major(st.st_rdev)}:{os.minor(st.st_rdev)}").read()
        except OSError:
            continue
        if "E:ID_INPUT_TOUCHPAD=1" in data:
            res.append(dev)
    return sorted(res)


class Recogniser:
    def __init__(self):
        self.kind, self.fingers, self.dx, self.dy, self.scale = None, 0, 0.0, 0.0, 1.0

    def feed(self, line):
        """Returns a gesture string when one finished, else None."""
        m = LINE.search(line)
        if not m:
            return None
        ev, fingers, rest = m.group(1), int(m.group(2)), m.group(3)
        kind = "swipe" if "SWIPE" in ev else "pinch"
        if ev.endswith("BEGIN"):
            self.kind, self.fingers, self.dx, self.dy, self.scale = kind, fingers, 0.0, 0.0, 1.0
            return None
        if self.kind != kind:
            return None
        if ev.endswith("UPDATE"):
            d = DELTA.search(rest)
            if d:
                self.dx += float(d.group(1)); self.dy += float(d.group(2))
            s = SCALE.search(rest[d.end():] if d else rest)
            if s and kind == "pinch":
                self.scale = float(s.group(1))   # libinput: absolute scale since the gesture began
            return None
        # END
        self.kind = None
        if "cancelled" in rest or self.fingers < 3:
            return None   # 2-finger pinch = zoom in apps, not ours
        if kind == "pinch":
            if self.scale <= PINCH_IN:
                return f"pinch {self.fingers} in"
            if self.scale >= PINCH_OUT:
                return f"pinch {self.fingers} out"
            kind = "swipe"   # a 3-finger "pinch" that did not scale is usually a swipe libinput mis-guessed
        if max(abs(self.dx), abs(self.dy)) < SWIPE_MIN:
            return None
        if abs(self.dx) > abs(self.dy):
            return f"swipe {self.fingers} {'right' if self.dx > 0 else 'left'}"
        return f"swipe {self.fingers} {'down' if self.dy > 0 else 'up'}"


def main():
    if os.geteuid() != 0 and "--test" not in sys.argv:
        sys.exit("phoenixge-gestured must run as root (it reads the touchpad device)")
    try:
        os.unlink(SOCK)
    except FileNotFoundError:
        pass
    srv = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    srv.bind(SOCK)
    os.chmod(SOCK, 0o666)   # only gesture names are ever written to it
    srv.listen(8)
    srv.setblocking(False)
    clients, procs, last_scan = [], {}, 0.0   # procs: node -> (Popen, Recogniser)

    def send(msg):
        print(msg, flush=True)
        for c in clients[:]:
            try:
                c.sendall((msg + "\n").encode())
            except OSError:
                clients.remove(c); c.close()

    while True:
        now = time.monotonic()
        if now - last_scan > RESCAN:
            last_scan = now
            nodes = touchpad_nodes()
            for n in list(procs):
                if n not in nodes or procs[n][0].poll() is not None:
                    try:
                        procs[n][0].kill()
                    except OSError:
                        pass
                    del procs[n]
            for n in nodes:
                if n not in procs:
                    # stdbuf: libinput's stdout is block-buffered in a pipe, gestures must arrive at once
                    p = subprocess.Popen(["stdbuf", "-oL", "libinput", "debug-events", "--device", n],
                                         stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
                    procs[n] = [p, Recogniser(), b""]
                    print(f"watching {n}", flush=True)
            if not nodes and not procs:
                print("no touchpad - exiting", flush=True)
                break
        rl = [srv] + [v[0].stdout for v in procs.values()] + clients
        ready, _w, _x = select.select(rl, [], [], 2.0)
        for r in ready:
            if r is srv:
                try:
                    c, _a = srv.accept(); c.setblocking(False); clients.append(c)
                except OSError:
                    pass
            elif r in clients:   # clients never talk; readable = closed
                try:
                    if not r.recv(64):
                        raise OSError
                except BlockingIOError:
                    pass
                except OSError:
                    clients.remove(r); r.close()
            else:
                for n, v in list(procs.items()):
                    if v[0].stdout is not r:
                        continue
                    chunk = os.read(r.fileno(), 65536)
                    if not chunk:
                        v[0].kill(); del procs[n]; last_scan = 0
                        break
                    *lines, v[2] = (v[2] + chunk).split(b"\n")
                    for line in lines:
                        g = v[1].feed(line.decode(errors="replace"))
                        if g:
                            send(g)
    srv.close()
    os.unlink(SOCK)


if __name__ == "__main__":
    if "--parse" in sys.argv:   # test the recogniser on saved `libinput debug-events` output: gestured.py --parse < log
        rec = Recogniser()
        for ln in sys.stdin:
            g = rec.feed(ln)
            if g:
                print(g)
    else:
        main()
