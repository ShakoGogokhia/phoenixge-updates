"""PhoenixGe "Desktop & touchpad" - data and actions shared by the Center page and the session agent.

Touchpad settings: KWin exports every input device on the session bus
  /org/kde/KWin/InputDevice/<eventN>  interface org.kde.KWin.InputDevice
and its writable properties (tapToClick, naturalScroll, pointerAcceleration, disableWhileTyping, ...) apply at once AND
are saved by KWin itself to ~/.config/kcminputrc [Libinput][<vendor>][<product>][<name>] (decimal ids).
We talk to it with busctl (always installed with systemd) so no extra Python D-Bus module is needed.

Gestures: Plasma 6.3 has NO settings for touchpad gestures (KDE bug 402857). Built into KWin (fixed):
  4 fingers up = Overview (again = Grid), 4 down = Grid, 4 left/right = switch desktop,
  3 fingers left/right (and up/down with more than one desktop row) = switch desktop.
Everything else comes from our own small gesture service (gestured.py, root, reads ONLY touchpads) + agent.py (session).

Monitors: kscreen-doctor -j (libkscreen 6.3 keys: name, enabled, connected, priority, pos, size, scale, rotation,
currentModeId, modes). Wallpaper and taskbars: plasmashell scripting via org.kde.PlasmaShell.evaluateScript.
"""
import json
import os
import shutil
import subprocess
from pathlib import Path

HOME = Path.home()
CFG_DIR = HOME / ".config/phoenixge"
GESTURES = CFG_DIR / "gestures.json"
DESKCFG = CFG_DIR / "desktopsetup.json"
SOCKET = "/run/phoenixge-gestures.sock"
WALLDIR = Path("/usr/share/wallpapers")

DEMO = False  # set by the page's --demo


def sh(cmd, timeout=10):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout.strip(), r.stderr.strip()
    except Exception as e:  # noqa: BLE001
        return -1, "", str(e)


def load_json(p, default):
    try:
        return json.loads(Path(p).read_text())
    except Exception:  # noqa: BLE001
        return default


def save_json(p, data):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2))
    tmp.replace(p)


# ================================================================== gestures
GESTURE_KEYS = ["swipe3_up", "swipe3_down", "swipe3_left", "swipe3_right",
                "pinch3_in", "pinch3_out", "pinch4_in", "pinch4_out"]
GESTURE_LABEL = {
    "swipe3_up": "3 fingers up", "swipe3_down": "3 fingers down",
    "swipe3_left": "3 fingers left", "swipe3_right": "3 fingers right",
    "pinch3_in": "3-finger pinch in", "pinch3_out": "3-finger spread out",
    "pinch4_in": "4-finger pinch in", "pinch4_out": "4-finger spread out",
}
# Fixed in KWin 6.3 (src/plugins/overview/overvieweffect.cpp, src/virtualdesktops.cpp) - shown, not editable
BUILTIN = [("swipe4_up", "4 fingers up", "Overview (again: all desktops)"),
           ("swipe4_down", "4 fingers down", "Desktop grid"),
           ("swipe4_left", "4 fingers left", "Next / previous desktop"),
           ("swipe4_right", "4 fingers right", "Next / previous desktop")]

# action id -> (label, kglobalaccel component, shortcut name). Component "" = nothing.
ACTIONS = {
    "none": ("Nothing", "", ""),
    "builtin": ("Plasma default (switch desktop)", "", ""),
    "overview": ("Overview", "kwin", "Overview"),
    "grid": ("Desktop grid", "kwin", "Grid View"),
    "windows_desktop": ("Windows on this desktop", "kwin", "Expose"),
    "windows_all": ("All windows", "kwin", "ExposeAll"),
    "windows_app": ("Windows of the current app", "kwin", "ExposeClass"),
    "show_desktop": ("Show desktop", "kwin", "Show Desktop"),
    "desktop_next": ("Next desktop", "kwin", "Switch to Next Desktop"),
    "desktop_prev": ("Previous desktop", "kwin", "Switch to Previous Desktop"),
    "app_next": ("Switch to next app", "kwin", "Walk Through Windows"),
    "app_prev": ("Switch to previous app", "kwin", "Walk Through Windows (Reverse)"),
    "launcher": ("Open start menu", "plasmashell", "activate application launcher"),
    "search": ("Search (KRunner)", "org.kde.krunner.desktop", "_launch"),
    "maximize": ("Maximize / restore window", "kwin", "Window Maximize"),
    "minimize": ("Minimize window", "kwin", "Window Minimize"),
    "tile_left": ("Snap window left", "kwin", "Window Quick Tile Left"),
    "tile_right": ("Snap window right", "kwin", "Window Quick Tile Right"),
    "playpause": ("Play / pause media", "mediacontrol", "playpausemedia"),
    "screenshot": ("Screenshot of an area", "org.kde.spectacle.desktop", "RectangularRegionScreenShot"),
}

PRESETS = {
    "phoenixge": ("PhoenixGe (default)", {
        "swipe3_up": "overview", "swipe3_down": "show_desktop", "swipe3_left": "builtin", "swipe3_right": "builtin",
        "pinch3_in": "windows_all", "pinch3_out": "none", "pinch4_in": "launcher", "pinch4_out": "show_desktop"}),
    "windows": ("Windows-like", {
        "swipe3_up": "overview", "swipe3_down": "show_desktop", "swipe3_left": "app_prev", "swipe3_right": "app_next",
        "pinch3_in": "none", "pinch3_out": "none", "pinch4_in": "none", "pinch4_out": "none"}),
    "mac": ("Mac-like", {
        "swipe3_up": "overview", "swipe3_down": "windows_app", "swipe3_left": "builtin", "swipe3_right": "builtin",
        "pinch3_in": "none", "pinch3_out": "none", "pinch4_in": "launcher", "pinch4_out": "show_desktop"}),
    "off": ("Off", {k: "none" for k in GESTURE_KEYS}),
}
DEFAULT_PRESET = "phoenixge"


def gesture_config():
    c = load_json(GESTURES, {})
    preset = c.get("preset", DEFAULT_PRESET)
    m = dict(PRESETS.get(preset, PRESETS[DEFAULT_PRESET])[1])
    if preset == "custom":
        m.update({k: v for k, v in c.get("map", {}).items() if k in GESTURE_KEYS and v in ACTIONS})
    return preset, m


def save_gestures(preset, mapping):
    save_json(GESTURES, {"preset": preset, "map": {k: mapping.get(k, "none") for k in GESTURE_KEYS}})


def match_preset(mapping):
    for pid, (_n, m) in PRESETS.items():
        if all(m[k] == mapping.get(k) for k in GESTURE_KEYS):
            return pid
    return "custom"


def run_action(action):
    """Called by the agent. invokeShortcut runs exactly what the keyboard shortcut would run."""
    _label, comp, name = ACTIONS.get(action, ACTIONS["none"])
    if not comp:
        return False
    path = "/component/" + comp.replace(".", "_").replace("-", "_")
    code, _o, _e = sh(["gdbus", "call", "--session", "--dest", "org.kde.kglobalaccel", "--object-path", path,
                       "--method", "org.kde.kglobalaccel.Component.invokeShortcut", name], timeout=5)
    return code == 0


def gesture_service_state():
    """'running' | 'no-touchpad' | 'missing' (libinput-tools not installed)."""
    if DEMO:
        return "running"
    if not shutil.which("libinput"):
        return "missing"
    return "running" if os.path.exists(SOCKET) else "no-touchpad"


def desktop_count():
    if DEMO:
        return 2
    code, out, _ = sh(["kreadconfig6", "--file", "kwinrc", "--group", "Desktops", "--key", "Number"])
    try:
        return int(out)
    except ValueError:
        return 1


# ================================================================== touchpad (KWin InputDevice over D-Bus)
KW = ["busctl", "--user", "--json=short"]
DEV_IF = "org.kde.KWin.InputDevice"
# property -> (busctl type, label)
TP_PROPS = {
    "tapToClick": ("b", "Tap to click"),
    "tapAndDrag": ("b", "Tap and drag"),
    "naturalScroll": ("b", "Natural scrolling (content follows your fingers)"),
    "disableWhileTyping": ("b", "Ignore the touchpad while typing"),
    "clickMethodClickfinger": ("b", "Right click = press with two fingers (instead of the bottom-right corner)"),
    "disableEventsOnExternalMouse": ("b", "Turn the touchpad off while a mouse is plugged in"),
    "pointerAccelerationProfileFlat": ("b", "Flat pointer speed (no acceleration)"),
    "pointerAcceleration": ("d", "Pointer speed"),
    "scrollFactor": ("d", "Scroll speed"),
    "enabled": ("b", "Touchpad on"),
}
TP_DEFAULTS = {"tapToClick": True, "tapAndDrag": True, "disableWhileTyping": True, "naturalScroll": False,
               "clickMethodClickfinger": True}

DEMO_TOUCHPAD = {"sysName": "event7", "name": "ELAN06FA:00 04F3:31BE Touchpad", "vendor": 1267, "product": 12734,
                 "touchpad": True, "enabled": True, "tapToClick": True, "tapAndDrag": True, "naturalScroll": False,
                 "disableWhileTyping": True, "clickMethodClickfinger": True, "disableEventsOnExternalMouse": False,
                 "pointerAccelerationProfileFlat": False, "pointerAcceleration": 0.2, "scrollFactor": 1.0,
                 "tapFingerCount": 3, "supportsDisableWhileTyping": True, "supportsNaturalScroll": True,
                 "supportsClickMethodClickfinger": True, "supportsDisableEventsOnExternalMouse": True,
                 "supportsPointerAcceleration": True, "supportsPointerAccelerationProfileFlat": True,
                 "gestureSupport": True}


def _unwrap(v):
    # busctl --json=short: {"type":"b","data":true}
    return v.get("data") if isinstance(v, dict) and "data" in v else v


def touchpads():
    """List of dicts with all InputDevice properties, touchpads only. [] when KWin is not reachable."""
    if DEMO:
        return [dict(DEMO_TOUCHPAD)]
    code, out, _ = sh(KW + ["get-property", "org.kde.KWin", "/org/kde/KWin/InputDevice",
                             "org.kde.KWin.InputDeviceManager", "devicesSysNames"])
    if code != 0:
        return []
    try:
        names = _unwrap(json.loads(out)) or []
    except ValueError:
        return []
    res = []
    for n in names:
        code, out, _ = sh(KW + ["call", "org.kde.KWin", f"/org/kde/KWin/InputDevice/{n}",
                                 "org.freedesktop.DBus.Properties", "GetAll", "s", DEV_IF])
        if code != 0:
            continue
        try:
            data = json.loads(out)["data"][0]
        except (ValueError, KeyError, IndexError):
            continue
        d = {k: _unwrap(v) for k, v in data.items()}
        if d.get("touchpad"):
            res.append(d)
    return res


def set_touchpad(sysname, prop, value):
    """Applies live; KWin saves it to kcminputrc itself."""
    if DEMO:
        return True
    t = TP_PROPS[prop][0]
    val = ("true" if value else "false") if t == "b" else f"{float(value):.3f}"
    code, _o, err = sh(["busctl", "--user", "set-property", "org.kde.KWin", f"/org/kde/KWin/InputDevice/{sysname}",
                        DEV_IF, prop, t, val])
    if code != 0:  # KWin not reachable (X11 session?) -> write the file KWin reads at the next login
        return write_kcminputrc(sysname, prop, value)
    return True


_KEYMAP = {"tapToClick": "TapToClick", "tapAndDrag": "TapAndDrag", "naturalScroll": "NaturalScroll",
           "disableWhileTyping": "DisableWhileTyping", "pointerAcceleration": "PointerAcceleration",
           "scrollFactor": "ScrollFactor", "enabled": "Enabled",
           "disableEventsOnExternalMouse": "DisableEventsOnExternalMouse"}


def write_kcminputrc(dev, prop, value):
    """dev = the device dict (needs vendor/product/name). Fallback only."""
    if isinstance(dev, str) or prop not in _KEYMAP:
        return False
    v = ("true" if value else "false") if isinstance(value, bool) else f"{float(value):.3f}"
    code, _o, _e = sh(["kwriteconfig6", "--file", "kcminputrc", "--group", "Libinput", "--group", str(dev["vendor"]),
                       "--group", str(dev["product"]), "--group", dev["name"], "--key", _KEYMAP[prop], v])
    return code == 0


def apply_touchpad_defaults():
    """Automatic defaults, once per touchpad model: tap to click, tap-and-drag, ignore while typing, two-finger right
    click. Never touches a touchpad the user already set up (remembered in desktopsetup.json)."""
    cfg = load_json(DESKCFG, {})
    if cfg.get("touchpadAuto") is False:
        return []
    done = set(cfg.get("touchpadDefaultsDone", []))
    applied = []
    for d in touchpads():
        key = f"{d.get('vendor')}:{d.get('product')}:{d.get('name')}"
        if key in done:
            continue
        for prop, val in TP_DEFAULTS.items():
            if prop == "clickMethodClickfinger" and not d.get("supportsClickMethodClickfinger"):
                continue
            if prop == "disableWhileTyping" and not d.get("supportsDisableWhileTyping"):
                continue
            set_touchpad(d["sysName"], prop, val)
        done.add(key)
        applied.append(d.get("name", "?"))
    if applied:
        cfg["touchpadDefaultsDone"] = sorted(done)
        save_json(DESKCFG, cfg)
    return applied


# ================================================================== monitors
DEMO_OUTPUTS = [
    {"name": "eDP-1", "label": "Built-in screen", "enabled": True, "primary": False, "x": 0, "y": 240,
     "w": 1920, "h": 1200, "lw": 1536, "lh": 960, "scale": 1.25, "hz": 120, "rotation": 1},
    {"name": "DP-2", "label": "DELL U2723QE", "enabled": True, "primary": True, "x": 1536, "y": 0,
     "w": 2560, "h": 1440, "lw": 2560, "lh": 1440, "scale": 1.0, "hz": 144, "rotation": 1},
    {"name": "HDMI-A-1", "label": "LG 27GL850", "enabled": True, "primary": False, "x": 4096, "y": 0,
     "w": 2560, "h": 1440, "lw": 2560, "lh": 1440, "scale": 1.0, "hz": 60, "rotation": 1},
]


def outputs():
    """Enabled outputs with logical geometry (what Plasma's screenGeometry() reports)."""
    if DEMO:
        return [dict(o) for o in DEMO_OUTPUTS]
    code, out, _ = sh(["kscreen-doctor", "-j"], timeout=8)
    if code != 0 or not out:
        return []
    try:
        data = json.loads(out[out.find("{"):])
    except ValueError:
        return []
    res = []
    for o in data.get("outputs", []):
        if not (o.get("enabled") and o.get("connected", True)):
            continue
        mode = next((m for m in o.get("modes", []) if str(m.get("id")) == str(o.get("currentModeId"))), {})
        size = mode.get("size") or o.get("size") or {}
        w, h = int(size.get("width", 0)), int(size.get("height", 0))
        scale = float(o.get("scale") or 1.0)
        rot = int(o.get("rotation", 1))
        lw, lh = round(w / scale), round(h / scale)
        if rot in (2, 8):  # left / right
            lw, lh = lh, lw
        prio = o.get("priority")
        res.append({"name": o.get("name", "?"), "label": _pretty_type(o), "enabled": True,
                    "primary": prio == 1 if prio is not None else bool(o.get("primary")),
                    "x": int(o.get("pos", {}).get("x", 0)), "y": int(o.get("pos", {}).get("y", 0)),
                    "w": w, "h": h, "lw": lw, "lh": lh, "scale": scale,
                    "hz": round(float(mode.get("refreshRate", 0) or 0)), "rotation": rot})
    res.sort(key=lambda o: (o["x"], o["y"]))
    return res


def _pretty_type(o):
    n = o.get("name", "")
    if n.startswith(("eDP", "LVDS", "DSI")):
        return "Built-in screen"
    return {"DP": "DisplayPort", "HDMI": "HDMI", "DVI": "DVI", "VGA": "VGA", "Virtual": "Virtual"}.get(
        n.split("-")[0], "Monitor")


def wallpapers():
    """[(name, url, preview path)] of installed PhoenixGe wallpapers."""
    res = []
    for d in sorted(WALLDIR.glob("PhoenixGe*")):
        imgs = sorted((d / "contents/images").glob("*.*"))
        if not imgs:
            continue
        name = load_json(d / "metadata.json", {}).get("KPlugin", {}).get("Name", d.name)
        prev = next((i for i in imgs if i.name.startswith("1920x1080")), imgs[0])
        res.append((name.replace("PhoenixGe ", "") or "Phoenix", f"file://{d}/", str(prev)))
    return res


def preview_for(url):
    """Small image for a wallpaper url (package folder or single file)."""
    if not url:
        return ""
    p = Path(url.replace("file://", ""))
    if p.is_dir():
        imgs = sorted((p / "contents/images").glob("*.*"))
        return str(next((i for i in imgs if i.name.startswith("1920x1080")), imgs[0])) if imgs else ""
    return str(p) if p.exists() else ""


# ------------------------------------------------------------------ plasmashell scripting
def evaluate(js):
    """Run a Plasma desktop script. Returns (ok, printed output or error)."""
    if DEMO:
        return True, ""
    code, out, err = sh(KW + ["call", "org.kde.plasmashell", "/PlasmaShell", "org.kde.PlasmaShell", "evaluateScript",
                              "s", js], timeout=20)
    if code != 0:
        return False, err or out
    try:
        return True, str(json.loads(out)["data"][0])
    except (ValueError, KeyError, IndexError):
        return True, out


_JS_SCREEN = """
function screenOf(x, y) {   // Plasma screen number whose top-left corner is (x, y) - matches kscreen positions
  var ds = desktops();
  for (var i = 0; i < ds.length; i++) {
    if (ds[i].screen < 0) continue;
    var g = screenGeometry(ds[i].screen);
    if (Math.round(g.x) == x && Math.round(g.y) == y) return ds[i].screen;
  }
  return -1;
}
"""

JS_STATE = """
var res = {desktops: [], panels: []};
desktops().forEach(function (d) {
  if (d.screen < 0) return;
  var g = screenGeometry(d.screen);
  var plug = d.wallpaperPlugin;
  d.currentConfigGroup = ["Wallpaper", plug, "General"];
  res.desktops.push({screen: d.screen, x: Math.round(g.x), y: Math.round(g.y), plugin: plug,
                     image: String(d.readConfig("Image", ""))});
});
panels().forEach(function (p) {
  p.currentConfigGroup = ["PhoenixGe"];
  var clone = String(p.readConfig("taskbarClone", "false")) == "true";
  var only = null, tasks = false;
  p.widgets().forEach(function (w) {
    if (w.type == "org.kde.plasma.icontasks" || w.type == "org.kde.plasma.taskmanager") {
      tasks = true; w.currentConfigGroup = ["General"];
      only = String(w.readConfig("showOnlyCurrentScreen", "false")) == "true";
    }
  });
  res.panels.push({id: p.id, screen: p.screen, location: p.location, clone: clone, tasks: tasks, onlyScreen: only});
});
print(JSON.stringify(res));
"""


def plasma_state():
    if DEMO:
        return {"desktops": [{"screen": 0, "x": 1536, "y": 0, "plugin": "org.kde.image",
                              "image": "file:///usr/share/wallpapers/PhoenixGe/"},
                             {"screen": 1, "x": 0, "y": 240, "plugin": "org.kde.image",
                              "image": "file:///usr/share/wallpapers/PhoenixGe-Obsidian/"},
                             {"screen": 2, "x": 4096, "y": 0, "plugin": "org.kde.image",
                              "image": "file:///usr/share/wallpapers/PhoenixGe-CyberHUD/"}],
                "panels": [{"id": 2, "screen": 0, "location": "bottom", "clone": False, "tasks": True, "onlyScreen": True},
                           {"id": 41, "screen": 1, "location": "bottom", "clone": True, "tasks": True, "onlyScreen": True},
                           {"id": 57, "screen": 2, "location": "bottom", "clone": True, "tasks": True, "onlyScreen": True}]}
    ok, out = evaluate(JS_STATE)
    if not ok:
        return {}
    try:
        return json.loads(out.strip().splitlines()[-1])
    except (ValueError, IndexError):
        return {}


def _q(s):
    return json.dumps(str(s))


def js_wallpaper(targets):
    """targets: [{"x":..,"y":..,"url":..}] or [{"all":True,"url":..}]. Keeps the live fire wallpaper plugin if used."""
    return _JS_SCREEN + f"var T = {json.dumps(targets)};" + """
function setImage(d, url) {
  var plug = d.wallpaperPlugin;
  if (plug != "org.phoenixge.fire") { d.wallpaperPlugin = "org.kde.image"; plug = "org.kde.image"; }
  d.currentConfigGroup = ["Wallpaper", plug, "General"];
  d.writeConfig("Image", url);
}
var n = 0;
desktops().forEach(function (d) {
  if (d.screen < 0) return;
  var g = screenGeometry(d.screen);
  T.forEach(function (t) {
    if (t.all || (Math.round(g.x) == t.x && Math.round(g.y) == t.y)) { setImage(d, t.url); n++; }
  });
});
print(n);
"""


# Taskbar on every monitor. Clones carry [PhoenixGe] taskbarClone=true in their containment config so they can be
# found and removed again; running "on" twice never makes a second copy (screens that already have a taskbar are skipped).
JS_TASKBAR_COMMON = _JS_SCREEN + """
var TASKS = ["org.kde.plasma.icontasks", "org.kde.plasma.taskmanager"];
function isClone(p) { p.currentConfigGroup = ["PhoenixGe"]; return String(p.readConfig("taskbarClone", "false")) == "true"; }
function hasTasks(p) { var r = false; p.widgets().forEach(function (w) { if (TASKS.indexOf(w.type) >= 0) r = true; }); return r; }
function setOnly(only) {
  panels().forEach(function (p) {
    p.widgets().forEach(function (w) {
      if (TASKS.indexOf(w.type) < 0) return;
      w.currentConfigGroup = ["General"];
      w.writeConfig("showOnlyCurrentScreen", only ? "true" : "false");
    });
  });
}
function removeClones() { var n = 0; panels().forEach(function (p) { if (isClone(p)) { p.remove(); n++; } }); return n; }
function copyGroups(from, to) {
  ["General", "Appearance"].forEach(function (g) {
    from.currentConfigGroup = [g]; to.currentConfigGroup = [g];
    from.configKeys.forEach(function (k) { to.writeConfig(k, from.readConfig(k)); });
  });
}
function orderedWidgets(p) {
  p.currentConfigGroup = ["General"];
  var order = String(p.readConfig("AppletOrder", "")).split(";").filter(function (s) { return s.length; });
  var ids = order.length ? order.map(function (s) { return parseInt(s); }) : p.widgetIds;
  p.widgetIds.forEach(function (id) { if (ids.indexOf(id) < 0) ids.push(id); });
  return ids.map(function (id) { return p.widgetById(id); }).filter(function (w) { return w; });
}
function cloneTo(src, screen) {
  var n = new Panel;
  n.screen = screen;
  n.location = src.location;
  n.height = src.height;
  n.alignment = src.alignment;
  n.lengthMode = src.lengthMode;
  n.hiding = src.hiding;
  n.floating = src.floating;
  n.currentConfigGroup = ["PhoenixGe"];
  n.writeConfig("taskbarClone", "true");
  orderedWidgets(src).forEach(function (w) {
    if (w.type == "org.kde.plasma.systemtray") return;   // one tray (on the main screen) is enough
    var c = n.addWidget(w.type);
    if (c) copyGroups(w, c);
  });
}
"""


def js_taskbar(every, only_screen, primary_xy=None):
    """every: True = a taskbar on every monitor, False = remove our copies. only_screen: tasks filter for all taskbars."""
    px, py = primary_xy if primary_xy else (-99999, -99999)
    return JS_TASKBAR_COMMON + f"var EVERY = {json.dumps(bool(every))}; var ONLY = {json.dumps(bool(only_screen))};" \
                               f" var PX = {int(px)}, PY = {int(py)};" + """
var made = 0, removed = 0;
if (!EVERY) {
  removed = removeClones();
} else {
  var prim = screenOf(PX, PY); if (prim < 0) prim = 0;
  var own = panels().filter(function (p) { return !isClone(p) && hasTasks(p); });
  var src = own.filter(function (p) { return p.screen == prim; })[0] || own[0];
  if (src) {
    var covered = {};
    panels().forEach(function (p) { if (hasTasks(p)) covered[p.screen] = true; });
    desktops().forEach(function (d) {
      if (d.screen < 0 || covered[d.screen]) return;
      cloneTo(src, d.screen); covered[d.screen] = true; made++;
    });
  }
}
setOnly(ONLY);
print(JSON.stringify({made: made, removed: removed}));
"""


def desk_cfg():
    c = load_json(DESKCFG, {})
    c.setdefault("taskbarEvery", True)       # automatic default: a taskbar on every monitor
    c.setdefault("tasksOnlyScreen", True)    # each taskbar shows its own monitor's windows (like Windows 11)
    c.setdefault("sameWallpaper", False)
    c.setdefault("touchpadAuto", True)
    c.setdefault("monitorsAuto", True)       # re-apply taskbars/wallpaper when a monitor is plugged in
    return c


def save_desk_cfg(**kw):
    c = load_json(DESKCFG, {})
    c.update(kw)
    save_json(DESKCFG, c)


def apply_monitor_defaults():
    """Used by the agent at login and on monitor hot-plug (idempotent)."""
    c = desk_cfg()
    if not c.get("monitorsAuto"):
        return
    outs = outputs()
    prim = next((o for o in outs if o["primary"]), outs[0] if outs else None)
    if len(outs) > 1 or not c["taskbarEvery"]:
        evaluate(js_taskbar(c["taskbarEvery"], c["tasksOnlyScreen"], (prim["x"], prim["y"]) if prim else None))
    if c.get("sameWallpaper") and prim and len(outs) > 1:
        st = plasma_state()
        img = next((d["image"] for d in st.get("desktops", []) if d["x"] == prim["x"] and d["y"] == prim["y"]), "")
        if img:
            evaluate(js_wallpaper([{"all": True, "url": img}]))
