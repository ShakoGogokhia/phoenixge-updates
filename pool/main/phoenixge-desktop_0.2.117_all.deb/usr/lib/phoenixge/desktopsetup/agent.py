#!/usr/bin/env python3
"""PhoenixGe desktop agent (runs in the Plasma session, autostart).

- touchpad gestures: reads gesture names from phoenixge-gestured (/run/phoenixge-gestures.sock) and runs the action the
  user picked in PhoenixGe Center > Desktop & touchpad (~/.config/phoenixge/gestures.json, re-read when it changes)
- automatic defaults: tap to click etc. once for each new touchpad model
- monitors: when a monitor is plugged in or out, re-applies "taskbar on every monitor" / "same wallpaper everywhere"
  (idempotent scripts, see ds_data.js_taskbar)
"""
import glob
import os
import socket
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ds_data as dd  # noqa: E402

KEY = {("swipe", "3", d): f"swipe3_{d}" for d in ("up", "down", "left", "right")}
KEY.update({("pinch", f, d): f"pinch{f}_{d}" for f in ("3", "4") for d in ("in", "out")})


def connected_outputs():
    res = []
    for f in glob.glob("/sys/class/drm/card*-*/status"):
        try:
            if open(f).read().strip() == "connected":
                res.append(f.split("/")[-2])
        except OSError:
            pass
    return sorted(res)


class Agent:
    def __init__(self):
        self.sock, self.buf, self.mtime, self.map = None, b"", None, {}
        self.outs, self.outs_since = connected_outputs(), None
        self.last_try = 0.0

    def load(self):
        try:
            m = dd.GESTURES.stat().st_mtime
        except OSError:
            m = 0
        if m != self.mtime:
            self.mtime = m
            _p, self.map = dd.gesture_config()

    def connect(self):
        if self.sock or time.monotonic() - self.last_try < 15:
            return
        self.last_try = time.monotonic()
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            s.connect(dd.SOCKET)
            s.settimeout(2.0)
            self.sock, self.buf = s, b""
        except OSError:
            s.close()

    def gesture(self, msg):
        parts = msg.split()
        if len(parts) != 3:
            return
        self.load()
        key = KEY.get(tuple(parts))
        action = self.map.get(key, "none") if key else "none"
        if action not in ("none", "builtin"):
            dd.run_action(action)

    def tick(self):
        self.connect()
        if self.sock:
            try:
                data = self.sock.recv(4096)
                if not data:
                    raise OSError("closed")
                *lines, self.buf = (self.buf + data).split(b"\n")
                for ln in lines:
                    self.gesture(ln.decode(errors="replace").strip())
            except socket.timeout:
                pass
            except OSError:
                self.sock.close(); self.sock = None
        else:
            time.sleep(2)
        # monitor hot-plug: wait until the set of connected outputs is stable for 4 s, then re-apply
        now = connected_outputs()
        if now != self.outs:
            self.outs, self.outs_since = now, time.monotonic()
        elif self.outs_since and time.monotonic() - self.outs_since > 4:
            self.outs_since = None
            dd.apply_monitor_defaults()
            dd.apply_touchpad_defaults()   # a docked USB / Bluetooth touchpad


def main():
    time.sleep(3)   # let plasmashell and KWin finish starting
    try:
        dd.apply_touchpad_defaults()
        dd.apply_monitor_defaults()
    except Exception as e:  # noqa: BLE001
        print("defaults:", e, file=sys.stderr)
    a = Agent()
    a.load()
    while True:
        try:
            a.tick()
        except Exception as e:  # noqa: BLE001 - never die in the session
            print("agent:", e, file=sys.stderr)
            time.sleep(5)


if __name__ == "__main__":
    main()
