#!/bin/sh
# PhoenixGe laptop root helper: battery protection (charge limit), graphics mode, NVIDIA sleep per power state.
# Called via pkexec (/usr/bin/phoenixge-laptop, PhoenixGe Center, tray widget) and by systemd/udev:
#   charge auto|on|off|<60-100>   charge-once   charge-once-cancel
#   gpu auto|hybrid|integrated    nv-sleep ac|battery on|off      reset
#   boot   (phoenixge-laptop.service: restore after every start; firmware often resets the charge limit)
#   event  (phoenixge-laptop-event.service, from udev on plug/unplug: "charge once" end, NVIDIA sleep)
# Settings: /etc/phoenixge/laptop.conf. Everything here is reversible: "reset" brings back the defaults.
set -u
PATH=/usr/sbin:/usr/bin:/sbin:/bin
CONF=/etc/phoenixge/laptop.conf
ONCE=/var/lib/phoenixge/laptop-charge-once
GPUREBOOT=/var/lib/phoenixge/laptop-gpu-reboot
BLACKLIST=/etc/modprobe.d/00-phoenixge-gpu-integrated.conf
SYS=${PHOENIXGE_SYSROOT:-}          # tests only
SYS=${SYS%/}

[ "$(id -u)" = 0 ] || [ -n "$SYS" ] || { echo "needs root (use: phoenixge-laptop set ...)"; exit 1; }

CHARGE_MODE=auto; CHARGE_PROTECT=1; CHARGE_LIMIT=80; GPU_MODE=auto; NV_SLEEP_AC=1; NV_SLEEP_BAT=1; PERSISTENCED_WAS=0
load() {
  [ -f "$SYS$CONF" ] || return 0
  while IFS='=' read -r k v; do
    v=$(printf %s "$v" | tr -cd 'A-Za-z0-9_.-')
    case "$k" in
      CHARGE_MODE) CHARGE_MODE=$v ;; CHARGE_PROTECT) CHARGE_PROTECT=$v ;; CHARGE_LIMIT) CHARGE_LIMIT=$v ;;
      GPU_MODE) GPU_MODE=$v ;; NV_SLEEP_AC) NV_SLEEP_AC=$v ;; NV_SLEEP_BAT) NV_SLEEP_BAT=$v ;;
      PERSISTENCED_WAS) PERSISTENCED_WAS=$v ;;
    esac
  done < "$SYS$CONF"
  case "$CHARGE_LIMIT" in ''|*[!0-9]*) CHARGE_LIMIT=80 ;; esac
}
save() {
  mkdir -p "$SYS/etc/phoenixge"
  cat > "$SYS$CONF.tmp" <<EOF
# PhoenixGe laptop settings (system part) - written by /usr/lib/phoenixge/laptop-root.sh.
# Change them in PhoenixGe Center > Devices or with: phoenixge-laptop set ...
CHARGE_MODE=$CHARGE_MODE
CHARGE_PROTECT=$CHARGE_PROTECT
CHARGE_LIMIT=$CHARGE_LIMIT
GPU_MODE=$GPU_MODE
NV_SLEEP_AC=$NV_SLEEP_AC
NV_SLEEP_BAT=$NV_SLEEP_BAT
PERSISTENCED_WAS=$PERSISTENCED_WAS
EOF
  mv "$SYS$CONF.tmp" "$SYS$CONF"
}

# ---------------------------------------------------------------- hardware
IDEAPAD=""; END=""; START=""; BAT=""
for f in "$SYS"/sys/bus/platform/drivers/ideapad_acpi/*/conservation_mode; do [ -e "$f" ] && { IDEAPAD=$f; break; }; done
for b in "$SYS"/sys/class/power_supply/*; do
  [ "$(cat "$b/type" 2>/dev/null)" = Battery ] || continue
  [ "$(cat "$b/scope" 2>/dev/null)" = Device ] && continue
  [ -n "$BAT" ] || BAT=$b
  if [ -z "$END" ] && [ -e "$b/charge_control_end_threshold" ]; then
    END=$b/charge_control_end_threshold; [ -e "$b/charge_control_start_threshold" ] && START=$b/charge_control_start_threshold
  fi
done

ac_online() {   # 0 = charger connected
  seen=1
  for s in "$SYS"/sys/class/power_supply/*; do
    case "$(cat "$s/type" 2>/dev/null)" in Mains|USB|USB_C|USB_PD|USB_PD_DRP) ;; *) continue ;; esac
    [ -e "$s/online" ] || continue
    seen=0
    [ "$(cat "$s/online" 2>/dev/null)" = 1 ] && return 0
  done
  [ $seen = 0 ] && return 1
  [ -n "$BAT" ] && [ "$(cat "$BAT/status" 2>/dev/null)" != Discharging ]
}

has_igpu() {
  for d in "$SYS"/sys/bus/pci/devices/*; do
    case "$(cat "$d/class" 2>/dev/null)" in 0x03*) ;; *) continue ;; esac
    [ "$(cat "$d/vendor" 2>/dev/null)" != 0x10de ] && return 0
  done
  return 1
}

nvidia_devices() {   # display functions first is NOT wanted for removal -> print class too
  for d in "$SYS"/sys/bus/pci/devices/*; do
    [ "$(cat "$d/vendor" 2>/dev/null)" = 0x10de ] && echo "$(cat "$d/class" 2>/dev/null) $d"
  done
}

# ---------------------------------------------------------------- charge limit
set_threshold() {   # $1 = end threshold 1..100
  if [ -n "$START" ]; then
    s=$(cat "$START" 2>/dev/null || echo 0)
    if [ "$1" -lt 100 ] && [ "${s:-0}" -ge "$1" ]; then echo $(( $1 > 10 ? $1 - 10 : 0 )) > "$START" 2>/dev/null; fi
  fi
  echo "$1" > "$END" 2>/dev/null || { echo "The battery driver refused $1% - this model may only accept some values (e.g. 60, 80, 100)."; return 1; }
  echo "Charge limit now $(cat "$END")%."
}

apply_charge() {
  want=$CHARGE_PROTECT
  [ -f "$SYS$ONCE" ] && want=0
  if [ -n "$IDEAPAD" ]; then
    echo "$want" > "$IDEAPAD" 2>/dev/null || { echo "Could not change conservation mode."; return 1; }
    [ "$(cat "$IDEAPAD")" = 1 ] && echo "Battery protection (Lenovo conservation mode) is ON." || echo "Battery protection is OFF - charging to 100%."
  elif [ -n "$END" ]; then
    if [ "$want" = 1 ]; then set_threshold "$CHARGE_LIMIT"; else set_threshold 100; fi
  else
    echo "This laptop does not let Linux limit charging."; return 2
  fi
}

once_check() {   # end "charge to 100% once" when full or after the charger was unplugged
  [ -f "$SYS$ONCE" ] || return 0
  if ac_online; then
    echo seen-ac > "$SYS$ONCE"
    st=$(cat "$BAT/status" 2>/dev/null); cap=$(cat "$BAT/capacity" 2>/dev/null || echo 0)
    if [ "$st" = Full ] || [ "${cap:-0}" -ge 100 ]; then rm -f "$SYS$ONCE"; echo "Battery full - protection back on."; apply_charge; fi
  elif grep -q seen-ac "$SYS$ONCE" 2>/dev/null; then
    rm -f "$SYS$ONCE"; echo "Charger unplugged - protection back on."; apply_charge
  fi
}

# ---------------------------------------------------------------- NVIDIA sleep (runtime D3)
apply_nv_sleep() {
  if ac_online; then v=$NV_SLEEP_AC; else v=$NV_SLEEP_BAT; fi
  [ "$v" = 1 ] && pc=auto || pc=on
  nvidia_devices | while read -r cls d; do
    case "$cls" in 0x0300*|0x0302*) [ -L "$d/driver" ] && echo "$pc" > "$d/power/control" 2>/dev/null ;; esac
  done
  return 0
}

# ---------------------------------------------------------------- graphics mode
mark_reboot() { mkdir -p "$SYS/var/lib/phoenixge"; cat "$SYS/proc/sys/kernel/random/boot_id" > "$SYS$GPUREBOOT" 2>/dev/null || true; }
rebuild_initramfs() {
  [ -n "$SYS" ] && return 0
  echo "Updating the boot image (initramfs) - about a minute..."
  if command -v systemd-inhibit >/dev/null; then systemd-inhibit --why="PhoenixGe graphics mode" update-initramfs -u -k all
  else update-initramfs -u -k all; fi
}

write_blacklist() {
  mkdir -p "$SYS/etc/modprobe.d"
  cat > "$SYS$BLACKLIST" <<'EOF'
# PhoenixGe graphics mode "Integrated": the NVIDIA card is switched off (like envycontrol's integrated mode).
# Undo: PhoenixGe Center > Devices > Graphics > Hybrid, or: sudo sh /usr/lib/phoenixge/laptop-root.sh gpu hybrid
blacklist nouveau
blacklist nvidia
blacklist nvidia_drm
blacklist nvidia_modeset
blacklist nvidia_uvm
blacklist nvidia_peermem
blacklist nvidia_current
blacklist nvidia_current_drm
blacklist nvidia_current_modeset
blacklist nvidia_current_uvm
blacklist nvidia_current_peermem
options nouveau modeset=0
install nouveau /bin/false
install nvidia /bin/false
install nvidia_drm /bin/false
install nvidia_modeset /bin/false
install nvidia_uvm /bin/false
install nvidia_current /bin/false
install nvidia_current_drm /bin/false
install nvidia_current_modeset /bin/false
install nvidia_current_uvm /bin/false
EOF
}

gpu_set() {
  [ -d "$SYS/run/live" ] && { echo "Graphics modes can only be changed on the installed system."; return 1; }
  case "$1" in
    auto|hybrid)
      GPU_MODE=$1
      if [ -f "$SYS$BLACKLIST" ]; then
        rm -f "$SYS$BLACKLIST"
        [ "$PERSISTENCED_WAS" = 1 ] && [ -z "$SYS" ] && systemctl enable nvidia-persistenced.service >/dev/null 2>&1
        PERSISTENCED_WAS=0; save
        rebuild_initramfs; mark_reboot
        echo "Hybrid mode set: restart the computer to switch the NVIDIA card back on."
      else
        save; rm -f "$SYS$GPUREBOOT"; echo "Hybrid mode is active (NVIDIA sleeps when nothing uses it)."
      fi ;;
    integrated)
      has_igpu || { echo "No integrated graphics found (the BIOS may be in 'dGPU only' mode) - Integrated mode would leave you without a screen. Not changed."; return 3; }
      GPU_MODE=integrated
      if [ ! -f "$SYS$BLACKLIST" ]; then
        if [ -z "$SYS" ] && systemctl is-enabled nvidia-persistenced.service >/dev/null 2>&1; then
          PERSISTENCED_WAS=1; systemctl disable nvidia-persistenced.service >/dev/null 2>&1
        fi
        write_blacklist; save; rebuild_initramfs; mark_reboot
        echo "Integrated mode set: restart the computer. The NVIDIA card will be powered off."
      else
        save; echo "Integrated mode is already set."
      fi ;;
    *) echo "gpu: auto | hybrid | integrated (NVIDIA-only is a BIOS setting on most laptops)"; return 2 ;;
  esac
}

gpu_boot() {
  [ -f "$SYS$BLACKLIST" ] || return 0
  if ! has_igpu; then
    # safety net: firmware switched to dGPU-only while we had the NVIDIA card disabled -> undo, keep a screen
    echo "Integrated graphics missing (BIOS dGPU mode?) - undoing PhoenixGe Integrated mode."
    rm -f "$SYS$BLACKLIST"; GPU_MODE=auto; save
    mkdir -p "$SYS/var/lib/phoenixge"; echo "gpu-safety $(date)" > "$SYS/var/lib/phoenixge/laptop-gpu-safety"
    [ -z "$SYS" ] && { modprobe nvidia-drm 2>/dev/null || modprobe nvidia-current-drm 2>/dev/null; (update-initramfs -u -k all >/dev/null 2>&1 &) ; }
    return 0
  fi
  # power off and remove the NVIDIA functions (audio/USB/UCSI first, then the GPU itself)
  nvidia_devices | sort -r | while read -r cls d; do
    echo auto > "$d/power/control" 2>/dev/null
    echo 1 > "$d/remove" 2>/dev/null && echo "NVIDIA $cls removed (Integrated mode)."
  done
  return 0
}

# ---------------------------------------------------------------- main
load
cmd=${1:-}; arg=${2:-}; arg2=${3:-}
case "$cmd" in
  charge)
    case "$arg" in
      auto) CHARGE_MODE=auto; CHARGE_PROTECT=1; CHARGE_LIMIT=80; rm -f "$SYS$ONCE" ;;
      on)   CHARGE_MODE=manual; CHARGE_PROTECT=1 ;;
      off)  CHARGE_MODE=manual; CHARGE_PROTECT=0; rm -f "$SYS$ONCE" ;;
      *[!0-9]*|'') echo "charge: auto | on | off | 60-100"; exit 2 ;;
      *) [ "$arg" -ge 50 ] && [ "$arg" -le 100 ] || { echo "charge limit must be 50-100"; exit 2; }
         CHARGE_MODE=manual; rm -f "$SYS$ONCE"
         if [ "$arg" = 100 ]; then CHARGE_PROTECT=0; else CHARGE_PROTECT=1; CHARGE_LIMIT=$arg; fi ;;
    esac
    [ -n "$IDEAPAD$END" ] || { echo "This laptop does not let Linux limit charging."; exit 2; }
    save; apply_charge ;;
  charge-once)
    [ -n "$IDEAPAD$END" ] || { echo "This laptop does not let Linux limit charging."; exit 2; }
    mkdir -p "$SYS/var/lib/phoenixge"; : > "$SYS$ONCE"
    ac_online && echo seen-ac > "$SYS$ONCE"
    apply_charge
    echo "Charging to 100% once. Protection comes back when the battery is full or the charger is unplugged." ;;
  charge-once-cancel)
    rm -f "$SYS$ONCE"; apply_charge ;;
  gpu)
    gpu_set "$arg" ;;
  nv-sleep)
    case "$arg2" in on) v=1 ;; off) v=0 ;; *) echo "nv-sleep ac|battery on|off"; exit 2 ;; esac
    case "$arg" in ac) NV_SLEEP_AC=$v ;; battery) NV_SLEEP_BAT=$v ;; *) echo "nv-sleep ac|battery on|off"; exit 2 ;; esac
    save; apply_nv_sleep; echo "NVIDIA sleep when idle: on charger $NV_SLEEP_AC, on battery $NV_SLEEP_BAT (1 = sleeps)." ;;
  reset)
    CHARGE_MODE=auto; CHARGE_PROTECT=1; CHARGE_LIMIT=80; NV_SLEEP_AC=1; NV_SLEEP_BAT=1; rm -f "$SYS$ONCE"
    save
    [ -n "$IDEAPAD$END" ] && apply_charge
    apply_nv_sleep
    gpu_set auto ;;
  boot)
    gpu_boot
    if [ -n "$IDEAPAD$END" ]; then
      if [ -f "$SYS$ONCE" ] && ! ac_online; then rm -f "$SYS$ONCE"; fi
      apply_charge
    fi
    apply_nv_sleep
    rm -f "$SYS$GPUREBOOT" ;;
  event)
    [ -n "$IDEAPAD$END" ] && once_check
    apply_nv_sleep ;;
  *) sed -n '2,8p' "$0"; exit 2 ;;
esac
