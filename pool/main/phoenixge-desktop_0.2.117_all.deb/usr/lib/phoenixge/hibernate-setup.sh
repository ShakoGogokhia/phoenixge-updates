#!/bin/sh
# PhoenixGe hibernation (PhoenixGe Center > Hibernate). Run as root (pkexec).
#   hibernate-setup.sh enable [SIZE_MB]     swap big enough for RAM + resume= in GRUB/initramfs + "Hibernate" in Plasma
#   hibernate-setup.sh disable              undo everything enable did
#   hibernate-setup.sh delay SECONDS|off    "sleep, then hibernate after ..." (systemd HibernateDelaySec)
# Swap: an existing swap partition >= RAM is used as is. Otherwise a swap FILE:
#   btrfs: /swap/swapfile in the @swap subvolume (created and mounted at /swap if Calamares didn't),
#          made with "btrfs filesystem mkswapfile" (no copy-on-write), offset from "btrfs inspect-internal map-swapfile"
#   ext4/xfs: /swapfile (fallocate), offset from filefrag
# Everything it changes is recorded in /var/lib/phoenixge/hibernate.state so "disable" can undo exactly that.
set -u
export LC_ALL=C
ST=/var/lib/phoenixge/hibernate.state
GRUBCFG=/etc/default/grub.d/phoenixge-resume.cfg
INITRD=/etc/initramfs-tools/conf.d/resume
SLEEP=/etc/systemd/sleep.conf.d/phoenixge-hibernate.conf
POLKIT=/etc/polkit-1/rules.d/50-phoenixge-hibernate.rules
MARK="# phoenixge-hibernate"
say() { echo "$*"; }
die() { echo "NOT POSSIBLE: $*" >&2; exit 3; }

[ "$(id -u)" = 0 ] || { echo "run as root" >&2; exit 1; }
[ -d /run/live ] && die "this is the live session - install PhoenixGe first."
mkdir -p /var/lib/phoenixge

setstate() { # KEY VALUE
  touch "$ST"; sed -i "/^$1=/d" "$ST"; echo "$1=$2" >> "$ST"
}
getstate() { sed -n "s/^$1=//p" "$ST" 2>/dev/null | tail -n 1; }

check_kernel() {
  grep -qw disk /sys/power/state 2>/dev/null || die "this kernel can't hibernate (no 'disk' in /sys/power/state)."
  if grep -q '\[disabled\]' /sys/power/disk 2>/dev/null; then
    if grep -Eq '\[(integrity|confidentiality)\]' /sys/kernel/security/lockdown 2>/dev/null; then
      die "Secure Boot is on - the kernel locks hibernation (lockdown). Turn Secure Boot off in the firmware setup to use it."
    fi
    die "hibernation is disabled by the kernel (/sys/power/disk)."
  fi
}

update_boot() {
  say "--- updating the boot files (initramfs + GRUB), this takes a minute"
  update-initramfs -u -k all || say "!!! update-initramfs failed"
  if command -v update-grub >/dev/null 2>&1; then update-grub || say "!!! update-grub failed"; fi
}

swap_partition() { # an active swap partition >= NEED_KB -> its device
  awk -v need="$1" 'NR>1 && $2=="partition" && $1 !~ /zram/ && $3>=need {print $1; exit}' /proc/swaps
}

enable() {
  check_kernel
  RAM_KB=$(awk '/^MemTotal:/{print $2}' /proc/meminfo)
  GIB=$(( (RAM_KB + 1048575) / 1048576 ))                 # RAM rounded up to whole GiB
  [ -n "${1:-}" ] && GIB=$(( (${1} + 1023) / 1024 ))
  NEED_KB=$(( RAM_KB * 95 / 100 ))
  PART=$(swap_partition "$NEED_KB")
  OFFSET=""
  if [ -n "$PART" ]; then
    say "Using the swap partition $PART (big enough for ${GIB} GB of RAM)."
    RES="UUID=$(blkid -s UUID -o value "$PART")"
    setstate MODE partition
  else
    FS=$(findmnt -no FSTYPE /)
    case "$FS" in
      btrfs)
        SWAPDIR=/swap; FILE=/swap/swapfile
        if [ "$(findmnt -no FSTYPE "$SWAPDIR" 2>/dev/null)" != btrfs ]; then
          DEV=$(findmnt -no SOURCE / | sed 's/\[.*//')
          FSUUID=$(findmnt -no UUID /)
          T=$(mktemp -d)
          mount -o subvolid=5 "$DEV" "$T" || die "can't open the btrfs volume."
          if [ ! -d "$T/@swap" ]; then
            btrfs subvolume create "$T/@swap" >/dev/null || { umount "$T"; die "can't create the @swap subvolume."; }
            setstate SUBVOL_CREATED 1
          fi
          umount "$T"; rmdir "$T"
          mkdir -p "$SWAPDIR"
          if ! grep -q "[[:space:]]$SWAPDIR[[:space:]]" /etc/fstab; then
            echo "UUID=$FSUUID $SWAPDIR btrfs subvol=/@swap,noatime 0 0 $MARK" >> /etc/fstab
            setstate FSTAB_SUBVOL 1
          fi
          mount "$SWAPDIR" || die "can't mount /swap."
        fi
        ;;
      ext4|xfs) FILE=/swapfile ;;
      *) die "the system disk uses $FS - hibernation with a swap file needs btrfs, ext4 or xfs." ;;
    esac
    # enough space? (size + 3 GB left over)
    CUR_KB=0; [ -f "$FILE" ] && CUR_KB=$(( $(stat -c %s "$FILE") / 1024 ))
    FREE_KB=$(df -Pk "$(dirname "$FILE")" | awk 'NR==2{print $4}')
    WANT_KB=$(( GIB * 1048576 ))
    if [ "$CUR_KB" -lt "$WANT_KB" ] && [ $(( FREE_KB + CUR_KB )) -lt $(( WANT_KB + 3 * 1048576 )) ]; then
      die "not enough free disk space: a ${GIB} GB swap file is needed (plus 3 GB to spare), only $(( (FREE_KB + CUR_KB) / 1048576 )) GB free."
    fi
    if [ "$CUR_KB" -ge "$WANT_KB" ]; then
      say "Reusing $FILE ($(( CUR_KB / 1048576 )) GB)."
    else
      if [ -f "$FILE" ]; then
        say "Making $FILE bigger (${GIB} GB)."
        swapoff "$FILE" 2>/dev/null; rm -f "$FILE"
      else
        say "Creating a ${GIB} GB swap file $FILE."
        setstate FILE_CREATED 1
      fi
      if [ "$FS" = btrfs ]; then
        btrfs filesystem mkswapfile --size "${GIB}g" "$FILE" >/dev/null || die "btrfs could not create the swap file."
      else
        fallocate -l "${GIB}G" "$FILE" || dd if=/dev/zero of="$FILE" bs=1M count=$(( GIB * 1024 )) status=none || die "could not create the swap file."
        chmod 600 "$FILE"; mkswap "$FILE" >/dev/null || die "mkswap failed."
      fi
    fi
    grep -q "^$FILE[[:space:]]" /proc/swaps || swapon "$FILE" || die "swapon $FILE failed."
    if ! grep -q "^$FILE[[:space:]]" /etc/fstab; then
      echo "$FILE none swap defaults 0 0 $MARK" >> /etc/fstab
      setstate FSTAB_FILE 1
    fi
    RES="UUID=$(findmnt -no UUID -T "$FILE")"
    if [ "$FS" = btrfs ]; then
      OFFSET=$(btrfs inspect-internal map-swapfile -r "$FILE")
    else
      OFFSET=$(filefrag -v "$FILE" | awk '$1=="0:"{gsub(/\.\./,"",$4); print $4; exit}')
    fi
    [ -n "$OFFSET" ] || die "could not find where the swap file starts on the disk."
    setstate MODE file; setstate FILE "$FILE"
  fi
  # remember what was there before
  if [ -f "$INITRD" ] && [ -z "$(getstate INITRD_SAVED)" ]; then cp -a "$INITRD" /var/lib/phoenixge/hibernate.resume.orig; setstate INITRD_SAVED 1; fi
  [ -n "$(getstate INITRD_SAVED)" ] || setstate INITRD_SAVED 0
  echo "RESUME=$RES" > "$INITRD"
  mkdir -p /etc/default/grub.d
  {
    echo "# PhoenixGe hibernation (PhoenixGe Center > Hibernate) - remove with: hibernate-setup.sh disable"
    echo "GRUB_CMDLINE_LINUX_DEFAULT=\"\$GRUB_CMDLINE_LINUX_DEFAULT resume=$RES${OFFSET:+ resume_offset=$OFFSET}\""
  } > "$GRUBCFG"
  mkdir -p "$(dirname "$SLEEP")"
  DELAY=$(getstate DELAY)
  {
    echo "# PhoenixGe hibernation"
    echo "[Sleep]"
    echo "AllowHibernation=yes"
    echo "AllowSuspendThenHibernate=yes"
    echo "AllowHybridSleep=yes"
    [ -n "$DELAY" ] && [ "$DELAY" != off ] && echo "HibernateDelaySec=$DELAY"
  } > "$SLEEP"
  mkdir -p "$(dirname "$POLKIT")"
  cat > "$POLKIT" <<'P'
// PhoenixGe: people sitting at the computer may hibernate it without a password (like suspend)
polkit.addRule(function (action, subject) {
    if ((action.id == "org.freedesktop.login1.hibernate" ||
         action.id == "org.freedesktop.login1.hibernate-multiple-sessions" ||
         action.id == "org.freedesktop.login1.suspend-then-hibernate") && subject.local && subject.active) {
        return polkit.Result.YES;
    }
});
P
  # tell the running kernel already, so "Hibernate" works before the next restart
  DEVNODE=$(blkid -U "${RES#UUID=}" 2>/dev/null)
  if [ -n "$DEVNODE" ]; then
    MM=$(lsblk -dno MAJ:MIN "$DEVNODE" 2>/dev/null | head -n 1 | tr -d ' ')
    [ -n "$OFFSET" ] && echo "$OFFSET" > /sys/power/resume_offset 2>/dev/null
    [ -n "$MM" ] && echo "$MM" > /sys/power/resume 2>/dev/null
  fi
  setstate RESUME "$RES"; setstate OFFSET "$OFFSET"; setstate ENABLED 1
  update_boot
  systemctl daemon-reload 2>/dev/null || true
  say "DONE - hibernation is on. Restart once; after that \"Hibernate\" is in the power menu."
}

disable() {
  [ -f "$ST" ] || { say "Hibernation was not set up by PhoenixGe - nothing to undo."; exit 0; }
  FILE=$(getstate FILE)
  rm -f "$GRUBCFG" "$SLEEP" "$POLKIT"
  if [ "$(getstate INITRD_SAVED)" = 1 ] && [ -f /var/lib/phoenixge/hibernate.resume.orig ]; then
    cp -a /var/lib/phoenixge/hibernate.resume.orig "$INITRD"; rm -f /var/lib/phoenixge/hibernate.resume.orig
  else
    rm -f "$INITRD"
  fi
  if [ -n "$FILE" ] && [ "$(getstate FILE_CREATED)" = 1 ]; then
    swapoff "$FILE" 2>/dev/null; rm -f "$FILE"; say "Removed $FILE (disk space is free again)."
  fi
  # remove only the fstab lines PhoenixGe added
  if grep -q "$MARK\$" /etc/fstab; then
    [ "$(getstate FSTAB_SUBVOL)" = 1 ] && umount /swap 2>/dev/null
    sed -i "\\|$MARK\$|d" /etc/fstab
  fi
  if [ "$(getstate SUBVOL_CREATED)" = 1 ]; then
    DEV=$(findmnt -no SOURCE / | sed 's/\[.*//'); T=$(mktemp -d)
    if mount -o subvolid=5 "$DEV" "$T"; then
      [ -d "$T/@swap" ] && [ -z "$(ls -A "$T/@swap")" ] && btrfs subvolume delete "$T/@swap" >/dev/null 2>&1
      umount "$T"
    fi
    rmdir "$T" 2>/dev/null; rmdir /swap 2>/dev/null
  fi
  rm -f "$ST"
  update_boot
  systemctl daemon-reload 2>/dev/null || true
  say "DONE - hibernation is off."
}

delay() {
  V=${1:-off}
  case "$V" in off|[0-9]*) ;; *) echo "delay: seconds or off" >&2; exit 2 ;; esac
  setstate DELAY "$V"
  if [ -f "$SLEEP" ]; then
    sed -i '/^HibernateDelaySec=/d' "$SLEEP"
    [ "$V" != off ] && echo "HibernateDelaySec=$V" >> "$SLEEP"
  fi
  say "DONE - sleep then hibernate: $([ "$V" = off ] && echo off || echo "after $((V / 60)) minutes")."
}

case "${1:-}" in
  enable) enable "${2:-}" ;;
  disable) disable ;;
  delay) delay "${2:-off}" ;;
  *) sed -n '2,10p' "$0" | sed 's/^# \{0,1\}//'; exit 2 ;;
esac
