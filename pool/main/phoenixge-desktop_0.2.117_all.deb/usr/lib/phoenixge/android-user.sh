#!/bin/sh
# Start the Android session for this user, enable app windows on the desktop, install F-Droid (free app store).
waydroid session start >/dev/null 2>&1 &
for i in $(seq 1 90); do waydroid status 2>/dev/null | grep -q 'Session:.*RUNNING' && break; sleep 2; done
waydroid prop set persist.waydroid.multi_windows true
if ! waydroid app list 2>/dev/null | grep -q org.fdroid.fdroid; then
  curl -fsSL -o /tmp/F-Droid.apk https://f-droid.org/F-Droid.apk && waydroid app install /tmp/F-Droid.apk && echo "F-Droid installed."
fi
echo "Android apps now appear in the start menu. Install more from F-Droid or with 'Install APK'."
