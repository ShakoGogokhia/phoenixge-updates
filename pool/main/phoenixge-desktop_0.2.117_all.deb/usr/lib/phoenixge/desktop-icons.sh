#!/bin/sh
# PhoenixGe desktop at login. Owner: a clean desktop - only the Trash (apps live in the start menu, the
# taskbar and PhoenixGe Center). Shortcuts that earlier versions put here are removed once.
DESK=$(xdg-user-dir DESKTOP 2>/dev/null)
[ -n "$DESK" ] || DESK="$HOME/Desktop"
DONE="$HOME/.local/share/phoenixge/desktop-icons.done"
mkdir -p "$DESK" "$(dirname "$DONE")" "$HOME/Games" "$HOME/Windows Apps"

# one-time cleanup of the shortcuts from earlier PhoenixGe versions (only files PhoenixGe created)
if ! grep -qx "v3-clean" "$DONE" 2>/dev/null; then
  for f in 01-home 02-games 03-windows-apps 05-center 06-store 07-android 08-themes 09-gamemode \
           phoenixge-center phoenix-toolbox ge.chatlaxi.ai firefox-esr net.lutris.Lutris com.valvesoftware.Steam \
           com.heroicgameslauncher.hgl com.discordapp.Discord org.prismlauncher.PrismLauncher; do
    rm -f "$DESK/$f.desktop"
  done
  echo "v3-clean" >> "$DONE"
fi

if ! grep -qx "04-trash" "$DONE" 2>/dev/null; then
  printf '[Desktop Entry]\nType=Link\nName=Trash\nURL=trash:/\nIcon=phoenixge-trash\n' > "$DESK/04-trash.desktop"
  chmod +x "$DESK/04-trash.desktop"
  echo "04-trash" >> "$DONE"
fi
