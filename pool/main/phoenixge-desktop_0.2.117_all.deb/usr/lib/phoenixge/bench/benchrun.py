"""PhoenixGe benchmark - "Is my PC OK?" (about 2-3 minutes). Used by PhoenixGe Center > Benchmark, works alone too:

    python3 benchrun.py [--skip cpu,ram,disk,gpu] [--json]

Prints one JSON object per line (for the Center), or readable text without --json:
  {"ev": "stage", "id": ..., "title": ..., "n": i, "of": n, "secs": estimated seconds}
  {"ev": "sample", "t": s, "cpu_temp": C, "cpu_mhz": MHz, "gpu_temp": C, "gpu_mhz": MHz, "gpu_power": W}
  {"ev": "result", "id": ..., ...}
  {"ev": "done", "run": {...}}             (the run is also saved in ~/.local/share/phoenixge/bench.json)

Tools (Debian packages): 7zip (CPU: '7z b'), sysbench (RAM, also CPU fallback), fio (disk; dd fallback),
vkmark (GPU, Vulkan, headless - no window, no vsync), nvidia-smi (NVIDIA temperatures / throttle reasons).
Missing tools -> that test is skipped with a note, never a crash. Nothing here needs root.
"""
import argparse
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import benchref  # noqa: E402

TMP = Path.home() / ".cache/phoenixge/bench-disk.tmp"
JSON_OUT = False
CHILD = {"p": None}
STOP = {"now": False}


def emit(**kw):
    if JSON_OUT:
        print(json.dumps(kw), flush=True)
    elif kw["ev"] == "stage":
        print(f"[{kw['n']}/{kw['of']}] {kw['title']} (~{kw['secs']} s)", flush=True)
    elif kw["ev"] == "result":
        print("   ", {k: v for k, v in kw.items() if k != "ev"}, flush=True)


def run(cmd, timeout=300, env=None):
    """Run a test tool, killable by Cancel. Returns (returncode, output)."""
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, env=env,
                             start_new_session=True)
    except OSError as e:
        return -1, str(e)
    CHILD["p"] = p
    try:
        out, _ = p.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        os.killpg(p.pid, signal.SIGKILL)
        out, _ = p.communicate()
        return -2, out or ""
    finally:
        CHILD["p"] = None
    return p.returncode, out or ""


def sh(cmd, timeout=5):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return ""


# ------------------------------------------------------------------ live sensors
def _read(p, default=""):
    try:
        return Path(p).read_text().strip()
    except OSError:
        return default


def cpu_temp():
    best = None
    for hw in Path("/sys/class/hwmon").glob("hwmon*"):
        name = _read(hw / "name")
        if name not in ("coretemp", "k10temp", "zenpower", "cpu_thermal", "acpitz"):
            continue
        for t in hw.glob("temp*_input"):
            label = _read(str(t).replace("_input", "_label"))
            if name == "coretemp" and label and not label.startswith("Package"):
                continue
            if name in ("k10temp", "zenpower") and label not in ("Tctl", "Tdie", ""):
                continue
            try:
                v = int(_read(t, "0")) / 1000
            except ValueError:
                continue
            if name == "acpitz" and best is not None:
                continue
            best = max(best or 0, v)
        if best is not None and name != "acpitz":
            return best
    return best


def cpu_mhz():
    vals = []
    for f in Path("/sys/devices/system/cpu").glob("cpu[0-9]*/cpufreq/scaling_cur_freq"):
        try:
            vals.append(int(_read(f, "0")) / 1000)
        except ValueError:
            pass
    return round(sum(vals) / len(vals)) if vals else None


def cpu_max_mhz():
    vals = []
    for f in Path("/sys/devices/system/cpu").glob("cpu[0-9]*/cpufreq/cpuinfo_max_freq"):
        try:
            vals.append(int(_read(f, "0")) / 1000)
        except ValueError:
            pass
    return round(max(vals)) if vals else None


def throttle_count():
    """Intel: number of times the CPU package was thermally throttled since boot (readable by users)."""
    tot = 0
    for f in Path("/sys/devices/system/cpu").glob("cpu[0-9]*/thermal_throttle/package_throttle_count"):
        try:
            tot = max(tot, int(_read(f, "0")))
        except ValueError:
            pass
    return tot


NV_FIELDS = "temperature.gpu,clocks.sm,clocks.max.sm,power.draw,utilization.gpu,clocks_throttle_reasons.active"


def nvidia_sample():
    if not shutil.which("nvidia-smi"):
        return None
    out = sh(["nvidia-smi", f"--query-gpu={NV_FIELDS}", "--format=csv,noheader,nounits"], 4)
    if not out:
        return None
    parts = [x.strip() for x in out.splitlines()[0].split(",")]

    def num(x):
        try:
            return float(x)
        except ValueError:
            return None
    try:
        reasons = int(parts[5], 16) if len(parts) > 5 and parts[5].startswith("0x") else 0
    except ValueError:
        reasons = 0
    return dict(gpu_temp=num(parts[0]), gpu_mhz=num(parts[1]), gpu_max_mhz=num(parts[2]), gpu_power=num(parts[3]),
                gpu_util=num(parts[4]), gpu_reasons=reasons)


def amd_gpu_sample():
    for hw in Path("/sys/class/hwmon").glob("hwmon*"):
        if _read(hw / "name") == "amdgpu":
            dev = hw / "device"
            try:
                t = int(_read(hw / "temp1_input", "0")) / 1000
            except ValueError:
                t = None
            busy = _read(dev / "gpu_busy_percent")
            return dict(gpu_temp=t, gpu_util=float(busy) if busy.isdigit() else None)
    return None


class Monitor(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self.samples, self.stage, self.stop, self.t0 = [], "idle", False, time.time()
        self.nvidia = bool(shutil.which("nvidia-smi")) and Path("/proc/driver/nvidia/version").exists()

    def run(self):
        n = 0
        while not self.stop:
            s = dict(t=round(time.time() - self.t0, 1), stage=self.stage, cpu_temp=cpu_temp(), cpu_mhz=cpu_mhz())
            if n % 2 == 0:
                g = nvidia_sample() if self.nvidia else amd_gpu_sample()
                if g:
                    s.update(g)
            self.samples.append(s)
            emit(ev="sample", **{k: v for k, v in s.items() if v is not None})
            n += 1
            time.sleep(1)


# ------------------------------------------------------------------ system facts
def system_info():
    model = ""
    for line in _read("/proc/cpuinfo").splitlines():
        if line.startswith("model name"):
            model = line.split(":", 1)[1].strip(); break
    threads = os.cpu_count() or 1
    mem = 0
    for line in _read("/proc/meminfo").splitlines():
        if line.startswith("MemTotal"):
            mem = int(line.split()[1]) // 1024
    ac, battery = None, False
    for ps in Path("/sys/class/power_supply").glob("*"):
        typ = _read(ps / "type")
        if typ == "Mains":
            ac = (ac or False) or _read(ps / "online") == "1"
        elif typ == "Battery" and _read(ps / "scope", "System") != "Device":
            battery = True
    profile = sh(["powerprofilesctl", "get"]) if shutil.which("powerprofilesctl") else ""
    gov = _read("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor")
    gpus = []
    for line in sh(["lspci", "-nn"]).splitlines():
        if re.search(r"VGA compatible|3D controller|Display controller", line):
            gpus.append(re.sub(r"^\S+\s+[^:]+:\s*", "", line))
    nv_present = any("NVIDIA" in g for g in gpus)
    nv_ver = _read("/proc/driver/nvidia/version")
    m = re.search(r"Kernel Module\s+(?:for x86_64\s+)?([\d.]+)", nv_ver) or re.search(r"\s(\d{3}\.\d+(?:\.\d+)?)\s", nv_ver)
    nv_driver = m.group(1) if m else ""
    nouveau = Path("/sys/module/nouveau").exists()
    return dict(cpu=model, threads=threads, ram_mib=mem, laptop=battery, on_ac=ac, power_profile=profile,
                governor=gov, gpus=gpus, nvidia_present=nv_present, nvidia_driver=nv_driver, nouveau=nouveau,
                cpu_max_mhz=cpu_max_mhz(), kernel=os.uname().release)


def disk_info(path):
    src = sh(["findmnt", "-no", "SOURCE", "--target", str(path)])
    src = re.sub(r"\[.*\]$", "", src)               # btrfs subvolume suffix
    name = os.path.basename(os.path.realpath(src)) if src.startswith("/dev/") else ""
    parent = sh(["lsblk", "-no", "PKNAME", f"/dev/{name}"]).splitlines()[0] if name else ""
    # dm-crypt / LVM: walk up to the real disk
    for _ in range(3):
        if not parent:
            break
        pp = sh(["lsblk", "-no", "PKNAME", f"/dev/{parent}"]).splitlines()
        if pp and pp[0]:
            parent = pp[0]
        else:
            break
    disk = parent or name
    info = dict(device=disk, kind="unknown", model="", link="")
    if not disk:
        return info
    rota = _read(f"/sys/block/{disk}/queue/rotational")
    tran = sh(["lsblk", "-dno", "TRAN", f"/dev/{disk}"])
    info["model"] = sh(["lsblk", "-dno", "MODEL", f"/dev/{disk}"])
    if disk.startswith("nvme"):
        ctrl = re.sub(r"n\d+$", "", disk)
        speed = _read(f"/sys/class/nvme/{ctrl}/device/current_link_speed")
        width = _read(f"/sys/class/nvme/{ctrl}/device/current_link_width")
        maxs = _read(f"/sys/class/nvme/{ctrl}/device/max_link_speed")
        info["link"] = f"{speed} x{width}" if speed else ""
        info["max_link"] = maxs
        gt = re.match(r"([\d.]+)", speed or "")
        info["kind"] = "nvme4" if gt and float(gt.group(1)) >= 16 else "nvme3" if gt and float(gt.group(1)) >= 8 else "nvme"
    elif disk.startswith("mmcblk"):
        info["kind"] = "emmc"
    elif tran == "usb":
        info["kind"] = "usb"
    elif rota == "1":
        info["kind"] = "hdd"
    elif rota == "0":
        info["kind"] = "ssd"
    return info


# ------------------------------------------------------------------ tests
def test_cpu():
    """7-Zip: multi + single thread rating (MIPS). ~30 s."""
    res = {}
    if shutil.which("7z"):
        for key, extra in (("multi", []), ("single", ["-mmt1"])):
            code, out = run(["7z", "b", "2", "-md22"] + extra, 240)
            m = re.search(r"^Tot:\s+\d+\s+\d+\s+(\d+)", out, re.M)
            if m:
                res[key] = int(m.group(1))
        res["tool"] = "7-Zip"
    elif shutil.which("sysbench"):
        for key, th in (("multi", os.cpu_count() or 1), ("single", 1)):
            code, out = run(["sysbench", "cpu", f"--threads={th}", "--time=10", "run"], 60)
            m = re.search(r"events per second:\s*([\d.]+)", out)
            if m:
                res[key] = round(float(m.group(1)))
        res["tool"] = "sysbench"
    else:
        res["skipped"] = "7zip / sysbench not installed"
    return res


def test_ram():
    if not shutil.which("sysbench"):
        return dict(skipped="sysbench not installed")
    th = max(1, min(4, os.cpu_count() or 1))
    code, out = run(["sysbench", "memory", f"--threads={th}", "--memory-block-size=64M", "--memory-total-size=2000G",
                     "--memory-oper=write", "--time=8", "run"], 60)
    m = re.search(r"\(([\d.]+) MiB/sec\)", out)
    return dict(write_mibs=round(float(m.group(1)))) if m else dict(skipped="sysbench memory failed")


def _free_bytes(p):
    try:
        st = os.statvfs(p)
        return st.f_bavail * st.f_frsize
    except OSError:
        return 0


def test_disk():
    TMP.parent.mkdir(parents=True, exist_ok=True)
    if _free_bytes(TMP.parent) < 3 * 1024 ** 3:
        return dict(skipped="less than 3 GB free in your home folder")
    res = {}
    try:
        if shutil.which("fio"):
            base = ["fio", "--name=phx", f"--filename={TMP}", "--size=1G", "--direct=1", "--output-format=json",
                    "--ioengine=libaio", "--group_reporting"]
            for key, args in (("write", ["--rw=write", "--bs=1M", "--iodepth=16", "--end_fsync=1"]),
                              ("read", ["--rw=read", "--bs=1M", "--iodepth=16"]),
                              ("rand4k", ["--rw=randread", "--bs=4k", "--iodepth=1", "--time_based", "--runtime=6"])):
                for attempt in (0, 1):
                    code, out = run(base + args, 180)
                    try:
                        j = json.loads(out[out.index("{"):])["jobs"][0]
                        side = j["write" if key == "write" else "read"]
                        if key == "rand4k":
                            res["rand4k_iops"] = round(side["iops"])
                        else:
                            res[f"{key}_mbs"] = round(side["bw"] * 1024 / 1e6)
                        break
                    except (ValueError, KeyError, IndexError):
                        if attempt or "--direct=1" not in base:
                            break
                        base = [b for b in base if b != "--direct=1"] + ["--direct=0"]   # file system without O_DIRECT
                        res["note"] = "cached I/O (no direct I/O on this file system)"
            res["tool"] = "fio"
        else:
            code, out = run(["dd", "if=/dev/zero", f"of={TMP}", "bs=1M", "count=1024", "oflag=direct", "conv=fsync"], 180)
            m = re.search(r"copied, ([\d.,]+) s", out)
            if m:
                res["write_mbs"] = round(1073.741824 / float(m.group(1).replace(",", ".")))
            code, out = run(["dd", f"if={TMP}", "of=/dev/null", "bs=1M", "iflag=direct"], 180)
            m = re.search(r"copied, ([\d.,]+) s", out)
            if m:
                res["read_mbs"] = round(1073.741824 / float(m.group(1).replace(",", ".")))
            res["tool"] = "dd"
    finally:
        try:
            TMP.unlink()
        except OSError:
            pass
    return res or dict(skipped="disk test failed")


def vk_devices(env):
    code, out = run(["vkmark", "--list-devices"], 30, env)
    devs, cur = [], {}
    for line in out.splitlines():
        m = re.match(r"\s*(Vendor ID|Device Name|Device UUID|Device Type):\s*(.+)", line)
        if m:
            k = {"Vendor ID": "vendor", "Device Name": "name", "Device UUID": "uuid", "Device Type": "type"}[m.group(1)]
            if k == "vendor" and cur.get("vendor"):
                devs.append(cur); cur = {}
            cur[k] = m.group(2).strip()
    if cur:
        devs.append(cur)
    return [d for d in devs if d.get("name")]


def pick_gpu(devs):
    """Discrete first: NVIDIA, then AMD discrete, then anything that is not a software renderer."""
    real = [d for d in devs if not re.search(r"llvmpipe|lavapipe|SwiftShader|softpipe", d["name"], re.I)]
    for rx in (r"NVIDIA|GeForce|RTX|GTX", r"Radeon RX|Arc A\d"):
        for d in real:
            if re.search(rx, d["name"]):
                return d
    return real[0] if real else (devs[0] if devs else None)


def test_gpu(sysinfo):
    if not shutil.which("vkmark"):
        return dict(skipped="vkmark not installed")
    env = dict(os.environ)
    if sysinfo.get("nvidia_present") and sysinfo.get("nvidia_driver"):
        env.update(__NV_PRIME_RENDER_OFFLOAD="1", __VK_LAYER_NV_optimus="NVIDIA_only")   # laptop: use the RTX
    devs = vk_devices(env)
    dev = pick_gpu(devs)
    cmd = ["vkmark", "--winsys", "headless", "--size", "1920x1080", "-b", ":duration=4.0"]
    if dev and dev.get("uuid") and len(devs) > 1:
        cmd += ["--use-device", dev["uuid"]]
    code, out = run(cmd, 240, env)
    m = re.search(r"vkmark Score:\s*(\d+)", out)
    if not m and not STOP["now"]:                   # no headless plugin / driver refuses: use a normal window
        cmd = [c for c in cmd if c not in ("--winsys", "headless")] + ["--present-mode", "immediate"]
        code, out = run(cmd, 240, env)
        m = re.search(r"vkmark Score:\s*(\d+)", out)
    name = re.search(r"Device Name:\s*(.+)", out)
    res = dict(devices=[d["name"] for d in devs], used=(name.group(1).strip() if name else (dev or {}).get("name", "")))
    if m:
        res["score"] = int(m.group(1))
    else:
        tail = [x for x in out.strip().splitlines() if x.strip()][-1:] or ["no output"]
        res["skipped"] = "Vulkan test failed: " + tail[0][:160]
    res["software"] = bool(re.search(r"llvmpipe|lavapipe", res["used"], re.I))
    return res


# ------------------------------------------------------------------ main
TESTS = [("cpu", "Processor (all cores, then one core)", 35), ("ram", "Memory speed", 10),
         ("disk", "Disk speed (1 GB test file)", 25), ("gpu", "Graphics (Vulkan, 3D scenes)", 50)]


def main(argv=None):
    global JSON_OUT
    ap = argparse.ArgumentParser(description="Is my PC OK? - quick benchmark")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--skip", default="", help="comma separated: cpu,ram,disk,gpu")
    a = ap.parse_args(argv)
    JSON_OUT = a.json
    skip = set(filter(None, a.skip.split(",")))

    def stop(*_):
        STOP["now"] = True
        p = CHILD["p"]
        if p:
            try:
                os.killpg(p.pid, signal.SIGTERM)
            except OSError:
                pass
        try:
            TMP.unlink()
        except OSError:
            pass
        sys.exit(130)
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)

    info = system_info()
    info["disk"] = disk_info(Path.home())
    mon = Monitor(); mon.start()
    thr0 = throttle_count()
    time.sleep(2)                                   # idle temperatures
    results = {}
    todo = [t for t in TESTS if t[0] not in skip]
    for i, (tid, title, secs) in enumerate(todo, 1):
        emit(ev="stage", id=tid, title=title, n=i, of=len(todo), secs=secs)
        mon.stage = tid
        t0 = time.time()
        r = {"cpu": test_cpu, "ram": test_ram, "disk": test_disk, "gpu": lambda: test_gpu(info)}[tid]()
        r["seconds"] = round(time.time() - t0, 1)
        results[tid] = r
        emit(ev="result", id=tid, **r)
    mon.stage = "end"
    time.sleep(1)
    mon.stop = True
    run_ = dict(time=int(time.time()), system=info, results=results, samples=mon.samples,
                throttle_events=max(0, throttle_count() - thr0))
    run_["analysis"] = benchref.analyze(run_)
    benchref.save_run(run_)
    emit(ev="done", run=run_)
    if not JSON_OUT:
        a_ = run_["analysis"]
        print("\n" + a_["summary"])
        for rec in a_["recommendations"]:
            print(" -", rec["title"] + ":", rec["text"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
