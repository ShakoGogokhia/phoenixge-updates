"""Benchmark results -> "your result vs typical for your hardware", thermals, recommendations, history.

analyze(run) -> {"state", "summary", "items": [...], "thermal": {...}, "recommendations": [...]}
History: ~/.local/share/phoenixge/bench.json  {"runs": [run, ...]} (newest last, 20 kept).
Reference values: reference.json next to this file (approximate - see its "about").
"""
import json
import os
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
REF_FILE = HERE / "reference.json"
HISTORY = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local/share") / "phoenixge/bench.json"
GREEN, YELLOW, RED, GREY = "green", "yellow", "red", "grey"
RANK = {GREY: 0, GREEN: 1, YELLOW: 2, RED: 3}


def ref():
    try:
        return json.loads(REF_FILE.read_text())
    except (OSError, ValueError):
        return {"cpu": [], "gpu": [], "gpu_anchor": {"vkmark": 0}, "ram_mibs": {}, "disk": {}}


def find_cpu(model, r=None):
    for c in (r or ref())["cpu"]:
        if re.search(c["match"], model or "", re.I):
            return c
    return None


def find_gpu(name, r=None):
    r = r or ref()
    for g in r["gpu"]:
        if re.search(g["match"], name or "", re.I):
            return dict(g, vkmark=round(r["gpu_anchor"]["vkmark"] * g["rel"]))
    return None


def verdict(ratio, estimated=False):
    if ratio is None:
        return GREY
    ok, low = (0.7, 0.45) if estimated else (0.85, 0.6)
    return GREEN if ratio >= ok else YELLOW if ratio >= low else RED


def _item(id_, title, value, unit, typical=None, estimated=False, note=""):
    ratio = (value / typical) if (value and typical) else None
    return dict(id=id_, title=title, value=value, unit=unit, typical=typical, ratio=round(ratio, 2) if ratio else None,
                state=verdict(ratio, estimated), estimated=estimated, note=note)


def thermal(run):
    s = run.get("samples") or []
    out = dict(cpu_max=None, gpu_max=None, cpu_throttled=False, gpu_throttled=False, cpu_drop=None, gpu_reasons=[])
    cpu = [x for x in s if x.get("stage") == "cpu"]
    temps = [x["cpu_temp"] for x in s if x.get("cpu_temp")]
    out["cpu_max"] = round(max(temps)) if temps else None
    mhz = [x["cpu_mhz"] for x in cpu if x.get("cpu_mhz")]
    if len(mhz) >= 9:
        third = len(mhz) // 3
        first, last = sum(mhz[:third]) / third, sum(mhz[-third:]) / third
        out["cpu_drop"] = round(1 - last / first, 2) if first else None
    hot = out["cpu_max"] is not None and out["cpu_max"] >= 95
    out["cpu_throttled"] = bool(run.get("throttle_events")) or (hot and (out["cpu_drop"] or 0) > 0.2)
    g = [x for x in s if x.get("stage") == "gpu"]
    gt = [x["gpu_temp"] for x in g if x.get("gpu_temp")]
    out["gpu_max"] = round(max(gt)) if gt else None
    reasons = 0
    for x in g:
        reasons |= int(x.get("gpu_reasons") or 0)
    names = {0x4: "power limit", 0x8: "hardware slowdown", 0x20: "too hot (software)", 0x40: "too hot (hardware)",
             0x80: "power brake"}
    out["gpu_reasons"] = [v for k, v in names.items() if reasons & k]
    out["gpu_throttled"] = bool(reasons & (0x8 | 0x20 | 0x40 | 0x80)) or (out["gpu_max"] or 0) >= 90
    return out


def analyze(run):
    r = ref()
    sysi, res = run.get("system", {}), run.get("results", {})
    items, recs = [], []

    # ---- CPU
    c = res.get("cpu", {})
    cref = find_cpu(sysi.get("cpu", ""), r) if c.get("tool") == "7-Zip" else None
    unit = "MIPS" if c.get("tool") == "7-Zip" else "events/s"
    if c.get("multi"):
        items.append(_item("cpu_multi", "Processor - all cores", c["multi"], unit, cref and cref["multi"],
                           note="" if cref else "no typical value for this processor"))
    if c.get("single"):
        items.append(_item("cpu_single", "Processor - one core", c["single"], unit, cref and cref["single"]))
    if c.get("skipped"):
        items.append(dict(id="cpu", title="Processor", state=GREY, note=c["skipped"], value=None))

    # ---- RAM
    m = res.get("ram", {})
    if m.get("write_mibs"):
        good = r.get("ram_mibs", {}).get("good", 15000)
        items.append(_item("ram", "Memory speed", m["write_mibs"], "MiB/s", good,
                           note="compared with a typical dual-channel PC"))
    elif m.get("skipped"):
        items.append(dict(id="ram", title="Memory speed", state=GREY, note=m["skipped"], value=None))

    # ---- disk
    d = res.get("disk", {})
    dk = sysi.get("disk", {}) or {}
    dref = r.get("disk", {}).get(dk.get("kind"), None)
    kname = dref["name"] if dref else "disk"
    if d.get("read_mbs"):
        items.append(_item("disk_read", f"Disk read ({kname})", d["read_mbs"], "MB/s", dref and dref["read"]))
    if d.get("write_mbs"):
        items.append(_item("disk_write", f"Disk write ({kname})", d["write_mbs"], "MB/s", dref and dref["write"]))
    if d.get("rand4k_iops"):
        items.append(_item("disk_rand", "Disk small files (4K random read)", d["rand4k_iops"], "IOPS",
                           dref and dref.get("rand4k_iops")))
    if d.get("skipped"):
        items.append(dict(id="disk", title="Disk", state=GREY, note=d["skipped"], value=None))

    # ---- GPU
    g = res.get("gpu", {})
    used = g.get("used", "")
    gref = find_gpu(used, r)
    if g.get("score"):
        items.append(_item("gpu", f"Graphics ({used or 'GPU'})", g["score"], "points", gref and gref["vkmark"],
                           estimated=True, note="typical value is an estimate" if gref else "no typical value for this GPU"))
    elif g.get("skipped"):
        items.append(dict(id="gpu", title="Graphics", state=GREY, note=g["skipped"], value=None))

    th = thermal(run)
    below = [i for i in items if i["state"] in (YELLOW, RED)]

    def rec(id_, title, text, action=None, sev=YELLOW):
        recs.append(dict(id=id_, title=title, text=text, action=action, severity=sev))

    # ---- why (most important first)
    if g.get("software"):
        rec("swgpu", "No graphics acceleration", "The 3D test ran in software (llvmpipe) - games will not run well. "
            "The graphics driver is missing or broken.", "drivers", RED)
    if sysi.get("nvidia_present") and not sysi.get("nvidia_driver"):
        rec("nvdriver", "NVIDIA driver is not active", "Your NVIDIA card runs " +
            ("on the basic open driver (nouveau), which is much slower." if sysi.get("nouveau") else "without its driver.") +
            " Install it on the Drivers page and restart.", "drivers", RED)
    elif sysi.get("nvidia_present") and used and not re.search(r"NVIDIA|GeForce|RTX|GTX", used):
        rec("prime", "The test did not use your NVIDIA card",
            f"It ran on {used}. On laptops the NVIDIA card only works for apps started on it (PRIME offload). "
            "Phoenix Games and Steam do this for you; for other apps right-click > \"Run using dedicated graphics card\".",
            "drivers", RED)
    nv = sysi.get("nvidia_driver") or ""
    if nv and nv.split(".")[0].isdigit() and int(nv.split(".")[0]) < 550:
        rec("nvold", "Old NVIDIA driver", f"Driver {nv} is old - newer drivers are faster in new games.", "drivers")
    if sysi.get("laptop") and sysi.get("on_ac") is False:
        rec("battery", "Running on battery", "Laptops slow down a lot on battery. Plug in the charger and run the "
            "test again.", "rerun", RED if below else YELLOW)
    pp = sysi.get("power_profile", "")
    if pp == "power-saver" or (pp == "balanced" and below):
        rec("profile", f"Power mode is \"{pp.replace('-', ' ').title()}\"", "Performance mode lets the processor and "
            "graphics run at full speed (louder fans). Game Mode switches it on by itself while you play.",
            "performance", RED if pp == "power-saver" else YELLOW)
    if th["cpu_throttled"]:
        rec("cputhermal", "Processor gets too hot", f"It reached {th['cpu_max']} °C and slowed itself down. Keep the "
            "vents free (hard surface, not a bed), clean the dust out of the fans, a cooling pad helps laptops.",
            None, RED)
    elif th["cpu_max"] and th["cpu_max"] >= 90:
        rec("cpuwarm", "Processor runs hot", f"It reached {th['cpu_max']} °C. Normal for many laptops under full load, "
            "but clean vents keep it faster.")
    if th["gpu_throttled"]:
        why = ", ".join(th["gpu_reasons"]) or f"{th['gpu_max']} °C"
        rec("gputhermal", "Graphics card slows down", f"Reason reported by the driver: {why}. Check the fans and vents.",
            None, RED if any("hot" in x for x in th["gpu_reasons"]) else YELLOW)
    ram_item = next((i for i in items if i["id"] == "ram"), None)
    if ram_item and ram_item["value"] and ram_item["value"] < r.get("ram_mibs", {}).get("low", 9000):
        rec("ram1ch", "Memory is slow - maybe only one RAM stick", "Memory runs in single-channel mode when there is "
            "only one stick. A second identical stick often gives 10-30% more FPS in CPU-heavy games.")
    if dk.get("kind") == "hdd":
        rec("hdd", "Your home folder is on a hard disk", "Games load much faster from an SSD. Put your Steam library "
            "on an SSD if you have one.")
    if dk.get("link") and dk.get("max_link") and dk["max_link"].split()[0] != dk["link"].split()[0]:
        rec("nvmelink", "SSD runs slower than it could", f"The SSD is connected at {dk['link']} but supports "
            f"{dk['max_link']}. The slot may be slower (common on laptops) - nothing to fix in software.")
    cpu_below = any(i["id"].startswith("cpu") and i["state"] in (YELLOW, RED) for i in items)
    if cpu_below and not any(x["id"] in ("battery", "profile", "cputhermal") for x in recs):
        rec("background", "Processor result is low", "Close heavy programs (browser with many tabs, downloads, "
            "updates) and run the test again. Laptop makers' power limits also differ (±20%).", "rerun")

    worst = max([i["state"] for i in items] + [x["severity"] for x in recs], key=lambda s: RANK[s], default=GREY)
    if not items:
        summary = "Nothing could be measured - the test tools are missing."
    elif worst == GREEN:
        summary = "Your PC is OK - everything is as fast as typical for your hardware."
    elif worst == YELLOW:
        summary = "Your PC is mostly OK - a few things are a bit slower than typical."
    else:
        summary = "Something is holding your PC back - see the recommendations."
    return dict(state=worst, summary=summary, items=items, thermal=th, recommendations=recs,
                cpu_ref=cref["name"] if cref else None, gpu_ref=gref["name"] if gref else None)


# ------------------------------------------------------------------ history
def load_history():
    try:
        h = json.loads(HISTORY.read_text())
        return h.get("runs", []) if isinstance(h, dict) else []
    except (OSError, ValueError):
        return []


def save_run(run, keep=20):
    runs = load_history()
    slim = dict(run)
    s = slim.get("samples") or []
    if len(s) > 240:
        step = len(s) / 240
        slim["samples"] = [s[int(i * step)] for i in range(240)]
    runs.append(slim)
    HISTORY.parent.mkdir(parents=True, exist_ok=True)
    tmp = HISTORY.with_suffix(".tmp")
    tmp.write_text(json.dumps({"runs": runs[-keep:]}))
    tmp.replace(HISTORY)


def demo_run():
    """Made-up run for screenshots (RTX 4060 Laptop on Balanced, CPU hot)."""
    import math
    import time
    samples = []
    t = 0.0
    for stage, n, ct, gt in (("idle", 2, 48, 41), ("cpu", 32, 96, 45), ("ram", 9, 78, 44), ("disk", 20, 62, 43),
                             ("gpu", 46, 74, 83)):
        for i in range(n):
            samples.append(dict(t=round(t, 1), stage=stage, cpu_temp=ct - 6 * math.exp(-i / 4) + (i % 3),
                                cpu_mhz=(4200 - i * 28) if stage == "cpu" else 2800,
                                gpu_temp=gt - 8 * math.exp(-i / 6), gpu_mhz=2370 if stage == "gpu" else 210,
                                gpu_power=88 if stage == "gpu" else 4, gpu_reasons=0x4 if stage == "gpu" else 0))
            t += 1
    run = dict(time=int(time.time()) - 60,
               system=dict(cpu="12th Gen Intel(R) Core(TM) i5-12450HX", threads=12, ram_mib=15700, laptop=True,
                           on_ac=True, power_profile="balanced", governor="powersave",
                           gpus=["Intel Corporation Alder Lake-S GT1 [UHD Graphics 730]",
                                 "NVIDIA Corporation AD107M [GeForce RTX 4060 Max-Q / Mobile]"],
                           nvidia_present=True, nvidia_driver="550.163.01", nouveau=False, cpu_max_mhz=4400,
                           disk=dict(device="nvme0n1", kind="nvme4", model="SAMSUNG MZAL8512HDLU", link="16.0 GT/s PCIe x4",
                                     max_link="16.0 GT/s PCIe")),
               results=dict(cpu=dict(multi=36500, single=5150, tool="7-Zip", seconds=31.2),
                            ram=dict(write_mibs=17850, seconds=8.1),
                            disk=dict(write_mbs=2730, read_mbs=3890, rand4k_iops=11800, tool="fio", seconds=19.5),
                            gpu=dict(score=8640, used="NVIDIA GeForce RTX 4060 Laptop GPU", seconds=47.0,
                                     devices=["NVIDIA GeForce RTX 4060 Laptop GPU", "Intel(R) UHD Graphics (ADL-S GT1)"],
                                     software=False)),
               samples=samples, throttle_events=14)
    run["analysis"] = analyze(run)
    return run
