"""Keyboard / mouse remapping through input-remapper (Debian package input-remapper, v2.x).

input-remapper runs a root service (input-remapper-daemon.service) that grabs a device and injects the mapped events;
presets are JSON files in ~/.config/input-remapper-2/presets/<device name>/<preset>.json and
~/.config/input-remapper-2/config.json {"version", "autoload": {"<device key>": "<preset>"}} says which preset each
device uses. We only write those files and call the public commands
    input-remapper-control --command stop-all | autoload
(both work as a normal user; "start --device" does not, because it has to open the device itself, and users can't
read keyboards/mice). Full manual control: input-remapper-gtk (the "Advanced editor" button).
"""
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

CONF = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config") / "input-remapper-2"
CONFIG = CONF / "config.json"
PRESETS = CONF / "presets"

KEY_CHOICES = [("F13 (unused key - set it in Discord / the game)", "KEY_F13"), ("Scroll Lock", "KEY_SCROLLLOCK"),
               ("Pause", "KEY_PAUSE"), ("Right Ctrl", "KEY_RIGHTCTRL"), ("V", "KEY_V"), ("Caps Lock", "KEY_CAPSLOCK")]
BTN_SIDE, BTN_EXTRA, BTN_MIDDLE, KEY_CAPSLOCK, KEY_LEFTMETA, KEY_RIGHTMETA = 275, 276, 274, 58, 125, 126


def _m(code, symbol, name=None, target="keyboard"):
    d = {"input_combination": [{"type": 1, "code": code}], "target_uinput": target, "output_symbol": symbol,
         "mapping_type": "key_macro"}
    if name:
        d["name"] = name
    return d


# id: (title, description, device kind, needs a key choice, mappings(key) -> list)
QUICK = {
    "side-nav": ("Side buttons = Back / Forward", "The two thumb buttons go back / forward in the browser and in Dolphin.",
                 "mouse", False, lambda _k: [_m(BTN_SIDE, "KEY_BACK"), _m(BTN_EXTRA, "KEY_FORWARD")]),
    "side-copy": ("Side buttons = Copy / Paste", "Back thumb button copies, front one pastes (a small macro).",
                  "mouse", False, lambda _k: [_m(BTN_SIDE, "modify(KEY_LEFTCTRL, key(KEY_C))"),
                                              _m(BTN_EXTRA, "modify(KEY_LEFTCTRL, key(KEY_V))")]),
    "ptt": ("Push-to-talk on the side button", "Holding the back thumb button holds a key - pick the same key as "
            "push-to-talk in Discord or the game.", "mouse", True, lambda k: [_m(BTN_SIDE, k or "KEY_F13")]),
    "caps-esc": ("Caps Lock = Esc", "No more accidental CAPS. Handy for vim and for closing menus.", "keyboard", False,
                 lambda _k: [_m(KEY_CAPSLOCK, "KEY_ESC")]),
    "no-win": ("Turn off the Windows key", "No more start menu popping up in the middle of a game.", "keyboard", False,
               lambda _k: [_m(KEY_LEFTMETA, "disable"), _m(KEY_RIGHTMETA, "disable")]),
}
QUICK_NAMES = {"side-nav": "PhoenixGe - Back Forward", "side-copy": "PhoenixGe - Copy Paste",
               "ptt": "PhoenixGe - Push to talk", "caps-esc": "PhoenixGe - Caps is Esc",
               "no-win": "PhoenixGe - No Windows key"}


def installed():
    return bool(shutil.which("input-remapper-control"))


def has_gui():
    return bool(shutil.which("input-remapper-gtk"))


def service_active():
    try:
        r = subprocess.run(["systemctl", "is-active", "input-remapper-daemon.service"], capture_output=True, text=True,
                           timeout=5)
        return r.stdout.strip() == "active"
    except (OSError, subprocess.SubprocessError):
        return False


def _version():
    try:
        from inputremapper.logging.logger import VERSION   # noqa: PLC0415
        return VERSION
    except Exception:  # noqa: BLE001
        return "2.1.1"


def safe(name):
    for ch in '/\\?%*:|"<>':
        name = name.replace(ch, "_")
    return name


def read_config():
    try:
        c = json.loads(CONFIG.read_text())
        return c if isinstance(c, dict) else {}
    except (OSError, ValueError):
        return {}


def write_config(c):
    c.setdefault("version", _version())
    c.setdefault("autoload", {})
    CONF.mkdir(parents=True, exist_ok=True)
    tmp = CONFIG.with_suffix(".tmp")
    tmp.write_text(json.dumps(c, indent=4) + "\n")
    tmp.replace(CONFIG)


def autoload_map():
    return dict(read_config().get("autoload") or {})


def set_autoload_map(m):
    c = read_config()
    c["autoload"] = dict(m)
    write_config(c)


def presets(device_name):
    d = PRESETS / safe(device_name)
    return sorted(p.stem for p in d.glob("*.json")) if d.is_dir() else []


def write_preset(device_name, preset, mappings):
    d = PRESETS / safe(device_name)
    d.mkdir(parents=True, exist_ok=True)
    (d / f"{safe(preset)}.json").write_text(json.dumps(mappings, indent=4) + "\n")


def preset_summary(device_name, preset):
    try:
        data = json.loads((PRESETS / safe(device_name) / f"{safe(preset)}.json").read_text())
        return len(data) if isinstance(data, list) else len(data.get("mapping", {}))
    except (OSError, ValueError, AttributeError):
        return 0


def control(*cmds):
    """Run input-remapper-control commands in order. Returns (ok, message)."""
    if not installed():
        return False, "input-remapper is not installed"
    for c in cmds:
        try:
            r = subprocess.run(["input-remapper-control", "--command", c], capture_output=True, text=True, timeout=20)
        except (OSError, subprocess.SubprocessError) as e:
            return False, str(e)
        if r.returncode != 0:
            msg = (r.stderr or r.stdout).strip().splitlines()
            return False, msg[-1] if msg else f"input-remapper-control {c} failed ({r.returncode})"
    return True, ""


def reload():
    return control("stop-all", "autoload")


def apply_quick(device, quick_id, key=None):
    """Write the quick preset for this device and make it the device's active (autoloaded) preset."""
    title, _desc, _kind, _needs, fn = QUICK[quick_id]
    name = QUICK_NAMES[quick_id]
    write_preset(device["name"], name, fn(key))
    m = autoload_map()
    m[device["key"]] = name
    set_autoload_map(m)
    return reload()


def set_active(device_key, preset):
    m = autoload_map()
    if preset:
        m[device_key] = preset
    else:
        m.pop(device_key, None)
    set_autoload_map(m)
    return reload()


def open_editor():
    if has_gui():
        subprocess.Popen(["input-remapper-gtk"], start_new_session=True, stdin=subprocess.DEVNULL)
        return True
    return False


def valid_preset_name(name):
    return bool(name) and not re.search(r'[/\\?%*:|"<>]', name)
