"""Input devices for PhoenixGe Center > Controllers & keys (no root needed, no Qt).

controllers()        game controllers: [{name, kind, label, vendor, product, bus, event, js, driver, standard, battery, dkey}]
remap_devices()      keyboards / mice as input-remapper groups: [{key, name, kind, names}]
battery_for(dev)     {"percent": int|None, "level": str, "status": str} or None

Everything comes from /proc/bus/input/devices and /sys (readable by every user). Opening /dev/input/event* is only
needed for the live test view and the Xbox mapper; controllers get the "uaccess" tag from systemd (70-uaccess.rules),
so the logged-in user can read them. Keyboards and mice can't be read by users (keylogger protection) - input-remapper
does that part through its own root service.
"""
import os
import re
from pathlib import Path

PROC = "/proc/bus/input/devices"
BTN_SOUTH, BTN_TRIGGER, BTN_LEFT, KEY_A, KEY_Q = 0x130, 0x120, 0x110, 30, 16
ABS_X, ABS_RX = 0, 3
SKIP_NAMES = re.compile(r"Motion Sensors|Touchpad|IMU|Accelerometer|input-remapper|PhoenixGe virtual|"
                        r"Power Button|Sleep Button|Lid Switch|Video Bus|PC Speaker|HDA |HDMI|DP,pcm|"
                        r"Intel HID|WMI hotkeys|ideapad_extra|Headphone|Headset Jack|\bMic\b", re.I)

# vendor -> (kind, label)
VENDORS = {"045e": ("xbox", "Xbox"), "054c": ("playstation", "PlayStation"), "057e": ("nintendo", "Nintendo"),
           "2dc8": ("8bitdo", "8BitDo"), "28de": ("steam", "Steam"), "046d": ("generic", "Logitech"),
           "0e6f": ("xbox", "Xbox compatible (PDP)"), "24c6": ("xbox", "Xbox compatible (PowerA)"),
           "0f0d": ("generic", "Hori"), "1532": ("generic", "Razer"), "0079": ("generic", "Generic"),
           "081f": ("generic", "Generic"), "0810": ("generic", "Generic"), "2563": ("generic", "Generic"),
           "20d6": ("xbox", "Xbox compatible (PowerA)"), "3537": ("generic", "GameSir")}
PRODUCTS = {("054c", "05c4"): "DualShock 4", ("054c", "09cc"): "DualShock 4", ("054c", "0ba0"): "DualShock 4 (adapter)",
            ("054c", "0ce6"): "DualSense", ("054c", "0df2"): "DualSense Edge", ("054c", "0268"): "DualShock 3",
            ("057e", "2009"): "Switch Pro Controller", ("057e", "2006"): "Joy-Con (L)", ("057e", "2007"): "Joy-Con (R)",
            ("045e", "028e"): "Xbox 360", ("045e", "02d1"): "Xbox One", ("045e", "02dd"): "Xbox One",
            ("045e", "02ea"): "Xbox One S", ("045e", "0b12"): "Xbox Series X|S", ("045e", "0b13"): "Xbox Series X|S",
            ("045e", "0b20"): "Xbox Series X|S", ("045e", "0b22"): "Xbox Elite 2", ("045e", "02e0"): "Xbox One S",
            ("045e", "0b00"): "Xbox Elite 2", ("045e", "0b05"): "Xbox Elite 2", ("28de", "1102"): "Steam Controller",
            ("28de", "1205"): "Steam Deck", ("28de", "1142"): "Steam Controller (dongle)"}
# kernel drivers that already report the Linux standard gamepad layout (BTN_SOUTH = bottom face button, ...)
STANDARD_DRIVERS = {"xpad", "playstation", "sony", "nintendo", "microsoft", "steam", "xpadneo", "hid-xpadneo"}
NATIVE_KINDS = {"xbox", "playstation", "nintendo", "steam"}   # SDL / Proton already know these - no Xbox mode needed
BUS = {"0003": "USB", "0005": "Bluetooth", "0006": "Virtual", "0011": "Built-in", "0019": "Built-in"}


def _bits(words):
    """'7fdb000000000000 0 0' -> set of bit numbers (kernel prints the highest long first)."""
    out = set()
    for i, w in enumerate(reversed(words.split())):
        v = int(w, 16)
        b = 0
        while v:
            if v & 1:
                out.add(i * 64 + b)
            v >>= 1; b += 1
    return out


def parse_proc(text=None):
    if text is None:
        try:
            text = Path(PROC).read_text(errors="replace")
        except OSError:
            return []
    devs = []
    for block in text.strip().split("\n\n"):
        d = dict(bus="", vendor="", product="", version="", name="", phys="", sysfs="", uniq="", handlers=[],
                 keys=set(), abs=set(), rel=set())
        for line in block.splitlines():
            tag, _, rest = line.partition(": ")
            if tag == "I":
                for kv in rest.split():
                    k, _, v = kv.partition("=")
                    if k.lower() in ("bus", "vendor", "product", "version"):
                        d[k.lower()] = v.lower()
            elif tag == "N":
                d["name"] = rest.partition("=")[2].strip().strip('"')
            elif tag == "P":
                d["phys"] = rest.partition("=")[2].strip()
            elif tag == "S":
                d["sysfs"] = rest.partition("=")[2].strip()
            elif tag == "U":
                d["uniq"] = rest.partition("=")[2].strip()
            elif tag == "H":
                d["handlers"] = rest.partition("=")[2].split()
            elif tag == "B":
                k, _, v = rest.partition("=")
                if k in ("KEY", "ABS", "REL"):
                    d[{"KEY": "keys", "ABS": "abs", "REL": "rel"}[k]] = _bits(v)
        if d["name"]:
            devs.append(d)
    return devs


def driver_of(sysfs):
    """Kernel driver behind an input device (xpad, playstation, nintendo, hid-generic, ...)."""
    if not sysfs:
        return ""
    for up in ("device/driver", "device/device/driver"):
        p = Path("/sys" + sysfs) / up
        try:
            if p.exists():
                return os.path.basename(os.path.realpath(p))
        except OSError:
            pass
    return ""


def event_node(d):
    ev = next((h for h in d["handlers"] if h.startswith("event")), "")
    return f"/dev/input/{ev}" if ev else ""


def is_controller(d):
    if SKIP_NAMES.search(d["name"]):
        return False
    has_js = any(h.startswith("js") for h in d["handlers"])
    pad_keys = any(BTN_TRIGGER <= k < BTN_TRIGGER + 0x20 for k in d["keys"])
    return (has_js or pad_keys) and bool(d["abs"] or d["keys"])


def dkey(d):
    """Stable id of a controller model+name for input-profiles.json (same pad on another port = same key)."""
    return f"{d['vendor']}:{d['product']}:{d['name']}"


def classify(d, driver=""):
    v, p = d["vendor"], d["product"]
    kind, label = VENDORS.get(v, ("generic", "Generic"))
    if driver == "xpad":
        kind, label = "xbox", label if v == "045e" else "Xbox compatible"
    elif driver in ("playstation", "sony"):
        kind, label = "playstation", "PlayStation"
    elif driver == "nintendo":
        kind, label = "nintendo", "Nintendo"
    model = PRODUCTS.get((v, p))
    if model:
        label = model if kind != "generic" else f"{label} {model}"
    elif kind == "8bitdo":
        label = "8BitDo"
    return kind, label


def virtual_xbox_count(text=None):
    return sum(1 for d in parse_proc(text) if d["sysfs"].startswith("/devices/virtual/")
               and d["name"] == "Microsoft X-Box 360 pad")


def controllers(text=None):
    out = []
    for d in parse_proc(text):
        if not is_controller(d) or d["sysfs"].startswith("/devices/virtual/"):
            continue                              # virtual pads (our Xbox mode, Steam Input) are not listed
        drv = driver_of(d["sysfs"])
        kind, label = classify(d, drv)
        standard = (drv in STANDARD_DRIVERS or kind in NATIVE_KINDS) and BTN_SOUTH in d["keys"]
        out.append(dict(name=d["name"], kind=kind, label=label, vendor=d["vendor"], product=d["product"],
                        bus=BUS.get(d["bus"], d["bus"]), event=event_node(d),
                        js=next((h for h in d["handlers"] if h.startswith("js")), ""), driver=drv or "unknown",
                        standard=standard, native=kind in NATIVE_KINDS, uniq=d["uniq"], sysfs=d["sysfs"],
                        dkey=dkey(d), battery=battery_for(d)))
    return out


# ------------------------------------------------------------------ battery
def battery_for(d):
    base = Path("/sys/class/power_supply")
    if not base.is_dir():
        return None
    in_path = os.path.realpath("/sys" + d["sysfs"]) if d.get("sysfs") else ""
    uniq = (d.get("uniq") or "").lower()
    for ps in base.iterdir():
        try:
            if (ps / "type").read_text().strip() != "Battery":
                continue
            scope = (ps / "scope").read_text().strip() if (ps / "scope").exists() else ""
            if scope != "Device" and not re.search(r"controller|gamepad|joy|xpad|sony|nintendo", ps.name, re.I):
                continue
            parent = os.path.realpath(ps / "device") if (ps / "device").exists() else ""
            match = (parent and in_path.startswith(parent + "/")) or (uniq and uniq in ps.name.lower())
            if not match:
                continue
            cap = (ps / "capacity").read_text().strip() if (ps / "capacity").exists() else ""
            lvl = (ps / "capacity_level").read_text().strip() if (ps / "capacity_level").exists() else ""
            st = (ps / "status").read_text().strip() if (ps / "status").exists() else ""
            return dict(percent=int(cap) if cap.isdigit() else None, level=lvl, status=st)
        except OSError:
            continue
    return None


def battery_text(b):
    if not b:
        return ""
    s = f"{b['percent']}%" if b.get("percent") is not None else (b.get("level") or "")
    if b.get("status") in ("Charging", "Full"):
        s += " (charging)" if b["status"] == "Charging" else " (full)"
    return s


# ------------------------------------------------------------------ keyboards / mice (input-remapper groups)
def kind_of(d):
    if BTN_LEFT in d["keys"] and 0 in d["rel"]:
        return "mouse"
    if KEY_A in d["keys"] and KEY_Q in d["keys"]:
        return "keyboard"
    if is_controller(d):
        return "gamepad"
    return ""


def remap_devices(text=None):
    """Same grouping as input-remapper (groups.get_unique_key): bus_vendor_product_uniq_phys-prefix, decimal numbers.
    The group key is the shortest name in the group (+ " 2" for a second identical device)."""
    groups = {}
    for d in parse_proc(text):
        if re.search(r"input-remapper|Yubico.*YubiKey|Eee PC WMI hotkeys", d["name"]):
            continue
        k = kind_of(d)
        if not k or SKIP_NAMES.search(d["name"]) and k != "gamepad":
            continue
        try:
            uk = (f"{int(d['bus'] or '0', 16)}_{int(d['vendor'] or '0', 16)}_{int(d['product'] or '0', 16)}_"
                  f"{d['uniq']}_{d['phys'].split('/')[0] or '-'}")
        except ValueError:
            continue
        g = groups.setdefault(uk, dict(names=[], kinds=set()))
        g["names"].append(d["name"]); g["kinds"].add(k)
    out, used = [], set()
    for g in groups.values():
        name = sorted(g["names"], key=len)[0]
        key, i = name, 2
        while key in used:
            key = f"{name} {i}"; i += 1
        used.add(key)
        kind = "mouse" if "mouse" in g["kinds"] else "keyboard" if "keyboard" in g["kinds"] else "gamepad"
        out.append(dict(key=key, name=name, kind=kind, names=g["names"]))
    order = {"mouse": 0, "keyboard": 1, "gamepad": 2}
    out.sort(key=lambda x: (order[x["kind"]], x["name"].lower()))
    return out


# ------------------------------------------------------------------ demo data (screenshots)
DEMO_CONTROLLERS = [
    dict(name="Sony Interactive Entertainment DualSense Wireless Controller", kind="playstation", label="DualSense",
         vendor="054c", product="0ce6", bus="Bluetooth", event="/dev/input/event21", js="js0", driver="playstation",
         standard=True, native=True, uniq="", sysfs="", dkey="054c:0ce6:DualSense",
         battery=dict(percent=70, level="", status="Discharging")),
    dict(name="Microsoft Xbox Series S|X Controller", kind="xbox", label="Xbox Series X|S", vendor="045e",
         product="0b12", bus="USB", event="/dev/input/event23", js="js1", driver="xpad", standard=True, native=True,
         uniq="", sysfs="", dkey="045e:0b12:Xbox", battery=None),
    dict(name="USB Gamepad", kind="generic", label="Generic", vendor="0079", product="0006", bus="USB",
         event="/dev/input/event25", js="js2", driver="hid-generic", standard=False, native=False, uniq="", sysfs="",
         dkey="0079:0006:USB Gamepad", battery=None),
]
DEMO_REMAP = [dict(key="Logitech G502 HERO Gaming Mouse", name="Logitech G502 HERO Gaming Mouse", kind="mouse", names=[]),
              dict(key="AT Translated Set 2 keyboard", name="AT Translated Set 2 keyboard", kind="keyboard", names=[]),
              dict(key="Keychron K8", name="Keychron K8", kind="keyboard", names=[])]
