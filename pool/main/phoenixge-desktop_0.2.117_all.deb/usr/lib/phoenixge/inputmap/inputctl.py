"""phoenix-input - controllers and per-game input profiles (PhoenixGe).

    phoenix-input list                     controllers (JSON)
    phoenix-input xbox-start EVENT [KEY]   start Xbox mode for one controller (background)
    phoenix-input xbox-stop [EVENT]        stop Xbox mode (all controllers without EVENT)
    phoenix-input game-start GAME_ID       apply the game's profile (phoenix-game-run calls this before the game)
    phoenix-input game-stop GAME_ID        undo it (after the game)
    phoenix-input watch                    keep Xbox mode on for controllers set to "always" (autostart; exits when none)

State lives in $XDG_RUNTIME_DIR/phoenixge-input/ (gone after logout/reboot - nothing can stay stuck).
"""
import json
import os
import re
import signal
import subprocess
import sys
import time
from pathlib import Path

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import inputdevices as devices  # noqa: E402
import inputprofiles as profiles  # noqa: E402
import remapper  # noqa: E402

RUN = Path(os.environ.get("XDG_RUNTIME_DIR") or f"/run/user/{os.getuid()}") / "phoenixge-input"


def _pidfile(event):
    return RUN / f"xbox-{os.path.basename(event)}.pid"


def _alive(pid):
    try:
        os.kill(pid, 0)
        cl = Path(f"/proc/{pid}/cmdline").read_bytes()
        return b"xpad.py" in cl
    except (OSError, ValueError):
        return False


def xbox_running():
    """{event: pid} of running Xbox-mode mappers."""
    out = {}
    if RUN.is_dir():
        for f in RUN.glob("xbox-*.pid"):
            try:
                pid = int(f.read_text().strip())
            except (OSError, ValueError):
                continue
            if _alive(pid):
                out["/dev/input/" + f.stem[5:]] = pid
            else:
                f.unlink(missing_ok=True)
    return out


def xbox_start(event, key=None):
    if event in xbox_running():
        return True, "already on"
    if not os.access(event, os.R_OK):
        return False, f"no permission to read {event}"
    if not os.access("/dev/uinput", os.W_OK):
        return False, "no permission to create a virtual controller (/dev/uinput) - log out and back in once"
    RUN.mkdir(parents=True, exist_ok=True)
    log = open(RUN / f"xbox-{os.path.basename(event)}.log", "w")
    args = [sys.executable, os.path.join(HERE, "xpad.py"), event] + (["--key", key] if key else [])
    p = subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=log, stderr=log, start_new_session=True)
    _pidfile(event).write_text(str(p.pid))
    time.sleep(0.4)
    if p.poll() is not None:
        _pidfile(event).unlink(missing_ok=True)
        try:
            tail = (RUN / f"xbox-{os.path.basename(event)}.log").read_text().strip().splitlines()[-1:]
        except OSError:
            tail = []
        return False, tail[0] if tail else "Xbox mode stopped right away"
    return True, ""


def xbox_stop(event=None):
    for ev, pid in xbox_running().items():
        if event and ev != event:
            continue
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            pass
        _pidfile(ev).unlink(missing_ok=True)


def wants_xbox(mode, ctrl, game_id):
    if mode == "off" or ctrl["kind"] == "xbox":
        return False
    if mode == "on":
        return True
    return not ctrl["native"] and not game_id.startswith("steam:")   # auto


def _state(game_id):
    return RUN / ("game-" + re.sub(r"[^A-Za-z0-9_.-]", "_", game_id) + ".json")


def game_start(game_id):
    data = profiles.load()
    g = profiles.game(data, game_id)
    st = {"xbox": [], "autoload": None}
    running = xbox_running()
    for c in devices.controllers():
        if c["event"] and c["event"] not in running and wants_xbox(g["xbox"], c, game_id):
            ok, msg = xbox_start(c["event"], c["dkey"])
            print(f"Xbox mode {c['name']}: {'on' if ok else msg}", file=sys.stderr)
            if ok:
                st["xbox"].append(c["event"])
    if g["remap"] and remapper.installed():
        before = remapper.autoload_map()
        st["autoload"] = before
        remapper.set_autoload_map({**before, **{k: v for k, v in g["remap"].items() if v}})
        ok, msg = remapper.reload()
        if not ok:
            print("input-remapper:", msg, file=sys.stderr)
    if st["xbox"] or st["autoload"] is not None:
        RUN.mkdir(parents=True, exist_ok=True)
        _state(game_id).write_text(json.dumps(st))
    return 0


def game_stop(game_id):
    f = _state(game_id)
    try:
        st = json.loads(f.read_text())
    except (OSError, ValueError):
        return 0
    for ev in st.get("xbox", []):
        xbox_stop(ev)
    if st.get("autoload") is not None:
        remapper.set_autoload_map(st["autoload"])
        remapper.reload()
    f.unlink(missing_ok=True)
    return 0


def watch():
    """Xbox mode for controllers marked "always", started when they are plugged in / turned on."""
    while True:
        data = profiles.load()
        always = {k for k, v in data["devices"].items() if v.get("always_xbox")}
        if not always:
            return 0
        running = xbox_running()
        for c in devices.controllers():
            if c["dkey"] in always and c["event"] and c["event"] not in running:
                xbox_start(c["event"], c["dkey"])
        time.sleep(3)


def ensure_watch():
    """Start "watch" in the background unless it already runs (the autostart entry only starts it at login)."""
    me = os.getuid()
    for d in Path("/proc").iterdir():
        try:
            if d.name.isdigit() and d.stat().st_uid == me:
                cl = (d / "cmdline").read_bytes().split(b"\0")
                if any(b"inputctl" in x or b"phoenix-input" in x for x in cl[:2]) and b"watch" in cl:
                    return
        except OSError:
            continue
    subprocess.Popen([sys.executable, os.path.join(HERE, "inputctl.py"), "watch"], start_new_session=True,
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def main(argv=None):
    a = list(sys.argv[1:] if argv is None else argv)
    cmd = a[0] if a else "list"
    if cmd == "list":
        print(json.dumps(devices.controllers(), indent=2))
    elif cmd == "xbox-start" and len(a) >= 2:
        ok, msg = xbox_start(a[1], a[2] if len(a) > 2 else None)
        print(msg or "on", file=sys.stderr)
        return 0 if ok else 1
    elif cmd == "xbox-stop":
        xbox_stop(a[1] if len(a) > 1 else None)
    elif cmd == "game-start" and len(a) == 2:
        return game_start(a[1])
    elif cmd == "game-stop" and len(a) == 2:
        return game_stop(a[1])
    elif cmd == "watch":
        return watch()
    else:
        print(__doc__, file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
