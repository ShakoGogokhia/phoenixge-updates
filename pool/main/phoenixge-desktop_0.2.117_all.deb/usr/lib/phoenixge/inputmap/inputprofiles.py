"""~/.config/phoenixge/input-profiles.json - controller settings and per-game input profiles.

{
  "version": 1,
  "devices": {"<vendor>:<product>:<name>": {"name": str, "mapping": {logical: [source, ...]} | null,
                                           "always_xbox": bool, "swap_ab": bool, "swap_xy": bool, "deadzone": 0-30}},
  "games":   {"<game id, e.g. steam:730>": {"name": str, "xbox": "auto" | "on" | "off",
                                           "remap": {"<input-remapper device key>": "<preset name>"}}}
}
xbox "auto" (default): Xbox mode for controllers SDL/Proton don't know (generic pads), never for Steam games
(Steam Input already translates every controller there).
"""
import fcntl
import json
import os
from pathlib import Path

FILE = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config") / "phoenixge/input-profiles.json"
DEVICE_DEFAULT = dict(name="", mapping=None, always_xbox=False, swap_ab=False, swap_xy=False, deadzone=6)
GAME_DEFAULT = dict(name="", xbox="auto", remap={})


def load():
    try:
        data = json.loads(FILE.read_text())
        if not isinstance(data, dict):
            raise ValueError
    except (OSError, ValueError):
        data = {}
    data.setdefault("version", 1)
    data.setdefault("devices", {})
    data.setdefault("games", {})
    return data


def save(data):
    FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(FILE.with_suffix(".lock"), "w") as lk:
        fcntl.flock(lk, fcntl.LOCK_EX)
        tmp = FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2))
        tmp.replace(FILE)


def device(data, key):
    return {**DEVICE_DEFAULT, **data["devices"].get(key, {})}


def set_device(key, **kw):
    data = load()
    d = data["devices"].setdefault(key, {})
    d.update(kw)
    save(data)
    return data


def game(data, gid):
    g = {**GAME_DEFAULT, **data["games"].get(gid, {})}
    g["remap"] = dict(g.get("remap") or {})
    return g


def set_game(gid, **kw):
    data = load()
    g = data["games"].setdefault(gid, {})
    g.update(kw)
    if g.get("xbox", "auto") == "auto" and not g.get("remap"):
        data["games"].pop(gid, None)          # all defaults again - keep the file small
    save(data)
    return data
