"""Xbox mode: makes any controller look like a wired Xbox 360 pad (045e:028e) to games.

    python3 xpad.py /dev/input/eventN [--key DKEY]     (normally started by phoenix-input)

Why: SDL (most native games, Proton/Wine for Windows games) and many old games only know Xbox-style pads by
vendor/product id. Cheap "generic" USB pads report their buttons as BTN_TRIGGER, BTN_THUMB, ... with no fixed order,
so games show wrong buttons or ignore them. This reads the real pad with python3-evdev, grabs it (games no longer see
the original - no double input) and writes the translated events to a virtual Xbox 360 pad made with /dev/uinput.

Needs: read access to the pad (systemd gives the logged-in user "uaccess" to joysticks) and write access to
/dev/uinput (steam-devices' 60-steam-input.rules and our 71-phoenixge-uinput.rules tag it "uaccess").
Not forwarded (v1): rumble, gyro, touchpad, lights. Steam games: Steam Input already does this - leave it to Steam.

Mapping format (input-profiles.json devices.<key>.mapping): {logical: [source, ...]} with sources
  {"t": "key", "c": code}                 button
  {"t": "abs", "c": code, "inv": bool}    axis (sticks: full range, triggers: min..max = released..pressed)
  {"t": "hat", "c": code, "v": -1|1}      one direction of a hat / d-pad axis
"""
import argparse
import os
import signal
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

LOGICAL = ["a", "b", "x", "y", "lb", "rb", "back", "start", "guide", "ls", "rs", "lt", "rt",
           "lx", "ly", "rx", "ry", "up", "down", "left", "right"]
LABELS = {"a": "A (bottom)", "b": "B (right)", "x": "X (left)", "y": "Y (top)", "lb": "LB (left bumper)",
          "rb": "RB (right bumper)", "back": "Back / View / Select", "start": "Start / Menu", "guide": "Guide / Home",
          "ls": "Left stick click", "rs": "Right stick click", "lt": "LT (left trigger)", "rt": "RT (right trigger)",
          "lx": "Left stick: push RIGHT", "ly": "Left stick: push DOWN", "rx": "Right stick: push RIGHT",
          "ry": "Right stick: push DOWN", "up": "D-pad up", "down": "D-pad down", "left": "D-pad left",
          "right": "D-pad right"}
# Xbox 360 output codes as the xpad driver reports them (SDL's mapping for 045e:028e expects exactly these)
OUT_BTN = {"a": 304, "b": 305, "x": 307, "y": 308, "lb": 310, "rb": 311, "back": 314, "start": 315, "guide": 316,
           "ls": 317, "rs": 318}
OUT_AXIS = {"lx": 0, "ly": 1, "rx": 3, "ry": 4}
OUT_TRIG = {"lt": 2, "rt": 5}
ABS_HAT0X, ABS_HAT0Y = 16, 17

# Linux standard gamepad layout (Documentation/input/gamepad.rst): positions, not labels
STANDARD = {"a": [("key", 304)], "b": [("key", 305)], "x": [("key", 308)], "y": [("key", 307)],
            "lb": [("key", 310)], "rb": [("key", 311)], "back": [("key", 314)], "start": [("key", 315)],
            "guide": [("key", 316)], "ls": [("key", 317)], "rs": [("key", 318)],
            "lt": [("abs", 2), ("key", 312)], "rt": [("abs", 5), ("key", 313)],
            "lx": [("abs", 0)], "ly": [("abs", 1)], "rx": [("abs", 3)], "ry": [("abs", 4)],
            "up": [("hat", 17, -1), ("key", 544)], "down": [("hat", 17, 1), ("key", 545)],
            "left": [("hat", 16, -1), ("key", 546)], "right": [("hat", 16, 1), ("key", 547)]}


def default_mapping(keys, axes, standard):
    """Best guess from the device's capabilities. keys/axes: sets of codes."""
    m = {}
    if standard:
        for lg, cands in STANDARD.items():
            src = []
            for c in cands:
                if c[0] == "key" and c[1] in keys:
                    src.append({"t": "key", "c": c[1]})
                elif c[0] == "abs" and c[1] in axes:
                    src.append({"t": "abs", "c": c[1]})
                elif c[0] == "hat" and c[1] in axes:
                    src.append({"t": "hat", "c": c[1], "v": c[2]})
            if src:
                m[lg] = src
        return m
    # generic DirectInput pad: buttons in code order (most cheap pads: 1=Y/triangle 2=B 3=A 4=X ... vary a lot ->
    # the Learn wizard fixes it), axes X/Y = left stick, Z/RZ or RX/RY = right stick, hat = d-pad
    btns = sorted(k for k in keys if 0x120 <= k < 0x140 or 0x2c0 <= k < 0x2e8)
    order = ["x", "a", "b", "y", "lb", "rb", "lt", "rt", "back", "start", "ls", "rs", "guide"]
    for lg, code in zip(order, btns):
        m[lg] = [{"t": "key", "c": code}]
    if 0 in axes:
        m["lx"] = [{"t": "abs", "c": 0}]
    if 1 in axes:
        m["ly"] = [{"t": "abs", "c": 1}]
    right = [c for c in (2, 3, 4, 5) if c in axes][:2]       # right stick: first two of Z / RX / RY / RZ
    for lg, code in zip(("rx", "ry"), right):
        m[lg] = [{"t": "abs", "c": code}]
    if ABS_HAT0X in axes:
        m.update(left=[{"t": "hat", "c": 16, "v": -1}], right=[{"t": "hat", "c": 16, "v": 1}],
                 up=[{"t": "hat", "c": 17, "v": -1}], down=[{"t": "hat", "c": 17, "v": 1}])
    return m


def apply_swaps(m, swap_ab=False, swap_xy=False):
    m = dict(m)
    if swap_ab:
        m["a"], m["b"] = m.get("b", []), m.get("a", [])
    if swap_xy:
        m["x"], m["y"] = m.get("y", []), m.get("x", [])
    return m


class Translator:
    """Source events -> logical state -> Xbox 360 values. Pure logic (also used by the test view)."""

    def __init__(self, mapping, absinfo, deadzone=6):
        self.mapping = mapping
        self.absinfo = absinfo          # {code: (min, max)}
        self.dz = max(0, min(30, int(deadzone))) / 100.0
        self.raw_key, self.raw_abs = {}, {}

    def feed(self, etype, code, value):
        if etype == 1:
            self.raw_key[code] = value
        elif etype == 3:
            self.raw_abs[code] = value

    def _norm(self, code, val):
        lo, hi = self.absinfo.get(code, (-32768, 32767))
        if hi == lo:
            return 0.0
        return max(-1.0, min(1.0, (val - lo) / (hi - lo) * 2 - 1))

    def _src_value(self, s, kind):
        """kind: 'btn' -> 0/1, 'trig' -> 0..1, 'axis' -> -1..1"""
        t = s.get("t")
        if t == "key":
            v = 1.0 if self.raw_key.get(s["c"], 0) else 0.0
            return v
        if t == "hat":
            v = self.raw_abs.get(s["c"], 0)
            return 1.0 if v and (v > 0) == (s.get("v", 1) > 0) else 0.0
        if t == "abs":
            if s["c"] not in self.raw_abs:
                return 0.0 if kind != "axis" else 0.0
            n = self._norm(s["c"], self.raw_abs[s["c"]])
            if s.get("inv"):
                n = -n
            if kind == "trig":
                lo, hi = self.absinfo.get(s["c"], (0, 255))
                if lo < 0:                       # centred axis used as trigger: -1..1 -> 0..1
                    return (n + 1) / 2
                return max(0.0, n * 0.5 + 0.5)
            if kind == "btn":
                return 1.0 if abs(n) > 0.5 else 0.0
            return n
        return 0.0

    def state(self):
        out = {}
        for lg in OUT_BTN:
            out[lg] = max((self._src_value(s, "btn") for s in self.mapping.get(lg, [])), default=0.0) >= 0.5
        for lg in OUT_TRIG:
            out[lg] = max((self._src_value(s, "trig") for s in self.mapping.get(lg, [])), default=0.0)
        for lg in OUT_AXIS:
            vals = [self._src_value(s, "axis") for s in self.mapping.get(lg, [])]
            v = max(vals, key=abs) if vals else 0.0
            if abs(v) < self.dz:
                v = 0.0
            elif self.dz:
                v = (abs(v) - self.dz) / (1 - self.dz) * (1 if v > 0 else -1)
            out[lg] = v
        for lg in ("up", "down", "left", "right"):
            out[lg] = max((self._src_value(s, "btn") for s in self.mapping.get(lg, [])), default=0.0) >= 0.5
        return out


def xbox_values(st):
    """logical state -> {(type, code): value} for the virtual Xbox 360 pad."""
    v = {}
    for lg, code in OUT_BTN.items():
        v[(1, code)] = 1 if st[lg] else 0
    for lg, code in OUT_AXIS.items():
        v[(3, code)] = int(round(st[lg] * (32767 if st[lg] >= 0 else 32768)))
    for lg, code in OUT_TRIG.items():
        v[(3, code)] = int(round(st[lg] * 255))
    v[(3, ABS_HAT0X)] = (1 if st["right"] else 0) - (1 if st["left"] else 0)
    v[(3, ABS_HAT0Y)] = (1 if st["down"] else 0) - (1 if st["up"] else 0)
    return v


def device_info(dev):
    from evdev import ecodes as e
    caps = dev.capabilities(absinfo=True)
    keys = set(caps.get(e.EV_KEY, []))
    absinfo = {code: (ai.min, ai.max) for code, ai in caps.get(e.EV_ABS, [])}
    return keys, absinfo


def run(path, key=None):
    import evdev
    from evdev import AbsInfo, UInput, ecodes as e
    import inputprofiles as profiles

    dev = evdev.InputDevice(path)
    keys, absinfo = device_info(dev)
    import inputdevices as devices
    info = next((c for c in devices.controllers() if c["event"] == path), None)
    key = key or (info["dkey"] if info else f"{dev.info.vendor:04x}:{dev.info.product:04x}:{dev.name}")
    prof = profiles.device(profiles.load(), key)
    mapping = prof["mapping"] or default_mapping(keys, set(absinfo), bool(info and info["standard"]))
    mapping = apply_swaps(mapping, prof["swap_ab"], prof["swap_xy"])
    tr = Translator(mapping, absinfo, prof["deadzone"])

    stick = AbsInfo(value=0, min=-32768, max=32767, fuzz=16, flat=128, resolution=0)
    trig = AbsInfo(value=0, min=0, max=255, fuzz=0, flat=0, resolution=0)
    hat = AbsInfo(value=0, min=-1, max=1, fuzz=0, flat=0, resolution=0)
    caps = {e.EV_KEY: sorted(OUT_BTN.values()),
            e.EV_ABS: [(0, stick), (1, stick), (3, stick), (4, stick), (2, trig), (5, trig),
                       (ABS_HAT0X, hat), (ABS_HAT0Y, hat)]}
    ui = UInput(caps, name="Microsoft X-Box 360 pad", vendor=0x045e, product=0x028e, version=0x110,
                bustype=e.BUS_USB)
    stop = {"now": False}

    def bye(*_):
        stop["now"] = True
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, bye)
    try:
        dev.grab()
    except OSError as err:
        print(f"xpad: could not grab {path} ({err}) - games may see both pads", file=sys.stderr)
    last = {}
    print(f"xpad: {dev.name} -> virtual Xbox 360 pad ({ui.device.path if ui.device else 'uinput'})", file=sys.stderr)
    try:
        for ev in dev.read_loop():
            if ev.type not in (e.EV_KEY, e.EV_ABS):
                continue
            tr.feed(ev.type, ev.code, ev.value)
            vals = xbox_values(tr.state())
            changed = False
            for (t, c), v in vals.items():
                if last.get((t, c)) != v:
                    ui.write(t, c, v); last[(t, c)] = v; changed = True
            if changed:
                ui.syn()
    except (KeyboardInterrupt, OSError):
        pass                                     # stopped, or the pad was unplugged / turned off
    finally:
        try:
            dev.ungrab()
        except OSError:
            pass
        ui.close()
    return 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Make a controller look like an Xbox 360 pad")
    ap.add_argument("device")
    ap.add_argument("--key")
    a = ap.parse_args()
    sys.exit(run(a.device, a.key))
