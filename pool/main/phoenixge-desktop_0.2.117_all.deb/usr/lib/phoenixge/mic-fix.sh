#!/bin/sh
# PhoenixGe: one-time microphone fix at login (per user, per microphone).
# Laptop Realtek (ALC) mics come up at 100 % = Capture max + Internal Mic Boost +36 dB -> loud hiss and distortion
# ("the mic sounds terrible on Linux, fine on Windows"). Windows uses ~ +20..+30 dB. We set each built-in analog
# mic once to 25 % (~ +24 dB) and, if a Bluetooth headset mic is the default, make the laptop mic the default.
# The user's own later changes are kept (stamp per mic). Clean Mic (noise suppression): Center > Sound & camera.
STAMPS=${XDG_STATE_HOME:-$HOME/.local/state}/phoenixge/mic-fix
mkdir -p "$STAMPS"
command -v pactl >/dev/null || exit 0
i=0; until pactl info >/dev/null 2>&1; do i=$((i+1)); [ $i -ge 30 ] && exit 0; sleep 1; done
internal=""
for src in $(pactl list sources short | awk '$2 ~ /^alsa_input\.pci-.*analog/ {print $2}'); do
  internal=${internal:-$src}
  id=$(echo "$src" | tr -c 'A-Za-z0-9._-' _)
  [ -f "$STAMPS/$id" ] && continue
  pactl set-source-volume "$src" 25%
  pactl set-source-mute "$src" 0
  touch "$STAMPS/$id"
done
if [ -n "$internal" ] && pactl get-default-source 2>/dev/null | grep -q '^bluez_input' && [ ! -f "$STAMPS/default-done" ]; then
  pactl set-default-source "$internal" && touch "$STAMPS/default-done"
fi
exit 0
