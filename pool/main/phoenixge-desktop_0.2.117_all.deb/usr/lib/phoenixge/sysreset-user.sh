#!/bin/sh
# PhoenixGe "Reset settings" (PhoenixGe Center > Reset). Runs as the user - no password, never deletes anything:
# the desktop's settings are MOVED to ~/PhoenixGe-reset-backup-<date>, so PhoenixGe's defaults (Ember theme, taskbar,
# start menu) come back at the next login. Documents, pictures, downloads, games and app data are not touched.
#   sysreset-user.sh --list [--all]      what would be moved (paths that exist)
#   sysreset-user.sh --schedule [--all]  do it at the next login, before Plasma starts (then log out)
#   sysreset-user.sh --cancel            cancel a scheduled reset
#   sysreset-user.sh --apply [--all]     do it now (called at login by ~/.config/plasma-workspace/env/phoenixge-reset.sh)
#   sysreset-user.sh --restore DIR       put a backup back (also scheduled for the next login)
#   sysreset-user.sh --backups           list backups
# --all: every app's settings in ~/.config (browsers like Chrome, Discord, VS Code forget logins and settings too).
# Always kept: language, keyboard layouts, screen layout, folder names (user-dirs), KDE Wallet, Flatpak apps' data
# (~/.var), Firefox (~/.mozilla), Steam/games.
set -u
H=$HOME
ENVD="$H/.config/plasma-workspace/env"
HOOK="$ENVD/phoenixge-reset.sh"

# desktop-only reset (relative to $HOME)
DESKTOP=".config/kdeglobals .config/kwinrc .config/kwinrulesrc .config/plasma-org.kde.plasma.desktop-appletsrc
.config/plasmashellrc .config/plasmarc .config/plasmanotifyrc .config/ksmserverrc .config/kscreenlockerrc
.config/kglobalshortcutsrc .config/khotkeysrc .config/kcminputrc .config/ksplashrc .config/kdedefaults .config/kded6rc
.config/krunnerrc .config/kactivitymanagerdrc .config/kactivitymanagerd-statsrc .config/kactivitymanagerd-pluginsrc
.config/kactivitymanagerd-switcher .config/klaunchrc .config/kservicemenurc .config/dolphinrc .config/konsolerc
.config/breezerc .config/gtkrc .config/gtkrc-2.0 .config/gtk-3.0 .config/gtk-4.0 .config/Trolltech.conf .config/Kvantum
.config/powerdevilrc .config/powermanagementprofilesrc .config/systemsettingsrc .config/baloofilerc .config/plasmaparc
.config/spectaclerc .config/kiorc .config/xsettingsd .config/autostart
.config/phoenixge .config/plasma-systemmonitorrc .config/plasma_calendar_holiday_regions
.local/share/plasma .local/share/kactivitymanagerd .local/share/konsole .local/share/dolphin .local/share/kxmlgui5
.local/share/plasma_notes .local/share/color-schemes .local/share/aurorae .local/share/kwin .local/share/plasmashell
.local/state/plasmashellstaterc .local/state/konsolestaterc .local/state/dolphinstaterc .local/state/systemsettingsstaterc
.local/state/kwinstaterc .local/state/plasma-systemmonitorstaterc"
# never moved (also not with --all)
KEEP_CONFIG="plasma-workspace user-dirs.dirs user-dirs.locale plasma-localerc kxkbrc kwinoutputconfig.json monitors.xml
kwalletrc kdeconnect pulse session"

items() { # ALL -> existing paths, relative to $HOME
  for p in $DESKTOP; do [ -e "$H/$p" ] || [ -L "$H/$p" ] && echo "$p"; done
  if [ "${1:-0}" = 1 ]; then
    for f in "$H"/.config/* "$H"/.config/.[!.]*; do
      [ -e "$f" ] || [ -L "$f" ] || continue
      b=$(basename "$f")
      case " $(echo $KEEP_CONFIG) " in *" $b "*) continue ;; esac
      echo ".config/$b"
    done
  fi
}

apply() {
  ALL=${1:-0}
  B="$H/PhoenixGe-reset-backup-$(date +%Y-%m-%d_%H-%M-%S)"
  mkdir -p "$B" || exit 1
  N=0
  for p in $(items "$ALL" | sort -u); do
    mkdir -p "$B/$(dirname "$p")"
    if mv "$H/$p" "$B/$p" 2>/dev/null; then N=$((N + 1)); fi
  done
  # caches that remember the old layout (safe to delete)
  rm -rf "$H"/.cache/plasmashell "$H"/.cache/plasma_theme_* "$H"/.cache/plasma-svgelements* "$H"/.cache/ksycoca6_* \
         "$H"/.cache/icon-cache.kcache "$H"/.cache/kwin 2>/dev/null
  # PhoenixGe's per-user defaults (shortcuts, lock screen) from /etc/skel
  if [ -d /etc/skel/.config ]; then mkdir -p "$H/.config"; cp -rn /etc/skel/.config/. "$H/.config/" 2>/dev/null; fi
  cat > "$B/README.txt" <<R
PhoenixGe reset backup ($(date '+%F %T')) - $N settings moved here.
Desktop settings were reset to PhoenixGe's defaults. To get these settings back:
PhoenixGe Center > Reset > "Restore settings from a backup", or run
  sh /usr/lib/phoenixge/sysreset-user.sh --restore "$B"
and log out and in again. You can delete this folder when everything is fine.
R
  echo "moved $N settings to $B"
}

restore() {
  SRC=$1
  [ -d "$SRC" ] || { echo "no backup $SRC" >&2; exit 1; }
  # the current settings are moved aside too, so a restore can be undone as well
  ( cd "$SRC" && find . -mindepth 1 -maxdepth 3 \( -path './.config/*' -o -path './.local/share/*' -o -path './.local/state/*' \) -prune -print ) \
    | sed 's|^\./||' > "${TMPDIR:-/tmp}/phx-restore.$$"
  B="$H/PhoenixGe-reset-backup-$(date +%Y-%m-%d_%H-%M-%S)-before-restore"
  while read -r p; do
    [ -n "$p" ] || continue
    if [ -e "$H/$p" ]; then mkdir -p "$B/$(dirname "$p")"; mv "$H/$p" "$B/$p"; fi
    mkdir -p "$H/$(dirname "$p")"; cp -a "$SRC/$p" "$H/$p"
  done < "${TMPDIR:-/tmp}/phx-restore.$$"
  rm -f "${TMPDIR:-/tmp}/phx-restore.$$"
  rm -rf "$H"/.cache/plasmashell "$H"/.cache/ksycoca6_* 2>/dev/null
  echo "restored from $SRC"
}

schedule() { # COMMAND... -> runs once at the next login, before Plasma starts
  mkdir -p "$ENVD"
  {
    echo "# PhoenixGe: one-time settings reset/restore (PhoenixGe Center > Reset). Removes itself."
    echo "rm -f \"\$HOME/.config/plasma-workspace/env/phoenixge-reset.sh\""
    echo "mkdir -p \"\$HOME/.cache\""
    echo "sh /usr/lib/phoenixge/sysreset-user.sh $* >> \"\$HOME/.cache/phoenixge-reset.log\" 2>&1 || true"
  } > "$HOOK.new" && mv "$HOOK.new" "$HOOK"
  echo "scheduled for the next login"
}

ALL=0
for a in "$@"; do [ "$a" = --all ] && ALL=1; done
case "${1:-}" in
  --list) items "$ALL" | sort -u ;;
  --schedule) if [ "$ALL" = 1 ]; then schedule --apply --all; else schedule --apply; fi ;;
  --cancel) rm -f "$HOOK"; echo "cancelled" ;;
  --pending) if [ -f "$HOOK" ]; then grep -oE -- '--all|--restore' "$HOOK" | head -n 1; echo pending; fi ;;
  --apply) apply "$ALL" ;;
  --restore) [ -n "${2:-}" ] || exit 2
             case "${3:-}" in --now) restore "$2" ;; *) schedule --restore "\"$2\"" --now ;; esac ;;
  --backups) ls -1d "$H"/PhoenixGe-reset-backup-* 2>/dev/null | sort -r ;;
  *) sed -n '2,13p' "$0" | sed 's/^# \{0,1\}//'; exit 2 ;;
esac
