#!/bin/sh
# PhoenixGe Center > Health: SMART report of every drive as one JSON document (run with pkexec, reading SMART needs root).
#   {"disks": [{"dev": "/dev/nvme0n1", "model": "...", "smartctl": {...smartctl -j -a...} | null, "nvme": {...} | null}, ...]}
# Read-only: never runs self-tests, never changes drive settings, does not wake sleeping hard disks (-n standby).
export LC_ALL=C
printf '{"disks":['
sep=""
lsblk -dnro NAME,TYPE 2>/dev/null | while read -r name type; do
  [ "$type" = disk ] || continue
  case "$name" in zram*|loop*|ram*|sr*|fd*) continue ;; esac
  dev="/dev/$name"
  model=$(lsblk -dno MODEL "$dev" 2>/dev/null | sed 's/[[:space:]]*$//; s/["\]//g')
  sm=null; nv=null
  if command -v smartctl >/dev/null 2>&1; then
    out=$(timeout 30 smartctl -j -a -n standby "$dev" 2>/dev/null)
    case "$out" in "{"*) sm=$out ;; esac
  fi
  if [ "$sm" = null ] && command -v nvme >/dev/null 2>&1; then
    case "$name" in nvme*)
      out=$(timeout 30 nvme smart-log -o json "$dev" 2>/dev/null)
      case "$out" in "{"*) nv=$out ;; esac ;;
    esac
  fi
  printf '%s{"dev":"%s","model":"%s","smartctl":%s,"nvme":%s}' "$sep" "$dev" "$model" "$sm" "$nv"
  sep=","
done
printf ']}\n'
