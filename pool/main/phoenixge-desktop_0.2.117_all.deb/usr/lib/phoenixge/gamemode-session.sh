#!/bin/sh
# PhoenixGe Game Mode session (chosen on the login screen): Steam's console UI inside gamescope, like SteamOS.
# Steam > Power > Exit to Desktop (or quitting Steam) ends the session and returns to the login screen.
export XDG_CURRENT_DESKTOP=gamescope
export MANGOHUD_CONFIGFILE="$HOME/.config/MangoHud/MangoHud.conf"
if flatpak info com.valvesoftware.Steam >/dev/null 2>&1; then STEAM="flatpak run com.valvesoftware.Steam"
elif command -v steam >/dev/null; then STEAM=steam
else exec gamescope -f -- konsole -e sh -c 'echo "Install Steam first: PhoenixGe Center > Store > Games"; read x'
fi
W=$(cat /sys/class/drm/*/modes 2>/dev/null | head -1 | cut -dx -f1); H=$(cat /sys/class/drm/*/modes 2>/dev/null | head -1 | cut -dx -f2)
exec gamescope -e -f ${W:+-W $W} ${H:+-H $H} --adaptive-sync -- $STEAM -gamepadui
