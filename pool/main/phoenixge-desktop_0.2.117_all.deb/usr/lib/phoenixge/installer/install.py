#!/usr/bin/env python3
"""PhoenixGe Installer - double-click a downloaded app file and install it, like setup.exe on Windows.

    phoenixge-install FILE      .deb (apt: dependencies, upgrades, refuses to remove core packages)
                                .AppImage (copied to ~/Applications + start menu entry + icon, uninstall)
                                .flatpakref / .flatpak / .flatpakrepo (Flatpak: just for me / for everyone)
                                .rpm / .snap -> explanation, .exe / .msi -> phoenix-run
    phoenixge-install           installed AppImages (open, uninstall) + "Open a file"
    phoenixge-install --uninstall-appimage PATH     (the start menu entry's "Uninstall" action)
Details are read without running anything from the file (dpkg-deb, unsquashfs; the AppImage is never started
before you click Install). Dev: --demo deb|appimage|flatpak|manage, --shot PNG (grab the window and quit).
"""
import configparser
import hashlib
import os
import re
import shlex
import shutil
import stat
import subprocess
import sys
import tarfile
import threading
import urllib.parse
import urllib.request
from pathlib import Path

from PySide6.QtCore import QObject, QProcess, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QGuiApplication, QIcon, QPixmap
from PySide6.QtWidgets import (QApplication, QButtonGroup, QCheckBox, QFileDialog, QFrame,
                               QGridLayout, QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QMessageBox, QPlainTextEdit,
                               QProgressBar, QPushButton, QRadioButton, QScrollArea, QStackedWidget, QToolButton,
                               QVBoxLayout, QWidget)

DEMO = sys.argv[sys.argv.index("--demo") + 1] if "--demo" in sys.argv[:-1] else ""
SHOT = sys.argv[sys.argv.index("--shot") + 1] if "--shot" in sys.argv[:-1] else ""
HOME = Path.home()
APPDIR = HOME / "Applications"
APPS = Path(os.environ.get("XDG_DATA_HOME") or HOME / ".local/share") / "applications"
ICONS = Path(os.environ.get("XDG_DATA_HOME") or HOME / ".local/share") / "icons/phoenixge-appimages"
LOGO = "/usr/share/pixmaps/phoenixge.png"
GREEN, YELLOW, RED = "#3fb950", "#e3b341", "#f85149"
# packages a downloaded .deb may never replace or remove
CORE = re.compile(r"^(plasma-.*|plasma|kwin.*|sddm.*|systemd.*|libsystemd.*|udev|dbus|dbus-.*|libc6.*|libc-bin|dpkg|apt|"
                  r"base-files|init|init-system-helpers|login|passwd|sudo|polkitd|pkexec|network-manager|linux-image-.*|"
                  r"grub.*|shim-.*|phoenixge-.*|calamares.*|kde-plasma-desktop|plasma-workspace|plasma-desktop|"
                  r"xwayland|xserver-xorg-core|libpam-.*|bash|coreutils)$")
KIND_LABEL = {"deb": "Debian package", "appimage": "AppImage", "flatpakref": "Flatpak app", "flatpak": "Flatpak bundle",
              "flatpakrepo": "Flatpak source"}


# ------------------------------------------------------------------ small helpers
def run(cmd, timeout=60, env=None):
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=timeout, env=env)
        return r.returncode, r.stdout.decode(errors="replace"), r.stderr.decode(errors="replace")
    except (OSError, subprocess.SubprocessError) as e:
        return 1, "", str(e)


def human(n):
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit in ("B", "KB") else f"{n:.1f} {unit}"
        n /= 1024


def accent():
    _c, out, _e = run(["kreadconfig6", "--file", "kdeglobals", "--group", "General", "--key", "AccentColor"], 5)
    try:
        r, g, b = (int(x) for x in out.strip().split(",")[:3])
        return QColor(r, g, b).name()
    except Exception:
        return "#ff7a2e"


def slug(text):
    s = re.sub(r"[^A-Za-z0-9]+", "-", text).strip("-").lower()
    return s[:60] or "app"


def desktop_quote(path):
    """Exec= argument quoting (Desktop Entry spec)."""
    s = str(path)
    for ch in ("\\", '"', "`", "$"):
        s = s.replace(ch, "\\" + ch)
    return f'"{s}"'


def parse_desktop(text):
    cp = configparser.ConfigParser(interpolation=None, strict=False)
    cp.optionxform = str
    try:
        cp.read_string(text)
        return dict(cp["Desktop Entry"]) if cp.has_section("Desktop Entry") else {}
    except configparser.Error:
        return {}


def origin_url(path):
    """Where the file was downloaded from (Dolphin/KIO and browsers store it as an extended attribute)."""
    for attr in ("user.xdg.origin.url", "user.xdg.referrer.url"):
        try:
            v = os.getxattr(path, attr).decode(errors="replace")
            if v:
                return v
        except (OSError, AttributeError):
            pass
    return ""


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def launch_desktop(path):
    for prog, args in (("kioclient", ["exec", str(path)]), ("gio", ["launch", str(path)])):
        if shutil.which(prog) and QProcess.startDetached(prog, args)[0]:
            return True
    return False


class Bridge(QObject):
    done = Signal(object)


def in_thread(fn, callback):
    """Run fn() in a thread, deliver its result to callback in the UI thread."""
    b = Bridge()
    b.done.connect(callback)
    in_thread.keep.append(b)

    def work():
        try:
            res = fn()
        except Exception as e:  # noqa: BLE001
            res = e
        b.done.emit(res)
    threading.Thread(target=work, daemon=True).start()


in_thread.keep = []


# ------------------------------------------------------------------ file type
def detect(path):
    low = path.lower()
    try:
        with open(path, "rb") as f:
            head = f.read(64)
    except OSError:
        head = b""
    if head.startswith(b"!<arch>\ndebian-binary") or low.endswith(".deb"):
        return "deb"
    if head[:4] == b"\x7fELF" and head[8:11] in (b"AI\x02", b"AI\x01"):
        return "appimage"
    if low.endswith(".appimage"):
        return "appimage"
    for ext, kind in ((".flatpakref", "flatpakref"), (".flatpakrepo", "flatpakrepo"), (".flatpak", "flatpak")):
        if low.endswith(ext):
            return kind
    if low.endswith(".rpm") or head[:4] == b"\xed\xab\xee\xdb":
        return "rpm"
    if low.endswith(".snap"):
        return "snap"
    if low.endswith((".exe", ".msi")) or head[:2] == b"MZ":
        return "exe"
    return "unknown"


# ------------------------------------------------------------------ .deb
def deb_fields(path):
    code, out, err = run(["dpkg-deb", "-f", path], 30)
    if code != 0:
        raise RuntimeError(err.strip() or "This is not a valid Debian package (dpkg-deb could not read it).")
    fields, key = {}, None
    for line in out.splitlines():
        if line.startswith((" ", "\t")) and key:
            fields[key] += "\n" + line[1:]
        elif ":" in line:
            key, val = line.split(":", 1)
            fields[key.strip()] = val.strip()
    return fields


def deb_assets(path, pkg):
    """Desktop entry + icon bytes from data.tar (streamed, nothing written to disk)."""
    desktops, icons, links, total = {}, {}, {}, 0
    try:
        p = subprocess.Popen(["dpkg-deb", "--fsys-tarfile", path], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        with tarfile.open(fileobj=p.stdout, mode="r|") as tar:
            for m in tar:
                name = m.name.lstrip("./")
                low = name.lower()
                if m.issym():
                    links[name] = m.linkname
                    continue
                if not m.isfile():
                    continue
                if low.startswith("usr/share/applications/") and low.endswith(".desktop") and m.size < 65536:
                    desktops[name] = tar.extractfile(m).read().decode(errors="replace")
                elif low.endswith((".png", ".svg", ".xpm")) and m.size < 1_500_000 and total < 60_000_000 and (
                        "/icons/" in low or "/pixmaps/" in low or "icon" in low.rsplit("/", 1)[-1] or "logo" in low.rsplit("/", 1)[-1]):
                    icons[name] = tar.extractfile(m).read()
                    total += m.size
        p.wait(timeout=60)
    except Exception:  # noqa: BLE001 - details are optional, installing still works
        pass
    entry, dfile = {}, ""
    for name in sorted(desktops, key=lambda n: (pkg not in n, len(n))):
        e = parse_desktop(desktops[name])
        if e and e.get("NoDisplay", "false").lower() != "true":
            entry, dfile = e, name
            break
    icon = pick_icon(entry.get("Icon", pkg), icons, links) or pick_icon(pkg, icons, links)
    if not icon and icons:  # e.g. /opt/<app>/product_logo_256.png installed by a postinst
        best = max(icons, key=lambda n: (n.endswith(".png") and ("256" in n or "128" in n or "512" in n), len(icons[n])))
        icon = icons[best]
    return entry, "/" + dfile if dfile else "", icon


def pick_icon(name, icons, links):
    if not name:
        return None
    if name.startswith("/"):
        n = name.lstrip("/")
        for _ in range(5):
            if n in icons:
                return icons[n]
            if n in links:
                t = links[n]
                n = t.lstrip("/") if t.startswith("/") else os.path.normpath(os.path.join(os.path.dirname(n), t))
        return None
    stem = re.compile(r"(^|/)" + re.escape(name) + r"\.(png|svg|xpm)$")
    found = [n for n in list(icons) + list(links) if stem.search(n)]

    def score(n):
        if n.endswith(".svg"):
            return 10_000
        m = re.search(r"/(\d+)x\d+/", n)
        return int(m.group(1)) if m else 48
    for n in sorted(found, key=score, reverse=True):
        data = pick_icon("/" + n, icons, links)
        if data:
            return data
    return None


def apt_simulate(path):
    """What apt would do: (installs [(name, new?)], removes, errors, download, disk)."""
    env = dict(os.environ, LC_ALL="C")
    _code, out, err = run(["apt-get", "-s", "-o", "Debug::NoLocking=1", "install", path], 120, env)
    inst, rem, errors = [], [], []
    for line in (out + "\n" + err).splitlines():
        if line.startswith("Inst "):
            parts = line.split()
            inst.append((parts[1], "[" not in parts[2]))
        elif line.startswith("Remv "):
            rem.append(line.split()[1])
        elif line.startswith("E:") or "but it is not installable" in line or "but it is not going to be installed" in line \
                or "Depends:" in line and "but" in line:
            errors.append(line.strip())
    dl = re.search(r"Need to get ([\d.,]+ [kMG]?B)", out)
    disk = re.search(r"After this operation, ([\d.,]+ [kMG]?B) of additional", out)
    return inst, rem, errors, dl.group(1) if dl else "", disk.group(1) if disk else ""


def deb_info(path):
    f = deb_fields(path)
    pkg = f.get("Package", "")
    desc = f.get("Description", "")
    summary, _, long = desc.partition("\n")
    long = "\n".join("" if l.strip() == "." else l.strip() for l in long.splitlines()).strip()
    entry, dfile, icon = deb_assets(path, pkg)
    native = run(["dpkg", "--print-architecture"], 5)[1].strip() or "amd64"
    foreign = run(["dpkg", "--print-foreign-architectures"], 5)[1].split()
    info = dict(kind="deb", path=path, package=pkg, name=entry.get("Name") or pkg, version=f.get("Version", ""),
                publisher=re.sub(r"\s*<.*?>", "", f.get("Maintainer", "")) or "Unknown", summary=entry.get("Comment") or summary,
                description=long, homepage=f.get("Homepage", ""), arch=f.get("Architecture", ""), icon=icon,
                desktop=dfile, size=os.path.getsize(path), installed_size=int(f.get("Installed-Size", "0") or 0) * 1024,
                fields=f, problems=[], warnings=[])
    if info["arch"] not in ("all", native, *foreign):
        info["problems"].append(f"This package is built for {info['arch']} computers - this computer is {native}. "
                                "Look for the amd64 / x86_64 download.")
    if CORE.match(pkg):
        info["problems"].append(f"\"{pkg}\" is a core part of PhoenixGe. Replacing it with a downloaded file could break the "
                                "system, so it can only come from PhoenixGe updates.")
    for fld, verb in (("Conflicts", "conflicts with"), ("Breaks", "breaks")):
        hit = [d.strip().split()[0] for d in f.get(fld, "").split(",") if d.strip() and CORE.match(d.strip().split()[0])]
        if hit:
            info["problems"].append(f"It says it {verb} core packages ({', '.join(hit)}).")
    code, cur, _e = run(["dpkg-query", "-W", "-f", "${Version} ${db:Status-Abbrev}", pkg], 10)
    info["mode"] = "install"
    if code == 0 and cur.split()[1:2] and cur.split()[1].startswith("ii"):
        old = cur.split()[0]
        info["old"] = old
        if run(["dpkg", "--compare-versions", old, "lt", info["version"]], 5)[0] == 0:
            info["mode"] = "upgrade"
        elif old == info["version"]:
            info["mode"] = "reinstall"
        else:
            info["mode"] = "downgrade"
    inst, rem, errors, dl, disk = apt_simulate(path)
    info.update(deps=[n for n, _new in inst if n != pkg], new_deps=[n for n, new in inst if new and n != pkg],
                removes=rem, sim_errors=errors, download=dl, disk=disk)
    if info["deps"] and not dl:  # apt -s doesn't print sizes: add them up from the package lists
        _c, out, _e = run(["apt-cache", "show", "--no-all-versions", *info["deps"]], 30)
        size = sum(int(x) for x in re.findall(r"^Size: (\d+)", out, re.M))
        inst_kb = sum(int(x) for x in re.findall(r"^Installed-Size: (\d+)", out, re.M))
        if size:
            info["download"] = human(size)
        info["disk"] = human(info["installed_size"] + inst_kb * 1024)
    elif not disk and info["installed_size"]:
        info["disk"] = human(info["installed_size"])
    core_rm = [r for r in rem if CORE.match(r)]
    if core_rm:
        info["problems"].append("Installing it would REMOVE core parts of PhoenixGe: " + ", ".join(core_rm) +
                                ". That would break the desktop, so it is blocked.")
    return info


# ------------------------------------------------------------------ AppImage
def elf_end(path):
    """The squashfs image of a type 2 AppImage starts right after the ELF runtime (section headers end)."""
    with open(path, "rb") as f:
        h = f.read(64)
    if h[:4] != b"\x7fELF":
        return 0
    little = h[5] == 1
    order = "little" if little else "big"
    if h[4] == 2:  # 64-bit
        shoff, shentsize, shnum = int.from_bytes(h[0x28:0x30], order), int.from_bytes(h[0x3A:0x3C], order), int.from_bytes(h[0x3C:0x3E], order)
    else:
        shoff, shentsize, shnum = int.from_bytes(h[0x20:0x24], order), int.from_bytes(h[0x2E:0x30], order), int.from_bytes(h[0x30:0x32], order)
    return shoff + shentsize * shnum


class Squash:
    """Read files from the AppImage's squashfs without running it (unsquashfs -o OFFSET -cat)."""

    def __init__(self, path):
        self.path, self.off, self.files, self.links = path, elf_end(path), set(), {}
        if not shutil.which("unsquashfs") or not self.off:
            return
        code, out, _e = run(["unsquashfs", "-o", str(self.off), "-lln", "-no-progress", path], 60)
        if code != 0:
            return
        for line in out.splitlines():
            m = re.search(r"squashfs-root/(.+?)(?: -> (.+))?$", line)
            if not m:
                continue
            if line.startswith("l") and m.group(2):
                self.links[m.group(1)] = m.group(2)
            elif line.startswith("-"):
                self.files.add(m.group(1))

    def resolve(self, name):
        for _ in range(6):
            if name in self.files:
                return name
            if name not in self.links:
                return None
            t = self.links[name]
            name = os.path.normpath(os.path.join(os.path.dirname(name), t)) if not t.startswith("/") else t.lstrip("/")
        return None

    def read(self, name, limit=3_000_000):
        real = self.resolve(name)
        if not real:
            return None
        try:
            r = subprocess.run(["unsquashfs", "-o", str(self.off), "-cat", self.path, real], capture_output=True, timeout=60)
            return r.stdout[:limit] if r.returncode == 0 else None
        except (OSError, subprocess.SubprocessError):
            return None


def has_fuse2():
    return "libfuse.so.2" in run(["/sbin/ldconfig", "-p"], 10)[1] or any(
        Path(d, "libfuse.so.2").exists() for d in ("/usr/lib/x86_64-linux-gnu", "/lib/x86_64-linux-gnu", "/usr/lib"))


def appimage_info(path):
    fn = os.path.basename(path)
    sq = Squash(path)
    entry, icon, dname = {}, None, ""
    tops = sorted(n for n in sq.files | set(sq.links) if "/" not in n and n.endswith(".desktop"))
    if tops:
        dname = tops[0]
        entry = parse_desktop((sq.read(dname) or b"").decode(errors="replace"))
    icon_name = entry.get("Icon", "")
    for cand in [".DirIcon", f"{icon_name}.png", f"{icon_name}.svg",
                 *(f"usr/share/icons/hicolor/{s}/apps/{icon_name}.png" for s in ("512x512", "256x256", "128x128")),
                 f"usr/share/icons/hicolor/scalable/apps/{icon_name}.svg"]:
        if cand.startswith(".") or icon_name:
            data = sq.read(cand)
            if data:
                icon = data
                break
    base = re.sub(r"\.appimage$", "", fn, flags=re.I)
    name = entry.get("Name") or re.split(r"[-_ ](?:v?\d|x86|amd64|linux)", base, maxsplit=1, flags=re.I)[0] or base
    ver = entry.get("X-AppImage-Version", "")
    if not ver:
        m = re.search(r"[-_ ]v?(\d+(?:\.\d+)+[\w.+~-]*?)(?:[-_.](?:x86_64|amd64|linux|aarch64|arm64)|$)", base, re.I)
        ver = m.group(1) if m else ""
    sid = slug(name)
    target = APPDIR / f"{sid}.AppImage"
    existing = APPS / f"appimage-{sid}.desktop"
    info = dict(kind="appimage", path=path, name=name, version=ver, publisher="Not verified (AppImages are usually not signed)",
                summary=entry.get("Comment", ""), description="", homepage="", icon=icon, entry=entry, id=sid,
                size=os.path.getsize(path), target=str(target), readable=bool(sq.files), fuse=has_fuse2(),
                installed=existing.exists(), problems=[], warnings=[])
    if existing.exists():
        old = parse_desktop(existing.read_text(errors="replace"))
        info["old"] = old.get("X-AppImage-Version", "")
        info["target"] = old.get("X-PhoenixGe-AppImage", str(target))
        info["mode"] = "same" if os.path.realpath(path) == os.path.realpath(info["target"]) else "upgrade"
    else:
        info["mode"] = "install"
    if not sq.files:
        info["warnings"].append("Details could not be read from this AppImage (old format or unknown compression). It can still "
                                "be installed - the name comes from the file name.")
    with open(path, "rb") as f:
        h = f.read(20)
    if h[:4] == b"\x7fELF" and int.from_bytes(h[18:20], "little") not in (62,):
        info["problems"].append("This AppImage is not for 64-bit PCs (x86_64) - look for the x86_64 / amd64 download.")
    return info


def integrate_appimage(info, progress=None):
    """Copy to ~/Applications, make executable, start menu entry + icon. Returns the .desktop path."""
    src, target, sid = Path(info["path"]), Path(info["target"]), info["id"]
    APPDIR.mkdir(parents=True, exist_ok=True)
    APPS.mkdir(parents=True, exist_ok=True)
    ICONS.mkdir(parents=True, exist_ok=True)
    if os.path.realpath(src) != os.path.realpath(target):
        tmp = target.with_name(target.name + ".part")
        size, done = max(1, src.stat().st_size), 0
        with open(src, "rb") as a, open(tmp, "wb") as b:
            for chunk in iter(lambda: a.read(4 << 20), b""):
                b.write(chunk)
                done += len(chunk)
                if progress:
                    progress(int(done * 90 / size))
        os.replace(tmp, target)
    target.chmod(target.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    icon_path = "application-x-executable"
    if info.get("icon"):
        ext = "svg" if info["icon"].lstrip()[:5] in (b"<?xml", b"<svg ") or b"<svg" in info["icon"][:300] else "png"
        for old in ICONS.glob(f"{sid}.*"):
            old.unlink()
        ip = ICONS / f"{sid}.{ext}"
        ip.write_bytes(info["icon"])
        icon_path = str(ip)
    e = info.get("entry", {})
    run_env = "" if info.get("fuse") else "env APPIMAGE_EXTRACT_AND_RUN=1 "
    lines = ["[Desktop Entry]", "Type=Application", f"Name={info['name']}"]
    for key in ("GenericName", "Comment", "Keywords", "MimeType", "StartupWMClass"):
        if e.get(key):
            lines.append(f"{key}={e[key]}")
    lines += [f"Exec={run_env}{desktop_quote(target)} %U", f"TryExec={target}", f"Icon={icon_path}",
              f"Categories={e.get('Categories') or 'Utility;'}", "Terminal=false", f"X-AppImage-Version={info.get('version', '')}",
              f"X-PhoenixGe-AppImage={target}", "Actions=PhoenixGeUninstall;", "",
              "[Desktop Action PhoenixGeUninstall]", "Name=Uninstall", "Icon=edit-delete",
              f"Exec=phoenixge-install --uninstall-appimage {desktop_quote(target)}", ""]
    df = APPS / f"appimage-{sid}.desktop"
    df.write_text("\n".join(lines))
    df.chmod(0o755)
    if progress:
        progress(100)
    refresh_menu()
    return str(df)


def refresh_menu():
    if shutil.which("update-desktop-database"):
        run(["update-desktop-database", "-q", str(APPS)], 30)
    for prog in ("kbuildsycoca6", "kbuildsycoca5"):
        if shutil.which(prog):
            QProcess.startDetached(prog, [])
            break


def installed_appimages():
    out = []
    for df in sorted(APPS.glob("appimage-*.desktop")) if APPS.exists() else []:
        e = parse_desktop(df.read_text(errors="replace"))
        t = e.get("X-PhoenixGe-AppImage")
        if not t:
            continue
        size = os.path.getsize(t) if os.path.exists(t) else 0
        out.append(dict(desktop=str(df), target=t, name=e.get("Name", df.stem), version=e.get("X-AppImage-Version", ""),
                        icon=e.get("Icon", ""), size=size, missing=not os.path.exists(t)))
    return out


def uninstall_appimage(target):
    """Remove the AppImage, its start menu entry and icon. Settings in ~/.config stay (like Windows uninstallers)."""
    removed = []
    for df in APPS.glob("appimage-*.desktop") if APPS.exists() else []:
        e = parse_desktop(df.read_text(errors="replace"))
        if e.get("X-PhoenixGe-AppImage") and os.path.realpath(e["X-PhoenixGe-AppImage"]) == os.path.realpath(target):
            ic = e.get("Icon", "")
            if ic.startswith(str(ICONS)) and os.path.exists(ic):
                os.unlink(ic)
            df.unlink()
            removed.append(str(df))
    if os.path.exists(target) and os.path.realpath(target).startswith(str(APPDIR.resolve())):
        os.unlink(target)
        removed.append(target)
    refresh_menu()
    return removed


# ------------------------------------------------------------------ Flatpak
def ini(path, section):
    cp = configparser.ConfigParser(interpolation=None, strict=False)
    cp.optionxform = str
    try:
        cp.read(path, encoding="utf-8")
        return dict(cp[section]) if cp.has_section(section) else {}
    except configparser.Error:
        return {}


def flatpak_installed(app_id):
    for scope in ("--user", "--system"):
        if run(["flatpak", "info", scope, app_id], 15)[0] == 0:
            return scope.strip("-")
    return ""


def fetch_icon(url):
    if not url.startswith("https://"):
        return None
    try:
        with urllib.request.urlopen(url, timeout=6) as r:
            return r.read(1_000_000)
    except Exception:  # noqa: BLE001
        return None


def flatpak_info(path, kind):
    fn = os.path.basename(path)
    info = dict(kind=kind, path=path, size=os.path.getsize(path), problems=[], warnings=[], description="", icon=None, mode="install")
    if not shutil.which("flatpak") and not DEMO:
        info["problems"].append("Flatpak is not installed (sudo apt install flatpak).")
    if kind == "flatpakref":
        r = ini(path, "Flatpak Ref")
        if not r.get("Name"):
            raise RuntimeError("This .flatpakref file has no app name - it may be damaged.")
        url = r.get("Url", "")
        host = urllib.parse.urlparse(url).hostname or "?"
        info.update(name=r.get("Title") or r["Name"], app_id=r["Name"], version=r.get("Branch", "stable"),
                    publisher=host, summary=r.get("Comment", ""), description=r.get("Description", ""),
                    homepage=r.get("Homepage", ""), url=url, signed=bool(r.get("GPGKey")),
                    runtime=r.get("IsRuntime", "false").lower() == "true", icon_url=r.get("Icon", ""))
        if "flathub" not in host:
            info["warnings"].append(f"This adds \"{host}\" as an app source: updates for this app will come from there.")
        if not info["signed"]:
            info["warnings"].append("The file has no signing key - Flatpak can't verify where the app comes from.")
    elif kind == "flatpakrepo":
        r = ini(path, "Flatpak Repo")
        url = r.get("Url", "")
        host = urllib.parse.urlparse(url).hostname or "?"
        info.update(name=r.get("Title") or re.sub(r"\.flatpakrepo$", "", fn, flags=re.I), version="", publisher=host,
                    summary=r.get("Comment", "Adds an app source (remote) to Flatpak."), description=r.get("Description", ""),
                    homepage=r.get("Homepage", ""), url=url, signed=bool(r.get("GPGKey")), icon_url=r.get("Icon", ""),
                    remote=slug(r.get("SuggestRemoteName") or re.sub(r"\.flatpakrepo$", "", fn, flags=re.I)))
        if not info["signed"]:
            info["warnings"].append("The file has no signing key - apps from this source can't be verified.")
    else:  # bundle: the ref is stored near the start of the file
        with open(path, "rb") as f:
            head = f.read(1 << 18)
        m = re.search(rb"(app|runtime)/([A-Za-z0-9_.-]+\.[A-Za-z0-9_.-]+)/(x86_64|aarch64|i386)/([A-Za-z0-9_.-]+)", head)
        app_id = m.group(2).decode() if m else ""
        info.update(name=app_id.rsplit(".", 1)[-1] if app_id else re.sub(r"\.flatpak$", "", fn, flags=re.I), app_id=app_id,
                    version=m.group(4).decode() if m else "", publisher="Not verified (bundle file)",
                    summary=app_id or "Flatpak bundle", homepage="", signed=False)
        info["warnings"].append("Bundles don't update by themselves unless the developer built in an update source.")
    if info.get("app_id") and not DEMO and shutil.which("flatpak"):
        inst = flatpak_installed(info["app_id"])
        if inst:
            info["mode"], info["old"] = "installed", inst
    if info.get("icon_url") and not DEMO:
        info["icon"] = fetch_icon(info["icon_url"])
    return info


# ------------------------------------------------------------------ demo data
def demo_info(kind):
    from PySide6.QtGui import QPainter, QLinearGradient, QFont

    def fake_icon(c1, c2, letter):
        pm = QPixmap(128, 128); pm.fill(Qt.transparent)
        p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing)
        g = QLinearGradient(0, 0, 128, 128); g.setColorAt(0, QColor(c1)); g.setColorAt(1, QColor(c2))
        p.setBrush(g); p.setPen(Qt.NoPen); p.drawRoundedRect(8, 8, 112, 112, 26, 26)
        f = QFont(); f.setPixelSize(64); f.setBold(True); p.setFont(f); p.setPen(QColor("white"))
        p.drawText(pm.rect(), Qt.AlignCenter, letter); p.end()
        from PySide6.QtCore import QBuffer, QByteArray
        ba = QByteArray(); buf = QBuffer(ba); buf.open(QBuffer.WriteOnly); pm.save(buf, "PNG")
        return bytes(ba)
    if kind == "appimage":
        return dict(kind="appimage", path="/home/shako/Downloads/Obsidian-1.7.7.AppImage", name="Obsidian", version="1.7.7",
                    publisher="Not verified (AppImages are usually not signed)", summary="Private and flexible note-taking app",
                    description="", homepage="", icon=fake_icon("#7c3aed", "#4c1d95", "O"), entry={}, id="obsidian",
                    size=127_400_000, target="/home/shako/Applications/obsidian.AppImage", readable=True, fuse=False,
                    installed=False, mode="install", problems=[], warnings=[], origin="https://github.com/obsidianmd/obsidian-releases/releases",
                    sha="9f2c1e7a4b0d3c5e8f6a1b2c3d4e5f60718293a4b5c6d7e8f9012a3b4c5d6e7f8")
    if kind == "flatpak":
        return dict(kind="flatpakref", path="/home/shako/Downloads/com.spotify.Client.flatpakref", name="Spotify",
                    app_id="com.spotify.Client", version="stable", publisher="dl.flathub.org", summary="Online music streaming service",
                    description="", homepage="https://www.spotify.com", url="https://dl.flathub.org/repo/", signed=True,
                    icon=fake_icon("#1db954", "#0b6b2f", "S"), size=1_780, mode="install", problems=[], warnings=[],
                    origin="https://flathub.org/apps/com.spotify.Client", sha="")
    return dict(kind="deb", path="/home/shako/Downloads/code_1.96.2-1734607745_amd64.deb", package="code",
                name="Visual Studio Code", version="1.96.2-1734607745", publisher="Microsoft Corporation",
                summary="Code Editing. Redefined.", description="Visual Studio Code is a new choice of tool that combines the "
                "simplicity of a code editor with what developers need for the core edit-build-debug cycle.",
                homepage="https://code.visualstudio.com/", arch="amd64", icon=fake_icon("#2f80ed", "#0b4aa2", "<>"),
                desktop="/usr/share/applications/code.desktop", size=105_300_000, installed_size=412_000_000, fields={},
                problems=[], warnings=[], mode="install", deps=["libxkbfile1", "libvulkan1", "gnupg"], new_deps=["libxkbfile1", "libvulkan1"],
                removes=[], sim_errors=[], download="1,214 kB", disk="413 MB",
                origin="https://code.visualstudio.com/docs/?dv=linux64_deb", sha="3b1f0c9d2e8a7f6b5c4d3e2f1a0b9c8d7e6f5a4b3c2d1e0f9a8b7c6d5e4f3a2b")


# ------------------------------------------------------------------ UI
STYLE = """
QWidget {{ font-size: 13px; }}
#title {{ font-size: 24px; font-weight: 700; }}
#dim {{ color: palette(placeholder-text); }}
#chip {{ background: {acc_bg}; color: palette(text); border-radius: 9px; padding: 3px 10px; }}
#card {{ background: palette(alternate-base); border-radius: 14px; border: 1px solid {acc_line}; }}
#warn {{ background: {yel_bg}; border-radius: 14px; border: 1px solid {yel_line}; }}
#bad {{ background: {red_bg}; border-radius: 14px; border: 1px solid {red_line}; }}
#cardTitle {{ font-size: 14px; font-weight: 600; }}
#bottom {{ background: palette(alternate-base); border-top: 1px solid {acc_line}; }}
QPushButton {{ padding: 8px 18px; border-radius: 10px; }}
QPushButton#primary {{ background: {acc}; color: #1a0b06; font-weight: 600; border: none; }}
QPushButton#primary:disabled {{ background: {acc_dis}; color: rgba(26,11,6,0.55); }}
QPushButton#danger {{ background: {red}; color: white; font-weight: 600; border: none; }}
QProgressBar {{ border: none; border-radius: 6px; background: {acc_bg}; height: 12px; text-align: center; }}
QProgressBar::chunk {{ border-radius: 6px; background: {acc}; }}
"""


def rgba(hexcol, alpha):
    c = QColor(hexcol)
    return f"rgba({c.red()},{c.green()},{c.blue()},{alpha})"


def style_sheet(acc):
    """Qt style sheets read 8-digit hex as #AARRGGBB - use rgba() for see-through colors."""
    return STYLE.format(acc=acc, red=RED, acc_bg=rgba(acc, 0.16), acc_line=rgba(acc, 0.22), acc_dis=rgba(acc, 0.35),
                        yel_bg=rgba(YELLOW, 0.12), yel_line=rgba(YELLOW, 0.45), red_bg=rgba(RED, 0.10), red_line=rgba(RED, 0.55))


def card(name="card", title=""):
    f = QFrame(); f.setObjectName(name)
    lay = QVBoxLayout(f); lay.setContentsMargins(16, 14, 16, 14); lay.setSpacing(6)
    if title:
        t = QLabel(title); t.setObjectName("cardTitle"); lay.addWidget(t)
    return f, lay


def label(text, obj="", wrap=True, rich=False):
    x = QLabel(text); x.setWordWrap(wrap)
    if obj:
        x.setObjectName(obj)
    if rich:
        x.setTextFormat(Qt.RichText); x.setOpenExternalLinks(True)
    else:
        x.setTextFormat(Qt.PlainText)
    x.setTextInteractionFlags(Qt.TextSelectableByMouse | (Qt.LinksAccessibleByMouse if rich else Qt.NoTextInteraction))
    return x


def icon_pixmap(data, size, fallback="application-x-executable"):
    pm = QPixmap()
    if data and pm.loadFromData(data):
        return pm.scaled(size, size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
    return QIcon.fromTheme(fallback, QIcon.fromTheme("application-x-executable")).pixmap(size, size)


def esc(s):
    return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


class Installer(QWidget):
    def __init__(self, path):
        super().__init__()
        self.path, self.info, self.proc, self.desktop = path, None, None, ""
        self.setWindowTitle("PhoenixGe Installer")
        self.setWindowIcon(QIcon.fromTheme("system-software-install", QIcon(LOGO)))
        self.resize(720, 640)
        self.setMinimumSize(560, 480)
        self.acc = accent()
        self.setStyleSheet(style_sheet(self.acc))
        root = QVBoxLayout(self); root.setContentsMargins(0, 0, 0, 0); root.setSpacing(0)
        self.stack = QStackedWidget(); root.addWidget(self.stack, 1)
        # bottom bar
        bar = QFrame(); bar.setObjectName("bottom")
        bl = QHBoxLayout(bar); bl.setContentsMargins(20, 12, 20, 12)
        self.status = label("", "dim"); bl.addWidget(self.status, 1)
        self.cancel = QPushButton("Cancel"); self.cancel.clicked.connect(self.close)
        self.extra = QPushButton(); self.extra.hide()
        self.go = QPushButton("Install"); self.go.setObjectName("primary"); self.go.setEnabled(False)
        self.go.clicked.connect(self.start)
        for b in (self.extra, self.cancel, self.go):
            bl.addWidget(b)
        root.addWidget(bar)
        # page 0: loading
        load = QWidget(); ll = QVBoxLayout(load); ll.addStretch()
        sp = QProgressBar(); sp.setRange(0, 0); sp.setMaximumWidth(260); sp.setTextVisible(False)
        ll.addWidget(label("Reading " + os.path.basename(path) + " …", "dim"), 0, Qt.AlignCenter)
        ll.addWidget(sp, 0, Qt.AlignCenter); ll.addStretch()
        self.stack.addWidget(load)
        self.status.setText("Checking the file - nothing is installed or run yet.")
        if DEMO:
            QTimer.singleShot(0, lambda: self.show_info(demo_info(DEMO)))
        else:
            in_thread(self.analyze, self.show_info)

    # ---------------------------------------------------------- analysis
    def analyze(self):
        kind = detect(self.path)
        if kind == "deb":
            info = deb_info(self.path)
        elif kind == "appimage":
            info = appimage_info(self.path)
        elif kind in ("flatpakref", "flatpak", "flatpakrepo"):
            info = flatpak_info(self.path, kind)
        else:
            return dict(kind=kind, path=self.path)
        info["origin"] = origin_url(self.path)
        info["sha"] = sha256(self.path) if info["size"] < 4 << 30 else ""
        return info

    def show_info(self, info):
        if isinstance(info, Exception):
            return self.fail_page("This file can't be installed", str(info))
        self.info = info
        k = info["kind"]
        if k == "exe":
            QProcess.startDetached("phoenix-run", [self.path])
            QTimer.singleShot(300, self.close)
            return
        if k in ("rpm", "snap", "unknown"):
            return self.unsupported(k)
        page = QWidget()
        outer = QVBoxLayout(page); outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame)
        inner = QWidget(); lay = QVBoxLayout(inner); lay.setContentsMargins(28, 24, 28, 20); lay.setSpacing(14)
        scroll.setWidget(inner); outer.addWidget(scroll)
        # header
        head = QHBoxLayout(); head.setSpacing(18)
        ic = QLabel(); ic.setPixmap(icon_pixmap(info.get("icon"), 88, "package-x-generic")); ic.setFixedSize(92, 92)
        ic.setAlignment(Qt.AlignTop)
        head.addWidget(ic, 0, Qt.AlignTop)
        hv = QVBoxLayout(); hv.setSpacing(4)
        hv.addWidget(label(info.get("name", "?"), "title"))
        sub = " · ".join(x for x in (("Version " + info["version"]) if info.get("version") else "", info.get("publisher", "")) if x)
        hv.addWidget(label(sub, "dim"))
        if info.get("summary"):
            hv.addWidget(label(info["summary"]))
        chips = QHBoxLayout(); chips.setSpacing(6)
        for t in self.chip_texts(info):
            c = QLabel(t); c.setObjectName("chip"); chips.addWidget(c)
        chips.addStretch(); hv.addLayout(chips)
        head.addLayout(hv, 1)
        lay.addLayout(head)
        # blocking problems
        if info.get("problems"):
            f, fl = card("bad", "Can't install this file")
            for p in info["problems"]:
                fl.addWidget(label("• " + p))
            lay.addWidget(f)
        # what happens
        f, fl = card("card", "What happens when you click Install")
        for line in self.plan_lines(info):
            fl.addWidget(label(line, rich=True))
        if k == "appimage" and not info.get("fuse"):
            row = QHBoxLayout()
            row.addWidget(label("FUSE 2 is missing: the app still starts (it unpacks itself first, a little slower). "
                                "Install FUSE 2 for normal start-up speed.", "dim"), 1)
            fb = QPushButton("Install FUSE 2"); fb.clicked.connect(self.install_fuse); row.addWidget(fb)
            fl.addLayout(row)
            self.fuse_btn = fb
        if k in ("flatpakref", "flatpak", "flatpakrepo") and info.get("mode") != "installed":
            fl.addSpacing(4)
            self.scope = QButtonGroup(self)
            for i, (t, tip) in enumerate((("Just for me", "Installed in your home folder - no password needed."),
                                          ("For everyone on this computer", "Asks for your password."))):
                rb = QRadioButton(t); rb.setToolTip(tip); self.scope.addButton(rb, i); fl.addWidget(rb)
                if i == 0:
                    rb.setChecked(True)
        if not info.get("problems"):
            lay.addWidget(f)
        # removals need an extra confirmation
        if info.get("removes") and not info.get("problems"):
            f, fl = card("bad", "Warning: other software will be REMOVED")
            fl.addWidget(label("To install this package, apt has to remove: " + ", ".join(info["removes"]) +
                               ". Only continue if you know you don't need them."))
            self.confirm_rm = QCheckBox("I understand - remove these packages")
            self.confirm_rm.toggled.connect(self.update_button)
            fl.addWidget(self.confirm_rm)
            lay.addWidget(f)
        if info.get("sim_errors") and not info.get("problems"):
            f, fl = card("bad", "Missing dependencies")
            fl.addWidget(label("apt can't find everything this package needs:\n" + "\n".join(info["sim_errors"][:6])))
            row = QHBoxLayout()
            row.addWidget(label("The package lists may just be old.", "dim"), 1)
            rb = QPushButton("Refresh package lists and check again"); rb.clicked.connect(self.refresh_lists); row.addWidget(rb)
            fl.addLayout(row)
            lay.addWidget(f)
        for w in info.get("warnings", []):
            f, fl = card("warn"); fl.addWidget(label("⚠  " + w)); lay.addWidget(f)
        # security note
        f, fl = card("warn", "Only install software you trust")
        fl.addWidget(label(self.security_text(info)))
        if info.get("origin"):
            host = urllib.parse.urlparse(info["origin"]).hostname or info["origin"]
            fl.addWidget(label(f"Downloaded from: <b>{esc(host)}</b> &nbsp;<span style='opacity:.7'>{esc(info['origin'][:90])}</span>", rich=True))
        if info.get("sha"):
            row = QHBoxLayout()
            s = label("SHA-256: " + info["sha"], "dim"); s.setStyleSheet("font-family: monospace; font-size: 11px;")
            row.addWidget(s, 1)
            cp = QToolButton(); cp.setText("Copy"); cp.setToolTip("Compare it with the checksum on the developer's website")
            cp.clicked.connect(lambda: QGuiApplication.clipboard().setText(info["sha"])); row.addWidget(cp)
            fl.addLayout(row)
        lay.addWidget(f)
        # details
        if info.get("description") or info.get("homepage") or info.get("fields"):
            more = QToolButton(); more.setText("Details  ▸"); more.setCheckable(True); more.setStyleSheet("border:none;font-weight:600;")
            det, dl = card("card")
            if info.get("description"):
                dl.addWidget(label(info["description"]))
            rows = [("File", info["path"]), ("Size", human(info["size"]))]
            if info.get("homepage"):
                rows.append(("Website", f"<a href='{esc(info['homepage'])}'>{esc(info['homepage'])}</a>"))
            for key in ("Package", "Architecture", "Section", "Depends"):
                if info.get("fields", {}).get(key):
                    rows.append((key, info["fields"][key]))
            if info.get("app_id"):
                rows.append(("App ID", info["app_id"]))
            g = QGridLayout(); g.setHorizontalSpacing(14)
            for i, (a, b) in enumerate(rows):
                g.addWidget(label(a, "dim", False), i, 0, Qt.AlignTop)
                g.addWidget(label(b if b.startswith("<a") else esc(b), rich=True), i, 1)
            g.setColumnStretch(1, 1); dl.addLayout(g)
            det.hide()
            more.toggled.connect(lambda on: (det.setVisible(on), more.setText("Details  ▾" if on else "Details  ▸")))
            lay.addWidget(more, 0, Qt.AlignLeft); lay.addWidget(det)
        lay.addStretch()
        self.stack.addWidget(page); self.stack.setCurrentWidget(page)
        self.setup_buttons()

    def chip_texts(self, info):
        k = info["kind"]
        out = [KIND_LABEL.get(k, k), human(info["size"])]
        if k == "deb" and info.get("installed_size"):
            out.append(f"{human(info['installed_size'])} on disk")
        mode = info.get("mode")
        if mode == "upgrade" and info.get("old"):
            out.append(f"Update from {info['old']}")
        elif mode == "upgrade":
            out.append("Update")
        elif mode == "reinstall":
            out.append("Already installed")
        elif mode == "downgrade":
            out.append(f"Older than installed ({info.get('old')})")
        elif mode in ("installed", "same"):
            out.append("Installed")
        return out

    def plan_lines(self, info):
        k, n = info["kind"], esc(info.get("name"))
        if k == "deb":
            out = [f"<b>{n}</b> is installed for all users of this computer (asks for your password)."]
            if info.get("mode") == "upgrade":
                out[0] = f"<b>{n}</b> is updated from {esc(info.get('old'))} to {esc(info['version'])}."
            elif info.get("mode") == "reinstall":
                out[0] = f"<b>{n}</b> {esc(info['version'])} is already installed - it is installed again (repair)."
            elif info.get("mode") == "downgrade":
                out[0] = f"<b>{n}</b> is replaced by an OLDER version ({esc(info['version'])}, installed: {esc(info.get('old'))})."
            deps = info.get("deps", [])
            if deps:
                shown = ", ".join(deps[:8]) + (f" and {len(deps) - 8} more" if len(deps) > 8 else "")
                extra = f" ({esc(info['download'])} to download)" if info.get("download") else ""
                out.append(f"Also installs {len(deps)} package(s) it needs from Debian{extra}: {esc(shown)}")
            else:
                out.append("Needs nothing else - everything it uses is already on this computer.")
            if info.get("disk"):
                out.append(f"Uses about {esc(info['disk'])} of disk space.")
            out.append("A restore point is saved first when backups are on. Remove it later in Discover or with "
                       f"<code>sudo apt remove {esc(info.get('package'))}</code>.")
            return out
        if k == "appimage":
            t = esc(info["target"].replace(str(HOME), "~"))
            first = (f"<b>{n}</b> is copied to <code>{t}</code> and made executable." if info.get("mode") != "same"
                     else f"<b>{n}</b> stays where it is (<code>{t}</code>).")
            if info.get("mode") == "upgrade":
                first = f"The installed {n} {esc(info.get('old') or '')} is replaced by version {esc(info.get('version') or 'from this file')}."
            return [first, "It appears in the start menu with its icon - right-click it there to uninstall.",
                    "Only for you - no password needed. The downloaded file can be deleted afterwards."]
        if k == "flatpakrepo":
            return [f"<b>{n}</b> is added as an app source (\"{esc(info.get('remote'))}\") - apps from it then show up in Discover."]
        if info.get("mode") == "installed":
            return [f"<b>{n}</b> is already installed ({esc(info.get('old'))}) - you can open it right away."]
        return [f"<b>{n}</b> is downloaded from {esc(info.get('publisher'))} and installed with Flatpak.",
                "Flatpak apps run in a sandbox and update together with your other apps (Discover / Auto updates)."]

    def security_text(self, info):
        k = info["kind"]
        if k == "deb":
            return ("A .deb package runs its install scripts with full administrator rights - it can change anything on this "
                    "computer. Apps from the PhoenixGe Store and Discover are checked; this file is not. Install it only if you "
                    "downloaded it from the developer's official website.")
        if k == "appimage":
            return ("An AppImage is not sandboxed: it runs with your rights and can read and change all your files. Download "
                    "AppImages only from the developer's official page (or GitHub releases of the project).")
        if k == "flatpakrepo":
            return "An app source can offer any app and its updates. Add only sources you trust (Flathub is already set up)."
        return ("Flatpak apps run in a sandbox, but the app itself asks for the permissions it needs (for example your files). "
                "Apps on Flathub are reviewed; apps from other sites are not. You can check permissions later in System "
                "Settings > Applications > Flatpak Permissions.")

    def setup_buttons(self):
        info, k = self.info, self.info["kind"]
        label_ = {"install": "Install", "upgrade": "Update", "reinstall": "Reinstall", "downgrade": "Install older version",
                  "same": "Add to start menu", "installed": "Open"}.get(info.get("mode"), "Install")
        if k == "flatpakrepo":
            label_ = "Add source"
        self.go.setText(label_)
        if k == "appimage" and info.get("installed"):
            self.extra.setText("Uninstall"); self.extra.show()
            self.extra.clicked.connect(self.uninstall)
        if info.get("mode") == "installed":
            self.go.clicked.disconnect(); self.go.clicked.connect(self.open_app)
        self.update_button()
        self.status.setText("Nothing has been changed yet." if not info.get("problems") else "This file can't be installed.")

    def update_button(self):
        info = self.info
        ok = not info.get("problems") and not (info["kind"] == "deb" and info.get("sim_errors"))
        if info.get("removes"):
            ok = ok and getattr(self, "confirm_rm", None) is not None and self.confirm_rm.isChecked()
            self.go.setObjectName("danger" if ok else "primary")
            self.go.style().unpolish(self.go); self.go.style().polish(self.go)
        self.go.setEnabled(ok)

    def unsupported(self, kind):
        name = os.path.basename(self.path)
        if kind == "rpm":
            title = "This is a Fedora / openSUSE package (.rpm)"
            text = ("PhoenixGe is based on Debian and uses .deb packages - .rpm files can't be installed safely here.\n\n"
                    "Look for the same app as: a Flatpak (PhoenixGe Store / Discover), a .deb download, or an AppImage on the "
                    "developer's website. Developer tools that only exist as .rpm can run in a Fedora container "
                    "(Toolbox / distrobox).")
        elif kind == "snap":
            title = "Snap packages are not supported"
            text = "Most apps that exist as Snap are also on Flathub - search for it in the PhoenixGe Store / Discover."
        else:
            title = "Unknown file type"
            text = (f"\"{name}\" is not a .deb, AppImage or Flatpak file. If it is a Windows program (.exe/.msi), open it with "
                    "\"PhoenixGe Windows Launcher\".")
        self.fail_page(title, text, store=kind in ("rpm", "snap"))

    def fail_page(self, title, text, store=False):
        page = QWidget(); lay = QVBoxLayout(page); lay.setContentsMargins(36, 36, 36, 24)
        ic = QLabel(); ic.setPixmap(QIcon.fromTheme("dialog-information").pixmap(64, 64)); lay.addWidget(ic)
        lay.addWidget(label(title, "title")); lay.addWidget(label(text))
        if store:
            b = QPushButton("Search in the Store"); b.setObjectName("primary")
            term = re.split(r"[-_.\d]", os.path.basename(self.path))[0]
            b.clicked.connect(lambda: QProcess.startDetached("plasma-discover", ["--search", term]))
            lay.addWidget(b, 0, Qt.AlignLeft)
        lay.addStretch()
        self.stack.addWidget(page); self.stack.setCurrentWidget(page)
        self.go.hide(); self.cancel.setText("Close"); self.status.setText("")

    # ---------------------------------------------------------- actions
    def progress_page(self):
        page = QWidget(); lay = QVBoxLayout(page); lay.setContentsMargins(36, 30, 36, 20); lay.setSpacing(12)
        head = QHBoxLayout()
        ic = QLabel(); ic.setPixmap(icon_pixmap(self.info.get("icon"), 64, "package-x-generic")); head.addWidget(ic)
        self.ptitle = label(f"Installing {self.info.get('name')} …", "title"); head.addWidget(self.ptitle, 1)
        lay.addLayout(head)
        self.bar = QProgressBar(); self.bar.setRange(0, 0); self.bar.setTextVisible(False); lay.addWidget(self.bar)
        self.pstep = label("Starting …", "dim"); lay.addWidget(self.pstep)
        self.logbox = QPlainTextEdit(); self.logbox.setReadOnly(True)
        self.logbox.setStyleSheet("font-family: monospace; font-size: 11px;")
        tog = QToolButton(); tog.setText("Show details  ▸"); tog.setCheckable(True); tog.setStyleSheet("border:none;")
        tog.toggled.connect(lambda on: (self.logbox.setVisible(on), tog.setText("Hide details  ▾" if on else "Show details  ▸")))
        self.logbox.hide()
        lay.addWidget(tog, 0, Qt.AlignLeft); lay.addWidget(self.logbox, 1)
        self.done_row = QHBoxLayout(); lay.addLayout(self.done_row)
        lay.addStretch()
        self.stack.addWidget(page); self.stack.setCurrentWidget(page)
        self.go.hide(); self.extra.hide(); self.cancel.setEnabled(False)
        self.status.setText("Please wait - don't switch the computer off.")

    def start(self):
        info, k = self.info, self.info["kind"]
        if info.get("removes") and QMessageBox.warning(
                self, "Remove packages?", "These packages will be removed:\n\n" + "\n".join(info["removes"]) +
                "\n\nContinue?", QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        self.progress_page()
        if DEMO:
            self.bar.setRange(0, 100); self.bar.setValue(62); self.pstep.setText("Unpacking code (1.96.2-1734607745) …")
            return
        if k == "deb":
            args = ["env", "DEBIAN_FRONTEND=noninteractive", "apt-get", "-o", "APT::Status-Fd=1", "-o", "DPkg::Lock::Timeout=300",
                    "-o", "Dpkg::Options::=--force-confdef", "-o", "Dpkg::Options::=--force-confold", "install", "-y"]
            if info.get("mode") == "reinstall":
                args.append("--reinstall")
            if info.get("mode") == "downgrade":
                args.append("--allow-downgrades")
            self.run_proc("pkexec", args + [os.path.abspath(info["path"])])
        elif k == "appimage":
            self.bar.setRange(0, 100)
            self.pstep.setText("Copying to ~/Applications …")
            br = Bridge(); br.done.connect(self.on_appimage_progress); self._br = br
            in_thread(lambda: integrate_appimage(info, lambda v: br.done.emit(v)), self.appimage_done)
        elif k == "flatpakrepo":
            scope = "--system" if self.scope.checkedId() == 1 else "--user"
            self.run_proc("flatpak", ["remote-add", scope, "--if-not-exists", "--from", info["remote"], info["path"]])
        else:
            scope = "--system" if self.scope.checkedId() == 1 else "--user"
            src = ["--from", info["path"]] if k == "flatpakref" else ["--bundle", info["path"]]
            self.run_proc("flatpak", ["install", scope, "-y", "--noninteractive", *src])

    def run_proc(self, prog, args):
        p = QProcess(self); self.proc = p
        p.setProcessChannelMode(QProcess.MergedChannels)
        p.readyReadStandardOutput.connect(self.on_output)
        p.finished.connect(lambda code, _s: self.finished(code))
        p.errorOccurred.connect(lambda e: e == QProcess.ProcessError.FailedToStart and self.finished(-1))
        self.logbox.appendPlainText("$ " + " ".join(shlex.quote(a) for a in [prog, *args]))
        p.start(prog, args)

    def on_output(self):
        text = bytes(self.proc.readAllStandardOutput()).decode(errors="replace")
        for line in text.splitlines():
            m = re.match(r"(pmstatus|dlstatus):[^:]*:([\d.]+):(.*)", line)
            if m:
                self.bar.setRange(0, 100)
                pct = float(m.group(2))
                self.bar.setValue(int(pct * 0.3) if m.group(1) == "dlstatus" else 30 + int(pct * 0.7))
                self.pstep.setText(m.group(3).strip())
                continue
            fm = re.search(r"(\d{1,3})%", line)
            if fm and self.info["kind"].startswith("flatpak"):
                self.bar.setRange(0, 100); self.bar.setValue(int(fm.group(1)))
            if line.strip():
                self.logbox.appendPlainText(line.rstrip())
                if not line.startswith(("pmstatus", "dlstatus")):
                    self.pstep.setText(line.strip()[:120])

    def on_appimage_progress(self, v):
        self.bar.setValue(v)
        if v >= 90:
            self.pstep.setText("Adding to the start menu …")

    def appimage_done(self, res):
        if isinstance(res, Exception):
            self.logbox.appendPlainText(str(res)); self.logbox.show()
            return self.finished(1)
        self.desktop = res
        self.logbox.appendPlainText(f"Installed: {self.info['target']}\nStart menu entry: {res}")
        self.finished(0)

    def finished(self, code):
        self.cancel.setEnabled(True); self.cancel.setText("Close")
        self.bar.setRange(0, 100)
        if code == 0:
            self.bar.setValue(100)
            name = self.info.get("name")
            self.ptitle.setText(f"{name} is installed" if self.info["kind"] != "flatpakrepo" else f"{name} was added")
            self.pstep.setText("Done. You find it in the start menu." if self.info["kind"] != "flatpakrepo"
                               else "Apps from this source now show up in Discover.")
            self.status.setText("")
            if self.info["kind"] != "flatpakrepo":
                ob = QPushButton("Open app"); ob.setObjectName("primary"); ob.clicked.connect(self.open_app)
                self.done_row.addWidget(ob)
            self.done_row.addStretch()
            self.go.hide()
        else:
            self.ptitle.setText("Installation failed")
            self.go.setText("Try again"); self.go.setEnabled(True); self.go.show()
            reason = "You cancelled the password prompt." if code in (126, 127) else "See the details below."
            if code == -1:
                reason = "The installer tool could not be started."
            self.pstep.setText(reason + " Nothing was changed if it stopped before installing.")
            self.logbox.show()
            self.status.setText("")

    def open_app(self):
        k = self.info["kind"]
        if k == "appimage":
            QProcess.startDetached(self.info["target"], [])
        elif k == "deb":
            df = self.info.get("desktop") or ""
            if not df or not os.path.exists(df):
                out = run(["dpkg", "-L", self.info["package"]], 10)[1].splitlines()
                cand = [l for l in out if l.startswith("/usr/share/applications/") and l.endswith(".desktop")]
                df = cand[0] if cand else ""
            if not df or not launch_desktop(df):
                QMessageBox.information(self, "PhoenixGe Installer", "This package has no app window to open - it may be a "
                                        "command-line tool or a library. Look for it in the start menu or a terminal.")
                return
        elif self.info.get("app_id"):
            QProcess.startDetached("flatpak", ["run", self.info["app_id"]])
        QTimer.singleShot(800, self.close)

    def uninstall(self):
        if QMessageBox.question(self, "Uninstall", f"Remove {self.info['name']} (the AppImage and its start menu entry)? "
                                "Your settings for it stay.") != QMessageBox.Yes:
            return
        uninstall_appimage(self.info["target"])
        QMessageBox.information(self, "PhoenixGe Installer", f"{self.info['name']} was removed.")
        self.close()

    def install_fuse(self):
        self.fuse_btn.setEnabled(False); self.fuse_btn.setText("Installing …")
        p = QProcess(self); self._fuse = p
        p.finished.connect(lambda code, _s: (self.fuse_btn.setText("FUSE 2 installed" if code == 0 else "Failed - try again"),
                                             self.fuse_btn.setEnabled(code != 0), self.info.update(fuse=code == 0 or self.info["fuse"])))
        p.start("pkexec", ["env", "DEBIAN_FRONTEND=noninteractive", "apt-get", "install", "-y", "libfuse2t64"])

    def refresh_lists(self):
        self.status.setText("Refreshing the package lists …")
        p = QProcess(self); self._upd = p
        p.finished.connect(lambda code, _s: self.reanalyze())
        p.start("pkexec", ["apt-get", "update"])

    def reanalyze(self):
        self.stack.setCurrentIndex(0)
        self.status.setText("Checking again …")
        in_thread(self.analyze, self.show_info)

    def closeEvent(self, e):
        if self.proc and self.proc.state() != QProcess.NotRunning:
            QMessageBox.information(self, "PhoenixGe Installer", "Please wait until the installation has finished.")
            e.ignore()
            return
        super().closeEvent(e)


class Manager(QWidget):
    """No file given: installed AppImages + open a file."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("PhoenixGe Installer")
        self.setWindowIcon(QIcon.fromTheme("system-software-install", QIcon(LOGO)))
        self.resize(640, 520)
        acc = accent()
        self.setStyleSheet(style_sheet(acc))
        lay = QVBoxLayout(self); lay.setContentsMargins(28, 24, 28, 20); lay.setSpacing(12)
        lay.addWidget(label("PhoenixGe Installer", "title"))
        lay.addWidget(label("Double-click a downloaded .deb, AppImage or Flatpak file to install it. Most apps are easier to get "
                            "from the PhoenixGe Store (Discover) - they update by themselves.", "dim"))
        row = QHBoxLayout()
        ob = QPushButton("Open a file …"); ob.setObjectName("primary"); ob.clicked.connect(self.pick)
        sb = QPushButton("Open the Store"); sb.clicked.connect(lambda: QProcess.startDetached("plasma-discover", []))
        row.addWidget(ob); row.addWidget(sb); row.addStretch(); lay.addLayout(row)
        lay.addWidget(label("Installed AppImages", "cardTitle"))
        self.list = QListWidget(); self.list.setIconSize(QSize(36, 36)); self.list.setSpacing(2)
        lay.addWidget(self.list, 1)
        br = QHBoxLayout()
        self.openb = QPushButton("Open"); self.openb.clicked.connect(self.open_sel)
        self.unb = QPushButton("Uninstall"); self.unb.clicked.connect(self.uninstall_sel)
        br.addStretch(); br.addWidget(self.openb); br.addWidget(self.unb); lay.addLayout(br)
        self.fill()

    def fill(self):
        self.list.clear()
        items = installed_appimages()
        if DEMO:
            items = [dict(name="Obsidian", version="1.7.7", size=127_400_000, target="~/Applications/obsidian.AppImage", icon="", missing=False),
                     dict(name="Kdenlive", version="24.12.0", size=148_100_000, target="~/Applications/kdenlive.AppImage", icon="", missing=False),
                     dict(name="Cursor", version="0.44.11", size=192_800_000, target="~/Applications/cursor.AppImage", icon="", missing=False)]
        for a in items:
            it = QListWidgetItem(QIcon(a["icon"]) if a["icon"].startswith("/") else QIcon.fromTheme("application-x-executable"),
                                 f"{a['name']}  {a['version']}\n{human(a['size'])} · {a['target'].replace(str(HOME), '~')}"
                                 + ("  (file missing)" if a["missing"] else ""))
            it.setData(Qt.UserRole, a)
            self.list.addItem(it)
        if not items:
            it = QListWidgetItem("No AppImages installed yet."); it.setFlags(Qt.NoItemFlags); self.list.addItem(it)
        else:
            self.list.setCurrentRow(0)

    def sel(self):
        it = self.list.currentItem()
        return it.data(Qt.UserRole) if it else None

    def open_sel(self):
        a = self.sel()
        if a:
            QProcess.startDetached(a["target"], [])

    def uninstall_sel(self):
        a = self.sel()
        if a and QMessageBox.question(self, "Uninstall", f"Remove {a['name']}? Your settings for it stay.") == QMessageBox.Yes:
            uninstall_appimage(a["target"])
            self.fill()

    def pick(self):
        f, _ = QFileDialog.getOpenFileName(self, "Install an app", str(HOME / "Downloads"),
                                           "Apps (*.deb *.AppImage *.appimage *.flatpakref *.flatpak *.flatpakrepo);;All files (*)")
        if f:
            w = Installer(f); w.show(); self._w = w


def main():
    args = [a for i, a in enumerate(sys.argv[1:], 1) if not a.startswith("--") and sys.argv[i - 1] not in ("--demo", "--shot")]
    app = QApplication(sys.argv)
    app.setApplicationName("PhoenixGe Installer")
    app.setDesktopFileName("phoenixge-install")
    if "--uninstall-appimage" in sys.argv:
        target = sys.argv[sys.argv.index("--uninstall-appimage") + 1] if len(sys.argv) > sys.argv.index("--uninstall-appimage") + 1 else ""
        name = next((a["name"] for a in installed_appimages() if os.path.realpath(a["target"]) == os.path.realpath(target)),
                    os.path.basename(target))
        if QMessageBox.question(None, "Uninstall", f"Remove {name}? (the AppImage and its start menu entry - your settings "
                                "for it stay)") == QMessageBox.Yes:
            uninstall_appimage(target)
        return 0
    if DEMO in ("deb", "appimage", "flatpak"):
        w = Installer(f"/demo.{DEMO}")
    elif args and (DEMO or os.path.isfile(args[0])):
        w = Installer(os.path.abspath(args[0]))
    elif args:
        QMessageBox.warning(None, "PhoenixGe Installer", f"File not found:\n{args[0]}")
        return 1
    else:
        w = Manager()
    w.show()
    if SHOT:
        def grab():
            w.grab().save(SHOT)
            app.quit()
        QTimer.singleShot(int(os.environ.get("SHOT_DELAY", "1500")), grab)
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
