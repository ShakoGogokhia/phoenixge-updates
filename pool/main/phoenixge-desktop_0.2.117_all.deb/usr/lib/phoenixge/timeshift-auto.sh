#!/bin/sh
# Turn on daily Timeshift snapshots (system disk, keep 5 daily + 3 boot). Run as root (pkexec).
# btrfs root with the @ subvolume (PhoenixGe default since the safe-updates change) -> Timeshift btrfs mode:
# instant snapshots that also appear in GRUB ("PhoenixGe - restore previous state"). Otherwise rsync mode.
set -e
mkdir -p /etc/timeshift
UUID=$(findmnt -no UUID /)
BTRFS=false
if [ "$(findmnt -no FSTYPE /)" = btrfs ]; then
  case ",$(findmnt -no OPTIONS /)," in
    *,subvol=/@,*|*,subvol=@,*) BTRFS=true ;;
  esac
fi
cat > /etc/timeshift/timeshift.json <<J
{
  "backup_device_uuid" : "$UUID",
  "parent_device_uuid" : "",
  "do_first_run" : "false",
  "btrfs_mode" : "$BTRFS",
  "include_btrfs_home_for_backup" : "false",
  "include_btrfs_home_for_restore" : "false",
  "stop_cron_emails" : "true",
  "schedule_monthly" : "false",
  "schedule_weekly" : "false",
  "schedule_daily" : "true",
  "schedule_hourly" : "false",
  "schedule_boot" : "true",
  "count_monthly" : "2",
  "count_weekly" : "3",
  "count_daily" : "5",
  "count_hourly" : "6",
  "count_boot" : "3",
  "date_format" : "%Y-%m-%d %H:%M:%S",
  "exclude" : [ "/home/**", "/root/**" ],
  "exclude-apps" : []
}
J
timeshift --check >/dev/null 2>&1 || true
if [ "$BTRFS" = true ]; then MODE="btrfs"; else MODE="rsync"; fi
echo "Daily snapshots are on ($MODE mode, keep 5 daily, 3 at boot). First snapshot is being made now..."
timeshift --create --comments "PhoenixGe first snapshot" --yes
mkdir -p /var/lib/phoenixge && touch /var/lib/phoenixge/pre-update-snapshot.stamp  # counts as the pre-update snapshot for an hour
# btrfs: show the snapshot in the GRUB "restore previous state" menu
[ -x /usr/lib/phoenixge/snapshot-menu-refresh.sh ] && /usr/lib/phoenixge/snapshot-menu-refresh.sh || true
