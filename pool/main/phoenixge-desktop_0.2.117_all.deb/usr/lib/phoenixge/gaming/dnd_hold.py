#!/usr/bin/env python3
"""Hold Plasma's Do Not Disturb while a game runs.

org.freedesktop.Notifications.Inhibit() lasts only as long as the caller's D-Bus connection, so this tiny process
stays alive; session.py starts it at game start and sends SIGTERM at game end (Plasma also drops the inhibition
by itself if this process dies).
"""
import signal
import sys

REASON = "Playing a game"
APP = "phoenixge-games"


def hold_dbus_python():
    import dbus  # python3-dbus
    bus = dbus.SessionBus()
    obj = bus.get_object("org.freedesktop.Notifications", "/org/freedesktop/Notifications")
    iface = dbus.Interface(obj, "org.freedesktop.Notifications")
    cookie = iface.Inhibit(APP, REASON, dbus.Dictionary({}, signature="sv"))
    return lambda: iface.UnInhibit(cookie)


def hold_qtdbus():
    from PySide6.QtDBus import QDBusConnection, QDBusInterface  # python3-pyside6.qtdbus
    bus = QDBusConnection.sessionBus()
    iface = QDBusInterface("org.freedesktop.Notifications", "/org/freedesktop/Notifications",
                           "org.freedesktop.Notifications", bus)
    reply = iface.call("Inhibit", APP, REASON, {})
    args = reply.arguments()
    if not args:
        raise RuntimeError(reply.errorMessage() or "Inhibit failed")
    cookie = args[0]
    return lambda: iface.call("UnInhibit", cookie)


def main():
    release = None
    for fn in (hold_dbus_python, hold_qtdbus):
        try:
            release = fn()
            break
        except Exception as e:  # noqa: BLE001 - try the next D-Bus binding
            print(f"dnd_hold: {fn.__name__}: {e}", file=sys.stderr)
    if release is None:
        return 1

    def stop(*_):
        try:
            release()
        finally:
            sys.exit(0)

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    while True:
        signal.pause()


if __name__ == "__main__":
    sys.exit(main())
