#!/usr/bin/env python3
"""Discord Rich Presence over Discord's local IPC socket (pure Python, no extra packages).

Protocol: unix socket $XDG_RUNTIME_DIR/discord-ipc-N (Flatpak Discord: $XDG_RUNTIME_DIR/app/com.discordapp.Discord/
discord-ipc-N, Snap: $XDG_RUNTIME_DIR/snap.discord/...). Every frame = uint32 opcode + uint32 length (little endian)
+ JSON. op 0 HANDSHAKE {"v":1,"client_id":...}, op 1 FRAME (commands), op 2 CLOSE, op 3 PING, op 4 PONG.
The presence stays while the socket is open, so phoenix-game-run keeps one Presence per game session.

Test by hand (Discord desktop app running):  python3 discord_rpc.py --test "Half-Life 2"
"""
import json
import os
import select
import socket
import struct
import sys
import time
import uuid

# TODO(owner): create an application at https://discord.com/developers/applications named "PhoenixGe OS"
# (that name is what Discord shows as "Playing ..." on clients that ignore status_display_type), upload the
# PhoenixGe logo under Rich Presence > Art Assets with the key "phoenixge", and paste its Application ID here
# (or per user: discord_client_id = ... in ~/.config/phoenixge/gaming.conf). Empty = Discord status disabled.
CLIENT_ID = ""
LARGE_IMAGE = "phoenixge"
LARGE_TEXT = "PhoenixGe OS"

OP_HANDSHAKE, OP_FRAME, OP_CLOSE, OP_PING, OP_PONG = 0, 1, 2, 3, 4


def socket_paths():
    bases = []
    rt = os.environ.get("XDG_RUNTIME_DIR") or f"/run/user/{os.getuid()}"
    for b in (rt, f"{rt}/app/com.discordapp.Discord", f"{rt}/app/com.discordapp.DiscordCanary",
              f"{rt}/app/dev.vencord.Vesktop", f"{rt}/snap.discord", f"{rt}/snap.discord-canary",
              os.environ.get("TMPDIR"), "/tmp"):
        if b and b not in bases:
            bases.append(b)
    return [f"{b}/discord-ipc-{i}" for b in bases for i in range(10)]


class RPCError(Exception):
    pass


class Presence:
    def __init__(self, client_id=None):
        self.client_id = client_id or CLIENT_ID
        self.sock = None

    # -------------------------------------------------------------- transport
    def _send(self, op, payload):
        data = json.dumps(payload).encode()
        self.sock.sendall(struct.pack("<II", op, len(data)) + data)

    def _recv_exact(self, n):
        buf = b""
        while len(buf) < n:
            chunk = self.sock.recv(n - len(buf))
            if not chunk:
                raise RPCError("Discord closed the connection")
            buf += chunk
        return buf

    def _recv(self):
        op, length = struct.unpack("<II", self._recv_exact(8))
        payload = json.loads(self._recv_exact(length).decode() or "{}")
        if op == OP_PING:
            self._send(OP_PONG, payload)
            return self._recv()
        if op == OP_CLOSE:
            raise RPCError(payload.get("message", "closed"))
        return payload

    # -------------------------------------------------------------- API
    @property
    def connected(self):
        return self.sock is not None

    def connect(self, timeout=3.0):
        """True when connected (Discord running and the client id accepted)."""
        if not self.client_id:
            return False
        for path in socket_paths():
            if not os.path.exists(path):
                continue
            s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            s.settimeout(timeout)
            try:
                s.connect(path)
                self.sock = s
                self._send(OP_HANDSHAKE, {"v": 1, "client_id": str(self.client_id)})
                ready = self._recv()
                if ready.get("evt") == "READY":
                    return True
            except (OSError, ValueError, struct.error, RPCError):
                pass
            self.close()
        return False

    def _command(self, cmd, args):
        self._send(OP_FRAME, {"cmd": cmd, "args": args, "nonce": str(uuid.uuid4())})
        reply = self._recv()
        if reply.get("evt") == "ERROR":
            raise RPCError(reply.get("data", {}).get("message", "error"))
        return reply

    def set_game(self, name, start=None, state="via Phoenix Games"):
        activity = {
            "type": 0,                        # "Playing"
            "details": name[:128],
            "state": state[:128],
            "timestamps": {"start": int(start or time.time())},
            "assets": {"large_image": LARGE_IMAGE, "large_text": LARGE_TEXT},
            "status_display_type": 2,         # show "Playing <details>" (newer Discord clients)
        }
        try:
            return self._command("SET_ACTIVITY", {"pid": os.getpid(), "activity": activity})
        except RPCError:
            activity.pop("status_display_type")  # older clients reject unknown fields
            return self._command("SET_ACTIVITY", {"pid": os.getpid(), "activity": activity})

    def clear(self):
        try:
            self._command("SET_ACTIVITY", {"pid": os.getpid(), "activity": None})
        except (OSError, RPCError, ValueError, struct.error):
            pass

    def close(self):
        if self.sock:
            try:
                self._send(OP_CLOSE, {})
            except OSError:
                pass
            try:
                self.sock.close()
            except OSError:
                pass
        self.sock = None


class GamePresence:
    """Keeps 'Playing <game>' up for a whole session: connects when Discord appears, reconnects after a restart.
    Call tick() every few seconds from the session loop and stop() at the end."""

    def __init__(self, name, client_id=None, retry=15):
        self.name, self.start, self.retry = name, int(time.time()), retry
        self.p = Presence(client_id)
        self.next_try = 0.0

    def tick(self):
        if self.p.connected:  # Discord quit? (a closed socket becomes readable) -> reconnect later
            try:
                if select.select([self.p.sock], [], [], 0)[0]:
                    self.p._recv()
            except (OSError, RPCError, ValueError, struct.error):
                self.p.close()
        if not self.p.client_id or self.p.connected or time.time() < self.next_try:
            return
        self.next_try = time.time() + self.retry
        try:
            if self.p.connect():
                self.p.set_game(self.name, self.start)
        except (OSError, RPCError, ValueError, struct.error):
            self.p.close()

    def stop(self):
        if self.p.connected:
            self.p.clear()
            self.p.close()


def main(argv):
    if len(argv) >= 3 and argv[1] == "--test":
        cid = argv[3] if len(argv) > 3 else CLIENT_ID
        if not cid:
            print("No client id: set CLIENT_ID in discord_rpc.py or pass it: --test NAME CLIENT_ID")
            return 2
        gp = GamePresence(argv[2], cid)
        gp.tick()
        print("connected" if gp.p.connected else "Discord not found (is the desktop app running?)")
        if gp.p.connected:
            print("Showing presence for 30 s...")
            time.sleep(30)
        gp.stop()
        return 0
    print("usage: discord_rpc.py --test NAME [CLIENT_ID]")
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
