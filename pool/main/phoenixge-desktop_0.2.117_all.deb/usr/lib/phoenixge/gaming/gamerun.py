"""phoenix-game-run - start a game the PhoenixGe way and stay alive exactly as long as the game runs.

    phoenix-game-run [--name NAME] [--match REGEX]... [--wait SEC] [--no-stats] GAME_ID -- COMMAND [ARG...]

  * GameMode: the game process is registered with gamemoded (D-Bus RegisterGame), which also fires the PhoenixGe
    auto-profile (/etc/gamemode.ini -> session.py: performance power profile, Do Not Disturb, updates paused).
  * FPS history: MangoHud records the session (overlay hidden unless the FPS counter is switched on) into
    ~/.local/share/phoenixge/perf/<game>/<program>_<date>.csv  (perf.py reads them).
  * Play time + last played go into ~/.local/share/phoenixge/games.json ({"<id>": {"last": ts, "time": sec}}).
  * Discord "Playing <NAME>" while the game runs (discord_rpc.py, needs the Discord desktop app).

Launchers (steam://, heroic://, lutris:, Prism, xdg-open, kioclient) hand the game to another process and return,
so the game itself is found in /proc: Steam games by "AppId=<id>" (Steam's reaper), Lutris by "lutris-wrapper: NAME",
Prism by the instance name, desktop games by their Exec binary, everything else by --match REGEX / the game name.
Their MangoHud logs go to perf/_incoming first and are moved to the game when the session ends (only works when
MangoHud is loaded in that launcher's games - e.g. Steam started from here or the global FPS counter switch).
Exit code: 0 (the game's own exit code is not meaningful for launcher games).
"""
import argparse
import configparser
import fcntl
import json
import os
import re
import shlex
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import perf  # noqa: E402
import settings  # noqa: E402

STATS = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local/share") / "phoenixge/games.json"
LAUNCHER_BINS = {"steam", "heroic", "lutris", "prismlauncher", "xdg-open", "gio", "kioclient", "kioclient5",
                 "kioclient6", "gtk-launch", "kde-open", "kde-open5"}
LAUNCHER_FLATPAKS = {"com.valvesoftware.Steam", "com.heroicgameslauncher.hgl", "net.lutris.Lutris",
                     "org.prismlauncher.PrismLauncher"}
SELF_MARKERS = ("phoenix-game-run", "gamerun.py", "games.py", "phoenixge-games")
POLL = 2.0
GRACE = 10.0   # game gone this long = session over (covers launcher -> game exe hand-offs)


def log(*a):
    print("phoenix-game-run:", *a, file=sys.stderr)


# ------------------------------------------------------------------ helpers
def is_launcher(cmd):
    if not cmd:
        return False
    b = os.path.basename(cmd[0])
    if b in LAUNCHER_BINS:
        return True
    if b == "flatpak" and "run" in cmd:
        app = next((a for a in cmd[cmd.index("run") + 1:] if not a.startswith("-")), "")
        return app in LAUNCHER_FLATPAKS
    return any("://" in a or a.startswith("lutris:") for a in cmd[1:])


def desktop_exec(stem):
    dirs = [Path.home() / ".local/share/applications"] + \
           [Path(d) / "applications" for d in (os.environ.get("XDG_DATA_DIRS") or "/usr/local/share:/usr/share").split(":")] + \
           [Path("/var/lib/flatpak/exports/share/applications"), Path.home() / ".local/share/flatpak/exports/share/applications"]
    for d in dirs:
        f = d / f"{stem}.desktop"
        if f.exists():
            cp = configparser.ConfigParser(interpolation=None, strict=False)
            try:
                cp.read(f, encoding="utf-8")
                args = shlex.split(cp.get("Desktop Entry", "Exec", fallback=""))
            except (configparser.Error, ValueError):
                return None
            args = [a for a in args if not a.startswith("%") and "=" not in a.split("/")[0] and a != "env"]
            if args and os.path.basename(args[0]) == "flatpak":
                return None   # flatpak apps: match by name instead
            return os.path.basename(args[0]) if args else None
    return None


def auto_matchers(game_id, name, cmd):
    """Regexes that find the real game process for launcher-started games."""
    kind, _, rest = game_id.partition(":")
    pats = []
    if kind == "steam" and rest.isdigit():
        pats.append(rf"\bAppId={rest}\b")
    elif kind == "lutris":
        pats.append(r"lutris-wrapper: " + re.escape(name))
    elif kind == "prism" and rest:
        pats.append(r"instances/" + re.escape(rest) + r"\b")
    elif kind == "heroic":
        app = rest.partition(":")[2]
        if app:
            pats.append(r"(legendary|gogdl|nile)\S*\s.*\b" + re.escape(app) + r"\b")
        if len(name) >= 4:
            pats.append(re.escape(name[:20]))
    elif kind == "desktop":
        exe = desktop_exec(rest)
        if exe and exe not in LAUNCHER_BINS:
            pats.append(r"(^|/)" + re.escape(exe) + r"(\s|$)")
    if not pats and is_launcher(cmd) and len(name) >= 4:
        pats.append(re.escape(name[:20]))
    return pats


def find_pids(regexes, exclude):
    if not regexes:
        return []
    rx = re.compile("|".join(f"(?:{r})" for r in regexes), re.I)
    out = []
    for d in Path("/proc").iterdir():
        if not d.name.isdigit() or int(d.name) in exclude:
            continue
        try:
            cl = (d / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace").strip()
        except OSError:
            continue
        if cl and rx.search(cl) and not any(m in cl for m in SELF_MARKERS):
            out.append(int(d.name))
    return out


def gamemode(method, pid):
    if not shutil.which("busctl"):
        return False
    try:
        r = subprocess.run(["busctl", "--user", "call", "com.feralinteractive.GameMode", "/com/feralinteractive/GameMode",
                            "com.feralinteractive.GameMode", method, "i", str(pid)],
                           capture_output=True, text=True, timeout=5)
        return r.returncode == 0 and r.stdout.strip() == "i 0"
    except (OSError, subprocess.SubprocessError):
        return False


def add_playtime(game_id, start, seconds):
    STATS.parent.mkdir(parents=True, exist_ok=True)
    with open(STATS.with_suffix(".lock"), "w") as lk:
        fcntl.flock(lk, fcntl.LOCK_EX)
        try:
            stats = json.loads(STATS.read_text())
        except (OSError, ValueError):
            stats = {}
        s = stats.setdefault(game_id, {})
        s["last"] = max(s.get("last", 0), start)
        s["time"] = s.get("time", 0) + int(seconds)
        tmp = STATS.with_suffix(".tmp")
        tmp.write_text(json.dumps(stats))
        tmp.replace(STATS)


def mangohud_env(env, conf, folder):
    cfg = ["read_cfg", "autostart_log=1", "log_interval=100", f"output_folder={folder}"]
    if not settings.overlay_wanted(conf):
        cfg.append("no_display")
    env["MANGOHUD"] = "1"
    env["MANGOHUD_CONFIG"] = ",".join(cfg)
    env["MANGOHUD_DLSYM"] = env.get("MANGOHUD_DLSYM", "0")


# ------------------------------------------------------------------ main
def run(argv=None):
    ap = argparse.ArgumentParser(prog="phoenix-game-run", description=__doc__.split("\n\n")[0])
    ap.add_argument("--name", help="game name (Discord status, process matching)")
    ap.add_argument("--match", action="append", default=[], help="regex for the game process (repeatable)")
    ap.add_argument("--wait", type=float, default=180, help="seconds to wait for a launcher to start the game")
    ap.add_argument("--no-stats", action="store_true", help="do not write play time to games.json")
    ap.add_argument("game_id")
    ap.add_argument("command", nargs=argparse.REMAINDER)
    a = ap.parse_args(argv)
    cmd = a.command[1:] if a.command[:1] == ["--"] else a.command
    if not cmd:
        ap.error("missing command after --")
    name = a.name or a.game_id
    conf = settings.load()
    launcher = is_launcher(cmd)

    env = dict(os.environ)
    if conf["fps_log"] and (shutil.which("mangohud") or any(Path("/usr/share/vulkan/implicit_layer.d").glob("MangoHud*"))):
        folder = perf.INCOMING if launcher else perf.game_dir(a.game_id)
        folder.mkdir(parents=True, exist_ok=True)
        mangohud_env(env, conf, folder)
        if not launcher and shutil.which("mangohud") and os.path.basename(cmd[0]) != "flatpak":
            cmd = ["mangohud"] + cmd          # also covers OpenGL games (MANGOHUD=1 alone is Vulkan only)
        if os.path.basename(cmd[0]) == "flatpak" and "run" in cmd:
            i = cmd.index("run") + 1          # let a sandboxed game write its log
            cmd = cmd[:i] + ["--filesystem=xdg-data/phoenixge/perf:create"] + cmd[i:]
    try:  # per-game display profile (HDR / FSR / gamescope) from Center > Display & performance
        sys.path.insert(0, "/usr/lib/phoenixge/gamedisplay")
        import profiles as display_profiles
        env, cmd = display_profiles.apply(a.game_id, env, cmd, launcher=launcher)
    except Exception as e:  # noqa: BLE001 - display profiles are optional
        log("display profile:", e)

    def input_profile(action):  # per-game controller/keyboard profile (Center > Controllers & keys)
        if shutil.which("phoenix-input"):
            try:
                subprocess.run(["phoenix-input", action, a.game_id], stdin=subprocess.DEVNULL, timeout=20)
            except (OSError, subprocess.SubprocessError) as e:
                log("input profile:", e)

    input_profile("game-start")
    start = time.time()
    try:
        child = subprocess.Popen(cmd, env=env, stdin=subprocess.DEVNULL)
    except OSError as e:
        log("cannot start", cmd[0], e)
        input_profile("game-stop")
        return 127

    matchers = a.match + auto_matchers(a.game_id, name, cmd)
    exclude = {os.getpid(), os.getppid()}
    registered = set()
    presence = None
    if conf["discord"]:
        try:
            import discord_rpc
            presence = discord_rpc.GamePresence(name, conf["discord_client_id"] or None)
        except Exception as e:  # noqa: BLE001 - Discord is optional
            log("discord:", e)

    stop = {"now": False}

    def on_signal(*_):
        stop["now"] = True
    signal.signal(signal.SIGTERM, on_signal)
    signal.signal(signal.SIGINT, on_signal)
    signal.signal(signal.SIGHUP, on_signal)

    first_seen = last_seen = None
    if conf["gamemode"] and not launcher and gamemode("RegisterGame", child.pid):
        registered.add(child.pid)
    while not stop["now"]:
        now = time.time()
        child_alive = child.poll() is None
        pids = [p for p in find_pids(matchers, exclude) if p != child.pid]
        alive = bool(pids) or (child_alive and not launcher)
        if alive:
            first_seen = first_seen or now
            last_seen = now
            if conf["gamemode"]:
                for p in pids:
                    if p not in registered and gamemode("RegisterGame", p):
                        registered.add(p)
            if presence:
                presence.tick()
        elif first_seen is not None:
            if now - last_seen > GRACE:
                break
        elif now - start > a.wait or (not child_alive and not launcher):
            break
        time.sleep(POLL)

    end = time.time()
    if stop["now"] and not launcher and child.poll() is None:
        child.terminate()
    for p in registered:
        gamemode("UnregisterGame", p)
    input_profile("game-stop")
    if presence:
        presence.stop()

    played = (last_seen - first_seen + POLL) if first_seen else 0
    if not a.no_stats:
        try:
            add_playtime(a.game_id, start, played)
        except OSError as e:
            log("stats:", e)
    try:
        logs = perf.collect_incoming(a.game_id, start, end)
        gdir = perf.game_dir(a.game_id)
        if not launcher and gdir.is_dir():
            logs += [s["path"] for s in perf.list_sessions(a.game_id) if s["start"] >= start - 5]
        if first_seen:
            gdir.mkdir(parents=True, exist_ok=True)
            with open(gdir / "sessions.jsonl", "a") as f:
                f.write(json.dumps({"start": int(first_seen), "end": int(last_seen), "seconds": int(played),
                                    "name": name, "logs": logs}) + "\n")
        perf.prune(a.game_id, conf["keep_logs"])
        perf.prune_incoming()
    except OSError as e:
        log("perf:", e)
    return 0


if __name__ == "__main__":
    sys.exit(run())
