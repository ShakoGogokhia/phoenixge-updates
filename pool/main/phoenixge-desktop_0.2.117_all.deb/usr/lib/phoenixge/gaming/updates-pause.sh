#!/bin/sh
# Pause / resume background updates while a game runs. Runs as root via pkexec (polkit action
# org.phoenixge.gaming.pause-updates, allowed without password for the active local user) from session.py.
#   updates-pause.sh pause    stop update/maintenance timers that are active + idle-priority for running updaters
#   updates-pause.sh resume   start exactly those timers again + restore the priorities
# A safety timer resumes automatically after 6 hours in case the game session never ends cleanly.
set -u
PATH=/usr/sbin:/usr/bin:/sbin:/bin
STATE_DIR=/run/phoenixge
STATE=$STATE_DIR/gaming-pause.state
SAFETY=phoenixge-gaming-autoresume
TIMERS='^(apt-daily|apt-daily-upgrade|phoenixge-[a-z0-9-]+|fwupd-refresh|man-db|plocate-updatedb|mlocate|packagekit[a-z0-9-]*|flatpak[a-z0-9-]*|unattended-upgrades?|e2scrub_all|fstrim|logrotate)\.timer$'
PROCS='^(packagekitd|apt|apt-get|aptitude|dpkg|unattended-upgr|unattended-upgrade|flatpak|flatpak-system-helper|fwupd|fwupdmgr|man-db|mandb|updatedb|updatedb.plocate|plocate-build|timeshift)$'

pause() {
  [ -f "$STATE" ] && exit 0            # already paused (several games / a second GameMode client)
  mkdir -p "$STATE_DIR"
  : > "$STATE.tmp"
  systemctl list-units --type=timer --state=active --plain --no-legend 2>/dev/null | awk '{print $1}' |
  grep -E "$TIMERS" | while read -r t; do
    systemctl stop "$t" 2>/dev/null && echo "timer $t" >> "$STATE.tmp"
  done
  for d in /proc/[0-9]*; do
    pid=${d#/proc/}
    comm=$(cat "$d/comm" 2>/dev/null) || continue
    echo "$comm" | grep -qE "$PROCS" || continue
    ni=$(ps -o ni= -p "$pid" 2>/dev/null | tr -d ' ') || continue
    io=$(ionice -p "$pid" 2>/dev/null) || io="none: prio 0"
    cls=$(echo "$io" | cut -d: -f1); prio=$(echo "$io" | sed -n 's/.*prio \([0-9]*\).*/\1/p')
    case "$cls" in realtime) c=1 ;; best-effort) c=2 ;; idle) c=3 ;; *) c=0 ;; esac
    renice -n 19 -p "$pid" >/dev/null 2>&1
    ionice -c 3 -p "$pid" >/dev/null 2>&1
    echo "proc $pid ${ni:-0} $c ${prio:-4} $comm" >> "$STATE.tmp"
  done
  mv "$STATE.tmp" "$STATE"
  systemd-run --quiet --unit="$SAFETY" --on-active=6h /bin/sh /usr/lib/phoenixge/gaming/updates-pause.sh resume \
    >/dev/null 2>&1 || true
}

resume() {
  systemctl stop "$SAFETY.timer" >/dev/null 2>&1 || true
  [ -f "$STATE" ] || exit 0
  while read -r kind a b c d e; do
    case "$kind" in
      timer) systemctl start "$a" 2>/dev/null || true ;;
      proc)
        # same process still there (pid not reused by something else)?
        [ "$(cat /proc/"$a"/comm 2>/dev/null)" = "$e" ] || continue
        renice -n "$b" -p "$a" >/dev/null 2>&1 || true
        if [ "$c" = 0 ]; then ionice -c 0 -p "$a" >/dev/null 2>&1 || true
        elif [ "$c" = 3 ]; then ionice -c 3 -p "$a" >/dev/null 2>&1 || true
        else ionice -c "$c" -n "$d" -p "$a" >/dev/null 2>&1 || true; fi ;;
    esac
  done < "$STATE"
  rm -f "$STATE"
}

case "${1:-}" in
  pause) pause ;;
  resume) resume ;;
  status) [ -f "$STATE" ] && cat "$STATE" || echo "not paused" ;;
  *) echo "usage: $0 pause|resume|status" >&2; exit 2 ;;
esac
