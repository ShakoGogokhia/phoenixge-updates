"""Currency conversion for PhoenixGe Spotlight ("100 usd to gel", "50 eur", "₾ 20 in usd", "1,5k lari to dollars").

Rates: National Bank of Georgia official rates (GEL per `quantity` units, updated every working day), fallback
open.er-api.com (free, no key). Both are turned into {code: GEL per 1 unit}. Cached 6 h in
~/.cache/phoenixge/currency-rates.json; a stale cache is still used while a background refresh runs.

parse(query) -> (amount, from_code, to_code_or_None) or None      (pure, no network)
convert(amount, src, dst, rates) -> float
Rates().get() -> dict or None (never blocks on the network); Rates().refresh() blocks (call in a thread)
"""
import json
import re
import threading
import time
import urllib.request
from pathlib import Path

NBG_URL = "https://nbg.gov.ge/gw/api/ct/monetarypolicy/currencies/en/json"
FALLBACK_URL = "https://open.er-api.com/v6/latest/GEL"
CACHE = Path.home() / ".cache/phoenixge/currency-rates.json"
TTL = 6 * 3600
UA = {"User-Agent": "PhoenixGe-Spotlight/1.0"}

SYMBOLS = {"$": "USD", "us$": "USD", "€": "EUR", "£": "GBP", "₾": "GEL", "₽": "RUB", "₺": "TRY", "¥": "JPY",
           "₴": "UAH", "₼": "AZN", "֏": "AMD", "₸": "KZT", "₹": "INR", "₩": "KRW", "zł": "PLN", "kč": "CZK",
           "chf": "CHF", "c$": "CAD", "a$": "AUD"}
WORDS = {
    "dollar": "USD", "dollars": "USD", "buck": "USD", "bucks": "USD", "usd": "USD",
    "euro": "EUR", "euros": "EUR", "eur": "EUR",
    "lari": "GEL", "laris": "GEL", "gel": "GEL", "gell": "GEL",
    "pound": "GBP", "pounds": "GBP", "sterling": "GBP", "quid": "GBP",
    "ruble": "RUB", "rubles": "RUB", "rouble": "RUB", "roubles": "RUB", "rub": "RUB",
    "lira": "TRY", "liras": "TRY", "lire": "TRY", "tl": "TRY",
    "hryvnia": "UAH", "hryvnias": "UAH", "manat": "AZN", "manats": "AZN", "dram": "AMD", "drams": "AMD",
    "yen": "JPY", "yuan": "CNY", "renminbi": "CNY", "rmb": "CNY", "franc": "CHF", "francs": "CHF",
    "zloty": "PLN", "zlotys": "PLN", "tenge": "KZT", "rupee": "INR", "rupees": "INR", "won": "KRW",
    "dirham": "AED", "dirhams": "AED",
    # Georgian
    "ლარი": "GEL", "ლარს": "GEL", "ლარში": "GEL", "ლ": "GEL", "დოლარი": "USD", "დოლარს": "USD", "დოლარში": "USD",
    "ევრო": "EUR", "ევროში": "EUR", "ფუნტი": "GBP", "რუბლი": "RUB", "ლირა": "TRY",
}
# ISO codes accepted even when the rate table isn't loaded yet
COMMON = {"USD", "EUR", "GEL", "GBP", "RUB", "TRY", "UAH", "AZN", "AMD", "JPY", "CNY", "CHF", "PLN", "KZT", "INR",
          "KRW", "AED", "CAD", "AUD", "SEK", "NOK", "DKK", "CZK", "HUF", "ILS", "BYN", "MDL", "UZS", "KGS", "TJS",
          "TMT", "EGP", "SAR", "QAR", "KWD", "BGN", "RON", "RSD", "ISK", "BRL", "MXN", "SGD", "HKD", "NZD", "ZAR"}
DEFAULT_TARGETS = {"GEL": ["USD", "EUR"]}  # anything else -> GEL (+ USD/EUR as extra lines)

_AMOUNT = r"(\d[\d\s,.']*\d|\d)(\s*[kmкм](?![^\W\d_]))?"
_CUR = r"([^\d\s]{1,12}?)"
_TO = r"(?:\s+(?:to|in|into)\s+|\s*(?:=|->|>)\s*|\s+)"
PATTERNS = [
    re.compile(rf"^\s*{_AMOUNT}\s*{_CUR}(?:{_TO}{_CUR}\??)?\s*$", re.I),          # 100 usd [to gel]
    re.compile(rf"^\s*{_CUR}\s*{_AMOUNT}(?:{_TO}{_CUR}\??)?\s*$", re.I),          # $100 [in gel] / ₾ 20 in usd
]


def code_of(token, known=()):
    t = (token or "").strip().lower().rstrip(".?!")
    if not t:
        return None
    if t in SYMBOLS:
        return SYMBOLS[t]
    if t in WORDS:
        return WORDS[t]
    up = t.upper()
    if len(up) == 3 and up.isalpha() and up.isascii() and (up in COMMON or up in known):
        return up
    return None


def parse_amount(s, suffix=""):
    s = s.replace(" ", "").replace(" ", "").replace("'", "")
    if "," in s and "." in s:          # 1,234.50  or  1.234,50
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:                      # 1,000 (thousands) vs 2,5 (decimal comma, common in Georgia)
        parts = s.split(",")
        s = s.replace(",", "") if all(len(p) == 3 for p in parts[1:]) and len(parts[0]) <= 3 else s.replace(",", ".")
    elif s.count(".") > 1:              # 1.000.000
        s = s.replace(".", "")
    v = float(s)
    suf = (suffix or "").strip().lower()
    if suf in ("k", "к"):
        v *= 1000
    elif suf in ("m", "м"):
        v *= 1_000_000
    return v


def parse(query, known=()):
    q = (query or "").strip()
    if not q or len(q) > 60 or not any(ch.isdigit() for ch in q):
        return None
    for i, pat in enumerate(PATTERNS):
        m = pat.match(q)
        if not m:
            continue
        if i == 0:
            amount, suf, src, dst = m.group(1), m.group(2), m.group(3), m.group(4)
        else:
            src, amount, suf, dst = m.group(1), m.group(2), m.group(3), m.group(4)
        s = code_of(src, known)
        if not s:
            continue
        d = None
        if dst:
            d = code_of(dst, known)
            if not d:
                continue
        try:
            a = parse_amount(amount, suf)
        except ValueError:
            continue
        return a, s, d
    return None


def convert(amount, src, dst, rates):
    """rates: {code: GEL per 1 unit} (GEL itself = 1)."""
    return amount * rates[src] / rates[dst]


def fmt(v, code, amount=False):
    if amount and float(v).is_integer():
        s = f"{v:,.0f}"
    elif abs(v) >= 1 or v == 0:
        s = f"{v:,.2f}"
    else:
        s = f"{v:.4g}"
    return f"{s} {code}"


# ------------------------------------------------------------------ rate sources
def parse_nbg(data):
    """NBG JSON: [{"date": ..., "currencies": [{"code", "quantity", "rate", "name", ...}]}] -> (rates, date, names)"""
    block = data[0] if isinstance(data, list) and data else data
    rates, names = {"GEL": 1.0}, {"GEL": "Georgian Lari"}
    for c in block.get("currencies", []):
        try:
            q = float(c.get("quantity") or 1)
            r = float(c["rate"])
            if r > 0 and q > 0:
                rates[c["code"].upper()] = r / q
                names[c["code"].upper()] = c.get("name", "")
        except (KeyError, TypeError, ValueError):
            continue
    return rates, (block.get("date") or "")[:10], names


def parse_erapi(data):
    """open.er-api.com /latest/GEL: rates = units per 1 GEL -> GEL per unit."""
    if data.get("result") != "success":
        raise ValueError("er-api: " + str(data.get("error-type")))
    rates = {k.upper(): 1.0 / float(v) for k, v in data.get("rates", {}).items() if float(v) > 0}
    rates["GEL"] = 1.0
    return rates, time.strftime("%Y-%m-%d", time.gmtime(int(data.get("time_last_update_unix", time.time())))), {}


def fetch(url, timeout=8):
    with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


class Rates:
    def __init__(self, cache=CACHE):
        self.cache, self.data, self._lock, self._busy = Path(cache), None, threading.Lock(), False
        try:
            self.data = json.loads(self.cache.read_text(encoding="utf-8"))
        except Exception:
            self.data = None

    def fresh(self):
        return bool(self.data) and time.time() - self.data.get("fetched", 0) < TTL

    def get(self):
        """Cached table (possibly stale) right away; starts a background refresh when older than 6 h."""
        if not self.fresh():
            self.refresh_async()
        return self.data

    def refresh_async(self):
        with self._lock:
            if self._busy:
                return
            self._busy = True
        threading.Thread(target=self._refresh_bg, daemon=True).start()

    def _refresh_bg(self):
        try:
            self.refresh()
        finally:
            self._busy = False

    def refresh(self):
        for name, url, parser in [("National Bank of Georgia", NBG_URL, parse_nbg),
                                  ("open.er-api.com", FALLBACK_URL, parse_erapi)]:
            try:
                rates, date, names = parser(fetch(url))
                if len(rates) < 10:
                    raise ValueError("too few rates")
                if name != "National Bank of Georgia" and self.data and self.data.get("names"):
                    names = self.data["names"]
                d = dict(source=name, date=date, fetched=time.time(), rates=rates, names=names)
                self.data = d
                try:
                    self.cache.parent.mkdir(parents=True, exist_ok=True)
                    tmp = self.cache.with_suffix(".tmp")
                    tmp.write_text(json.dumps(d), encoding="utf-8")
                    tmp.replace(self.cache)
                except OSError:
                    pass
                return d
            except Exception as e:  # noqa: BLE001
                print("spotlight currency:", name, e)
        if self.data:  # keep using the old table, retry in 10 minutes instead of on every key press
            self.data["fetched"] = time.time() - TTL + 600
        return self.data


def results(query, table):
    """-> list of dict(text, subtext, copy, relevance) for a query, or [] if it isn't a currency question.
    table None = rates not loaded yet -> one 'loading' hint when the query looks like money."""
    p = parse(query, set((table or {}).get("rates", {})))
    if not p:
        return []
    amount, src, dst = p
    if not table:
        return [dict(text=f"{fmt(amount, src, True)} = …", subtext="Loading exchange rates (needs internet)…", copy="",
                     relevance=0.5)]
    rates = table["rates"]
    if src not in rates or (dst and dst not in rates):
        miss = src if src not in rates else dst
        return [dict(text=f"No exchange rate for {miss}", subtext=f"Source: {table.get('source')}", copy="", relevance=0.3)]
    targets = [dst] if dst else [t for t in DEFAULT_TARGETS.get(src, ["GEL", "USD", "EUR"]) if t != src]
    out = []
    when = table.get("date", "")
    for i, t in enumerate(targets):
        v = convert(amount, src, t, rates)
        unit = convert(1, src, t, rates)
        out.append(dict(text=f"{fmt(amount, src, True)} = {fmt(v, t)}",
                        subtext=f"1 {src} = {unit:.4f} {t} · {table.get('source', '')} {when} · Enter copies {v:.2f}",
                        copy=f"{v:.2f}", relevance=1.0 - i * 0.05))
    return out
