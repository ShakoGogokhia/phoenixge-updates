#!/usr/bin/env python3
"""PhoenixGe Spotlight - KRunner D-Bus runners (KRunner 6 / org.kde.krunner1).

One D-Bus service (org.phoenixge.Spotlight, started on demand by D-Bus activation) with three runner objects:
  /games     PhoenixGe Games     - games from Steam / Heroic / Lutris / Prism (the Phoenix Games sources), started
                                   through phoenix-game-run like Phoenix Games does; the cover is the icon
  /settings  PhoenixGe Settings  - PhoenixGe Center pages and cards by keyword -> phoenixge-center --page <key>
  /currency  Currency            - "100 usd to gel", "50 eur", "₾ 20 in usd" (National Bank of Georgia rates)
They show up in KRunner (Alt+Space), the Plasma search and every launcher that uses KRunner (our start menu too).
Registered by /usr/share/krunner/dbusplugins/phoenixge-*.desktop, activated by
/usr/share/dbus-1/services/org.phoenixge.Spotlight.service.

Match never touches the disk or network: everything is indexed in memory and refreshed in background threads.

Testing without D-Bus:  python3 spotlight_service.py --query "cyber"     (prints what Match would return)
"""
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import unicodedata
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import currency  # noqa: E402
import games_source  # noqa: E402

BUS_NAME = "org.phoenixge.Spotlight"
IFACE = "org.kde.krunner1"
SETTINGS_INDEX = Path(os.environ.get("PHOENIXGE_SPOTLIGHT_INDEX", "/usr/share/phoenixge/spotlight/settings-index.json"))
# KRunner::QueryMatch::CategoryRelevance (KF6)
HIGHEST, HIGH, MODERATE, LOW, LOWEST = 100, 70, 50, 30, 0
GAME_REFRESH = 90       # s: re-read launcher libraries at most this often (in the background)
THUMB = 64              # px: cover icon size
SOURCE_ICON = {"Steam": "steam", "Lutris": "lutris", "Minecraft": "org.prismlauncher.PrismLauncher",
               "Epic": "com.heroicgameslauncher.hgl", "GOG": "com.heroicgameslauncher.hgl",
               "Amazon": "com.heroicgameslauncher.hgl", "Heroic": "com.heroicgameslauncher.hgl"}
PLAY_WORDS = ("play ", "launch ", "start ", "run ", "game ", "games ")


# ------------------------------------------------------------------ text matching (pure)
def norm(s):
    s = unicodedata.normalize("NFKD", str(s)).lower()
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    s = re.sub(r"[™®©:·\-_/\\.,!?'’\"()\[\]{}+&]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def initials(n):
    """'baldur s gate 3' -> 'bg3', 'counter strike 2' -> 'cs2'"""
    return "".join(w if w.isdigit() else w[0] for w in n.split() if w and w != "s")


def text_score(q, n):
    """q, n normalized. -> (score 0..1, category relevance) or (0, 0)."""
    if not q or not n:
        return 0.0, 0
    if n == q:
        return 1.0, HIGHEST
    if n.startswith(q):
        return 0.9 - min(0.2, (len(n) - len(q)) / 200), HIGH
    words = n.split()
    if any(w.startswith(q) for w in words):
        return 0.8, HIGH if len(q) >= 3 else MODERATE
    if len(q) >= 2 and initials(n).startswith(q.replace(" ", "")):
        return 0.78, HIGH
    if len(q) >= 3 and q in n:
        return 0.7, MODERATE
    qw = q.split()
    if len(qw) > 1 and all(any(w.startswith(x) for w in words) for x in qw):
        return 0.75, HIGH
    if len(q) >= 4:  # letters in order ("wtchr" -> "witcher") - weak
        it = iter(n)
        if all(ch in it for ch in q.replace(" ", "")):
            return 0.4, LOW
    return 0.0, 0


# ------------------------------------------------------------------ games
class GamesIndex:
    def __init__(self, loader=games_source.games):
        self.loader, self.items, self.thumbs = loader, [], {}
        self.loaded_at, self._busy, self._lock = 0.0, False, threading.Lock()

    def refresh(self):
        t0 = time.time()
        try:
            gs = self.loader()
        except Exception as e:  # noqa: BLE001
            print("spotlight games:", e, file=sys.stderr)
            gs = []
        items = []
        for g in gs:
            n = norm(re.sub(r"^Minecraft · ", "minecraft ", g.get("name", "")))
            items.append(dict(g, _n=n, _cover=games_source.cover_path(g)))
        self.items = items
        self.loaded_at = time.time()
        if os.environ.get("SPOTLIGHT_DEBUG"):
            print(f"spotlight: {len(items)} games in {1000 * (time.time() - t0):.0f} ms", file=sys.stderr)
        self._make_thumbs()

    def refresh_async(self, force=False):
        if not force and time.time() - self.loaded_at < GAME_REFRESH:
            return
        with self._lock:
            if self._busy:
                return
            self._busy = True

        def work():
            try:
                self.refresh()
            finally:
                self._busy = False
        threading.Thread(target=work, daemon=True).start()

    def _make_thumbs(self):
        """Covers -> 64x64 RGBA pixel data (KRunner icon-data). Portrait covers are fitted, rounded, centred."""
        try:
            from PIL import Image, ImageDraw
        except Exception:
            return
        for g in self.items:
            c = g.get("_cover")
            if not c or (c, g["id"]) in self.thumbs:
                continue
            try:
                im = Image.open(c).convert("RGBA")
                im.thumbnail((THUMB, THUMB), Image.LANCZOS)
                mask = Image.new("L", im.size, 0)
                ImageDraw.Draw(mask).rounded_rectangle([0, 0, im.size[0] - 1, im.size[1] - 1], radius=6, fill=255)
                im.putalpha(mask)
                canvas = Image.new("RGBA", (THUMB, THUMB), (0, 0, 0, 0))
                canvas.paste(im, ((THUMB - im.size[0]) // 2, (THUMB - im.size[1]) // 2))
                self.thumbs[(c, g["id"])] = canvas.tobytes()
            except Exception:  # noqa: BLE001
                self.thumbs[(c, g["id"])] = None

    def thumb(self, g):
        return self.thumbs.get((g.get("_cover"), g["id"]))

    def match(self, query, limit=6):
        self.refresh_async()
        q = norm(query)
        boost = 0.0
        for w in PLAY_WORDS:
            if q.startswith(w.strip() + " "):
                q, boost = q[len(w):].strip(), 0.05
                break
        if len(q) < 2:
            return []
        hits = []
        for g in self.items:
            s, cat = text_score(q, g["_n"])
            if s:
                hits.append((min(1.0, s + boost), cat, g))
        hits.sort(key=lambda h: (-h[0], -(h[2].get("last") or 0), h[2]["_n"]))
        return hits[:limit]

    def get(self, gid):
        return next((g for g in self.items if g["id"] == gid), None)


def fmt_playtime(sec):
    sec = int(sec or 0)
    if sec < 60:
        return "not played yet"
    h, m = divmod(sec // 60, 60)
    return f"{h} h played" if h else f"{m} min played"


# ------------------------------------------------------------------ settings
class SettingsIndex:
    def __init__(self, path=SETTINGS_INDEX):
        self.pages = []
        try:
            self.pages = json.loads(Path(path).read_text(encoding="utf-8")).get("pages", [])
        except Exception as e:  # noqa: BLE001
            print("spotlight settings index:", e, file=sys.stderr)
        for p in self.pages:
            p["_t"] = norm(p.get("title", ""))
            p["_k"] = [norm(k) for k in p.get("keywords", [])]
            p["_c"] = [(c, norm(c)) for c in p.get("cards", [])]

    def match(self, query, limit=4):
        q = norm(query)
        for w in ("settings ", "setting ", "center ", "open "):
            if q.startswith(w):
                q = q[len(w):].strip()
        if len(q) < 2:
            return []
        out = []
        for p in self.pages:
            best, cat, card = 0.0, 0, None
            s, c = text_score(q, p["_t"])
            if s >= 0.7:
                best, cat = s, c
            for k in p["_k"]:
                if k == q:
                    s, c = 0.92, HIGH
                elif k.startswith(q) and len(q) >= 3:
                    s, c = 0.8, MODERATE
                elif len(q) >= 4 and q in k:
                    s, c = 0.65, LOW
                elif len(k) >= 3 and (q.startswith(k + " ") or q.endswith(" " + k) or f" {k} " in f" {q} "):
                    s, c = 0.7, MODERATE        # "nvidia driver", "fix lag"
                else:
                    continue
                if s > best:
                    best, cat = s, c
            for title, cn in p["_c"]:
                s, c = text_score(q, cn)
                if s >= 0.7 and s + 0.02 > best:
                    best, cat, card = min(1.0, s + 0.02), c, title
            if best:
                out.append((best, cat, p, card))
        out.sort(key=lambda h: -h[0])
        return out[:limit]


# ------------------------------------------------------------------ launching
def spawn(cmd):
    """Start an app in its own systemd scope (outlives this service), never blocks; the waiter thread reaps it."""
    if shutil.which("systemd-run"):
        cmd = ["systemd-run", "--user", "--scope", "--quiet", "--collect", "--"] + list(cmd)
    try:
        p = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             start_new_session=True)
        threading.Thread(target=p.wait, daemon=True).start()
        return True
    except Exception as e:  # noqa: BLE001
        print("spotlight: could not start", cmd, e, file=sys.stderr)
        return False


def game_command(g):
    launch = list(g.get("launch") or [])
    if shutil.which("phoenix-game-run"):
        return ["phoenix-game-run", "--name", g["name"], g["id"], "--"] + launch
    return launch


def copy_to_clipboard(text, bus=None):
    """Klipper over D-Bus (always there in Plasma), else wl-copy / xclip."""
    if bus is not None:
        try:
            k = bus.get_object("org.kde.klipper", "/klipper")
            k.setClipboardContents(text, dbus_interface="org.kde.klipper.klipper")
            return True
        except Exception as e:  # noqa: BLE001
            print("spotlight: klipper", e, file=sys.stderr)
    for cmd in (["wl-copy", "--", text], ["xclip", "-selection", "clipboard"]):
        if shutil.which(cmd[0]):
            try:
                subprocess.run(cmd, input=text if cmd[0] == "xclip" else None, text=True, timeout=3)
                return True
            except Exception:  # noqa: BLE001
                continue
    return False


# ------------------------------------------------------------------ plain (bus-free) match results
class Engine:
    """All runner logic as plain Python: match_* return [(id, text, icon, category, relevance, props), ...]."""

    def __init__(self):
        self.games = GamesIndex()
        self.settings = SettingsIndex()
        self.rates = currency.Rates()
        self.currency_last = {}

    def match_games(self, query):
        out = []
        for score, cat, g in self.games.match(query):
            props = {"subtext": f"{g.get('source', 'Game')} game · {fmt_playtime(g.get('playtime'))}",
                     "category": "Games", "actions": ["library"]}
            px = self.games.thumb(g)
            icon = SOURCE_ICON.get(g.get("source"), "applications-games")
            if px:
                props["icon-data"] = (THUMB, THUMB, THUMB * 4, True, 8, 4, px)
                icon = ""  # KRunner prefers the icon name; leave it empty so the cover is shown
            out.append((g["id"], g["name"], icon, cat, score, props))
        return out

    def match_settings(self, query):
        out = []
        for score, cat, p, card in self.settings.match(query):
            text = card if card else p["title"]
            sub = f"PhoenixGe Center › {p['title']}" if card else "PhoenixGe Center"
            out.append((f"page:{p['key']}:{card or ''}", text, p.get("icon") or "phoenixge-center", cat, score,
                        {"subtext": sub, "category": "PhoenixGe settings", "actions": []}))
        return out

    def match_currency(self, query):
        if not any(ch.isdigit() for ch in query):
            return []
        res = currency.results(query, self.rates.get())
        out = []
        for i, r in enumerate(res):
            mid = f"cur:{i}:{r['copy']}"
            self.currency_last[mid] = r["copy"]
            out.append((mid, r["text"], "accessories-calculator", HIGHEST if r["copy"] else LOW, r["relevance"],
                        {"subtext": r["subtext"], "category": "Currency", "actions": []}))
        return out

    def run_game(self, gid, action):
        if action == "library":
            return spawn(["phoenixge-games"])
        g = self.games.get(gid)
        if not g:
            self.games.refresh()
            g = self.games.get(gid)
        if g:
            self.games.refresh_async(force=True)  # play time / last played change
            return spawn(game_command(g))
        return False

    def run_setting(self, mid):
        key = mid.split(":")[1]
        return spawn(["phoenixge-center", "--page", key])


# ------------------------------------------------------------------ D-Bus
def serve():
    import dbus
    import dbus.service
    from dbus.mainloop.glib import DBusGMainLoop
    from gi.repository import GLib

    DBusGMainLoop(set_as_default=True)
    bus = dbus.SessionBus()
    engine = Engine()
    # index games before taking the name: the first Match (which activated us) then already has results
    t = threading.Thread(target=engine.games.refresh, daemon=True)
    t.start()
    t.join(3.0)

    def to_dbus(rows):
        out = dbus.Array([], signature="(sssida{sv})")
        for mid, text, icon, cat, rel, props in rows:
            p = dbus.Dictionary({}, signature="sv")
            for k, v in props.items():
                if k == "actions":
                    p[k] = dbus.Array(v, signature="s")
                elif k == "icon-data":
                    w, h, stride, alpha, bps, ch, data = v
                    p[k] = dbus.Struct((dbus.Int32(w), dbus.Int32(h), dbus.Int32(stride), dbus.Boolean(alpha),
                                        dbus.Int32(bps), dbus.Int32(ch), dbus.ByteArray(data)), signature="iiibiiay")
                else:
                    p[k] = dbus.String(v)
            out.append(dbus.Struct((mid, text, icon, dbus.Int32(cat), dbus.Double(rel), p), signature="sssida{sv}"))
        return out

    class Runner(dbus.service.Object):
        actions = []

        def rows(self, query):
            return []

        def run(self, mid, action):
            pass

        @dbus.service.method(IFACE, in_signature="s", out_signature="a(sssida{sv})")
        def Match(self, query):
            try:
                return to_dbus(self.rows(str(query)))
            except Exception as e:  # noqa: BLE001
                print("spotlight Match:", type(self).__name__, e, file=sys.stderr)
                return dbus.Array([], signature="(sssida{sv})")

        @dbus.service.method(IFACE, in_signature="ss", out_signature="")
        def Run(self, mid, action):
            try:
                self.run(str(mid), str(action))
            except Exception as e:  # noqa: BLE001
                print("spotlight Run:", type(self).__name__, e, file=sys.stderr)

        @dbus.service.method(IFACE, in_signature="", out_signature="a(sss)")
        def Actions(self):
            return dbus.Array(self.actions, signature="(sss)")

        @dbus.service.method(IFACE, in_signature="", out_signature="a{sv}")
        def Config(self):
            return dbus.Dictionary({}, signature="sv")

        @dbus.service.method(IFACE, in_signature="", out_signature="")
        def Teardown(self):
            pass

    class Games(Runner):
        actions = [("library", "Show in Phoenix Games", "phoenixge-games")]

        def rows(self, q):
            return engine.match_games(q)

        def run(self, mid, action):
            engine.run_game(mid, action)

        @dbus.service.method(IFACE, in_signature="", out_signature="")
        def Teardown(self):
            engine.games.refresh_async()  # search window closed: be fresh for next time

    class Settings(Runner):
        def rows(self, q):
            return engine.match_settings(q)

        def run(self, mid, action):
            engine.run_setting(mid)

    class Currency(Runner):
        def rows(self, q):
            return engine.match_currency(q)

        def run(self, mid, action):
            text = engine.currency_last.get(mid) or mid.split(":", 2)[-1]
            if text:
                copy_to_clipboard(text, bus)

    Games(bus, "/games")
    Settings(bus, "/settings")
    Currency(bus, "/currency")
    try:
        name = dbus.service.BusName(BUS_NAME, bus, do_not_queue=True)  # noqa: F841 (keeps the name)
    except dbus.exceptions.NameExistsException:
        print("spotlight: already running", file=sys.stderr)
        return 0
    engine.rates.get()  # warm the currency table in the background
    GLib.MainLoop().run()
    return 0


def main():
    if "--query" in sys.argv:
        q = sys.argv[sys.argv.index("--query") + 1]
        e = Engine()
        t0 = time.time()
        e.games.refresh()
        if "--wait-rates" in sys.argv and not e.rates.fresh():
            e.rates.refresh()
        print(f"# indexed {len(e.games.items)} games in {1000 * (time.time() - t0):.0f} ms")
        for name, fn in (("games", e.match_games), ("settings", e.match_settings), ("currency", e.match_currency)):
            t1 = time.perf_counter()
            rows = fn(q)
            dt = 1000 * (time.perf_counter() - t1)
            print(f"[{name}] {len(rows)} results in {dt:.2f} ms")
            for mid, text, icon, cat, rel, props in rows:
                extra = " +cover" if "icon-data" in props else ""
                print(f"   {rel:.2f} cat={cat:<3} {text!r:42} icon={icon or '-'}{extra}  | {props.get('subtext', '')}  [{mid}]")
        return 0
    return serve()


if __name__ == "__main__":
    sys.exit(main())
