"""Game list for PhoenixGe Spotlight without Qt.

Phoenix Games (/usr/lib/phoenixge/games/games.py) already knows how to read Steam, Heroic, Lutris and Prism Launcher.
Its data functions are plain Python, but the file imports PySide6 at the top for its window. Loading PySide6 into the
KRunner service would cost ~60 MB and ~300 ms, so games.py is loaded here with a tiny stand-in for PySide6: every Qt
name becomes an inert dummy class, the GUI classes in games.py are defined but never used, and only the data
functions (all_games, steam_games, ...) are called. The stand-in is removed from sys.modules right after loading.

load() -> module with all_games() or None
games() -> [dict(id, name, source, cover, cover_url, launch, playtime, last), ...]   (desktop .desktop games excluded:
          KRunner's own application runner already finds those)
cover_path(g) -> local cover image path or None (launcher caches + Phoenix Games' download cache)
"""
import importlib.util
import os
import re
import sys
import types
from pathlib import Path

GAMES_PY = Path(os.environ.get("PHOENIXGE_GAMES_PY", "/usr/lib/phoenixge/games/games.py"))
COVERS = Path.home() / ".cache/phoenixge/covers"
_mod = None


class _Dummy:
    """Stands in for every Qt class/function/enum: can be subclassed, called, read and combined."""

    def __init__(self, *a, **k):
        pass

    def __call__(self, *a, **k):
        return _Dummy()

    def __getattr__(self, name):
        return _Dummy()

    def __or__(self, other):
        return self

    __ror__ = __and__ = __rand__ = __or__


class _QtModule(types.ModuleType):
    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return _Dummy


def load(path=GAMES_PY):
    global _mod
    if _mod is not None:
        return _mod
    if not Path(path).exists():
        return None
    names = ["PySide6", "PySide6.QtCore", "PySide6.QtGui", "PySide6.QtWidgets"]
    saved = {n: sys.modules.get(n) for n in names}
    real_qt = saved["PySide6.QtCore"] is not None and not isinstance(saved["PySide6.QtCore"], _QtModule)
    try:
        if not real_qt:
            pkg = _QtModule("PySide6")
            pkg.__path__ = []
            sys.modules["PySide6"] = pkg
            for n in names[1:]:
                m = _QtModule(n)
                sys.modules[n] = m
                setattr(pkg, n.split(".")[1], m)
        spec = importlib.util.spec_from_file_location("phoenixge_games_data", str(path))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        _mod = mod
        return mod
    except Exception as e:  # noqa: BLE001
        print("spotlight: could not load", path, e, file=sys.stderr)
        return None
    finally:
        if not real_qt:
            for n in names:
                if saved[n] is None:
                    sys.modules.pop(n, None)
                else:
                    sys.modules[n] = saved[n]
            # perf.py (imported by games.py) may have bound the stand-ins - harmless, never used here


def games():
    mod = load()
    if mod is None:
        return []
    try:
        out = mod.all_games()
    except Exception as e:  # noqa: BLE001
        print("spotlight: all_games failed", e, file=sys.stderr)
        return []
    return [g for g in out if not str(g.get("id", "")).startswith("desktop:")]


def cover_path(g):
    c = g.get("cover")
    if c and Path(c).exists():
        return c
    f = COVERS / (re.sub(r"[^a-zA-Z0-9]+", "_", g.get("id", "")) + ".jpg")
    if f.exists() and f.stat().st_size > 0:
        return str(f)
    return None
