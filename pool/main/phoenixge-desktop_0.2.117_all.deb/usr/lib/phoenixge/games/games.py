#!/usr/bin/env python3
"""Phoenix Games - every game on this PC in one library (design/GameMode-*.dc.html look).

Sources: Steam (native or Flatpak), Heroic (Epic / GOG / Amazon), Lutris, Prism Launcher (Minecraft instances),
desktop games (Games menu category) and Android games from Waydroid. Covers come from the launchers' own caches
(Steam's library images are downloaded once into ~/.cache/phoenixge/covers when not cached locally).
Play time / last played are tracked for games started here (~/.local/share/phoenixge/games.json); Lutris and
Steam play time is read from their data when available.
"""
import configparser
import json
import os
import re
import sqlite3
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
from pathlib import Path

from PySide6.QtCore import QObject, QSize, Qt, Signal, QTimer
from PySide6.QtGui import QColor, QFont, QIcon, QLinearGradient, QPainter, QPainterPath, QPixmap
from PySide6.QtWidgets import (QApplication, QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
                               QScrollArea, QSizePolicy, QVBoxLayout, QWidget)

sys.path.insert(0, "/usr/lib/phoenixge/gaming")
try:
    import perf  # FPS history (MangoHud logs written by phoenix-game-run)
except Exception:
    perf = None

HOME = Path.home()
CACHE = HOME / ".cache/phoenixge/covers"
STATS = HOME / ".local/share/phoenixge/games.json"
ACCENT = "#ff8a00"


def accent():
    try:
        v = subprocess.run(["kreadconfig6", "--file", "kdeglobals", "--group", "General", "--key", "AccentColor"],
                           capture_output=True, text=True, timeout=3).stdout.strip()
        r, g, b = (int(x) for x in v.split(",")[:3])
        return QColor(r, g, b).name()
    except Exception:
        return ACCENT


# ------------------------------------------------------------------ data sources
def vdf_load(path):
    """Tiny Valve KeyValues (text VDF) reader -> nested dicts with lower-case keys."""
    try:
        text = Path(path).read_text(errors="ignore")
    except Exception:
        return {}
    stack, key = [{}], None
    for s, br in re.findall(r'"((?:[^"\\]|\\.)*)"|([{}])', text):
        if br == "{":
            d = {}
            stack[-1][(key or "").lower()] = d
            stack.append(d)
            key = None
        elif br == "}":
            if len(stack) > 1:
                stack.pop()
            key = None
        elif key is None:
            key = s
        else:
            stack[-1][key.lower()] = s.replace("\\\\", "\\")
            key = None
    return stack[0]


def steam_playtimes(root):
    """appid -> (play time in minutes, last played) from every Steam user's localconfig.vdf."""
    out = {}
    for lc in (root / "userdata").glob("*/config/localconfig.vdf"):
        d = vdf_load(lc)
        for k in ("userlocalconfigstore", "software", "valve", "steam", "apps"):
            d = d.get(k, {}) if isinstance(d, dict) else {}
        for appid, a in d.items():
            if isinstance(a, dict):
                try:
                    m, last = int(a.get("playtime", 0) or 0), int(a.get("lastplayed", 0) or 0)
                except ValueError:
                    continue
                pm, pl = out.get(appid, (0, 0))
                out[appid] = (max(m, pm), max(last, pl))
    return out


# Proton / Steam Linux Runtime / Steamworks Common Redistributables are "apps" too
STEAM_TOOLS = re.compile(r"^(Proton\b|Steam Linux Runtime|Steamworks Common Redistributables)")
STEAM_TOOL_IDS = {"228980", "1070560", "1391110", "1628350", "1493710", "2180100", "1826330", "1161040"}


def steam_games():
    roots = [HOME / ".var/app/com.valvesoftware.Steam/.local/share/Steam", HOME / ".local/share/Steam", HOME / ".steam/steam"]
    out, seen = [], set()
    for root in roots:
        lf = root / "steamapps/libraryfolders.vdf"
        if not lf.exists():
            continue
        flat = "com.valvesoftware.Steam" in str(root)
        folders = vdf_load(lf).get("libraryfolders", {})
        libs = [Path(v["path"]) for v in folders.values() if isinstance(v, dict) and v.get("path")]
        if root not in libs:
            libs.insert(0, root)
        times = steam_playtimes(root)
        for lib in libs:
            for acf in (lib / "steamapps").glob("appmanifest_*.acf"):
                st = vdf_load(acf).get("appstate", {})
                appid, name = st.get("appid", ""), st.get("name", "")
                try:
                    installed = int(st.get("stateflags", "4")) & 4  # 4 = fully installed (also set while updating)
                except ValueError:
                    installed = True
                if (not appid or not name or appid in seen or not installed or appid in STEAM_TOOL_IDS
                        or STEAM_TOOLS.search(name)):
                    continue
                seen.add(appid)
                cache = root / "appcache/librarycache"
                # old layout: <appid>_library_600x900.jpg, new (2024+): <appid>/[<hash>/]library_600x900.jpg
                cover = next((str(c) for c in [cache / f"{appid}_library_600x900.jpg", cache / f"{appid}/library_600x900.jpg",
                                               *sorted(cache.glob(f"{appid}/*/library_600x900.jpg"))] if c.exists()), None)
                launch = (["flatpak", "run", "com.valvesoftware.Steam", f"steam://rungameid/{appid}"] if flat
                          else ["steam", f"steam://rungameid/{appid}"])
                mins, last = times.get(appid, (0, 0))
                out.append(dict(id=f"steam:{appid}", name=name, source="Steam", cover=cover,
                                cover_url=f"https://cdn.cloudflare.steamstatic.com/steam/apps/{appid}/library_600x900.jpg",
                                launch=launch, playtime=mins * 60, last=last))
    return out


def read_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default


def heroic_games():
    base = HOME / ".var/app/com.heroicgameslauncher.hgl/config/heroic"
    if not base.exists():
        base = HOME / ".config/heroic"
    # installed games per runner (the store_cache libraries list every OWNED game)
    legendary = read_json(base / "legendaryConfig/legendary/installed.json", {})
    gog = read_json(base / "gog_store/installed.json", {})
    nile = read_json(base / "nile_config/nile/installed.json", [])
    installed = {
        "legendary": {k for k, v in legendary.items() if not (isinstance(v, dict) and v.get("is_dlc"))}
        if isinstance(legendary, dict) else set(),
        "gog": {g.get("appName") for g in (gog.get("installed", []) if isinstance(gog, dict) else []) if isinstance(g, dict)},
        "nile": {g.get("id") for g in (nile if isinstance(nile, list) else []) if isinstance(g, dict)},
    }
    out = []
    for lib, runner, label in [(base / "store_cache/legendary_library.json", "legendary", "Epic"),
                               (base / "store_cache/gog_library.json", "gog", "GOG"),
                               (base / "store_cache/nile_library.json", "nile", "Amazon"),
                               (base / "sideload_apps/library.json", "sideload", "Heroic")]:
        data = read_json(lib)
        # legendary/nile cache: {"library": [...]}, gog cache and sideloaded apps: {"games": [...]}
        games = (data.get("library") or data.get("games") or []) if isinstance(data, dict) else data
        for g in games if isinstance(games, list) else []:
            if not isinstance(g, dict):
                continue
            app = g.get("app_name") or g.get("appName")
            ok = g.get("is_installed") if runner == "sideload" else app in installed[runner]
            if not app or not ok or (g.get("install") or {}).get("is_dlc"):
                continue
            out.append(dict(id=f"heroic:{runner}:{app}", name=g.get("title") or app, source=label, cover=None,
                            cover_url=g.get("art_square") or g.get("art_cover") or None,
                            launch=["xdg-open", "heroic://launch?" + urllib.parse.urlencode({"appName": app, "runner": runner})]))
    return out


def lutris_games():
    out = []
    for data, launch in [(HOME / ".local/share/lutris", ["lutris"]),
                         (HOME / ".var/app/net.lutris.Lutris/data/lutris", ["flatpak", "run", "net.lutris.Lutris"])]:
        db = data / "pga.db"
        if not db.exists():
            continue
        try:
            con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
            rows = con.execute("SELECT id, slug, name, playtime, lastplayed FROM games WHERE installed=1").fetchall()
            con.close()
        except Exception as e:
            print("lutris", db, e, file=sys.stderr)
            continue
        for gid, slug, name, playtime, last in rows:
            cover = None
            for d in [data / "coverart", HOME / ".cache/lutris/coverart"]:
                if (d / f"{slug}.jpg").exists():
                    cover = str(d / f"{slug}.jpg")
                    break
            # pga.db: playtime = hours (float), lastplayed = unix time; rungameid is unique, a slug can repeat
            out.append(dict(id=f"lutris:{slug}:{gid}", name=name or slug, source="Lutris", cover=cover, cover_url=None,
                            launch=launch + [f"lutris:rungameid/{gid}"], playtime=int((playtime or 0) * 3600),
                            last=int(last or 0)))
    return out


def minecraft_instances():
    out = []
    for base, launch in [(HOME / ".var/app/org.prismlauncher.PrismLauncher/data/PrismLauncher/instances",
                          ["flatpak", "run", "org.prismlauncher.PrismLauncher"]),
                         (HOME / ".local/share/PrismLauncher/instances", ["prismlauncher"])]:
        if not base.is_dir():
            continue
        for inst in sorted(p for p in base.iterdir() if (p / "instance.cfg").exists()):
            cfg = (inst / "instance.cfg").read_text(errors="ignore")
            name = (re.findall(r"^name=(.*)$", cfg, re.M) or [inst.name])[0].strip() or inst.name
            out.append(dict(id=f"prism:{inst.name}", name=f"Minecraft · {name}", source="Minecraft", cover=None,
                            cover_url=None, launch=launch + ["--launch", inst.name],
                            color=("#3c8527", "#1e4d1a")))
    return out


def desktop_games():
    out, seen = [], set()
    dirs = [HOME / ".local/share/applications", HOME / ".local/share/flatpak/exports/share/applications",
            Path("/var/lib/flatpak/exports/share/applications"), Path("/usr/share/applications")]
    skip = {"com.valvesoftware.Steam", "com.heroicgameslauncher.hgl", "net.lutris.Lutris", "org.prismlauncher.PrismLauncher",
            "com.usebottles.bottles", "net.davidotek.pupgui2", "phoenixge-games", "org.libretro.RetroArch", "steam", "lutris",
            "heroic", "prismlauncher", "com.vysp3r.ProtonPlus", "com.github.Matoking.protontricks", "protontricks",
            "io.github.benjamimgois.goverlay", "Waydroid", "waydroid"}
    # shortcuts Steam/Heroic/Lutris/Prism create for their games -> already listed from the launcher itself
    dup = re.compile(r"steam://rungameid|heroic://launch|lutris:rungame|prismlauncher", re.I)
    for d in dirs:
        for f in d.glob("*.desktop") if d.exists() else []:
            cp = configparser.RawConfigParser(strict=False, interpolation=None)
            try:
                cp.read(f, encoding="utf-8")
                e = cp["Desktop Entry"]
            except Exception:
                continue
            if f.stem in seen:
                continue
            seen.add(f.stem)  # first dir wins: a user copy overrides (or hides) the system entry
            if (e.get("NoDisplay", "false").lower() == "true" or e.get("Hidden", "false").lower() == "true"
                    or f.stem in skip or dup.search(e.get("Exec", ""))):
                continue
            cats = e.get("Categories", "")
            android = f.stem.startswith("waydroid.")
            if "Game" not in cats.split(";") and not (android and "game" in cats.lower()):
                continue
            out.append(dict(id=f"desktop:{f.stem}", name=e.get("Name", f.stem), source="Android" if android else "PhoenixGe",
                            cover=None, cover_url=None, icon=e.get("Icon", ""),
                            launch=["kioclient", "exec", str(f)]))
    return out


def all_games():
    games = []
    for fn in (steam_games, heroic_games, lutris_games, minecraft_instances, desktop_games):
        try:
            games += fn()
        except Exception as e:
            print(fn.__name__, e, file=sys.stderr)
    stats = load_stats()
    for g in games:
        s = stats.get(g["id"], {})
        g["last"] = max(g.get("last", 0), s.get("last", 0))
        g["playtime"] = g.get("playtime", 0) + s.get("time", 0)
    games.sort(key=lambda g: g["name"].lower())
    return games


def load_stats():
    try:
        return json.loads(STATS.read_text())
    except Exception:
        return {}


def save_stats(stats):
    STATS.parent.mkdir(parents=True, exist_ok=True)
    STATS.write_text(json.dumps(stats))


# ------------------------------------------------------------------ cover art
class Covers(QObject):
    ready = Signal(str)

    def get(self, g):
        if g.get("cover") and Path(g["cover"]).exists():
            return g["cover"]
        if not g.get("cover_url"):
            return None
        CACHE.mkdir(parents=True, exist_ok=True)
        f = CACHE / (re.sub(r"[^a-zA-Z0-9]+", "_", g["id"]) + ".jpg")
        if f.exists() and f.stat().st_size > 0:
            return str(f)
        threading.Thread(target=self._fetch, args=(g["cover_url"], f, g["id"]), daemon=True).start()
        return None

    def _fetch(self, url, f, gid):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "PhoenixGe-Games/1.0"})
            data = urllib.request.urlopen(req, timeout=15).read()
            if len(data) > 1000:
                f.write_bytes(data)
                self.ready.emit(gid)
        except Exception:
            pass


SOURCE_COLORS = {"Steam": ("#1b2838", "#2a475e"), "Epic": ("#2a2a2a", "#0078f2"), "GOG": ("#5c1f7a", "#a03fd0"),
                 "Amazon": ("#232f3e", "#ff9900"), "Lutris": ("#c77d00", "#5c3a00"), "Minecraft": ("#3c8527", "#1e4d1a"),
                 "PhoenixGe": ("#7a1f0c", "#ff7a2e"), "Android": ("#1e5631", "#3ddc84")}


def fmt_time(sec):
    if sec < 60:
        return "not played yet" if sec == 0 else "< 1 min"
    h, m = divmod(int(sec) // 60, 60)
    return f"{h} h {m} min" if h else f"{m} min"


# ------------------------------------------------------------------ widgets
class Cover(QWidget):
    clicked = Signal()

    def __init__(self, game, covers, w=180):
        super().__init__()
        self.g, self.covers, self.w = game, covers, w
        self.setFixedSize(w, int(w * 1.5) + 44)
        self.setCursor(Qt.PointingHandCursor)
        self.hover = False
        self.pix = None
        self.icon = QIcon.fromTheme(game.get("icon", "")) if game.get("icon") else None
        self.reload()

    def reload(self):
        p = self.covers.get(self.g)
        self.pix = QPixmap(p) if p else None
        self.update()

    def enterEvent(self, e):
        self.hover = True; self.update()

    def leaveEvent(self, e):
        self.hover = False; self.update()

    def mouseReleaseEvent(self, e):
        self.clicked.emit()

    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.SmoothPixmapTransform)
        h = int(self.w * 1.5)
        path = QPainterPath(); path.addRoundedRect(0, 0, self.w, h, 12, 12)
        p.setClipPath(path)
        if self.pix and not self.pix.isNull():
            pm = self.pix.scaled(self.w, h, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            p.drawPixmap((self.w - pm.width()) // 2, (h - pm.height()) // 2, pm)
        else:
            a, b = self.g.get("color") or SOURCE_COLORS.get(self.g["source"], ("#333", "#555"))
            grad = QLinearGradient(0, 0, self.w, h); grad.setColorAt(0, QColor(a)); grad.setColorAt(1, QColor(b))
            p.fillRect(0, 0, self.w, h, grad)
            if self.icon and not self.icon.isNull():
                p.drawPixmap(self.w // 2 - 40, h // 2 - 70, self.icon.pixmap(80, 80))
            p.setPen(QColor("white")); f = QFont(); f.setPixelSize(17); f.setBold(True); p.setFont(f)
            p.drawText(12, h - 70, self.w - 24, 60, Qt.AlignLeft | Qt.AlignBottom | Qt.TextWordWrap, self.g["name"])
        if self.hover:
            p.fillRect(0, 0, self.w, h, QColor(255, 255, 255, 28))
        p.setClipping(False)
        if self.hover:
            p.setPen(QColor(accent())); p.setBrush(Qt.NoBrush); p.drawRoundedRect(1, 1, self.w - 2, h - 2, 12, 12)
        p.setPen(QColor("#f5f5f5")); f = QFont(); f.setPixelSize(13); f.setBold(True); p.setFont(f)
        p.drawText(2, h + 6, self.w - 4, 18, Qt.AlignLeft, p.fontMetrics().elidedText(self.g["name"], Qt.ElideRight, self.w - 4))
        p.setPen(QColor("#9a9aa6")); f.setBold(False); f.setPixelSize(11); p.setFont(f)
        p.drawText(2, h + 24, self.w - 4, 16, Qt.AlignLeft, f"{self.g['source']} · {fmt_time(self.g.get('playtime', 0))}")


class Games(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Phoenix Games")
        self.setWindowIcon(QIcon.fromTheme("phoenixge-games", QIcon.fromTheme("applications-games")))
        self.resize(1280, 800)
        self.acc = accent()
        self.setStyleSheet(f"""
            QWidget {{ background: #0e0e13; color: #f5f5f5; font-size: 13px; }}
            QLineEdit {{ background: #1b1b24; border: 1px solid #2c2c38; border-radius: 18px; padding: 8px 16px; }}
            QPushButton {{ background: #1b1b24; border: none; border-radius: 16px; padding: 7px 16px; }}
            QPushButton:checked, QPushButton#play {{ background: {self.acc}; color: #111; font-weight: 700; }}
            QScrollArea {{ border: none; }}
            #h1 {{ font-size: 30px; font-weight: 800; }}
            #dim {{ color: #9a9aa6; }}
        """)
        self.covers = Covers(); self.covers.ready.connect(self.cover_ready)
        self.cards = {}
        root = QVBoxLayout(self); root.setContentsMargins(36, 26, 36, 20); root.setSpacing(16)
        top = QHBoxLayout()
        t = QLabel("Phoenix Games"); t.setObjectName("h1"); top.addWidget(t); top.addStretch()
        self.search = QLineEdit(); self.search.setPlaceholderText("Search games…"); self.search.setFixedWidth(320)
        self.search.textChanged.connect(lambda _t: self.fill())
        top.addWidget(self.search)
        ref = QPushButton("⟳"); ref.setToolTip("Refresh"); ref.clicked.connect(self.reload); top.addWidget(ref)
        full = QPushButton("⛶"); full.setToolTip("Full screen (F11)"); full.clicked.connect(self.toggle_full); top.addWidget(full)
        root.addLayout(top)
        # hero: last played
        self.hero = QFrame(); self.hero.setFixedHeight(150)
        hl = QHBoxLayout(self.hero); hl.setContentsMargins(24, 18, 24, 18)
        hv = QVBoxLayout()
        self.hero_label = QLabel("CONTINUE PLAYING"); self.hero_label.setObjectName("dim")
        self.hero_name = QLabel(""); self.hero_name.setStyleSheet("font-size: 34px; font-weight: 800; background: transparent;")
        self.hero_info = QLabel(""); self.hero_info.setObjectName("dim")
        for x in (self.hero_label, self.hero_name, self.hero_info):
            x.setStyleSheet(x.styleSheet() + "background: transparent;"); hv.addWidget(x)
        hl.addLayout(hv); hl.addStretch()
        self.hero_play = QPushButton("▶  Play"); self.hero_play.setObjectName("play"); self.hero_play.setFixedSize(150, 44)
        hl.addWidget(self.hero_play, 0, Qt.AlignVCenter)
        root.addWidget(self.hero)
        # filters
        fl = QHBoxLayout(); fl.setSpacing(8)
        self.filter = "All"; self.fbtns = []
        for name in ["All", "Recent", "Steam", "Epic", "GOG", "Lutris", "Minecraft", "Android", "PhoenixGe"]:
            b = QPushButton(name); b.setCheckable(True); b.setChecked(name == "All")
            b.clicked.connect(lambda _=False, n=name: self.set_filter(n)); self.fbtns.append(b); fl.addWidget(b)
        fl.addStretch()
        self.count = QLabel(""); self.count.setObjectName("dim"); fl.addWidget(self.count)
        root.addLayout(fl)
        self.scroll = QScrollArea(); self.scroll.setWidgetResizable(True)
        self.gridw = QWidget(); self.grid = QGridLayout(self.gridw); self.grid.setSpacing(20)
        self.grid.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.scroll.setWidget(self.gridw); root.addWidget(self.scroll, 1)
        self.empty = QLabel("No games found yet.\nInstall Steam, Heroic or Minecraft in PhoenixGe Center > Store - "
                            "they show up here automatically.")
        self.empty.setAlignment(Qt.AlignCenter); self.empty.setObjectName("dim"); root.addWidget(self.empty); self.empty.hide()
        self.running = {}
        self.timer = QTimer(self); self.timer.timeout.connect(self.tick); self.timer.start(5000)
        self.reload()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_F11:
            self.toggle_full()
        elif e.key() == Qt.Key_Escape and self.isFullScreen():
            self.showNormal()
        else:
            super().keyPressEvent(e)

    def toggle_full(self):
        self.showNormal() if self.isFullScreen() else self.showFullScreen()

    def reload(self):
        self.games = all_games()
        self.fill()
        self.update_hero()

    def set_filter(self, n):
        self.filter = n
        for b in self.fbtns:
            b.setChecked(b.text() == n)
        self.fill()

    def visible_games(self):
        q = self.search.text().strip().lower()
        gs = [g for g in self.games if not q or q in g["name"].lower()]
        if self.filter == "Recent":
            gs = sorted([g for g in gs if g.get("last")], key=lambda g: -g["last"])
        elif self.filter != "All":
            gs = [g for g in gs if g["source"] == self.filter]
        return gs

    def fill(self):
        while self.grid.count():
            it = self.grid.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        self.cards = {}
        gs = self.visible_games()
        cols = max(1, (self.scroll.viewport().width() - 10) // 200)
        for i, g in enumerate(gs):
            c = Cover(g, self.covers)
            c.clicked.connect(lambda gg=g: self.play(gg))
            self.cards[g["id"]] = c
            self.grid.addWidget(c, i // cols, i % cols)
        self.count.setText(f"{len(gs)} games")
        self.empty.setVisible(not self.games)
        self._cols = cols

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if getattr(self, "_cols", 0) != max(1, (self.scroll.viewport().width() - 10) // 200):
            self.fill()

    def cover_ready(self, gid):
        if gid in self.cards:
            self.cards[gid].reload()

    def update_hero(self):
        recent = sorted([g for g in self.games if g.get("last")], key=lambda g: -g["last"])
        g = recent[0] if recent else (self.games[0] if self.games else None)
        self.hero.setVisible(g is not None)
        if not g:
            return
        a, b = g.get("color") or SOURCE_COLORS.get(g["source"], ("#333", "#555"))
        self.hero.setStyleSheet(f"QFrame {{ border-radius: 16px; background: qlineargradient(x1:0, y1:0, x2:1, y2:1, "
                                f"stop:0 {a}, stop:1 {b}); }}")
        self.hero_label.setText("CONTINUE PLAYING" if recent else "READY TO PLAY")
        self.hero_name.setText(g["name"])
        info = f"{g['source']} · {fmt_time(g.get('playtime', 0))}"
        s = None
        if perf:
            try:
                s = perf.last_summary(g["id"])
            except Exception:
                s = None
        if s and s.get("avg_fps"):
            info += f" · last session {s['avg_fps']:.0f} FPS (1% low {s.get('low1_fps') or 0:.0f})"
        self.hero_info.setText(info)
        self.hero_game = g
        if not getattr(self, "_hero_wired", False):
            self.hero_play.clicked.connect(lambda: self.play(self.hero_game))
            self._hero_wired = True

    def play(self, g):
        """phoenix-game-run applies the game profile (GameMode, Do Not Disturb, paused updates), logs FPS, sets
        Discord status and writes play time; it lives exactly as long as the game."""
        import shutil
        cmd = (["phoenix-game-run", "--name", g["name"], g["id"], "--"] + list(g["launch"])
               if shutil.which("phoenix-game-run") else list(g["launch"]))
        try:
            p = subprocess.Popen(cmd, start_new_session=True)
        except Exception as e:
            print("launch failed", e, file=sys.stderr)
            return
        g["last"] = time.time()
        self.running[g["id"]] = (p, time.time(), g)
        self.update_hero()

    def tick(self):
        """Notice when a game ended, then reload its play time / FPS summary."""
        for gid, (p, start, g) in list(self.running.items()):
            if p.poll() is not None:
                del self.running[gid]
                self.reload()

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Phoenix Games")
    app.setDesktopFileName("phoenixge-games")
    w = Games()
    w.show()
    if "--fullscreen" in sys.argv:
        w.showFullScreen()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
