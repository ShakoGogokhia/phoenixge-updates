#!/bin/sh
# PhoenixGe: record the "factory state" that PhoenixGe Center > Reset goes back to. Run as root.
#   sysreset-factory-snapshot.sh            called at the END of the first-boot setup (firstboot-apps.sh, all steps done):
#                                           records once; skipped on systems that were set up long ago
#   sysreset-factory-snapshot.sh --now      (Center > Reset > "Use the current system as the reset point") record again
# Records:
#   /var/lib/phoenixge/factory-packages.installed.txt   installed packages (every file system)
#   /var/lib/phoenixge/factory-flatpaks.txt             system Flatpak apps
#   btrfs (@ layout): Timeshift snapshot "PhoenixGe factory state" (on-demand tag, never rotated by Timeshift or by the
#   pre-update snapshot cleanup) and its name in /var/lib/phoenixge/factory-snapshot
set -u
D=/var/lib/phoenixge
TAG="PhoenixGe factory state"
NOW=0; [ "${1:-}" = --now ] && NOW=1
[ "$(id -u)" = 0 ] || { echo "run as root" >&2; exit 1; }
[ -d /run/live ] && exit 0
mkdir -p "$D"
if [ "$NOW" = 0 ]; then
  [ -f "$D/factory-recorded" ] && exit 0
  # a system that finished its first-boot setup more than 2 days ago is already in use - don't call that "factory"
  if [ -f "$D/firstboot-v2.done" ] && [ -n "$(find "$D/firstboot-v2.done" -mmin +2880 2>/dev/null)" ]; then
    echo "late" > "$D/factory-recorded"
    echo "PhoenixGe: system set up long ago - no automatic factory point (Center > Reset can make one)."
    exit 0
  fi
fi

dpkg-query -W -f='${db:Status-Status} ${Package}\n' | awk '$1=="installed"{print $2}' | sort -u > "$D/factory-packages.installed.txt.new" \
  && mv "$D/factory-packages.installed.txt.new" "$D/factory-packages.installed.txt"
if command -v flatpak >/dev/null 2>&1; then
  flatpak list --system --app --columns=application 2>/dev/null | sort -u > "$D/factory-flatpaks.txt"
fi

SNAP=""
BTRFS=0
if [ "$(findmnt -no FSTYPE /)" = btrfs ]; then
  case ",$(findmnt -no OPTIONS /)," in *,subvol=/@,*|*,subvol=@,*) BTRFS=1 ;; esac
fi
if [ "$BTRFS" = 1 ]; then
  if ! command -v timeshift >/dev/null 2>&1; then
    sh /usr/lib/phoenixge/apt-install.sh timeshift || { echo "PhoenixGe: Timeshift missing - factory snapshot later"; exit 1; }
  fi
  [ -f /etc/timeshift/timeshift.json ] || sh /usr/lib/phoenixge/timeshift-auto.sh || exit 1
  if grep -q 'phoenixge.snapshot=' /proc/cmdline 2>/dev/null; then
    echo "PhoenixGe: running from a snapshot - no factory point now."; exit 1
  fi
  OLD=$(cat "$D/factory-snapshot" 2>/dev/null)
  BEFORE=$(timeshift --list --scripted 2>/dev/null | grep -oE '[0-9]{4}-[0-9]{2}-[0-9]{2}_[0-9]{2}-[0-9]{2}-[0-9]{2}' | sort)
  timeout 1800 timeshift --create --comments "$TAG" --tags O --scripted || { echo "PhoenixGe: factory snapshot failed"; exit 1; }
  SNAP=$(timeshift --list --scripted 2>/dev/null | grep "$TAG" | grep -oE '[0-9]{4}-[0-9]{2}-[0-9]{2}_[0-9]{2}-[0-9]{2}-[0-9]{2}' \
         | sort | grep -Fvx "$BEFORE" | tail -n 1)
  [ -n "$SNAP" ] || SNAP=$(timeshift --list --scripted 2>/dev/null | grep "$TAG" | grep -oE '[0-9]{4}-[0-9]{2}-[0-9]{2}_[0-9]{2}-[0-9]{2}-[0-9]{2}' | sort | tail -n 1)
  echo "$SNAP" > "$D/factory-snapshot"
  # only one factory point: the previous one is replaced
  if [ -n "$OLD" ] && [ "$OLD" != "$SNAP" ]; then timeout 600 timeshift --delete --snapshot "$OLD" --scripted >/dev/null 2>&1 || true; fi
  [ -x /usr/lib/phoenixge/snapshot-menu-refresh.sh ] && /usr/lib/phoenixge/snapshot-menu-refresh.sh >/dev/null 2>&1
fi
echo "$(date '+%F %T') $([ "$NOW" = 1 ] && echo manual || echo firstboot)${SNAP:+ $SNAP}" > "$D/factory-recorded"
echo "PhoenixGe: factory point recorded${SNAP:+ (snapshot $SNAP)}."
exit 0
