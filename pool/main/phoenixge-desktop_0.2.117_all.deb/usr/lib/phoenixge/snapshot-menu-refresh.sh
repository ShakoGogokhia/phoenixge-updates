#!/bin/sh
# Rebuild grub.cfg when the list of Timeshift btrfs snapshots changed, so the GRUB submenu
# "PhoenixGe - restore previous state" always shows the current snapshots.
# Run at boot (phoenixge-snapshot-menu.service) and after every pre-update snapshot. ext4/rsync: nothing to do.
#   snapshot-menu-refresh.sh [--force]
set +e
[ "$(id -u)" = 0 ] || exit 0
[ -d /run/live ] && exit 0
grep -q 'phoenixge.snapshot=' /proc/cmdline 2>/dev/null && exit 0   # booted snapshot: its grub.cfg is not used
[ "$(findmnt -no FSTYPE /)" = btrfs ] || exit 0
[ -x /etc/grub.d/42_phoenixge-restore ] || exit 0
[ -f /boot/grub/grub.cfg ] || exit 0
command -v update-grub >/dev/null 2>&1 || exit 0
UUID=$(findmnt -no UUID /)
[ -n "$UUID" ] || exit 0
T=$(mktemp -d /tmp/phoenixge-snaps.XXXXXX) || exit 0
if mount -t btrfs -o ro,subvolid=5 "UUID=$UUID" "$T" 2>/dev/null; then
  NOW=$(ls -1 "$T/timeshift-btrfs/snapshots" 2>/dev/null | sort)
  umount "$T"
else
  rmdir "$T"; exit 0
fi
rmdir "$T"
LIST=/var/lib/phoenixge/grub-snapshots.list
OLD=$(cat "$LIST" 2>/dev/null)
[ "$NOW" = "$OLD" ] && [ "$1" != --force ] && exit 0
if update-grub >/dev/null 2>&1; then
  mkdir -p /var/lib/phoenixge
  printf '%s\n' "$NOW" > "$LIST"
  echo "PhoenixGe: boot menu updated ($(printf '%s\n' "$NOW" | grep -c .) snapshots)."
fi
exit 0
