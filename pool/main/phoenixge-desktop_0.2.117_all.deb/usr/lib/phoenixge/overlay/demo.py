"""PhoenixGe Overlay --demo: plausible sample data (screenshots, design work). Same shapes as sources.py returns."""
import math
import random
import time

_rng = random.Random(7)
_t0 = time.time()
GAME = {"name": "Cyberpunk 2077", "id": "steam:1091500", "start": _t0 - 4354, "pid": 1}


class DemoSampler:
    def __init__(self):
        self.i = 0

    def frame(self):
        self.i += 1
        base = 141 + 3 * math.sin(self.i / 9)
        fps = base + _rng.gauss(0, 2.2)
        if self.i % 47 in (0, 1):     # small stutters, so the graphs look like a real game
            fps -= _rng.uniform(25, 45)
        fps = max(60, min(144, fps))
        return {"fps": fps, "frametime": 1000 / fps}

    def history(self, n=120):
        return [self.frame() for _ in range(n)]

    def sample(self):
        return {"live": True, "frames": [self.frame() for _ in range(5)], "cpu_load": 38 + _rng.uniform(-3, 3),
                "cpu_temp": 64 + _rng.uniform(-1, 1), "ram_used": 11.4, "ram_total": 31.2,
                "gpu": {"name": "RTX 4060 Laptop", "load": 97 + _rng.uniform(-2, 2), "temp": 62.0,
                        "vram_used": 6.1, "vram_total": 8.0}}


def game_session():
    return GAME


def audio_master():
    return {"name": "Speakers (Realtek ALC287)", "volume": 72, "muted": False}


def audio_streams():
    return [{"app": "Cyberpunk 2077", "icon": "steam", "ids": [1], "volume": 100, "muted": False, "binary": "wine64"},
            {"app": "Discord", "icon": "discord", "ids": [2], "volume": 65, "muted": False, "binary": "Discord"},
            {"app": "Spotify", "icon": "spotify-client", "ids": [3], "volume": 40, "muted": False, "binary": "spotify"},
            {"app": "Firefox", "icon": "firefox-esr", "ids": [4], "volume": 30, "muted": True, "binary": "firefox-esr"}]


def media_player():
    return {"player": "spotify", "status": "Playing", "title": "Midnight City", "artist": "M83", "art": "demo:",
            "length": 243.0, "pos": 97.0}


def replay_status():
    return {"installed": True, "running": True, "seconds": "30", "folder": "~/Videos/Replays"}


def discord_status(game=None):
    return {"running": True, "flatpak": True, "presence": "Playing Cyberpunk 2077", "rpc_configured": True}


def power_profiles():
    return {"active": "performance", "available": ["performance", "balanced", "power-saver"]}
