#!/usr/bin/env python3
"""PhoenixGe Overlay - a game bar that pops over the running game (Meta+G).

    phoenixge-overlay              toggle (first start shows it; the process stays resident while hidden)
    phoenixge-overlay --show/--hide/--quit
    phoenixge-overlay --daemon     start resident but hidden (login autostart: first Meta+G opens instantly)
    phoenixge-overlay --demo       sample data (design / screenshots)
    phoenixge-overlay --demo --screenshot out.png [--size 1920x1080] [--background img] [--accent #22d3ee]

Single instance: the first process listens on $XDG_RUNTIME_DIR/phoenixge-overlay.sock, later launches only send
"toggle" (or show/hide/quit) there and exit. Esc, Meta+G again or a click on the dimmed backdrop hides it.

Widgets: Performance (live FPS/frametime from the MangoHud CSV phoenix-game-run is writing, else sensors),
Audio mixer (pactl), Now playing (MPRIS: playerctl / dbus-python), Capture (Spectacle screenshot, GPU Screen Recorder
Instant Replay), Discord status, Power profile + game session. Data lives in sources.py, sample data in demo.py.

Window: a frameless, translucent, always-on-top full-screen Tool window on the screen under the cursor. That covers
windowed and borderless-fullscreen games on KWin (Wayland and X11). NOT supported: games in exclusive fullscreen
(X11 unredirected / direct scan-out takes the screen away) and the gamescope session (its own compositor) - there
use Steam's overlay or MangoHud. A wlr-layer-shell "overlay" layer surface would be the proper Wayland way, but
LayerShellQt has no Python binding.
"""
import argparse
import hashlib
import math
import os
import socket
import subprocess
import sys
import threading
import time
import urllib.request
from collections import deque
from pathlib import Path

from PySide6.QtCore import QObject, QPointF, QRectF, QSize, QSocketNotifier, Qt, QTimer, Signal
from PySide6.QtGui import (QColor, QCursor, QFont, QFontDatabase, QGuiApplication, QIcon, QLinearGradient, QPainter,
                           QPainterPath, QPen, QPixmap, QRadialGradient)
from PySide6.QtWidgets import (QApplication, QFrame, QGridLayout, QHBoxLayout, QLabel, QPushButton, QSizePolicy,
                               QSlider, QToolButton, QVBoxLayout, QWidget)

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sources  # noqa: E402

SOCK = sources.RUNTIME / "phoenixge-overlay.sock"
DEFAULT_ACCENT = "#ff8a00"
TEXT, DIM, FAINT = "#f1f1f6", "#9b9bab", "#6c6c7c"
GOOD, WARN, BAD = "#3ddc84", "#ffb020", "#ff4d5e"
LOGO = ["/usr/share/icons/hicolor/64x64/apps/phoenixge.png", "/usr/share/pixmaps/phoenixge.png",
        os.path.join(HERE, "../../../share/icons/hicolor/64x64/apps/phoenixge.png")]


def accent():
    try:
        v = subprocess.run(["kreadconfig6", "--file", "kdeglobals", "--group", "General", "--key", "AccentColor"],
                           capture_output=True, text=True, timeout=3).stdout.strip()
        r, g, b = (int(x) for x in v.split(",")[:3])
        return QColor(r, g, b).name()
    except Exception:  # noqa: BLE001
        return DEFAULT_ACCENT


def pick_font():
    fams = set(QFontDatabase.families())
    for f in ("Sora", "Inter", "Inter Variable", "Noto Sans", "Cantarell"):
        if f in fams:
            return f
    return QApplication.font().family()


def hms(sec):
    sec = max(0, int(sec))
    h, m, s = sec // 3600, sec % 3600 // 60, sec % 60
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def temp_color(t):
    return BAD if t is not None and t >= 85 else WARN if t is not None and t >= 75 else TEXT


# ------------------------------------------------------------------ vector icons (no icon theme needed)
def paint_icon(p, name, r, color):
    p.save()
    p.setRenderHint(QPainter.Antialiasing)
    c = QColor(color)
    x, y, w, h = r.x(), r.y(), r.width(), r.height()
    pen = QPen(c, max(1.4, w / 12), Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
    p.setPen(Qt.NoPen)
    p.setBrush(c)
    path = QPainterPath()
    if name == "play":
        path.moveTo(x + w * .3, y + h * .2); path.lineTo(x + w * .82, y + h * .5); path.lineTo(x + w * .3, y + h * .8)
        path.closeSubpath(); p.drawPath(path)
    elif name == "pause":
        p.drawRoundedRect(QRectF(x + w * .26, y + h * .2, w * .16, h * .6), 1.5, 1.5)
        p.drawRoundedRect(QRectF(x + w * .58, y + h * .2, w * .16, h * .6), 1.5, 1.5)
    elif name in ("prev", "next"):
        s = 1 if name == "next" else -1
        cx = x + w / 2
        for off in (-.2, .12):
            t = QPainterPath()
            t.moveTo(cx + s * w * (off - .12), y + h * .25); t.lineTo(cx + s * w * (off + .18), y + h * .5)
            t.lineTo(cx + s * w * (off - .12), y + h * .75); t.closeSubpath(); p.drawPath(t)
        p.drawRoundedRect(QRectF(cx + s * w * .3 - w * .04, y + h * .25, w * .08, h * .5), 1, 1)
    elif name in ("speaker", "mute"):
        path.moveTo(x + w * .14, y + h * .38); path.lineTo(x + w * .3, y + h * .38); path.lineTo(x + w * .5, y + h * .2)
        path.lineTo(x + w * .5, y + h * .8); path.lineTo(x + w * .3, y + h * .62); path.lineTo(x + w * .14, y + h * .62)
        path.closeSubpath(); p.drawPath(path)
        p.setBrush(Qt.NoBrush); p.setPen(pen)
        if name == "speaker":
            p.drawArc(QRectF(x + w * .38, y + h * .32, w * .3, h * .36), -50 * 16, 100 * 16)
            p.drawArc(QRectF(x + w * .34, y + h * .18, w * .5, h * .64), -50 * 16, 100 * 16)
        else:
            p.drawLine(QPointF(x + w * .62, y + h * .38), QPointF(x + w * .86, y + h * .62))
            p.drawLine(QPointF(x + w * .86, y + h * .38), QPointF(x + w * .62, y + h * .62))
    elif name == "camera":
        p.setBrush(Qt.NoBrush); p.setPen(pen)
        p.drawRoundedRect(QRectF(x + w * .1, y + h * .3, w * .8, h * .52), w * .1, w * .1)
        p.drawEllipse(QPointF(x + w * .5, y + h * .56), w * .15, h * .15)
        p.drawLine(QPointF(x + w * .36, y + h * .3), QPointF(x + w * .42, y + h * .18))
        p.drawLine(QPointF(x + w * .42, y + h * .18), QPointF(x + w * .58, y + h * .18))
        p.drawLine(QPointF(x + w * .58, y + h * .18), QPointF(x + w * .64, y + h * .3))
    elif name == "record":
        p.setBrush(Qt.NoBrush); p.setPen(pen)
        p.drawEllipse(QPointF(x + w / 2, y + h / 2), w * .36, h * .36)
        p.setPen(Qt.NoPen); p.setBrush(QColor(BAD))
        p.drawEllipse(QPointF(x + w / 2, y + h / 2), w * .2, h * .2)
    elif name == "folder":
        p.setBrush(Qt.NoBrush); p.setPen(pen)
        path.moveTo(x + w * .1, y + h * .78); path.lineTo(x + w * .1, y + h * .24); path.lineTo(x + w * .38, y + h * .24)
        path.lineTo(x + w * .46, y + h * .34); path.lineTo(x + w * .9, y + h * .34); path.lineTo(x + w * .9, y + h * .78)
        path.closeSubpath(); p.drawPath(path)
    elif name == "bolt":
        path.moveTo(x + w * .56, y + h * .08); path.lineTo(x + w * .2, y + h * .56); path.lineTo(x + w * .48, y + h * .56)
        path.lineTo(x + w * .42, y + h * .92); path.lineTo(x + w * .8, y + h * .42); path.lineTo(x + w * .52, y + h * .42)
        path.closeSubpath(); p.drawPath(path)
    elif name == "balance":
        p.setBrush(Qt.NoBrush); p.setPen(pen)
        p.drawEllipse(QPointF(x + w / 2, y + h / 2), w * .34, h * .34)
        p.setPen(Qt.NoPen); p.setBrush(c)
        p.drawPie(QRectF(x + w * .16, y + h * .16, w * .68, h * .68), 90 * 16, 180 * 16)
    elif name == "leaf":
        path.moveTo(x + w * .18, y + h * .84)
        path.cubicTo(x + w * .1, y + h * .3, x + w * .5, y + h * .12, x + w * .86, y + h * .14)
        path.cubicTo(x + w * .88, y + h * .5, x + w * .66, y + h * .86, x + w * .18, y + h * .84)
        p.drawPath(path)
        p.setPen(QPen(QColor(0, 0, 0, 120), max(1.2, w / 14))); p.setBrush(Qt.NoBrush)
        p.drawLine(QPointF(x + w * .24, y + h * .78), QPointF(x + w * .66, y + h * .36))
    elif name == "chat":
        path.addRoundedRect(QRectF(x + w * .1, y + h * .16, w * .8, h * .56), w * .18, w * .18)
        tail = QPainterPath()
        tail.moveTo(x + w * .3, y + h * .66); tail.lineTo(x + w * .26, y + h * .88); tail.lineTo(x + w * .5, y + h * .7)
        p.drawPath(path.united(tail))
        p.setBrush(QColor(0, 0, 0, 150))
        for k in (.34, .5, .66):
            p.drawEllipse(QPointF(x + w * k, y + h * .44), w * .06, w * .06)
    p.restore()


def make_icon(name, color, size=20):
    pm = QPixmap(size * 2, size * 2)
    pm.setDevicePixelRatio(2)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    paint_icon(p, name, QRectF(0, 0, size, size), color)
    p.end()
    return QIcon(pm)


# ------------------------------------------------------------------ building blocks
class Card(QFrame):
    """Dark glass card with an uppercase header (title + optional pill on the right)."""

    def __init__(self, title, acc, parent=None):
        super().__init__(parent)
        self.acc = QColor(acc)
        self.setAttribute(Qt.WA_StyledBackground, False)
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(20, 16, 20, 18)
        self.lay.setSpacing(12)
        head = QHBoxLayout(); head.setSpacing(8)
        dot = QLabel(); dot.setFixedSize(8, 8)
        dot.setStyleSheet(f"background:{acc}; border-radius:4px;")
        self.title = QLabel(title.upper()); self.title.setObjectName("cardTitle")
        self.pill = QLabel(""); self.pill.setObjectName("pill"); self.pill.hide()
        head.addWidget(dot, 0, Qt.AlignVCenter); head.addWidget(self.title); head.addStretch(1); head.addWidget(self.pill)
        self.lay.addLayout(head)

    def set_pill(self, text, color=None):
        self.pill.setVisible(bool(text))
        self.pill.setText(text)
        c = QColor(color or DIM)
        self.pill.setStyleSheet(f"color:{c.name()}; background: rgba({c.red()},{c.green()},{c.blue()},34);"
                                f"border-radius: 9px; padding: 2px 9px; font-size: 11px; font-weight: 600;")

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        path = QPainterPath(); path.addRoundedRect(r, 16, 16)
        g = QLinearGradient(0, 0, 0, r.height())
        g.setColorAt(0, QColor(30, 30, 42, 236)); g.setColorAt(1, QColor(15, 15, 22, 236))
        p.fillPath(path, g)
        hl = QLinearGradient(0, 0, r.width(), 0)   # accent hairline along the top edge
        a1 = QColor(self.acc); a1.setAlpha(0); a2 = QColor(self.acc); a2.setAlpha(150)
        hl.setColorAt(0, a1); hl.setColorAt(0.5, a2); hl.setColorAt(1, a1)
        p.setPen(QPen(QColor(255, 255, 255, 22), 1)); p.setBrush(Qt.NoBrush); p.drawPath(path)
        p.setPen(QPen(hl, 1.2)); p.drawLine(QPointF(24, 0.8), QPointF(r.width() - 24, 0.8))

    def mousePressEvent(self, e):
        e.accept()   # clicks on a card must not reach the backdrop (which closes the overlay)


class Bar(QWidget):
    def __init__(self, color, h=4, parent=None):
        super().__init__(parent)
        self.v, self.color = 0.0, QColor(color)
        self.setFixedHeight(h)

    def set(self, v, color=None):
        self.v = 0.0 if v is None else max(0.0, min(1.0, v))
        if color:
            self.color = QColor(color)
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()); rad = r.height() / 2
        p.setPen(Qt.NoPen); p.setBrush(QColor(255, 255, 255, 26)); p.drawRoundedRect(r, rad, rad)
        if self.v > 0:
            p.setBrush(self.color); p.drawRoundedRect(QRectF(0, 0, max(r.height(), r.width() * self.v), r.height()), rad, rad)


class Graph(QWidget):
    """Area (FPS) or line (frametime) chart of the last N samples, newest on the right."""

    def __init__(self, color, kind="area", height=92, parent=None):
        super().__init__(parent)
        self.color, self.kind, self.vals, self.label, self.empty = QColor(color), kind, [], "", ""
        self.setFixedHeight(height)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

    def set(self, vals, label="", empty=""):
        self.vals, self.label, self.empty = list(vals), label, empty
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        bg = QPainterPath(); bg.addRoundedRect(QRectF(0, 0, w, h), 10, 10)
        p.fillPath(bg, QColor(255, 255, 255, 9))
        f = p.font(); f.setPixelSize(10); f.setBold(True); f.setLetterSpacing(QFont.AbsoluteSpacing, 0.6); p.setFont(f)
        p.setPen(QColor(FAINT))
        p.drawText(QRectF(10, 6, w - 20, 14), Qt.AlignLeft | Qt.AlignVCenter, self.label)
        vals = [v for v in self.vals if v is not None]
        if len(vals) < 2:
            f.setBold(False); f.setLetterSpacing(QFont.AbsoluteSpacing, 0); f.setPixelSize(12); p.setFont(f)
            p.setPen(QColor(DIM)); p.drawText(QRectF(10, 0, w - 20, h), Qt.AlignCenter | Qt.TextWordWrap, self.empty)
            return
        top, bot = 24, h - 8
        if self.kind == "area":
            hi = max(30.0, math.ceil(max(vals) * 1.22 / 10) * 10); lo = 0.0
        else:   # frametime: centre around the median so spikes stand out
            med = sorted(vals)[len(vals) // 2]
            lo, hi = max(0.0, med * 0.4), max(med * 2.2, max(vals) * 1.05)
        grid = QPen(QColor(255, 255, 255, 16), 1, Qt.DashLine)
        p.setPen(grid)
        for k in (1, 2):
            yy = top + (bot - top) * k / 3
            p.drawLine(QPointF(8, yy), QPointF(w - 8, yy))
        n = len(self.vals)
        pts = []
        for i, v in enumerate(self.vals):
            if v is None:
                continue
            xx = 8 + (w - 16) * i / max(1, n - 1)
            yy = bot - (bot - top) * (min(max(v, lo), hi) - lo) / (hi - lo)
            pts.append(QPointF(xx, yy))
        line = QPainterPath(pts[0])
        for pt in pts[1:]:
            line.lineTo(pt)
        if self.kind == "area":
            area = QPainterPath(line); area.lineTo(pts[-1].x(), bot); area.lineTo(pts[0].x(), bot); area.closeSubpath()
            g = QLinearGradient(0, top, 0, bot)
            c1 = QColor(self.color); c1.setAlpha(110); c2 = QColor(self.color); c2.setAlpha(0)
            g.setColorAt(0, c1); g.setColorAt(1, c2)
            p.fillPath(area, g)
        p.setPen(QPen(self.color, 2.0 if self.kind == "area" else 1.5)); p.setBrush(Qt.NoBrush); p.drawPath(line)
        p.setPen(Qt.NoPen); p.setBrush(self.color); p.drawEllipse(pts[-1], 3, 3)
        f.setLetterSpacing(QFont.AbsoluteSpacing, 0); f.setBold(False); p.setFont(f); p.setPen(QColor(FAINT))
        unit = "" if self.kind == "area" else " ms"
        p.drawText(QRectF(10, 6, w - 20, 14), Qt.AlignRight | Qt.AlignVCenter, f"max {hi:.0f}{unit}")


class Tile(QWidget):
    """Small stat: LABEL / big value / sub line / bar."""

    def __init__(self, label, acc, parent=None):
        super().__init__(parent)
        self.setObjectName("tile")
        self.setAttribute(Qt.WA_StyledBackground, True)
        v = QVBoxLayout(self); v.setContentsMargins(12, 10, 12, 12); v.setSpacing(3)
        self.l = QLabel(label.upper()); self.l.setObjectName("tileLabel")
        self.v = QLabel("—"); self.v.setObjectName("tileValue")
        self.s = QLabel(""); self.s.setObjectName("tileSub")
        self.bar = Bar(acc, 4)
        v.addWidget(self.l); v.addWidget(self.v); v.addWidget(self.s); v.addSpacing(4); v.addWidget(self.bar)

    def set(self, value, sub="", frac=None, color=None, value_color=TEXT):
        self.v.setText(value)
        self.v.setStyleSheet(f"color:{value_color};")
        self.s.setText(sub)
        self.bar.set(frac, color)


def round_button(icon, acc, size=40, primary=False):
    b = QToolButton()
    b.setObjectName("roundPrimary" if primary else "round")
    b.setIcon(make_icon(icon, "#16110a" if primary else TEXT, int(size * .5)))
    b.setIconSize(QSize(int(size * .5), int(size * .5)))
    b.setFixedSize(size, size)
    b.setCursor(Qt.PointingHandCursor)
    return b


# ------------------------------------------------------------------ cards
class PerfCard(Card):
    HISTORY = 300   # MangoHud logs every 100 ms -> 30 s

    def __init__(self, acc):
        super().__init__("Performance", acc)
        self.frames = deque(maxlen=self.HISTORY)
        top = QHBoxLayout(); top.setSpacing(16)
        big = QVBoxLayout(); big.setSpacing(0)
        self.fps = QLabel("—"); self.fps.setObjectName("bigFps"); self.fps.setStyleSheet(f"color:{acc};")
        cap = QLabel("FPS"); cap.setObjectName("tileLabel")
        big.addWidget(self.fps); big.addWidget(cap)
        top.addLayout(big)
        top.addStretch(1)
        self.stats = {}
        for key, label in (("avg", "Average"), ("low", "1% low"), ("ft", "Frametime")):
            col = QVBoxLayout(); col.setSpacing(2)
            l = QLabel(label.upper()); l.setObjectName("tileLabel")
            v = QLabel("—"); v.setObjectName("midValue")
            col.addWidget(l); col.addWidget(v); col.addStretch(1)
            top.addLayout(col); self.stats[key] = v
        self.lay.addLayout(top)
        self.fps_graph = Graph(acc, "area", 96)
        self.ft_graph = Graph("#cfd3ff", "line", 56)
        self.lay.addWidget(self.fps_graph); self.lay.addWidget(self.ft_graph)
        self.hint = QLabel("FPS appears when a game is started from Phoenix Games, or turn on the FPS counter in "
                           "PhoenixGe Center → Gaming.")
        self.hint.setObjectName("hint"); self.hint.setWordWrap(True)
        self.lay.addWidget(self.hint)
        grid = QGridLayout(); grid.setSpacing(10)
        self.cpu, self.gpu, self.vram, self.ram = (Tile(t, acc) for t in ("CPU", "GPU", "VRAM", "RAM"))
        for i, t in enumerate((self.cpu, self.gpu, self.vram, self.ram)):
            grid.addWidget(t, i // 2, i % 2)
        self.lay.addLayout(grid)

    def update_data(self, s):
        self.frames.extend(s.get("frames") or [])
        live = bool(s.get("live")) and bool(self.frames)
        self.set_pill("● MANGOHUD LIVE" if live else "SENSORS", GOOD if live else DIM)
        self.hint.setVisible(not live)
        fps = [f["fps"] for f in self.frames]
        ft = [f.get("frametime") or (1000 / f["fps"]) for f in self.frames]
        if live and fps:
            recent = fps[-5:]
            self.fps.setText(f"{sum(recent) / len(recent):.0f}")
            self.fps.setStyleSheet(f"color:{self.acc.name()};")
            srt = sorted(fps); n = max(1, len(srt) // 100)
            self.stats["avg"].setText(f"{sum(fps) / len(fps):.0f}")
            self.stats["low"].setText(f"{sum(srt[:n]) / n:.0f}")
            self.stats["ft"].setText(f"{sum(ft[-5:]) / len(ft[-5:]):.1f} ms")
        else:
            self.fps.setText("—")
            self.fps.setStyleSheet(f"color:{FAINT};")
            for v in self.stats.values():
                v.setText("—")
        self.fps_graph.set(fps if live else [], "FPS · LAST 30 S", "No FPS data")
        self.ft_graph.set(ft if live else [], "FRAMETIME", "")
        self.ft_graph.setVisible(live)
        cl, ct = s.get("cpu_load"), s.get("cpu_temp")
        self.cpu.set("—" if cl is None else f"{cl:.0f}%", "" if ct is None else f"{ct:.0f} °C",
                     None if cl is None else cl / 100, None)
        self.cpu.s.setStyleSheet(f"color:{temp_color(ct) if ct and ct >= 75 else DIM};")
        g = s.get("gpu") or {}
        gt = g.get("temp")
        sub = " · ".join(x for x in ("" if gt is None else f"{gt:.0f} °C", g.get("name", "")) if x)
        self.gpu.set("—" if g.get("load") is None else f"{g['load']:.0f}%", sub or "no GPU sensor",
                     None if g.get("load") is None else g["load"] / 100)
        self.gpu.s.setStyleSheet(f"color:{temp_color(gt) if gt and gt >= 75 else DIM};")
        vu, vt = g.get("vram_used"), g.get("vram_total")
        if vu is not None and vt:
            self.vram.set(f"{vu:.1f} GB", f"of {vt:.1f} GB", vu / vt)
        else:
            self.vram.set("—", "not reported", None)
        ru, rt = s.get("ram_used"), s.get("ram_total")
        if ru is not None and rt:
            self.ram.set(f"{ru:.1f} GB", f"of {rt:.1f} GB", ru / rt)


class AudioRow(QWidget):
    def __init__(self, acc, master=False):
        super().__init__()
        self.ids, self.muted, self.master, self.acc, self.dragging = [], False, master, acc, False
        g = QGridLayout(self); g.setContentsMargins(0, 0, 0, 0); g.setHorizontalSpacing(10); g.setVerticalSpacing(5)
        self.icon = QLabel(); self.icon.setFixedSize(28, 28)
        self.name = QLabel(""); self.name.setObjectName("rowName")
        self.slider = QSlider(Qt.Horizontal); self.slider.setRange(0, 100)
        self.slider.setCursor(Qt.PointingHandCursor)
        self.pct = QLabel("0%"); self.pct.setObjectName("pct"); self.pct.setFixedWidth(38)
        self.pct.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.mute = QToolButton(); self.mute.setObjectName("round"); self.mute.setFixedSize(30, 30)
        self.mute.setCursor(Qt.PointingHandCursor); self.mute.setIconSize(QSize(16, 16))
        g.addWidget(self.icon, 0, 0, 2, 1, Qt.AlignVCenter)
        g.addWidget(self.name, 0, 1, 1, 2)
        g.addWidget(self.slider, 1, 1)
        g.addWidget(self.pct, 1, 2)
        g.addWidget(self.mute, 0, 3, 2, 1, Qt.AlignVCenter)
        g.setColumnStretch(1, 1)
        self.slider.sliderPressed.connect(lambda: setattr(self, "dragging", True))
        self.slider.sliderReleased.connect(self._released)
        self.slider.valueChanged.connect(self._changed)
        self.mute.clicked.connect(self._toggle_mute)
        self.on_volume = self.on_mute = None

    def set(self, name, volume, muted, icon=None, ids=()):
        self.ids, self.muted = list(ids), muted
        self.name.setText(name)
        if not self.dragging:
            self.slider.blockSignals(True); self.slider.setValue(min(100, volume)); self.slider.blockSignals(False)
        self.pct.setText(f"{volume}%")
        self.icon.setPixmap(self.app_pixmap(name, icon))
        self.mute.setIcon(make_icon("mute" if muted else "speaker", BAD if muted else TEXT, 16))
        self.name.setStyleSheet(f"color:{FAINT if muted else TEXT};")
        self.slider.setEnabled(not muted)

    def app_pixmap(self, name, icon):
        if self.master:
            pm = QPixmap(56, 56); pm.setDevicePixelRatio(2); pm.fill(Qt.transparent)
            p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing)
            c = QColor(self.acc); c.setAlpha(46); p.setPen(Qt.NoPen); p.setBrush(c)
            p.drawRoundedRect(QRectF(0, 0, 28, 28), 8, 8)
            paint_icon(p, "speaker", QRectF(5, 5, 18, 18), self.acc); p.end()
            return pm
        ic = QIcon.fromTheme(icon) if icon else QIcon()
        if not ic.isNull():
            return ic.pixmap(28, 28)
        pm = QPixmap(56, 56); pm.setDevicePixelRatio(2); pm.fill(Qt.transparent)
        p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing)
        hue = int(hashlib.md5(name.lower().encode()).hexdigest()[:4], 16) % 360
        p.setPen(Qt.NoPen); p.setBrush(QColor.fromHsl(hue, 150, 92)); p.drawRoundedRect(QRectF(0, 0, 28, 28), 8, 8)
        f = p.font(); f.setPixelSize(13); f.setBold(True); p.setFont(f); p.setPen(QColor("white"))
        p.drawText(QRectF(0, 0, 28, 28), Qt.AlignCenter, (name[:1] or "?").upper()); p.end()
        return pm

    def _changed(self, v):
        self.pct.setText(f"{v}%")
        if self.on_volume:
            self.on_volume(self, v)

    def _released(self):
        self.dragging = False
        self._changed(self.slider.value())

    def _toggle_mute(self):
        self.muted = not self.muted
        self.mute.setIcon(make_icon("mute" if self.muted else "speaker", BAD if self.muted else TEXT, 16))
        self.slider.setEnabled(not self.muted)
        self.name.setStyleSheet(f"color:{FAINT if self.muted else TEXT};")
        if self.on_mute:
            self.on_mute(self, self.muted)


class AudioCard(Card):
    MAX_APPS = 5

    def __init__(self, acc, actions):
        super().__init__("Audio", acc)
        self.actions = actions
        self.master = AudioRow(acc, master=True)
        self.master.on_volume = lambda r, v: actions.master_volume(v)
        self.master.on_mute = lambda r, m: actions.master_mute(m)
        self.lay.addWidget(self.master)
        sep = QFrame(); sep.setObjectName("sep"); sep.setFixedHeight(1); self.lay.addWidget(sep)
        self.rows = []
        for _ in range(self.MAX_APPS):
            r = AudioRow(acc)
            r.on_volume = lambda row, v: actions.stream_volume(row.ids, v)
            r.on_mute = lambda row, m: actions.stream_mute(row.ids, m)
            self.lay.addWidget(r); r.hide(); self.rows.append(r)
        self.empty = QLabel("No app is playing sound right now."); self.empty.setObjectName("hint")
        self.lay.addWidget(self.empty)

    def update_data(self, master, streams):
        if not master or master.get("unavailable"):
            self.set_pill("no sound server" if master else "pactl missing", WARN)
            self.master.set("Output", 0, True)
            self.master.setEnabled(False)
        else:
            self.set_pill(master["name"][:34], DIM)
            self.master.setEnabled(True)
            self.master.set("Master volume", master["volume"], master["muted"])
        streams = streams or []
        for r, s in zip(self.rows, streams):
            r.set(s["app"], s["volume"], s["muted"], s.get("icon"), s["ids"]); r.show()
        for r in self.rows[len(streams):]:
            r.hide()
        self.empty.setVisible(not streams)


class MediaCard(Card):
    def __init__(self, acc, actions):
        super().__init__("Now playing", acc)
        self.actions, self.acc, self.player, self.art_url, self.art = actions, acc, None, None, None
        body = QHBoxLayout(); body.setSpacing(14)
        self.cover = QLabel(); self.cover.setFixedSize(84, 84)
        info = QVBoxLayout(); info.setSpacing(3)
        self.title_l = QLabel(""); self.title_l.setObjectName("mediaTitle")
        self.artist = QLabel(""); self.artist.setObjectName("dim")
        self.progress = Bar(acc, 4)
        times = QHBoxLayout()
        self.t0 = QLabel(""); self.t0.setObjectName("small"); self.t1 = QLabel(""); self.t1.setObjectName("small")
        times.addWidget(self.t0); times.addStretch(1); times.addWidget(self.t1)
        info.addWidget(self.title_l); info.addWidget(self.artist); info.addStretch(1)
        info.addWidget(self.progress); info.addLayout(times)
        body.addWidget(self.cover); body.addLayout(info, 1)
        self.lay.addLayout(body)
        ctl = QHBoxLayout(); ctl.setSpacing(14); ctl.addStretch(1)
        self.prev = round_button("prev", acc, 38)
        self.play = round_button("pause", acc, 46, primary=True)
        self.next = round_button("next", acc, 38)
        for b, cmd in ((self.prev, "previous"), (self.play, "play-pause"), (self.next, "next")):
            b.clicked.connect(lambda _=False, c=cmd: actions.media(self.player, c))
            ctl.addWidget(b, 0, Qt.AlignVCenter)
        ctl.addStretch(1)
        self.lay.addLayout(ctl)
        self.empty = QLabel("Nothing is playing. Music from Spotify, a browser or Elisa shows up here.")
        self.empty.setObjectName("hint"); self.empty.setWordWrap(True)
        self.lay.addWidget(self.empty)

    def set_art(self, pm):
        out = QPixmap(168, 168); out.setDevicePixelRatio(2); out.fill(Qt.transparent)
        p = QPainter(out); p.setRenderHint(QPainter.Antialiasing); p.setRenderHint(QPainter.SmoothPixmapTransform)
        clip = QPainterPath(); clip.addRoundedRect(QRectF(0, 0, 84, 84), 12, 12); p.setClipPath(clip)
        if pm and not pm.isNull():
            pm = pm.scaled(168, 168, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            pm.setDevicePixelRatio(2); p.drawPixmap(0, 0, pm)
        else:   # placeholder: accent gradient with a note
            g = QLinearGradient(0, 0, 84, 84); g.setColorAt(0, QColor(self.acc)); g.setColorAt(1, QColor("#2a1640"))
            p.fillRect(QRectF(0, 0, 84, 84), g)
            p.setPen(QPen(QColor(255, 255, 255, 220), 3)); p.setBrush(QColor(255, 255, 255, 220))
            p.drawEllipse(QPointF(34, 56), 8, 6.5); p.drawEllipse(QPointF(56, 50), 8, 6.5)
            p.drawLine(QPointF(41, 56), QPointF(41, 26)); p.drawLine(QPointF(63, 50), QPointF(63, 20))
            p.drawLine(QPointF(41, 26), QPointF(63, 20))
        p.end()
        self.cover.setPixmap(out)

    def update_data(self, m):
        has = bool(m)
        for w in (self.cover, self.title_l, self.artist, self.progress, self.t0, self.t1, self.prev, self.play, self.next):
            w.setVisible(has)
        self.empty.setVisible(not has)
        if not has:
            self.set_pill("", None)
            return
        self.player = m["player"]
        self.set_pill(m["player"].split(".")[0].capitalize() + ("  ❚❚" if m["status"] == "Paused" else ""),
                      self.acc if m["status"] == "Playing" else DIM)
        fm = self.title_l.fontMetrics()
        self.title_l.setText(fm.elidedText(m["title"] or "Unknown title", Qt.ElideRight, max(120, self.width() - 160)))
        self.artist.setText(m["artist"] or "")
        self.progress.set(m["pos"] / m["length"] if m.get("length") else 0)
        self.t0.setText(hms(m["pos"]) if m.get("length") else ""); self.t1.setText(hms(m["length"]) if m.get("length") else "")
        self.play.setIcon(make_icon("pause" if m["status"] == "Playing" else "play", "#16110a", 23))
        if m.get("art") != self.art_url:
            self.art_url = m.get("art")
            self.set_art(None)
            self.actions.load_art(self.art_url, self.set_art)


class CaptureCard(Card):
    def __init__(self, acc, actions):
        super().__init__("Capture", acc)
        self.actions, self.replay = actions, {}
        row = QHBoxLayout(); row.setSpacing(10)
        self.shot = self._big("camera", "Screenshot")
        self.save = self._big("record", "Save last 30 s")
        self.folder = self._big("folder", "Captures")
        for b in (self.shot, self.save, self.folder):
            row.addWidget(b)
        self.lay.addLayout(row)
        self.status = QLabel(""); self.status.setObjectName("hint"); self.status.setWordWrap(True)
        self.lay.addWidget(self.status); self.status.hide()
        self.shot.clicked.connect(actions.screenshot)
        self.save.clicked.connect(self._replay)
        self.folder.clicked.connect(actions.open_captures)

    def _big(self, icon, text):
        b = QToolButton(); b.setObjectName("big")
        b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
        b.setIcon(make_icon(icon, TEXT, 26)); b.setIconSize(QSize(26, 26)); b.setText(text)
        b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed); b.setFixedHeight(76)
        b.setCursor(Qt.PointingHandCursor)
        return b

    def _replay(self):
        st = self.replay
        if st.get("running"):
            self.actions.replay_save()
            self.flash(f"Saving the last {st.get('seconds') or 30} s to {st.get('folder')} …")
        elif st.get("installed"):
            self.actions.replay_start()
            self.flash("Starting Instant Replay - KDE asks once which screen to record.")
        else:
            self.actions.get_replay()

    def update_data(self, st):
        self.replay = st or {}
        if self.replay.get("running"):
            sec = self.replay.get("seconds") or "30"
            self.save.setText(f"Save last {sec} s")
            self.set_pill(f"● REPLAY ON · {sec} S", BAD)
        elif self.replay.get("installed"):
            self.save.setText("Start Instant Replay")
            self.set_pill("REPLAY OFF", DIM)
        else:
            self.save.setText("Get Instant Replay")
            self.set_pill("", None)

    def flash(self, text):
        self.status.setText(text); self.status.setVisible(bool(text))


class DiscordCard(Card):
    def __init__(self, acc, actions):
        super().__init__("Discord", acc)
        self.actions, self.flat = actions, False
        row = QHBoxLayout(); row.setSpacing(12)
        ic = QLabel(); pm = QPixmap(64, 64); pm.setDevicePixelRatio(2); pm.fill(Qt.transparent)
        p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing); p.setPen(Qt.NoPen); p.setBrush(QColor("#5865f2"))
        p.drawRoundedRect(QRectF(0, 0, 32, 32), 9, 9); paint_icon(p, "chat", QRectF(6, 6, 20, 20), "white"); p.end()
        ic.setPixmap(pm); ic.setFixedSize(32, 32)
        col = QVBoxLayout(); col.setSpacing(1)
        self.state = QLabel(""); self.state.setObjectName("rowName")
        self.presence = QLabel(""); self.presence.setObjectName("dim")
        col.addWidget(self.state); col.addWidget(self.presence)
        self.open = QPushButton("Open"); self.open.setCursor(Qt.PointingHandCursor)
        self.open.clicked.connect(lambda: actions.discord(self.flat))
        row.addWidget(ic, 0, Qt.AlignTop); row.addLayout(col, 1); row.addWidget(self.open, 0, Qt.AlignVCenter)
        self.lay.addLayout(row)
        self.hint = QLabel("Mute / deafen stay in Discord: it has no control for other apps. "
                           "Set them in Discord → Settings → Keybinds.")
        self.hint.setObjectName("hint"); self.hint.setWordWrap(True)
        self.lay.addWidget(self.hint)

    def update_data(self, d):
        d = d or {}
        self.flat = d.get("flatpak", False)
        if d.get("running"):
            self.set_pill("● ONLINE", GOOD)
            self.state.setText("Discord is running")
            self.presence.setText(d.get("presence") or ("Game status: off (no Discord app id set)"
                                                       if not d.get("rpc_configured") else "No game status right now"))
            self.open.setText("Open")
        else:
            self.set_pill("NOT RUNNING", DIM)
            self.state.setText("Discord is not running")
            self.presence.setText("Start it to show “Playing …” to friends")
            self.open.setText("Start")


class PowerCard(Card):
    NAMES = (("performance", "Performance", "bolt"), ("balanced", "Balanced", "balance"),
             ("power-saver", "Battery saver", "leaf"))

    def __init__(self, acc, actions):
        super().__init__("Power", acc)
        self.acc, self.actions = acc, actions
        seg = QHBoxLayout(); seg.setSpacing(8)
        self.btns = {}
        for key, label, icon in self.NAMES:
            b = QToolButton(); b.setObjectName("seg"); b.setCheckable(True); b.setText(label)
            b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon); b.setIconSize(QSize(20, 20))
            b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed); b.setFixedHeight(64)
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, k=key: self._pick(k))
            seg.addWidget(b); self.btns[key] = (b, icon)
        self.lay.addLayout(seg)
        grid = QGridLayout(); grid.setHorizontalSpacing(14); grid.setVerticalSpacing(6)
        self.game = QLabel("—"); self.session = QLabel("—")
        for i, (k, v) in enumerate((("Game", self.game), ("Session", self.session))):
            l = QLabel(k); l.setObjectName("dim")
            v.setObjectName("rowName"); v.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            grid.addWidget(l, i, 0); grid.addWidget(v, i, 1)
        self.lay.addLayout(grid)
        self.note = QLabel("While a game runs, PhoenixGe switches to Performance by itself and restores it afterwards.")
        self.note.setObjectName("hint"); self.note.setWordWrap(True)
        self.lay.addWidget(self.note)
        self.start = None

    def _pick(self, key):
        self._mark(key)
        self.actions.power(key)

    def _mark(self, active):
        for key, (b, icon) in self.btns.items():
            b.setChecked(key == active)
            b.setIcon(make_icon(icon, "#16110a" if key == active else TEXT, 20))

    def update_data(self, prof, game):
        if prof is None:
            self.set_pill("unavailable", WARN)
            for b, _ in self.btns.values():
                b.setEnabled(False)
            self._mark(None)
        else:
            self.set_pill("", None)
            for key, (b, _) in self.btns.items():
                b.setEnabled(key in prof["available"])
            self._mark(prof["active"])
        if game:
            self.game.setText(game.get("name") or "Game (GameMode)")
            self.start = game.get("start")
        else:
            self.game.setText("No game running"); self.start = None
        self.tick()

    def tick(self):
        self.session.setText(hms(time.time() - self.start) if self.start else "—")


class TopBar(QFrame):
    def __init__(self, acc, font_family):
        super().__init__()
        self.acc, self.start = QColor(acc), None
        h = QHBoxLayout(self); h.setContentsMargins(16, 10, 18, 10); h.setSpacing(12)
        logo = QLabel(); logo.setFixedSize(36, 36)
        pm = next((QPixmap(p) for p in LOGO if os.path.exists(p)), QPixmap())
        if not pm.isNull():
            pm = pm.scaled(72, 72, Qt.KeepAspectRatio, Qt.SmoothTransformation); pm.setDevicePixelRatio(2)
            logo.setPixmap(pm)
        brand = QLabel(f"<span style='font-weight:800'>PhoenixGe</span> <span style='color:{DIM};font-weight:500'>"
                       f"Overlay</span>"); brand.setObjectName("brand")
        sep = QFrame(); sep.setObjectName("vsep"); sep.setFixedSize(1, 26)
        self.dot = QLabel(); self.dot.setFixedSize(8, 8)
        self.game = QLabel(""); self.game.setObjectName("gameName")
        self.sess = QLabel(""); self.sess.setObjectName("dim")
        h.addWidget(logo); h.addWidget(brand); h.addSpacing(6); h.addWidget(sep); h.addSpacing(6)
        h.addWidget(self.dot, 0, Qt.AlignVCenter); h.addWidget(self.game); h.addWidget(self.sess)
        h.addStretch(1)
        for k in ("Meta+G", "Esc"):
            kc = QLabel(k); kc.setObjectName("key"); h.addWidget(kc)
        close = QLabel("to close"); close.setObjectName("dim"); h.addWidget(close)
        h.addSpacing(10)
        sep2 = QFrame(); sep2.setObjectName("vsep"); sep2.setFixedSize(1, 26); h.addWidget(sep2); h.addSpacing(10)
        tc = QVBoxLayout(); tc.setSpacing(0)
        self.clock = QLabel(""); self.clock.setObjectName("clock"); self.clock.setAlignment(Qt.AlignRight)
        self.date = QLabel(""); self.date.setObjectName("small"); self.date.setAlignment(Qt.AlignRight)
        tc.addWidget(self.clock); tc.addWidget(self.date)
        h.addLayout(tc)

    def set_game(self, game):
        if game:
            self.dot.setStyleSheet(f"background:{GOOD}; border-radius:4px;")
            self.game.setText(game.get("name") or "Game running")
            self.start = game.get("start")
        else:
            self.dot.setStyleSheet(f"background:{FAINT}; border-radius:4px;")
            self.game.setText("No game running"); self.start = None
        self.tick()

    def tick(self):
        self.clock.setText(time.strftime("%H:%M"))
        self.date.setText(time.strftime("%a %d %b"))
        self.sess.setText(f"·  {hms(time.time() - self.start)}" if self.start else "")

    def paintEvent(self, _e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        path = QPainterPath(); path.addRoundedRect(r, r.height() / 2, r.height() / 2)
        p.fillPath(path, QColor(16, 16, 24, 230))
        p.setPen(QPen(QColor(255, 255, 255, 24), 1)); p.drawPath(path)

    def mousePressEvent(self, e):
        e.accept()


# ------------------------------------------------------------------ actions (real or demo)
class Actions(QObject):
    art_ready = Signal(str, object)

    def __init__(self, win, demo=False):
        super().__init__()
        self.win, self.demo = win, demo
        self.art_ready.connect(self._art_done)
        self.art_cb = {}

    def master_volume(self, v):
        self.demo or sources.set_master_volume(v)

    def master_mute(self, m):
        self.demo or sources.set_master_mute(m)

    def stream_volume(self, ids, v):
        self.demo or sources.set_stream_volume(ids, v)

    def stream_mute(self, ids, m):
        self.demo or sources.set_stream_mute(ids, m)

    def media(self, player, cmd):
        if not self.demo:
            sources.media_command(player, cmd)
            QTimer.singleShot(300, self.win.refresh_slow)

    def power(self, key):
        if not self.demo:
            threading.Thread(target=sources.set_power_profile, args=(key,), daemon=True).start()

    def screenshot(self):
        game = self.win.game
        self.win.hide_overlay()

        def take():
            path = None if self.demo else sources.screenshot(game)
            self.win.capture.flash(f"Screenshot saved: {path}" if path else "Spectacle is not installed.")
        QTimer.singleShot(450, take)   # let the compositor drop the overlay first

    def replay_save(self):
        if not self.demo and not sources.replay_save():
            self.win.capture.flash("Instant Replay is not running.")
        else:
            self.win.capture.flash("Replay saved to " + str(sources.REPLAYS if not self.demo else "~/Videos/Replays"))

    def replay_start(self):
        if not self.demo and not sources.replay_start(30):
            self.win.capture.flash("Could not start GPU Screen Recorder.")
        QTimer.singleShot(2500, self.win.refresh_slow)

    def get_replay(self):
        self.demo or sources.spawn(["phoenixge-center", "--page", "apps"])
        self.win.hide_overlay()

    def open_captures(self):
        if not self.demo:
            sources.open_path(sources.SHOTS)
        self.win.hide_overlay()

    def discord(self, flat):
        if not self.demo:
            sources.discord_raise(flat)
        self.win.hide_overlay()

    def load_art(self, url, cb):
        if not url or url == "demo:":
            return
        if url.startswith("file://"):
            cb(QPixmap(urllib.request.url2pathname(url[7:])))
            return
        if not url.startswith(("http://", "https://")):
            return
        self.art_cb[url] = cb
        cache = Path.home() / ".cache/phoenixge/overlay-art"
        f = cache / hashlib.sha1(url.encode()).hexdigest()

        def fetch():
            try:
                if not f.exists():
                    cache.mkdir(parents=True, exist_ok=True)
                    with urllib.request.urlopen(url, timeout=5) as r:
                        f.write_bytes(r.read(4 * 2 ** 20))
                self.art_ready.emit(url, str(f))
            except Exception:  # noqa: BLE001 - no art is fine
                pass
        threading.Thread(target=fetch, daemon=True).start()

    def _art_done(self, url, path):
        cb = self.art_cb.pop(url, None)
        if cb:
            cb(QPixmap(path))


# ------------------------------------------------------------------ the window
class Overlay(QWidget):
    data_ready = Signal(str, object)

    def __init__(self, acc, demo=False, background=None):
        super().__init__(None, Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setWindowTitle("PhoenixGe Overlay")
        self.acc, self.demo, self.bg = acc, demo, (QPixmap(background) if background else None)
        self.src = __import__("demo") if demo else sources
        self.sampler = self.src.DemoSampler() if demo else sources.PerfSampler()
        self.busy, self.game, self.shown_at = set(), None, 0.0
        self.actions = Actions(self, demo)
        self.data_ready.connect(self._on_data)
        self.setStyleSheet(stylesheet(acc))

        self.top = TopBar(acc, None)
        self.perf = PerfCard(acc)
        self.power = PowerCard(acc, self.actions)
        self.media = MediaCard(acc, self.actions)
        self.audio = AudioCard(acc, self.actions)
        self.discord = DiscordCard(acc, self.actions)
        self.capture = CaptureCard(acc, self.actions)
        for w in (self.top, self.perf, self.power, self.media, self.audio, self.discord, self.capture):
            w.setParent(self)
        self.fast = QTimer(self, interval=500, timeout=self.refresh_fast)
        self.slow = QTimer(self, interval=2000, timeout=self.refresh_slow)
        self.clock = QTimer(self, interval=1000, timeout=self._tick)

    # ---------------------------------------------------------- data
    def _bg(self, key, fn, *a):
        if key in self.busy:
            return
        self.busy.add(key)

        def work():
            try:
                res = fn(*a)
            except Exception as e:  # noqa: BLE001 - one broken source must not kill the overlay
                print("phoenixge-overlay:", key, e, file=sys.stderr)
                res = None
            self.data_ready.emit(key, res)
        threading.Thread(target=work, daemon=True).start()

    def _slow_bundle(self):
        s = self.src
        game = s.game_session()
        return {"game": game, "master": s.audio_master(), "streams": s.audio_streams(), "media": s.media_player(),
                "replay": s.replay_status(), "discord": s.discord_status(game), "power": s.power_profiles()}

    def refresh_fast(self):
        self._bg("perf", self.sampler.sample)

    def refresh_slow(self):
        self._bg("slow", self._slow_bundle)

    def _on_data(self, key, res):
        self.busy.discard(key)
        if res is None:
            return
        if key == "perf":
            self.perf.update_data(res)
        elif key == "slow":
            self.apply_slow(res)

    def apply_slow(self, b):
        self.game = b["game"]
        self.top.set_game(self.game)
        self.audio.update_data(b["master"], b["streams"])
        self.media.update_data(b["media"])
        self.capture.update_data(b["replay"])
        self.discord.update_data(b["discord"])
        self.power.update_data(b["power"], self.game)
        self.relayout()

    def _tick(self):
        self.top.tick(); self.power.tick()

    def fill_now(self):
        """Synchronous fill (screenshots)."""
        if self.demo:
            self.perf.frames.extend(self.sampler.history(PerfCard.HISTORY - 5))
        self.perf.update_data(self.sampler.sample())
        self.apply_slow(self._slow_bundle())

    # ---------------------------------------------------------- layout
    def relayout(self):
        W, H = self.width(), self.height()
        m, gap = (40, 18) if W >= 1600 else (20, 12)
        self.top.setGeometry(m, 22, W - 2 * m, 62)
        y0 = 22 + 62 + gap + 6

        def place(col_x, col_w, cards, y=y0, bottom=H - m):
            leftover = []
            for c in cards:
                h = c.heightForWidth(col_w) if c.hasHeightForWidth() else c.sizeHint().height()
                h = max(h, c.minimumSizeHint().height())
                if y + h > bottom and y > y0:
                    leftover.append(c); continue
                c.setGeometry(col_x, y, col_w, h); c.show()
                y += h + gap
            return leftover

        lw = min(470, int(W * 0.27)); rw = min(430, int(W * 0.25))
        cw = min(620, W - lw - rw - 2 * m - 2 * gap)
        cap_h = self.capture.sizeHint().height()
        cap_y = H - m - cap_h
        self.capture.setGeometry((W - cw) // 2, cap_y, cw, cap_h)
        rest = place(m, lw, [self.perf, self.power])
        rest += place(W - m - rw, rw, [self.media, self.audio, self.discord])
        # small screens: whatever did not fit goes above the capture card in the middle
        y = cap_y - gap
        for c in reversed(rest):
            h = c.sizeHint().height()
            y -= h
            c.setGeometry((W - cw) // 2, y, cw, h); c.show()
            y -= gap

    def resizeEvent(self, e):
        self.relayout()
        super().resizeEvent(e)

    def paintEvent(self, _e):
        p = QPainter(self)
        if self.bg is not None and not self.bg.isNull():
            p.drawPixmap(self.rect(), self.bg)
        p.fillRect(self.rect(), QColor(4, 4, 10, 92))   # ~35 % dim
        g = QRadialGradient(QPointF(self.width() / 2, self.height() / 2), max(self.width(), self.height()) * 0.7)
        g.setColorAt(0.55, QColor(0, 0, 0, 0)); g.setColorAt(1, QColor(0, 0, 0, 110))
        p.fillRect(self.rect(), g)

    # ---------------------------------------------------------- show / hide
    def toggle(self):
        self.hide_overlay() if self.isVisible() else self.show_overlay()

    def show_overlay(self):
        scr = QGuiApplication.screenAt(QCursor.pos()) or QGuiApplication.primaryScreen()
        if scr is not None:
            self.setScreen(scr)
            self.setGeometry(scr.geometry())
        self.showFullScreen()
        self.raise_(); self.activateWindow()
        self.shown_at = time.time()
        self.refresh_slow(); self.refresh_fast()
        self.fast.start(); self.slow.start(); self.clock.start(); self._tick()

    def hide_overlay(self):
        self.fast.stop(); self.slow.stop(); self.clock.stop()
        self.hide()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.hide_overlay()
        else:
            super().keyPressEvent(e)

    def mousePressEvent(self, e):
        self.hide_overlay()   # only reaches us for clicks on the backdrop (cards accept their own)

    def changeEvent(self, e):
        # focus went to another window (e.g. clicked on a second monitor) -> get out of the way
        if e.type() == e.Type.ActivationChange and self.isVisible() and not self.isActiveWindow() \
                and time.time() - self.shown_at > 0.8:
            self.hide_overlay()
        super().changeEvent(e)


def stylesheet(acc):
    a = QColor(acc)
    rgb = f"{a.red()},{a.green()},{a.blue()}"
    return f"""
        QWidget {{ color: {TEXT}; font-size: 13px; }}
        QLabel {{ background: transparent; }}
        #cardTitle {{ color: {DIM}; font-size: 11px; font-weight: 700; letter-spacing: 1.4px; }}
        #brand {{ font-size: 16px; }}
        #gameName {{ font-size: 15px; font-weight: 700; }}
        #clock {{ font-size: 20px; font-weight: 700; }}
        #small {{ color: {FAINT}; font-size: 11px; }}
        #dim {{ color: {DIM}; }}
        #hint {{ color: {DIM}; font-size: 12px; }}
        #key {{ color: {TEXT}; background: rgba(255,255,255,18); border: 1px solid rgba(255,255,255,30);
                border-bottom: 2px solid rgba(255,255,255,40); border-radius: 6px; padding: 2px 8px;
                font-size: 11px; font-weight: 700; }}
        #vsep {{ background: rgba(255,255,255,30); }}
        #sep {{ background: rgba(255,255,255,16); }}
        #bigFps {{ font-size: 60px; font-weight: 800; }}
        #midValue {{ font-size: 18px; font-weight: 700; }}
        #tile {{ background: rgba(255,255,255,10); border: 1px solid rgba(255,255,255,12); border-radius: 12px; }}
        #tileLabel {{ color: {FAINT}; font-size: 10px; font-weight: 700; letter-spacing: 1.2px; }}
        #tileValue {{ font-size: 20px; font-weight: 800; }}
        #tileSub {{ color: {DIM}; font-size: 11px; }}
        #rowName {{ font-size: 13px; font-weight: 600; }}
        #pct {{ color: {DIM}; font-size: 12px; }}
        #mediaTitle {{ font-size: 16px; font-weight: 700; }}
        QPushButton {{ background: rgba(255,255,255,16); border: 1px solid rgba(255,255,255,22); border-radius: 10px;
                       padding: 7px 16px; font-weight: 600; }}
        QPushButton:hover {{ background: rgba({rgb},60); border-color: rgba({rgb},140); }}
        QToolButton#round {{ background: rgba(255,255,255,14); border: 1px solid rgba(255,255,255,20); border-radius: 15px; }}
        QToolButton#round:hover {{ background: rgba({rgb},70); }}
        QToolButton#roundPrimary {{ background: {acc}; border: none; border-radius: 23px; }}
        QToolButton#big, QToolButton#seg {{ background: rgba(255,255,255,12); border: 1px solid rgba(255,255,255,20);
                       border-radius: 12px; padding: 8px 6px 6px 6px; font-weight: 600; font-size: 12px; }}
        QToolButton#big:hover, QToolButton#seg:hover {{ background: rgba({rgb},50); border-color: rgba({rgb},130); }}
        QToolButton#seg:checked {{ background: {acc}; color: #16110a; border-color: {acc}; }}
        QToolButton#seg:disabled {{ color: {FAINT}; }}
        QSlider::groove:horizontal {{ height: 4px; background: rgba(255,255,255,30); border-radius: 2px; }}
        QSlider::sub-page:horizontal {{ background: {acc}; border-radius: 2px; }}
        QSlider::sub-page:horizontal:disabled {{ background: rgba(255,255,255,40); }}
        QSlider::handle:horizontal {{ background: #ffffff; width: 14px; height: 14px; margin: -5px 0; border-radius: 7px; }}
    """


# ------------------------------------------------------------------ single instance
def send(cmd):
    """Hand cmd to a running overlay. True = delivered."""
    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(1.5)
        s.connect(str(SOCK))
        s.sendall(cmd.encode() + b"\n")
        s.close()
        return True
    except OSError:
        return False


class Server(QObject):
    command = Signal(str)

    def __init__(self):
        super().__init__()
        SOCK.parent.mkdir(parents=True, exist_ok=True)
        SOCK.unlink(missing_ok=True)   # stale socket (send() already failed)
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.bind(str(SOCK)); os.chmod(SOCK, 0o600)
        self.sock.listen(4); self.sock.setblocking(False)
        self.notifier = QSocketNotifier(self.sock.fileno(), QSocketNotifier.Read, self)
        self.notifier.activated.connect(self._accept)

    def _accept(self, *_):
        try:
            conn, _ = self.sock.accept()
        except OSError:
            return
        conn.settimeout(1)
        try:
            data = conn.recv(64).decode(errors="replace").strip()
        except OSError:
            data = ""
        conn.close()
        if data:
            self.command.emit(data)


# ------------------------------------------------------------------ main
def main(argv=None):
    ap = argparse.ArgumentParser(prog="phoenixge-overlay")
    g = ap.add_mutually_exclusive_group()
    for c in ("show", "hide", "quit"):
        g.add_argument(f"--{c}", action="store_true")
    g.add_argument("--daemon", action="store_true", help="start resident but hidden (login autostart)")
    ap.add_argument("--demo", action="store_true", help="sample data")
    ap.add_argument("--screenshot", metavar="PNG", help="render once offscreen and save (implies no server)")
    ap.add_argument("--size", default="1920x1080")
    ap.add_argument("--background", help="image behind the overlay in --screenshot mode")
    ap.add_argument("--accent", help="override the theme accent color")
    a = ap.parse_args(argv)
    cmd = "show" if a.show else "hide" if a.hide else "quit" if a.quit else "ping" if a.daemon else "toggle"

    if not a.screenshot:
        if send(cmd):
            return 0
        if cmd in ("hide", "quit"):
            return 0
        if os.environ.get("XDG_SESSION_TYPE") == "wayland":
            os.environ.setdefault("QT_QPA_PLATFORM", "wayland;xcb")

    app = QApplication(sys.argv[:1])
    app.setApplicationName("phoenixge-overlay")
    app.setDesktopFileName("phoenixge-overlay")
    app.setQuitOnLastWindowClosed(False)
    f = QFont(pick_font()); f.setPixelSize(13); f.setHintingPreference(QFont.PreferNoHinting)
    app.setFont(f)
    acc = a.accent or accent()
    win = Overlay(acc, demo=a.demo, background=a.background if a.screenshot else None)

    if a.screenshot:
        w, h = (int(x) for x in a.size.lower().split("x"))
        win.resize(w, h)
        win.show()
        win.fill_now()
        win.relayout()
        app.processEvents()
        win.fill_now()   # second pass: elided texts need the final widths
        app.processEvents()
        ok = win.grab().save(a.screenshot)
        print(("saved " if ok else "FAILED ") + a.screenshot)
        return 0 if ok else 1

    srv = Server()

    def on_cmd(c):
        if c == "quit":
            app.quit()
        elif c == "hide":
            win.hide_overlay()
        elif c == "show" or (c == "toggle" and not win.isVisible()):
            win.show_overlay()
        elif c in ("hide", "toggle"):
            win.hide_overlay()
    srv.command.connect(on_cmd)
    if not a.daemon:
        win.show_overlay()
    rc = app.exec()
    SOCK.unlink(missing_ok=True)
    return rc


if __name__ == "__main__":
    sys.exit(main())
