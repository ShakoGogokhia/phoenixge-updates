#!/bin/sh
# At login: when the system was started from a snapshot in GRUB ("PhoenixGe - restore previous state"),
# ask whether to keep this state. Yes -> phoenixge-rollback --make-permanent (Timeshift restore) + restart.
S=$(tr ' ' '\n' < /proc/cmdline | sed -n 's/^phoenixge\.snapshot=//p' | head -n 1)
[ -n "$S" ] || exit 0
W=$(echo "$S" | sed 's/^\(....-..-..\)_\(..\)-\(..\)-..$/\1 \2:\3/')
ICON=/usr/share/pixmaps/phoenixge.png
command -v kdialog >/dev/null 2>&1 || {
  notify-send -a PhoenixGe -i "$ICON" "Running a snapshot from $W" \
    "To keep this state run: sudo phoenixge-rollback --make-permanent"; exit 0; }
kdialog --icon "$ICON" --title "PhoenixGe - restore previous state" --yes-label "Make it permanent" --no-label "Not now" \
  --yesno "You are running the system as it was on $W (a snapshot from the boot menu).

Your files in Home are the current ones - they are never rolled back.

If everything works, make this state permanent: the broken state is kept as an extra snapshot and the computer restarts into this one.
'Not now' = just look around; a normal restart goes back to the current (newer) system." || exit 0
LOGF=$(mktemp)
if pkexec /usr/bin/phoenixge-rollback --make-permanent --yes > "$LOGF" 2>&1; then
  if kdialog --icon "$ICON" --title "PhoenixGe" --yes-label "Restart now" --no-label "Later" \
       --yesno "Done. The system from $W is now permanent. Restart to use it."; then
    systemctl reboot
  fi
else
  kdialog --icon "$ICON" --title "PhoenixGe" --error "Restoring did not work:

$(tail -n 15 "$LOGF")

You can try in a terminal: sudo phoenixge-rollback"
fi
rm -f "$LOGF"
