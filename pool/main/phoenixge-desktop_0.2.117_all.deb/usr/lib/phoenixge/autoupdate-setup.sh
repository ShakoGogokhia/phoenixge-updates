#!/bin/sh
# Auto updates + PhoenixGe Installer setup (root). Run by hook 0950 (ISO build) and by apply-system.sh (updates).
set +e
L=/usr/lib/phoenixge
chmod 755 "$L"/autoupdate.sh "$L"/autoupdate-setup.sh /usr/bin/phoenixge-install "$L"/installer/install.py 2>/dev/null
mkdir -p /var/lib/phoenixge
systemctl enable phoenixge-autoupdate.timer phoenixge-autoupdate-shutdown.service >/dev/null 2>&1
systemctl --global enable phoenixge-flatpak-autoupdate.timer >/dev/null 2>&1
# Debian's own unattended upgrades (if someone installs the package) would race with ours
[ -f /etc/apt/apt.conf.d/20auto-upgrades ] && grep -q 'Unattended-Upgrade "1"' /etc/apt/apt.conf.d/20auto-upgrades &&
  echo "PhoenixGe: note - unattended-upgrades is also enabled (20auto-upgrades)" >&2
# double-click installer: make it the default for packages (merged into /etc/xdg/mimeapps.list)
M=/etc/xdg/mimeapps.list S=/etc/xdg/phoenixge-installer-mimeapps.list
if [ -f "$S" ]; then
  [ -f "$M" ] || printf '[Default Applications]\n' > "$M"
  awk -F= 'NR == FNR { if ($0 ~ /=/ && $0 !~ /^[[#]/) { want[$1] = $0; order[++n] = $1 } next }
           /^\[Default Applications\]/ { print; for (i = 1; i <= n; i++) print want[order[i]]; inside = 1; next }
           /^\[/ { inside = 0 }
           inside && ($1 in want) { next }
           { print }' "$S" "$M" > "$M.tmp" && mv "$M.tmp" "$M"
  chmod 644 "$M"
fi
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database -q /usr/share/applications
exit 0
