#!/bin/sh
# PhoenixGe: GRUB submenu "PhoenixGe - restore previous state".
#  - btrfs root (@ subvolume, /boot inside it) + Timeshift btrfs snapshots: one entry per snapshot that boots
#    the snapshot directly (its own kernel + initrd + modules). After login a notice offers "Make it permanent".
#  - any filesystem (ext4 too): "Restore tool" entries that boot into a text-mode tool
#    (phoenixge-rollback --console via phoenixge-rollback.target) which lists snapshots and restores one.
# Installed as /etc/grub.d/42_phoenixge-restore by /usr/lib/phoenixge/safe-updates-setup.sh.
# It must NEVER break update-grub: on any problem entries are just left out and it exits 0.
set +e
prefix="/usr"
exec_prefix="/usr"
datarootdir="/usr/share"
. "${pkgdatadir:-/usr/share/grub}/grub-mkconfig_lib" 2>/dev/null || exit 0

MAX=${PHOENIXGE_GRUB_SNAPSHOTS:-8}
[ -d /run/live ] && exit 0
[ -n "$GRUB_DEVICE" ] || exit 0
command -v timeshift >/dev/null 2>&1 || exit 0
[ -x /usr/bin/phoenixge-rollback ] || exit 0

# GRUB menu titles: keep it to safe ASCII (no quotes)
clean() { printf '%s' "$1" | tr -cd 'A-Za-z0-9 ._:,()+/-'; }

DEV1=${GRUB_DEVICE%% *}
if [ -n "$GRUB_DEVICE_UUID" ] && [ "x$GRUB_DISABLE_LINUX_UUID" != xtrue ]; then ROOTDEV="UUID=$GRUB_DEVICE_UUID"; else ROOTDEV="$DEV1"; fi
RR=$(make_system_path_relative_to_its_root / 2>/dev/null)          # e.g. /@ on btrfs, empty on ext4
RB=$(make_system_path_relative_to_its_root /boot 2>/dev/null)      # e.g. /@/boot, /boot, or empty (own partition)
PREP=$(prepare_grub_to_access_device ${GRUB_DEVICE_BOOT:-$GRUB_DEVICE} 2>/dev/null)
[ -n "$PREP" ] || exit 0
VIDEO="		load_video"
[ "x$GRUB_GFXPAYLOAD_LINUX" = xtext ] && VIDEO=""

entry() { # title kernel initrd args
  printf "	menuentry '%s' --class phoenixge --class gnu-linux --class os {\n" "$1"
  [ -n "$VIDEO" ] && printf '%s\n' "$VIDEO"
  printf '		insmod gzio\n'
  printf '%s\n' "$PREP" | sed 's/^/		/'
  printf "		echo 'Loading %s ...'\n" "$1"
  printf '		linux %s %s\n' "$2" "$4"
  printf '		initrd %s\n' "$3"
  printf '	}\n'
}

OUT=""
# 1) bootable btrfs snapshots (Timeshift btrfs mode: /timeshift-btrfs/snapshots/<name>/@ on the top-level volume)
if [ "x$GRUB_FS" = xbtrfs ] && [ -n "$GRUB_DEVICE_UUID" ] && [ "x$RR" = "x/@" ] && [ "x$RB" = "x/@/boot" ]; then
  T=$(mktemp -d /tmp/phoenixge-grub.XXXXXX)
  if [ -n "$T" ] && mount -t btrfs -o ro,subvolid=5 "UUID=$GRUB_DEVICE_UUID" "$T" 2>/dev/null; then
    n=0
    for d in $(ls -1 "$T/timeshift-btrfs/snapshots" 2>/dev/null | sort -r); do
      [ "$n" -ge "$MAX" ] && break
      case "$d" in [0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]_[0-9][0-9]-[0-9][0-9]-[0-9][0-9]) ;; *) continue ;; esac
      S="$T/timeshift-btrfs/snapshots/$d/@"
      K=$(ls -1 "$S"/boot/vmlinuz-* 2>/dev/null | sort -V | tail -n 1)
      [ -n "$K" ] || continue
      V=${K##*/vmlinuz-}
      I=""
      for i in "initrd.img-$V" "initrd-$V.img" "initramfs-$V.img"; do
        if [ -f "$S/boot/$i" ]; then I=$i; break; fi
      done
      [ -n "$I" ] || continue
      C=$(sed -n 's/.*"comments"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$T/timeshift-btrfs/snapshots/$d/info.json" 2>/dev/null | head -n 1)
      W=$(echo "$d" | sed 's/^\(....-..-..\)_\(..\)-\(..\)-..$/\1 \2:\3/')
      TITLE=$(clean "Snapshot $W${C:+ - $C}")
      P="/timeshift-btrfs/snapshots/$d/@/boot"
      ARGS="root=$ROOTDEV rw rootflags=subvol=timeshift-btrfs/snapshots/$d/@ $GRUB_CMDLINE_LINUX $GRUB_CMDLINE_LINUX_DEFAULT phoenixge.snapshot=$d"
      OUT="$OUT$(entry "$TITLE" "$P/vmlinuz-$V" "$P/$I" "$ARGS")
"
      echo "Found PhoenixGe snapshot: $d" >&2
      n=$((n + 1))
    done
    umount "$T" 2>/dev/null
  fi
  [ -n "$T" ] && rmdir "$T" 2>/dev/null
fi

# 2) text-mode restore tool with the two newest kernels (works on ext4 / rsync snapshots too)
FLAGS=""
if [ "x$GRUB_FS" = xbtrfs ] && [ -n "${RR#/}" ]; then FLAGS="rootflags=subvol=${RR#/}"; fi
for K in $(ls -1 /boot/vmlinuz-* 2>/dev/null | sort -V -r | head -n 2); do
  V=${K##*/vmlinuz-}
  [ -f "/boot/initrd.img-$V" ] || continue
  TITLE=$(clean "Restore tool - pick a snapshot (text mode, Linux $V)")
  ARGS="root=$ROOTDEV ro $FLAGS $GRUB_CMDLINE_LINUX systemd.unit=phoenixge-rollback.target"
  OUT="$OUT$(entry "$TITLE" "$RB/vmlinuz-$V" "$RB/initrd.img-$V" "$ARGS")
"
done

[ -n "$OUT" ] || exit 0
echo "submenu 'PhoenixGe - restore previous state' --class phoenixge \$menuentry_id_option 'phoenixge-restore' {"
printf '%s' "$OUT"
echo "}"
exit 0
