#!/bin/sh
# PhoenixGe update channel: stable (default) or beta.
#   update-channel.sh get                         print the channel (/etc/phoenixge/channel, missing = stable)
#   update-channel.sh apply                       write the apt source + pin for the saved channel (no network;
#                                                 run by apply-system.sh after every PhoenixGe update)
#   update-channel.sh set stable|beta [--downgrade]
#                                                 save the channel, apply, apt-get update. Beta -> Stable with
#                                                 --downgrade: snapshot first, then install the stable versions of
#                                                 PhoenixGe packages that are newer than stable. Without it they stay
#                                                 until stable catches up (exit code 10 = some are newer than stable).
#   update-channel.sh downgrade                   only the downgrade step
#   update-channel.sh newer                       print "pkg installed stable" for packages newer than stable
#   update-channel.sh refresh                     apt-get update
# How it works: the source always lists both suites (so PhoenixGe Center can show what each channel has).
# Stable channel: /etc/apt/preferences.d/phoenixge-channel pins beta to priority 1 = listed, never installed.
# Beta channel: no pin, both suites at 500 -> apt takes the higher version (beta is always >= stable).
set -e
CHF=${PHX_CHANNEL_FILE:-/etc/phoenixge/channel}
SRC=${PHX_SOURCES:-/etc/apt/sources.list.d/phoenixge.sources}
PREF=${PHX_PREFS:-/etc/apt/preferences.d/phoenixge-channel}
DEF_URI=https://shakogogokhia.github.io/phoenixge-updates
DEF_KEY=/usr/share/keyrings/phoenixge-archive-keyring.gpg
# extra apt options (tests: an isolated apt state); word-split on purpose
APT_OPTS=${PHX_APT_OPTS:-}

get() {
  c=$(tr -cd 'a-z' 2>/dev/null < "$CHF" || true)
  case "$c" in beta) echo beta ;; *) echo stable ;; esac
}

field() { [ -f "$SRC" ] && sed -n "s/^$1:[[:space:]]*//p" "$SRC" | head -1; }

apply() {
  ch=$(get)
  uri=$(field URIs); uri=${uri:-$DEF_URI}
  key=$(field Signed-By); key=${key:-$DEF_KEY}
  mkdir -p "$(dirname "$SRC")" "$(dirname "$PREF")"
  cat > "$SRC.tmp" <<EOF
# PhoenixGe updates (themes, start menu, apps, scripts). Channel: $ch (saved in $CHF).
# Change it in PhoenixGe Center > Updates, or: sudo /usr/lib/phoenixge/update-channel.sh set stable|beta
# Both suites are listed so the Center can show what each channel has; $PREF decides what is installed.
Types: deb
URIs: $uri
Suites: stable beta
Components: main
Signed-By: $key
EOF
  mv "$SRC.tmp" "$SRC"
  if [ "$ch" = stable ]; then
    cat > "$PREF.tmp" <<'EOF'
# PhoenixGe update channel: stable. Beta versions are visible (apt-cache policy) but never installed.
# Written by /usr/lib/phoenixge/update-channel.sh - changes are overwritten.
Package: *
Pin: release o=PhoenixGe,a=beta
Pin-Priority: 1
EOF
    mv "$PREF.tmp" "$PREF"
  else
    rm -f "$PREF"
  fi
}

# newest version of PhoenixGe package $1 in suite $2 (from the apt lists; phoenixge-* only exist in our repo)
avail() {
  # shellcheck disable=SC2086
  apt-cache $APT_OPTS madison "$1" 2>/dev/null | awk -F'|' -v s=" $2/main" 'index($3, s) {gsub(/ /, "", $2); print $2}' \
    | sort -V | tail -1
}

newer() {
  # shellcheck disable=SC2086
  dpkg-query $PHX_DPKG_OPTS -W -f='${db:Status-Abbrev} ${Package} ${Version}\n' 'phoenixge-*' 2>/dev/null \
    | awk '$1 ~ /^ii/ {print $2, $3}' | while read -r p iv; do
      sv=$(avail "$p" stable)
      [ -n "$sv" ] || continue           # not in stable at all (e.g. a theme only beta has) - left alone
      if dpkg --compare-versions "$iv" gt "$sv"; then echo "$p $iv $sv"; fi
    done
}

refresh() {
  # shellcheck disable=SC2086
  apt-get $APT_OPTS update
}

downgrade() {
  list=$(newer | awk '{print $1 "=" $3}' | tr '\n' ' ')
  if [ -z "$list" ]; then echo "PhoenixGe packages already match the stable channel."; return 0; fi
  echo "Going back to the stable versions: $list"
  [ -n "${PHX_TEST:-}" ] || /bin/sh /usr/lib/phoenixge/pre-update-snapshot.sh --force --reason "switch to stable channel" || true
  # shellcheck disable=SC2086
  DEBIAN_FRONTEND=noninteractive apt-get $APT_OPTS install -y --allow-downgrades --no-install-recommends \
    -o Dpkg::Options::=--force-confold $list
}

need_root() { [ -n "${PHX_TEST:-}" ] || [ "$(id -u)" = 0 ] || { echo "run as root (pkexec/sudo)" >&2; exit 1; }; }

case "${1:-get}" in
  get) get ;;
  apply) need_root; apply ;;
  set)
    need_root
    case "${2:-}" in stable|beta) ;; *) echo "usage: $0 set stable|beta [--downgrade]" >&2; exit 2 ;; esac
    mkdir -p "$(dirname "$CHF")"; echo "$2" > "$CHF"
    apply
    echo "Update channel: $2"
    refresh || echo "apt-get update reported errors (offline?) - the channel is saved and used at the next update."
    if [ "$2" = stable ]; then
      if [ "${3:-}" = --downgrade ]; then downgrade
      elif [ -n "$(newer)" ]; then
        echo "These PhoenixGe packages are newer than stable and stay until stable catches up:"; newer
        exit 10
      fi
    else
      echo "Beta versions install with the next update (PhoenixGe Center > Updates, or Discover)."
    fi ;;
  downgrade) need_root; downgrade ;;
  newer) newer ;;
  refresh) need_root; refresh ;;
  *) sed -n '2,15p' "$0" >&2; exit 2 ;;
esac
