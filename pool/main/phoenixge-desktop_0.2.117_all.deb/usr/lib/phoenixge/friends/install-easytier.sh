#!/bin/sh
# PhoenixGe LAN rooms: install / update EasyTier (https://github.com/EasyTier/EasyTier, LGPL-3.0) - run as root.
#   pkexec /bin/sh /usr/lib/phoenixge/friends/install-easytier.sh [version|latest]
# Also usable from an ISO build hook (in the chroot, with internet).
# - downloads the official release zip from GitHub and checks its SHA-256 against the digest GitHub publishes
# - installs easytier-core / easytier-cli to /usr/lib/phoenixge/friends/easytier (root-owned)
# - gives easytier-core CAP_NET_ADMIN so a normal user can create the room's network interface (no password per room)
# - firewall (ufw): allows everything that comes in over the room interface phx0 (= only your friends in the room)
set -eu
VER="${1:-latest}"
DEST=/usr/lib/phoenixge/friends/easytier
case "$(uname -m)" in
    x86_64) ARCH=x86_64 ;;
    aarch64) ARCH=aarch64 ;;
    *) echo "Unsupported CPU: $(uname -m)"; exit 1 ;;
esac
command -v curl >/dev/null || { echo "curl is missing"; exit 1; }
command -v python3 >/dev/null || { echo "python3 is missing"; exit 1; }

if [ "$VER" = latest ]; then API=https://api.github.com/repos/EasyTier/EasyTier/releases/latest
else API="https://api.github.com/repos/EasyTier/EasyTier/releases/tags/$VER"; fi
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
echo "Looking up the EasyTier release ($VER)…"
curl -fsSL --retry 3 -H "Accept: application/vnd.github+json" "$API" -o "$TMP/rel.json"
set -- $(python3 - "$TMP/rel.json" "$ARCH" <<'EOF'
import json, sys
d = json.load(open(sys.argv[1]))
for a in d.get("assets", []):
    if a["name"].startswith(f"easytier-linux-{sys.argv[2]}-") and a["name"].endswith(".zip"):
        print(d["tag_name"], a["browser_download_url"], (a.get("digest") or "").replace("sha256:", ""))
        break
EOF
)
[ $# -ge 2 ] || { echo "No EasyTier download for $ARCH found."; exit 1; }
TAG=$1; URL=$2; SUM=${3:-}
if [ -x "$DEST/easytier-core" ] && [ "$(cat "$DEST/VERSION" 2>/dev/null)" = "$TAG" ]; then
    echo "EasyTier $TAG is already installed."
else
    echo "Downloading EasyTier $TAG…"
    curl -fL --retry 3 --progress-bar "$URL" -o "$TMP/et.zip"
    if [ -n "$SUM" ]; then
        echo "$SUM  $TMP/et.zip" | sha256sum -c - >/dev/null || { echo "Checksum mismatch - download damaged, nothing installed."; exit 1; }
        echo "Checksum OK."
    else
        echo "Warning: GitHub published no checksum for this file."
    fi
    python3 -I -c "import sys, zipfile; zipfile.ZipFile(sys.argv[1]).extractall(sys.argv[2])" "$TMP/et.zip" "$TMP/x"
    CORE=$(find "$TMP/x" -type f -name easytier-core | head -n1)
    CLIB=$(find "$TMP/x" -type f -name easytier-cli | head -n1)
    [ -n "$CORE" ] && [ -n "$CLIB" ] || { echo "The zip has no easytier-core/easytier-cli."; exit 1; }
    mkdir -p "$DEST"
    install -o root -g root -m 0755 "$CORE" "$DEST/easytier-core.new"
    install -o root -g root -m 0755 "$CLIB" "$DEST/easytier-cli"
    mv -f "$DEST/easytier-core.new" "$DEST/easytier-core"
    echo "$TAG" > "$DEST/VERSION"
fi

# Network interface without root: file capabilities on the root-owned binary.
if command -v setcap >/dev/null; then
    setcap cap_net_admin,cap_net_raw,cap_net_bind_service+ep "$DEST/easytier-core"
else
    echo "setcap missing (package libcap2-bin) - rooms will not be able to create their network interface."; exit 1
fi
# The kernel's TUN device must exist (it does on Debian; load it just in case).
modprobe tun 2>/dev/null || true

# Firewall: friends in the room may reach this computer (game servers, LAN games). Added even while ufw is off,
# so it is already there when the firewall gets turned on later.
if command -v ufw >/dev/null; then
    ufw allow in on phx0 comment 'PhoenixGe LAN room' >/dev/null 2>&1 || true
fi
echo "EasyTier $TAG ready."
