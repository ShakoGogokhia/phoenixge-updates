#!/bin/sh
# PhoenixGe game servers: open / close a server's ports in the firewall (ufw) - run as root via pkexec.
#   firewall.sh open  <name> <port/proto>...     e.g. firewall.sh open my-world 25565/tcp
#   firewall.sh close <name>                     removes every rule this server added
# Rules carry the comment "phoenixge-server <name>" so they can be found again. Friends in a LAN room never need
# this (install-easytier.sh allows the room interface); it is for players on the home network / internet.
set -eu
ACTION="${1:-}"; NAME="${2:-}"
case "$NAME" in ''|*[!a-z0-9-]*) echo "bad server name"; exit 2 ;; esac
command -v ufw >/dev/null || { echo "ufw is not installed - nothing to do."; exit 0; }
TAG="phoenixge-server $NAME"
close_rules() {
    # delete from the highest number down so the numbering doesn't shift under us
    ufw status numbered 2>/dev/null | grep -F "# $TAG" | sed -n 's/^\[ *\([0-9]*\)\].*/\1/p' | sort -rn |
        while read -r n; do ufw --force delete "$n" >/dev/null; done
}
case "$ACTION" in
    open)
        shift 2
        close_rules
        for p in "$@"; do
            case "$p" in *[!0-9/a-z:]*|'') echo "bad port $p"; exit 2 ;; esac
            ufw allow "$p" comment "$TAG" >/dev/null
            echo "Firewall: $p open for $NAME"
        done ;;
    close)
        close_rules
        echo "Firewall: rules for $NAME removed" ;;
    *) echo "usage: firewall.sh open|close <name> [port/proto...]"; exit 2 ;;
esac
