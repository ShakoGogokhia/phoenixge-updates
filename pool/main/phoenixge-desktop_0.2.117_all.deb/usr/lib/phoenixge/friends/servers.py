#!/usr/bin/env python3
"""PhoenixGe game servers - one-click Minecraft Java, Terraria, Counter-Strike 2 and Valheim servers that run as the
user (systemd --user unit phoenixge-server@<name>), stored in ~/Games/Servers/<name>.

    servers.py list                         JSON list with status of every server
    servers.py create <game> <title> [json] create the folder + settings (prints the name)
    servers.py install <name>               download / update the game server files (streams progress)
    servers.py start|stop|restart <name>
    servers.py autostart <name> on|off      start with the computer (systemd user unit + lingering)
    servers.py send <name> <command...>     type a command into the server console
    servers.py delete <name>                stop and remove the server folder (worlds too!)
    servers.py run <name>                   (phoenixge-server@.service) run the server in the foreground
Downloads come from the official sources only: Mojang's version manifest (SHA-1 checked), terraria.org, Valve's SteamCMD.
"""
import json
import os
import re
import shutil
import signal
import socket
import stat
import struct
import subprocess
import sys
import tarfile
import threading
import time
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path.home() / "Games/Servers"
STEAMCMD_DIR = ROOT / ".steamcmd"
RUNTIME_DIR = ROOT / ".runtime"
UNIT = "phoenixge-server@{}.service"
FIREWALL = "/usr/lib/phoenixge/friends/firewall.sh"
UA = {"User-Agent": "PhoenixGe-Center/1.0"}
MC_MANIFEST = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
TERRARIA_LIST = "https://terraria.org/api/get/dedicated-servers-names"
TERRARIA_ZIP = "https://terraria.org/api/download/pc-dedicated-server/{}"
STEAMCMD_URL = "https://steamcdn-a.akamaihd.net/client/installer/steamcmd_linux.tar.gz"
ADOPTIUM = "https://api.adoptium.net/v3/assets/latest/{}/hotspot?architecture=x64&image_type=jre&os=linux&vendor=eclipse"


def total_ram_mb():
    try:
        for line in open("/proc/meminfo"):
            if line.startswith("MemTotal:"):
                return int(line.split()[1]) // 1024
    except OSError:
        pass
    return 8192


def auto_ram():
    """Automatic Minecraft memory: a quarter of the RAM, 2-6 GB (leaves room for the game on the same PC)."""
    return int(min(6144, max(2048, total_ram_mb() // 4)) // 512 * 512)


# ------------------------------------------------------------------ catalog
# Field kinds: text, password, int, choice, bool, ram, list. "adv": shown under "Manual settings".
REACH = {"key": "reach", "label": "Who can join", "kind": "choice", "default": "lan",
         "choices": [("room", "Friends in my LAN room only (safest)"),
                     ("lan", "LAN room + my home network (recommended)"),
                     ("internet", "Everyone with my public IP (opens the router port via UPnP)")],
         "help": "LAN room friends can always join. Internet play needs UPnP on the router or a forwarded port."}

GAMES = {
    "minecraft": {
        "title": "Minecraft Java", "icon": "minecraft", "letter": "M", "color": "#5d9c3a", "size": "~200 MB",
        "blurb": "The official server from Mojang, always the newest release. Friends join from Minecraft Java Edition.",
        "ports": [("port", "tcp")], "default_port": 25565, "stop": "stop",
        "fields": [
            {"key": "world", "label": "World name", "kind": "text", "default": "world"},
            {"key": "motd", "label": "Message in the server list", "kind": "text", "default": "A PhoenixGe server"},
            {"key": "gamemode", "label": "Game mode", "kind": "choice", "default": "survival",
             "choices": [("survival", "Survival"), ("creative", "Creative"), ("adventure", "Adventure")]},
            {"key": "difficulty", "label": "Difficulty", "kind": "choice", "default": "normal",
             "choices": [("peaceful", "Peaceful"), ("easy", "Easy"), ("normal", "Normal"), ("hard", "Hard")]},
            {"key": "max_players", "label": "Max players", "kind": "int", "default": 10, "min": 1, "max": 100},
            {"key": "ram", "label": "Memory (RAM)", "kind": "ram", "default": 0,
             "help": "Automatic picks a quarter of your RAM (2-6 GB)."},
            {"key": "whitelist_on", "label": "Only players on my list may join (whitelist)", "kind": "bool", "default": False},
            {"key": "whitelist", "label": "Player names (one per line)", "kind": "list", "default": []},
            {"key": "cracked", "label": "Allow players without a paid Minecraft account (offline / \"cracked\" mode)",
             "kind": "bool", "default": False, "adv": True,
             "help": "Off = every player is checked by Mojang. On = anyone can join under any name, also as you - "
                     "turn the whitelist on if you allow this."},
            {"key": "pvp", "label": "Players can hurt each other (PvP)", "kind": "bool", "default": True, "adv": True},
            {"key": "view_distance", "label": "View distance (chunks)", "kind": "int", "default": 10, "min": 3, "max": 32, "adv": True},
            {"key": "jvm_args", "label": "Extra Java options", "kind": "text", "default": "", "adv": True},
            {"key": "eula", "label": "I agree to the Minecraft EULA (aka.ms/MinecraftEULA)", "kind": "bool", "default": False,
             "required": True},
        ],
    },
    "terraria": {
        "title": "Terraria", "icon": "terraria", "letter": "T", "color": "#3f7fd6", "size": "~50 MB",
        "blurb": "Official dedicated server from terraria.org. Friends join with Multiplayer > Join via IP.",
        "ports": [("port", "tcp")], "default_port": 7777, "stop": "exit",
        "fields": [
            {"key": "world", "label": "World name", "kind": "text", "default": "PhoenixWorld"},
            {"key": "size", "label": "World size (new worlds)", "kind": "choice", "default": "2",
             "choices": [("1", "Small"), ("2", "Medium"), ("3", "Large")]},
            {"key": "difficulty", "label": "Difficulty (new worlds)", "kind": "choice", "default": "0",
             "choices": [("0", "Classic"), ("1", "Expert"), ("2", "Master"), ("3", "Journey")]},
            {"key": "max_players", "label": "Max players", "kind": "int", "default": 8, "min": 1, "max": 255},
            {"key": "password", "label": "Password (empty = none)", "kind": "password", "default": ""},
            {"key": "motd", "label": "Welcome message", "kind": "text", "default": "Welcome to a PhoenixGe server!", "adv": True},
        ],
    },
    "cs2": {
        "title": "Counter-Strike 2", "icon": "steam", "letter": "CS", "color": "#de9b35", "size": "~60 GB",
        "blurb": "Valve's dedicated server via SteamCMD (big download). Friends open the console and type connect <address>.",
        "ports": [("port", "udp"), ("port", "tcp")], "default_port": 27015, "stop": "quit", "steam_app": 730,
        "fields": [
            {"key": "mode", "label": "Game mode", "kind": "choice", "default": "competitive",
             "choices": [("casual", "Casual"), ("competitive", "Competitive"), ("wingman", "Wingman"),
                         ("deathmatch", "Deathmatch"), ("armsrace", "Arms Race")]},
            {"key": "map", "label": "Map", "kind": "choice", "default": "de_dust2",
             "choices": [(m, m) for m in ("de_dust2", "de_mirage", "de_inferno", "de_nuke", "de_ancient", "de_anubis",
                                          "de_overpass", "de_vertigo", "de_train", "cs_office", "cs_italy")]},
            {"key": "max_players", "label": "Max players", "kind": "int", "default": 10, "min": 2, "max": 64},
            {"key": "password", "label": "Password (empty = none)", "kind": "password", "default": ""},
            {"key": "gslt", "label": "Game Server Login Token (for internet play)", "kind": "text", "default": "", "adv": True,
             "help": "Without a token Valve only allows LAN players - which includes friends in your LAN room. "
                     "For internet play create one for app 730 at steamcommunity.com/dev/managegameservers."},
            {"key": "extra", "label": "Extra launch options", "kind": "text", "default": "", "adv": True},
        ],
    },
    "valheim": {
        "title": "Valheim", "icon": "steam", "letter": "V", "color": "#b5562f", "size": "~1.5 GB",
        "blurb": "Valve's dedicated server via SteamCMD. Friends use Join Game > Add server with the address.",
        "ports": [("port", "udp"), ("port+1", "udp")], "default_port": 2456, "stop": None, "steam_app": 896660,
        "fields": [
            {"key": "server_name", "label": "Name shown in the game", "kind": "text", "default": "PhoenixGe Valheim"},
            {"key": "world", "label": "World name", "kind": "text", "default": "Midgard"},
            {"key": "password", "label": "Password (at least 5 characters)", "kind": "password", "default": "",
             "help": "Friends type it when they join. A random one is made for you."},
            {"key": "public", "label": "Show in the public server list", "kind": "bool", "default": False, "adv": True},
            {"key": "crossplay", "label": "Crossplay (Xbox / Game Pass players)", "kind": "bool", "default": False, "adv": True},
        ],
    },
}
COMMON_FIELDS = [REACH, {"key": "port", "label": "Port", "kind": "int", "default": 0, "min": 1024, "max": 65535, "adv": True}]
CS2_MODES = {"casual": (0, 0), "competitive": (0, 1), "wingman": (0, 2), "armsrace": (1, 0), "deathmatch": (1, 2)}


def fields(game):
    return GAMES[game]["fields"] + COMMON_FIELDS


def defaults(game):
    d = {f["key"]: f["default"] for f in fields(game)}
    d["port"] = GAMES[game]["default_port"]
    if game == "valheim":            # Valheim refuses to start without a password - make a friendly random one
        import secrets
        d["password"] = "".join(secrets.choice("abcdefghjkmnpqrstuvwxyz23456789") for _ in range(6))
    return d


def validate(game, s):
    """'' if fine, else a message for the user."""
    for f in fields(game):
        if f.get("required") and not s.get(f["key"]):
            return f"Please tick: {f['label']}"
    if game == "valheim":
        pw = s.get("password", "")
        if len(pw) < 5:
            return "Valheim needs a password of at least 5 characters."
        if pw and pw.lower() in s.get("server_name", "").lower():
            return "Valheim doesn't allow the password inside the server name."
    for k in ("world", "server_name"):
        if k in s and not str(s[k]).strip():
            return "The name can't be empty."
    if "world" in s and re.search(r"[/\\\0]", s["world"]):
        return "The world name can't contain / or \\."
    try:
        p = int(s.get("port", 0))
        assert 1024 <= p <= 65535
    except Exception:
        return "The port must be a number between 1024 and 65535."
    return ""


# ------------------------------------------------------------------ storage
def slug(text):
    s = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")[:32] or "server"
    name, i = s, 2
    while (ROOT / name).exists():
        name = f"{s}-{i}"; i += 1
    return name


def sdir(name):
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,40}", name or ""):
        raise ValueError(f"bad server name: {name!r}")
    return ROOT / name


def load(name):
    return json.loads((sdir(name) / "server.json").read_text())


def save(name, cfg):
    p = sdir(name) / "server.json"
    tmp = p.with_suffix(".tmp"); tmp.write_text(json.dumps(cfg, indent=2)); tmp.replace(p)


def ports(cfg):
    """[(port, proto)] the server listens on."""
    base = int(cfg["settings"].get("port") or GAMES[cfg["game"]]["default_port"])
    return [(base + (1 if which == "port+1" else 0), proto) for which, proto in GAMES[cfg["game"]]["ports"]]


def create(game, title, settings=None):
    if game not in GAMES:
        raise ValueError(f"unknown game {game}")
    s = defaults(game); s.update(settings or {})
    err = validate(game, s)
    if err:
        raise ValueError(err)
    name = slug(title)
    d = ROOT / name
    d.mkdir(parents=True)
    used = {p for other in list_servers() for p, _ in ports(other) if other["name"] != name}
    while int(s["port"]) in used:          # two servers of the same game get different ports automatically
        s["port"] = int(s["port"]) + 10
    save(name, {"name": name, "title": title, "game": game, "settings": s, "created": int(time.time()),
                "installed": False, "version": "", "fw_open": False})
    return name


def list_servers():
    out = []
    if not ROOT.is_dir():
        return out
    for d in sorted(ROOT.iterdir()):
        if d.name.startswith(".") or not (d / "server.json").exists():
            continue
        try:
            out.append(load(d.name))
        except Exception:
            continue
    return out


def systemctl(*args):
    return subprocess.run(["systemctl", "--user", *args], capture_output=True, text=True)


def is_active(name):
    return systemctl("is-active", UNIT.format(name)).stdout.strip() in ("active", "activating", "deactivating")


def is_enabled(name):
    return systemctl("is-enabled", UNIT.format(name)).stdout.strip() == "enabled"


def read_state(name):
    try:
        return json.loads((sdir(name) / "state.json").read_text())
    except Exception:
        return {}


def status_all():
    res = []
    for cfg in list_servers():
        n = cfg["name"]
        act = is_active(n)
        st = read_state(n) if act else {}
        res.append(dict(cfg, active=act, autostart=is_enabled(n), state=st, ports=ports(cfg)))
    return res


# ------------------------------------------------------------------ addresses
def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect(("192.0.2.1", 9))   # no packet is sent
        ip = s.getsockname()[0]; s.close()
        return ip
    except OSError:
        return ""


def public_ip():
    """Only when the user asks (one request to ipify.org)."""
    try:
        with urllib.request.urlopen(urllib.request.Request("https://api.ipify.org", headers=UA), timeout=6) as r:
            return r.read().decode().strip()
    except Exception:
        return ""


def ufw_on():
    try:
        return "ENABLED=yes" in Path("/etc/ufw/ufw.conf").read_text(errors="ignore")
    except OSError:
        return False


# ------------------------------------------------------------------ downloads
def fetch(url, dest=None, timeout=60):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        if dest is None:
            return r.read()
        total = int(r.headers.get("Content-Length") or 0)
        done, last = 0, 0
        tmp = Path(str(dest) + ".part")
        with open(tmp, "wb") as f:
            while True:
                b = r.read(1 << 16)
                if not b:
                    break
                f.write(b); done += len(b)
                if total and time.time() - last > 1:
                    last = time.time()
                    print(f"  {done * 100 // total}%  ({done >> 20} / {total >> 20} MB)", flush=True)
        tmp.replace(dest)
        print(f"  downloaded {done >> 20} MB", flush=True)
        return dest


def sha(path, algo):
    import hashlib
    h = hashlib.new(algo)
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def find_java(major):
    """System Java of exactly that version first (Debian openjdk-21/25), then any newer one, then our own download."""
    cands = []
    for d in Path("/usr/lib/jvm").glob("*"):
        m = re.match(r"(?:java|temurin|jdk|jre)-?(\d+)", d.name)
        if m and (d / "bin/java").exists():
            cands.append((int(m.group(1)), d / "bin/java"))
    for d in RUNTIME_DIR.glob("java-*"):
        j = next(iter(d.glob("*/bin/java")), None)
        if j and d.name[5:].isdigit():
            cands.append((int(d.name[5:]), j))
    ok = sorted((v, p) for v, p in cands if v >= major)
    exact = [p for v, p in ok if v == major]
    return str(exact[0] if exact else ok[0][1]) if ok else ""


def get_java(major):
    j = find_java(major)
    if j:
        return j
    print(f"Java {major} is not installed - downloading Eclipse Temurin {major} (JRE) for the server…", flush=True)
    info = json.loads(fetch(ADOPTIUM.format(major)))[0]["binary"]["package"]
    dest = RUNTIME_DIR / f"java-{major}"
    dest.mkdir(parents=True, exist_ok=True)
    tgz = fetch(info["link"], dest / "jre.tar.gz")
    if sha(tgz, "sha256") != info["checksum"]:
        tgz.unlink(); raise RuntimeError("Java download damaged (checksum mismatch)")
    with tarfile.open(tgz) as t:
        t.extractall(dest, filter="data")
    tgz.unlink()
    return find_java(major)


def install_minecraft(d, cfg):
    man = json.loads(fetch(MC_MANIFEST))
    ver = man["latest"]["release"]
    vurl = next(v["url"] for v in man["versions"] if v["id"] == ver)
    vj = json.loads(fetch(vurl))
    srv = vj["downloads"]["server"]
    major = int(vj.get("javaVersion", {}).get("majorVersion", 21))
    jar = d / "server.jar"
    if cfg.get("version") == ver and jar.exists() and sha(jar, "sha1") == srv["sha1"]:
        print(f"Minecraft server {ver} is already the newest.", flush=True)
    else:
        print(f"Downloading Minecraft server {ver} from Mojang…", flush=True)
        fetch(srv["url"], d / "server.jar.new")
        if sha(d / "server.jar.new", "sha1") != srv["sha1"]:
            (d / "server.jar.new").unlink(); raise RuntimeError("Download damaged (SHA-1 mismatch) - try again")
        (d / "server.jar.new").replace(jar)
        print("SHA-1 OK.", flush=True)
    cfg["java"] = get_java(major)
    cfg["java_major"] = major
    print(f"Java {major}: {cfg['java']}", flush=True)
    return ver


def install_terraria(d, cfg):
    names = json.loads(fetch(TERRARIA_LIST))
    zname = sorted(set(names), key=lambda n: int(re.sub(r"\D", "", n) or 0))[-1]
    ver = re.sub(r"\D", "", zname)
    if cfg.get("version") == ver and (d / "bin/TerrariaServer.bin.x86_64").exists():
        print(f"Terraria server {ver} is already the newest.", flush=True)
        return ver
    print(f"Downloading {zname} from terraria.org…", flush=True)
    z = fetch(TERRARIA_ZIP.format(zname), d / "terraria-server.zip")
    tmp = d / ".unpack"; shutil.rmtree(tmp, ignore_errors=True)
    with zipfile.ZipFile(z) as zf:
        for m in zf.infolist():
            if "/Linux/" in m.filename and ".." not in m.filename:
                zf.extract(m, tmp)
    lin = next(tmp.glob("*/Linux"))
    shutil.rmtree(d / "bin", ignore_errors=True)
    shutil.move(str(lin), d / "bin")
    shutil.rmtree(tmp, ignore_errors=True); z.unlink()
    for f in ("TerrariaServer", "TerrariaServer.bin.x86_64"):
        p = d / "bin" / f
        if p.exists():
            p.chmod(p.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP)
    return ver


def steamcmd():
    sc = STEAMCMD_DIR / "steamcmd.sh"
    if not sc.exists():
        print("Downloading SteamCMD from Valve…", flush=True)
        STEAMCMD_DIR.mkdir(parents=True, exist_ok=True)
        tgz = fetch(STEAMCMD_URL, STEAMCMD_DIR / "steamcmd.tar.gz")
        with tarfile.open(tgz) as t:
            t.extractall(STEAMCMD_DIR, filter="data")
        tgz.unlink()
    return sc


def install_steam(d, cfg):
    app = GAMES[cfg["game"]]["steam_app"]
    if not Path("/usr/lib32/libgcc_s.so.1").exists() and not Path("/lib32/libgcc_s.so.1").exists():
        print("Note: SteamCMD needs the 32-bit libraries lib32gcc-s1 and lib32stdc++6 (included in PhoenixGe).", flush=True)
    sc = steamcmd()
    (d / "game").mkdir(exist_ok=True)
    print(f"SteamCMD: installing / updating app {app} - the first time this takes a while…", flush=True)
    for attempt in (1, 2):   # SteamCMD updates itself on the first run and sometimes fails once ("Missing configuration")
        r = subprocess.run(["bash", str(sc), "+force_install_dir", str(d / "game"), "+login", "anonymous",
                            "+app_update", str(app), "validate", "+quit"])
        if r.returncode == 0:
            break
        print(f"SteamCMD exited with {r.returncode}, retrying…" if attempt == 1 else "SteamCMD failed.", flush=True)
    else:
        raise RuntimeError("SteamCMD could not download the server - check the internet connection and disk space")
    # Source 2 / Steam servers look for the Steam client library here
    sdk = Path.home() / ".steam/sdk64"
    sdk.mkdir(parents=True, exist_ok=True)
    lib = STEAMCMD_DIR / "linux64/steamclient.so"
    if lib.exists() and not (sdk / "steamclient.so").exists():
        (sdk / "steamclient.so").symlink_to(lib)
    acf = d / f"game/steamapps/appmanifest_{app}.acf"
    m = re.search(r'"buildid"\s+"(\d+)"', acf.read_text(errors="ignore")) if acf.exists() else None
    return f"build {m.group(1)}" if m else "installed"


def install(name):
    d = sdir(name); cfg = load(name)
    if is_active(name):
        print("Stopping the server for the update…", flush=True)
        systemctl("stop", UNIT.format(name))
    free = shutil.disk_usage(d).free >> 30
    print(f"{GAMES[cfg['game']]['title']}: needs {GAMES[cfg['game']]['size']}, {free} GB free in {ROOT}", flush=True)
    fn = {"minecraft": install_minecraft, "terraria": install_terraria}.get(cfg["game"], install_steam)
    ver = fn(d, cfg)
    cfg = dict(load(name), installed=True, version=ver, java=cfg.get("java", ""), java_major=cfg.get("java_major", 0),
               updated=int(time.time()))
    save(name, cfg)
    print(f"Ready: {cfg['title']} ({ver}). Press Start.", flush=True)
    return 0


# ------------------------------------------------------------------ config files + command line
def write_properties(path, values):
    """Update key=value lines, keep everything else (comments, keys the user added by hand)."""
    lines = path.read_text(errors="ignore").splitlines() if path.exists() else []
    seen = set()
    for i, line in enumerate(lines):
        k = line.split("=", 1)[0].strip()
        if k in values and not line.lstrip().startswith("#"):
            lines[i] = f"{k}={values[k]}"; seen.add(k)
    lines += [f"{k}={v}" for k, v in values.items() if k not in seen]
    path.write_text("\n".join(lines) + "\n")


def configure(name):
    """Write the game's own config from our settings. Returns (argv, env, stop_command)."""
    d = sdir(name); cfg = load(name); s = cfg["settings"]; g = cfg["game"]
    port = ports(cfg)[0][0]
    env = dict(os.environ)
    if g == "minecraft":
        if not s.get("eula"):
            raise SystemExit("Minecraft EULA not accepted - open the server settings in PhoenixGe Center.")
        (d / "eula.txt").write_text("# accepted in PhoenixGe Center\neula=true\n")
        write_properties(d / "server.properties", {
            "server-port": port, "level-name": s["world"], "motd": s["motd"].replace("\n", " "),
            "max-players": s["max_players"], "gamemode": s["gamemode"], "difficulty": s["difficulty"],
            "online-mode": "false" if s.get("cracked") else "true", "white-list": str(bool(s.get("whitelist_on"))).lower(),
            "enforce-whitelist": str(bool(s.get("whitelist_on"))).lower(), "pvp": str(bool(s.get("pvp"))).lower(),
            "view-distance": s.get("view_distance", 10)})
        ram = int(s.get("ram") or 0) or auto_ram()
        java = cfg.get("java") or find_java(int(cfg.get("java_major") or 21)) or "java"
        argv = [java, f"-Xms{max(512, ram // 2)}M", f"-Xmx{ram}M", "-XX:+UseG1GC", "-XX:+ParallelRefProcEnabled",
                *s.get("jvm_args", "").split(), "-jar", "server.jar", "nogui"]
    elif g == "terraria":
        (d / "worlds").mkdir(exist_ok=True)
        conf = {"world": str(d / "worlds" / (s["world"] + ".wld")), "autocreate": s["size"], "worldname": s["world"],
                "difficulty": s["difficulty"], "maxplayers": s["max_players"], "port": port, "password": s.get("password", ""),
                "worldpath": str(d / "worlds"), "motd": s.get("motd", ""), "upnp": 0, "secure": 1, "language": "en-US"}
        (d / "serverconfig.txt").write_text("".join(f"{k}={v}\n" for k, v in conf.items()))
        argv = [str(d / "bin/TerrariaServer.bin.x86_64"), "-config", str(d / "serverconfig.txt")]
        env.setdefault("TERM", "xterm")
    elif g == "cs2":
        gt, gm = CS2_MODES.get(s["mode"], (0, 1))
        argv = [str(d / "game/game/bin/linuxsteamrt64/cs2"), "-dedicated", "-console", "-usercon", "-port", str(port),
                "-maxplayers", str(s["max_players"]), "+game_type", str(gt), "+game_mode", str(gm), "+map", s["map"]]
        if s.get("gslt"):
            argv += ["+sv_setsteamaccount", s["gslt"]]
        else:
            argv += ["+sv_lan", "1"]
        if s.get("password"):
            argv += ["+sv_password", s["password"]]
        argv += s.get("extra", "").split()
    elif g == "valheim":
        (d / "saves").mkdir(exist_ok=True)
        argv = [str(d / "game/valheim_server.x86_64"), "-nographics", "-batchmode", "-name", s["server_name"],
                "-port", str(port), "-world", s["world"], "-password", s["password"], "-savedir", str(d / "saves"),
                "-public", "1" if s.get("public") else "0"]
        if s.get("crossplay"):
            argv.append("-crossplay")
        env["LD_LIBRARY_PATH"] = f"{d / 'game/linux64'}:{env.get('LD_LIBRARY_PATH', '')}"
        env["SteamAppId"] = "892970"
    else:
        raise SystemExit(f"unknown game {g}")
    return argv, env, GAMES[g]["stop"]


# ------------------------------------------------------------------ player count
def a2s_info(port, host="127.0.0.1", timeout=1.5):
    """Valve server query (CS2, Valheim): (players, max) or None."""
    req = b"\xFF\xFF\xFF\xFFTSource Engine Query\x00"
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.settimeout(timeout)
            s.sendto(req, (host, port))
            data = s.recv(4096)
            if data[4:5] == b"A":                       # challenge
                s.sendto(req + data[5:9], (host, port)); data = s.recv(4096)
            if data[4:5] != b"I":
                return None
            i = 6
            for _ in range(4):                          # name, map, folder, game
                i = data.index(b"\x00", i) + 1
            return data[i + 2], data[i + 3]
    except (OSError, ValueError, IndexError):
        return None


LOG_RULES = {   # (ready, joined, left) regexes on the console output
    "minecraft": (r"Done \(", r"\]: (\w{2,16}) joined the game", r"\]: (\w{2,16}) left the game"),
    "terraria": (r"Server started", r"^(.+?) has joined\.", r"^(.+?) has left\."),
    "cs2": (r"(?:Host activate|SV:  Spawn Server|GC Connection established)", None, None),
    "valheim": (r"(?:Game server connected|Opened Steam server)", None, None),
}


# ------------------------------------------------------------------ the wrapper (systemd runs this)
def run(name):
    d = sdir(name); cfg = load(name); g = cfg["game"]
    if not cfg.get("installed"):
        print("The server files are not downloaded yet - press Install in PhoenixGe Center.", file=sys.stderr)
        sys.exit(2)
    try:
        argv, env, stop_cmd = configure(name)
    except SystemExit as e:
        print(e, file=sys.stderr); sys.exit(2)
    log_path = d / "console.log"
    if log_path.exists() and log_path.stat().st_size:
        log_path.replace(d / "console.previous.log")
    log = open(log_path, "a", buffering=1, errors="replace")
    fifo = d / ".console"
    try:
        fifo.unlink()
    except FileNotFoundError:
        pass
    os.mkfifo(fifo, 0o600)
    state = {"pid": 0, "started": int(time.time()), "ready": False, "players": 0, "names": [],
             "max": int(cfg["settings"].get("max_players", 0) or 0)}

    def write_state():
        tmp = d / "state.tmp"; tmp.write_text(json.dumps(state)); tmp.replace(d / "state.json")

    def say(msg):
        log.write(f"[PhoenixGe] {msg}\n")

    upnp = []
    if cfg["settings"].get("reach") == "internet" and shutil.which("upnpc"):
        args = []
        for p, proto in ports(cfg):
            args += [str(p), proto.upper()]
        r = subprocess.run(["upnpc", "-e", f"PhoenixGe {name}", "-r", *args], capture_output=True, text=True, timeout=30)
        if r.returncode == 0 and "is redirected" in r.stdout:
            upnp = ports(cfg)
            ext = re.search(r"ExternalIPAddress = ([\d.]+)", r.stdout)
            state["public_ip"] = ext.group(1) if ext else ""
            say("router port opened via UPnP: " + ", ".join(f"{p}/{x}" for p, x in upnp))
        else:
            state["upnp_failed"] = True
            say("UPnP: the router did not open the port (UPnP off on the router?). Use a LAN room or forward the port by hand.")
    elif cfg["settings"].get("reach") == "internet":
        state["upnp_failed"] = True
        say("UPnP tool (upnpc) missing - forward the port on the router by hand.")

    secret = ("-password", "+sv_password", "+sv_setsteamaccount")
    say("starting: " + " ".join("******" if prev in secret else a for prev, a in zip([""] + argv, argv)))
    proc = subprocess.Popen(argv, cwd=str(d), env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, bufsize=0)
    state["pid"] = proc.pid; write_state()
    lock = threading.Lock()

    def send(line):
        with lock:
            try:
                proc.stdin.write((line.rstrip("\n") + "\n").encode()); proc.stdin.flush()
                return True
            except (BrokenPipeError, ValueError, OSError):
                return False

    def fifo_reader():
        while proc.poll() is None:
            try:
                with open(fifo, "r", errors="replace") as f:      # blocks until the Center opens it for writing
                    for line in f:
                        if line.strip():
                            log.write(f"> {line.strip()}\n")
                            send(line)
            except OSError:
                time.sleep(1)
    threading.Thread(target=fifo_reader, daemon=True).start()

    stopping = {"v": False}

    def on_term(_sig, _frm):
        if stopping["v"]:
            return
        stopping["v"] = True
        say("stopping - saving the world…")
        if stop_cmd and send(stop_cmd):
            pass
        else:
            try:
                proc.send_signal(signal.SIGINT)
            except OSError:
                pass

        def killer():
            time.sleep(75)
            if proc.poll() is None:
                say("the server did not stop in time - killing it")
                proc.kill()
        threading.Thread(target=killer, daemon=True).start()
    signal.signal(signal.SIGTERM, on_term)
    signal.signal(signal.SIGINT, on_term)

    if g in ("cs2", "valheim"):
        qport = ports(cfg)[0][0] + (1 if g == "valheim" else 0)

        def poller():
            while proc.poll() is None:
                r = a2s_info(qport)
                if r:
                    state["ready"] = True
                    state["players"], state["max"] = r[0], r[1] or state["max"]
                    write_state()
                time.sleep(15)
        threading.Thread(target=poller, daemon=True).start()

    ready_re, join_re, left_re = (re.compile(x, re.M) if x else None for x in LOG_RULES[g])
    if g == "minecraft" and cfg["settings"].get("whitelist_on"):
        pending = [f"whitelist add {n.strip()}" for n in cfg["settings"].get("whitelist", []) if n.strip()] + ["whitelist reload"]
    else:
        pending = []
    buf = b""
    while True:
        chunk = proc.stdout.read(4096)
        if not chunk:
            break
        buf += chunk
        *lines, buf = buf.split(b"\n")
        changed = False
        for raw in lines:
            line = raw.decode(errors="replace").rstrip("\r")
            line = re.sub(r"\x1b\[[0-9;?]*[A-Za-z]", "", line)
            log.write(line + "\n")
            if ready_re and not state["ready"] and ready_re.search(line):
                state["ready"] = True; changed = True
                for c in pending:
                    send(c)
                pending = []
            if join_re and (m := join_re.search(line)):
                n = m.group(1).strip()
                if n not in state["names"]:
                    state["names"].append(n)
                state["players"] = len(state["names"]); changed = True
            elif left_re and (m := left_re.search(line)):
                n = m.group(1).strip()
                if n in state["names"]:
                    state["names"].remove(n)
                state["players"] = len(state["names"]); changed = True
        if changed:
            write_state()
    code = proc.wait()
    for p, proto in upnp:
        subprocess.run(["upnpc", "-d", str(p), proto.upper()], capture_output=True, timeout=20)
    say(f"server stopped (exit code {code})")
    for f in (fifo, d / "state.json"):
        try:
            f.unlink()
        except FileNotFoundError:
            pass
    sys.exit(0 if stopping["v"] else code)


# ------------------------------------------------------------------ control
def send_command(name, line):
    """Type a command into the running server's console. False if it isn't running."""
    try:
        fd = os.open(sdir(name) / ".console", os.O_WRONLY | os.O_NONBLOCK)
    except OSError:
        return False
    try:
        os.write(fd, (line.strip() + "\n").encode())
        return True
    finally:
        os.close(fd)


def start(name):
    systemctl("daemon-reload")
    return systemctl("start", UNIT.format(name)).returncode


def stop(name):
    return systemctl("stop", UNIT.format(name)).returncode


def set_autostart(name, on):
    """On = start with the computer: enable the user unit, and let it run before/without login (lingering)."""
    r = systemctl("enable" if on else "disable", UNIT.format(name))
    if on:
        subprocess.run(["loginctl", "enable-linger", os.environ.get("USER", "")], capture_output=True)
    elif not any(is_enabled(c["name"]) for c in list_servers()):
        subprocess.run(["loginctl", "disable-linger", os.environ.get("USER", "")], capture_output=True)
    return r.returncode


def delete(name):
    d = sdir(name)
    systemctl("stop", UNIT.format(name)); systemctl("disable", UNIT.format(name))
    shutil.rmtree(d)
    return 0


def tail(name, lines=400):
    p = sdir(name) / "console.log"
    if not p.exists():
        p = sdir(name) / "console.previous.log"
    try:
        with open(p, "rb") as f:
            f.seek(0, 2); size = f.tell(); f.seek(max(0, size - 96 * 1024))
            return "\n".join(f.read().decode(errors="replace").splitlines()[-lines:])
    except OSError:
        return ""


def main(argv):
    cmd = argv[1] if len(argv) > 1 else "list"
    a = argv[2:]
    if cmd == "list":
        print(json.dumps(status_all(), indent=2)); return 0
    if cmd == "create":
        print(create(a[0], a[1], json.loads(a[2]) if len(a) > 2 else None)); return 0
    if cmd == "install":
        try:
            return install(a[0])
        except Exception as e:
            print(f"Install failed: {e}", flush=True); return 1
    if cmd in ("start", "stop"):
        return (start if cmd == "start" else stop)(a[0])
    if cmd == "restart":
        stop(a[0]); return start(a[0])
    if cmd == "autostart":
        return set_autostart(a[0], a[1] == "on")
    if cmd == "send":
        return 0 if send_command(a[0], " ".join(a[1:])) else 1
    if cmd == "delete":
        return delete(a[0])
    if cmd == "run":
        run(a[0])
    print(__doc__); return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
