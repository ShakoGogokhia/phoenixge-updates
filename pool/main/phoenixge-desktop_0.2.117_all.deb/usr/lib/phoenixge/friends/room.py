#!/usr/bin/env python3
"""PhoenixGe LAN rooms - a virtual LAN with friends (like Radmin VPN / Hamachi), built on EasyTier.

Why EasyTier: open source (LGPL-3.0), no account, no server of our own. Peers meet through free public "shared nodes"
run by the EasyTier community, punch through NAT for a direct (P2P) link and fall back to relaying through the shared
node when that fails. Traffic is encrypted with the network secret. Windows/macOS/Linux/Android clients exist, so
friends without PhoenixGe can join too.

A room code ("PHX-K7Q2M-9TZWA") is all a friend needs: the EasyTier network name and secret are derived from it.

    room.py create                 new code, join it, print the code
    room.py join <CODE>            join a friend's room
    room.py leave                  leave the room (stops the background service)
    room.py status                 JSON: state, code, my ip, peers [{name, ip, ping_ms, link}]
    room.py details                JSON: what a friend types into the EasyTier app by hand (network name/secret/servers)
    room.py run                    (used by phoenixge-room.service) exec easytier-core with the saved settings
Config: ~/.config/phoenixge/friends/room.json   (all fields optional except code)
"""
import hashlib
import json
import os
import secrets
import shutil
import subprocess
import sys
from pathlib import Path

ET_DIR = Path("/usr/lib/phoenixge/friends/easytier")
CORE, CLI = ET_DIR / "easytier-core", ET_DIR / "easytier-cli"
INSTALLER = "/usr/lib/phoenixge/friends/install-easytier.sh"
CONF = Path.home() / ".config/phoenixge/friends/room.json"
UNIT = "phoenixge-room.service"
RPC = "127.0.0.1:15899"          # not EasyTier's default 15888, so a separately installed EasyTier can run beside us
DEV = "phx0"                     # network interface name (the firewall allows everything that comes in on it)
# Free public shared nodes run by the EasyTier project (rendezvous + relay). Several = keeps working if one is down.
DEFAULT_SERVERS = ["tcp://public.easytier.top:11010", "tcp://public.easytier.cn:11010"]
ALPHABET = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ"   # no 0/O/1/I - easy to read out over voice chat
DEFAULTS = {"code": "", "name": "", "auto_ip": True, "ip": "10.126.126.10", "servers": DEFAULT_SERVERS,
            "broadcast": True, "autostart": False}


# ------------------------------------------------------------------ room code
def new_code():
    s = "".join(secrets.choice(ALPHABET) for _ in range(10))
    return f"PHX-{s[:5]}-{s[5:]}"


def normalize(code):
    """'phx k7q2m 9tzwa' / 'K7Q2M9TZWA' -> 'PHX-K7Q2M-9TZWA'. Returns '' if it doesn't look like a room code."""
    s = "".join(c for c in code.upper() if c.isalnum())
    if s.startswith("PHX"):
        s = s[3:]
    if len(s) != 10 or any(c not in ALPHABET for c in s):
        return ""
    return f"PHX-{s[:5]}-{s[5:]}"


def network_of(code):
    """EasyTier network name + secret derived from the room code (same on every computer, never shown unless asked)."""
    h = hashlib.sha256(("phoenixge-room:" + code).encode()).hexdigest()
    return "phx-" + h[:16], h[16:48]


# ------------------------------------------------------------------ config
def load():
    c = dict(DEFAULTS)
    try:
        c.update(json.loads(CONF.read_text()))
    except Exception:
        pass
    if not c.get("name"):
        c["name"] = os.environ.get("USER", "phoenix")
    if not c.get("servers"):
        c["servers"] = list(DEFAULT_SERVERS)
    return c


def save(c):
    CONF.parent.mkdir(parents=True, exist_ok=True)
    CONF.write_text(json.dumps(c, indent=2))


def installed():
    return CORE.exists() and CLI.exists()


def systemctl(*args):
    return subprocess.run(["systemctl", "--user", *args], capture_output=True, text=True)


def active():
    return systemctl("is-active", UNIT).stdout.strip() in ("active", "activating")


# ------------------------------------------------------------------ actions
def start(code):
    c = load()
    c["code"] = code
    save(c)
    systemctl("daemon-reload")
    r = systemctl("restart", UNIT)
    if c.get("autostart"):
        systemctl("enable", UNIT)
    return r.returncode


def leave():
    systemctl("disable", UNIT)
    return systemctl("stop", UNIT).returncode


def set_autostart(on):
    c = load(); c["autostart"] = bool(on); save(c)
    systemctl("enable" if on else "disable", UNIT)


def core_args(c):
    name, secret = network_of(c["code"])
    a = [str(CORE), "--network-name", name, "--network-secret", secret, "--hostname", c["name"][:40],
         "--dev-name", DEV, "--rpc-portal", RPC, "--instance-name", "phoenixge-room"]
    a += ["--dhcp"] if c.get("auto_ip", True) else ["--ipv4", c.get("ip", "10.126.126.10")]
    for s in c.get("servers") or DEFAULT_SERVERS:
        a += ["--peers", s]
    if c.get("broadcast", True):
        a += ["--enable-udp-broadcast-relay"]      # LAN game discovery (Terraria/older games broadcast to find servers)
    return a


def run():
    c = load()
    if not c.get("code"):
        print("No room code saved - create or join a room in PhoenixGe Center.", file=sys.stderr)
        sys.exit(2)
    if not installed():
        print(f"EasyTier is not installed - run: pkexec /bin/sh {INSTALLER}", file=sys.stderr)
        sys.exit(3)
    a = core_args(c)
    os.execv(a[0], a)


def cli_json(*args, timeout=4):
    try:
        out = subprocess.run([str(CLI), "-p", RPC, "-o", "json", *args], capture_output=True, text=True, timeout=timeout).stdout
        return json.loads(out)
    except Exception:
        return None


def _float(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def status():
    """{state: off|connecting|online|not-installed, code, my_ip, relays, peers:[{name, ip, ping_ms, link, loss}]}"""
    c = load()
    st = {"state": "off", "code": c.get("code", ""), "my_ip": "", "relays": 0, "peers": [], "name": c.get("name", ""),
          "autostart": bool(c.get("autostart"))}
    if not installed():
        st["state"] = "not-installed"
        return st
    if not active():
        return st
    st["state"] = "connecting"
    rows = cli_json("peer")
    if isinstance(rows, list) and rows and isinstance(rows[0], dict) and "result" in rows[0]:
        rows = rows[0]["result"]           # several instances -> wrapped (shouldn't happen with our own rpc port)
    if not isinstance(rows, list):
        return st
    for r in rows:
        host, cost = str(r.get("hostname", "")), str(r.get("cost", ""))
        ip = str(r.get("ipv4") or str(r.get("cidr", "")).split("/")[0])
        if cost == "Local":
            st["my_ip"] = ip
            continue
        if host.startswith("PublicServer_") or not ip:
            st["relays"] += 1                 # the shared node itself (no virtual IP)
            continue
        st["peers"].append({"name": host, "ip": ip, "ping_ms": _float(r.get("lat_ms")), "loss": r.get("loss_rate", ""),
                            "link": "direct" if cost.lower().startswith("p2p") else "relay"})
    if st["my_ip"] and (st["relays"] or st["peers"]):
        st["state"] = "online"
    return st


def details():
    c = load()
    name, secret = network_of(c.get("code", "")) if c.get("code") else ("", "")
    return {"code": c.get("code", ""), "network_name": name, "network_secret": secret,
            "servers": c.get("servers") or DEFAULT_SERVERS, "dhcp": True,
            "download": "https://easytier.cn/en/guide/download.html"}


def main(argv):
    cmd = argv[1] if len(argv) > 1 else "status"
    if cmd == "create":
        code = new_code()
        rc = start(code)
        print(code)
        return rc
    if cmd == "join":
        code = normalize(argv[2] if len(argv) > 2 else "")
        if not code:
            print("That doesn't look like a room code (PHX-XXXXX-XXXXX).", file=sys.stderr)
            return 2
        return start(code)
    if cmd == "leave":
        return leave()
    if cmd == "status":
        print(json.dumps(status(), indent=2)); return 0
    if cmd == "details":
        print(json.dumps(details(), indent=2)); return 0
    if cmd == "run":
        run()
    print(__doc__)
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
