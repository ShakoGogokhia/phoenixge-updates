"""PhoenixGe Clips - media helpers (pure Python, no Qt). Every function degrades gracefully when a tool is missing.

    scan()                      -> every clip / screenshot in the known folders (newest first)
    probe() / thumbnail() / filmstrip()                         (ffprobe / ffmpeg)
    hw_encoders()               -> working H.264 encoders on this PC: ["nvenc", "vaapi", "x264"] (tested, not guessed)
    export_cmd()                -> ffmpeg argv for trim / vertical crop / size limit
    clipboard + share helpers, Discord webhook upload (opt-in, urllib multipart)

Folders: Instant Replay (GPU Screen Recorder) saves to ~/Videos/Replays, the overlay's screenshots go to
~/Pictures/Screenshots, OBS recordings land in ~/Videos, our exports go to ~/Videos/Clips.
"""
import hashlib
import json
import os
import re
import shutil
import subprocess
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime
from pathlib import Path

HOME = Path.home()
VIDEO_EXT = {".mp4", ".mkv", ".webm", ".mov", ".flv", ".m4v"}
IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp"}


def _user_dir(kind, fallback):
    env = os.environ.get(f"XDG_{kind}_DIR")
    if env:
        return Path(env)
    try:
        for line in (HOME / ".config/user-dirs.dirs").read_text().splitlines():
            if line.startswith(f"XDG_{kind}_DIR="):
                return Path(line.split("=", 1)[1].strip().strip('"').replace("$HOME", str(HOME)))
    except OSError:
        pass
    return HOME / fallback


VIDEOS = _user_dir("VIDEOS", "Videos")
PICTURES = _user_dir("PICTURES", "Pictures")
REPLAYS = VIDEOS / "Replays"
SHOTS = PICTURES / "Screenshots"
EXPORTS = VIDEOS / "Clips"
DATA = Path(os.environ.get("XDG_DATA_HOME") or HOME / ".local/share") / "phoenixge"
PERF_ROOT = DATA / "perf"
INDEX = DATA / "clips-index.json"          # {"<path>": {"game": "..."}} - games of exported clips
CONF = HOME / ".config/phoenixge/clips.json"
CACHE = HOME / ".cache/phoenixge/clips"


def set_roots(videos, pictures, data=None):
    """Point everything at other folders (demo mode / tests)."""
    global VIDEOS, PICTURES, REPLAYS, SHOTS, EXPORTS, DATA, PERF_ROOT, INDEX, CACHE
    VIDEOS, PICTURES = Path(videos), Path(pictures)
    REPLAYS, SHOTS, EXPORTS = VIDEOS / "Replays", PICTURES / "Screenshots", VIDEOS / "Clips"
    if data:
        DATA = Path(data)
        PERF_ROOT, INDEX, CACHE = DATA / "perf", DATA / "clips-index.json", DATA / "cache"


def run(cmd, timeout=15):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout, r.stderr
    except (OSError, subprocess.SubprocessError) as e:
        return 1, "", str(e)


def have(tool):
    return bool(shutil.which(tool))


# ------------------------------------------------------------------ settings
def load_conf():
    try:
        return json.loads(CONF.read_text())
    except (OSError, ValueError):
        return {}


def save_conf(conf):
    CONF.parent.mkdir(parents=True, exist_ok=True)
    tmp = CONF.with_suffix(".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)   # may hold a webhook URL (= a password)
    with os.fdopen(fd, "w") as f:
        json.dump(conf, f, indent=1)
    tmp.replace(CONF)


def load_index():
    try:
        return json.loads(INDEX.read_text())
    except (OSError, ValueError):
        return {}


def index_set(path, **values):
    idx = load_index()
    idx.setdefault(str(path), {}).update(values)
    idx = {k: v for k, v in idx.items() if Path(k).exists()}     # forget deleted files
    INDEX.parent.mkdir(parents=True, exist_ok=True)
    INDEX.write_text(json.dumps(idx, indent=1))


def index_move(old, new):
    idx = load_index()
    if str(old) in idx:
        idx[str(new)] = idx.pop(str(old))
        INDEX.write_text(json.dumps(idx, indent=1))


# ------------------------------------------------------------------ which game?
GENERIC = {"replay", "screenshot", "screenshots", "screencast", "recording", "video", "clip", "spectacle", "obs",
           "desktop", "vlc-record", "untitled", "capture", "screen"}


def _pretty(name):
    name = re.sub(r"[_-]+", " ", name).strip()
    return name if any(c.isupper() for c in name) else name.title()


def _norm(name):
    return re.sub(r"[^a-z0-9]+", "", name.lower())


def _sessions():
    """[(start, end, name)] of game sessions phoenix-game-run recorded (perf/<game>/sessions.jsonl)."""
    out = []
    if not PERF_ROOT.is_dir():
        return out
    for f in PERF_ROOT.glob("*/sessions.jsonl"):
        try:
            lines = f.read_text().splitlines()
        except OSError:
            continue
        for line in lines:
            try:
                s = json.loads(line)
                out.append((float(s["start"]), float(s.get("end") or s["start"]), s.get("name") or _pretty(f.parent.name)))
            except (ValueError, KeyError, TypeError):
                continue
    return out


def game_of(path, mtime, sessions, index):
    """Game for a file: what we stored on export > '<Game>-2026-11-13_...' in the name > the game that was running
    when the file was written > 'Desktop'."""
    e = index.get(str(path))
    if e and e.get("game"):
        return e["game"]
    m = re.match(r"^(?P<g>.+?)[-_ ]+\d{4}-\d{2}-\d{2}", Path(path).stem)
    if m and m["g"].lower() not in GENERIC:
        # the overlay writes "Counter-Strike-2-<date>.png": map it back to the real name when we know the game
        known = {_norm(n): n for _, _, n in sessions}
        known.update({_norm(e["game"]): e["game"] for e in index.values() if e.get("game")})
        return known.get(_norm(m["g"])) or _pretty(m["g"])
    for parent in (Path(path).parent,):          # GPU Screen Recorder can sort replays into per-game folders
        if parent not in (REPLAYS, SHOTS, EXPORTS, VIDEOS, PICTURES) and parent.name.lower() not in GENERIC:
            return _pretty(parent.name)
    # the time in the name (Replay_2026-11-13_15-07-10, also kept by our exports) beats the file time
    times = [mtime]
    d = re.search(r"(\d{4}-\d{2}-\d{2})[_ T](\d{2})[-.:](\d{2})[-.:](\d{2})", Path(path).stem)
    if d:
        try:
            times.insert(0, datetime.strptime(f"{d[1]} {d[2]}:{d[3]}:{d[4]}", "%Y-%m-%d %H:%M:%S").timestamp())
        except ValueError:
            pass
    for t in times:
        best = None   # overlapping sessions: the one that started last wins
        for start, end, name in sessions:
            if start - 5 <= t <= end + 120 and (best is None or start > best[0]):
                best = (start, name)
        if best:
            return best[1]
    return "Desktop"


# ------------------------------------------------------------------ library
def source_of(path):
    p = Path(path)
    if EXPORTS in p.parents:
        return "export"
    if REPLAYS in p.parents:
        return "replay"
    if p.suffix.lower() in IMAGE_EXT:
        return "screenshot"
    return "recording"


def scan():
    """[{path, name, kind (video|image), source (replay|recording|export|screenshot), mtime, size, game}] newest first."""
    seen, items = set(), []
    sessions, index = _sessions(), load_index()
    places = [(REPLAYS, True), (EXPORTS, True), (VIDEOS, False), (SHOTS, True)]
    for folder, deep in places:
        if not folder.is_dir():
            continue
        try:
            files = folder.rglob("*") if deep else folder.iterdir()
            for p in files:
                ext = p.suffix.lower()
                if ext not in VIDEO_EXT and ext not in IMAGE_EXT or p in seen or p.name.startswith("."):
                    continue
                if folder == VIDEOS and ext in IMAGE_EXT:
                    continue
                try:
                    st = p.stat()
                except OSError:
                    continue
                if not p.is_file() or st.st_size == 0:
                    continue
                seen.add(p)
                items.append({"path": str(p), "name": p.name, "kind": "image" if ext in IMAGE_EXT else "video",
                              "source": source_of(p), "mtime": st.st_mtime, "size": st.st_size,
                              "game": game_of(p, st.st_mtime, sessions, index)})
        except OSError:
            continue
    items.sort(key=lambda i: -i["mtime"])
    return items


def day_label(ts, now=None):
    d = datetime.fromtimestamp(ts).date()
    today = datetime.fromtimestamp(now or time.time()).date()
    delta = (today - d).days
    if delta == 0:
        return "Today"
    if delta == 1:
        return "Yesterday"
    if delta < 7:
        return d.strftime("%A")
    return d.strftime("%-d %B %Y") if d.year != today.year else d.strftime("%-d %B")


def fmt_time(sec, ms=False):
    sec = max(0.0, sec or 0.0)
    h, rem = divmod(int(sec), 3600)
    m, s = divmod(rem, 60)
    base = f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"
    return f"{base}.{int((sec % 1) * 10)}" if ms else base


def fmt_size(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit in ("B", "KB") else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} GB"


# ------------------------------------------------------------------ ffprobe / thumbnails
def _key(path, extra=""):
    try:
        st = os.stat(path)
        sig = f"{path}|{st.st_mtime}|{st.st_size}|{extra}"
    except OSError:
        sig = f"{path}|{extra}"
    return hashlib.sha1(sig.encode()).hexdigest()


def probe(path):
    """{"duration", "width", "height", "fps", "vcodec", "acodec", "audio_tracks"} or {} without ffprobe."""
    cache = CACHE / "probe" / (_key(path) + ".json")
    try:
        return json.loads(cache.read_text())
    except (OSError, ValueError):
        pass
    if not have("ffprobe"):
        return {}
    code, out, _ = run(["ffprobe", "-v", "error", "-show_entries",
                        "format=duration:stream=codec_type,codec_name,width,height,avg_frame_rate", "-of", "json", path], 20)
    try:
        data = json.loads(out) if code == 0 else {}
    except ValueError:
        data = {}
    info = {"duration": 0.0, "width": 0, "height": 0, "fps": 0.0, "vcodec": "", "acodec": "", "audio_tracks": 0}
    try:
        info["duration"] = float(data.get("format", {}).get("duration") or 0)
    except ValueError:
        pass
    for s in data.get("streams", []):
        if s.get("codec_type") == "video" and not info["vcodec"]:
            info.update(width=s.get("width", 0), height=s.get("height", 0), vcodec=s.get("codec_name", ""))
            try:
                n, d = s.get("avg_frame_rate", "0/1").split("/")
                info["fps"] = round(float(n) / float(d), 2) if float(d) else 0.0
            except ValueError:
                pass
        elif s.get("codec_type") == "audio":
            info["audio_tracks"] += 1
            info["acodec"] = info["acodec"] or s.get("codec_name", "")
    if data:
        cache.parent.mkdir(parents=True, exist_ok=True)
        cache.write_text(json.dumps(info))
    return info


def thumbnail(path, width=480):
    """JPEG poster frame of a video (cached). None without ffmpeg."""
    out = CACHE / "thumbs" / (_key(path, width) + ".jpg")
    if out.exists():
        return str(out)
    if not have("ffmpeg"):
        return None
    out.parent.mkdir(parents=True, exist_ok=True)
    dur = probe(path).get("duration") or 0
    for t in ([min(2.0, dur / 3)] if dur > 0.5 else []) + [0]:
        run(["ffmpeg", "-v", "error", "-y", "-ss", f"{t:.2f}", "-i", path, "-frames:v", "1",
             "-vf", f"thumbnail=12,scale={width}:-2", "-q:v", "4", str(out)], 30)
        if out.exists() and out.stat().st_size:
            return str(out)
    return None


def filmstrip(path, duration, frames=14, height=64):
    """A strip of frames across the whole clip for the trim timeline (one ffmpeg call, fast seeks). None on failure."""
    out = CACHE / "strips" / (_key(path, f"{frames}x{height}") + ".jpg")
    if out.exists():
        return str(out)
    if not have("ffmpeg") or duration <= 0:
        return None
    out.parent.mkdir(parents=True, exist_ok=True)
    w = int(height * 16 / 9) // 2 * 2
    args, chains = ["ffmpeg", "-v", "error", "-y"], []
    for i in range(frames):
        t = duration * (i + 0.5) / frames
        args += ["-ss", f"{t:.2f}", "-i", path]
        chains.append(f"[{i}:v]scale={w}:{height}:force_original_aspect_ratio=increase,crop={w}:{height},setsar=1,"
                      f"trim=end_frame=1[v{i}]")
    graph = ";".join(chains) + ";" + "".join(f"[v{i}]" for i in range(frames)) + f"hstack=inputs={frames}[out]"
    run(args + ["-filter_complex", graph, "-map", "[out]", "-frames:v", "1", "-q:v", "5", str(out)], 60)
    return str(out) if out.exists() and out.stat().st_size else None


# ------------------------------------------------------------------ encoders
ENCODER_NAMES = {"nvenc": "NVIDIA NVENC", "vaapi": "VA-API (AMD / Intel GPU)", "x264": "Software (x264)"}
VAAPI_DEV = "/dev/dri/renderD128"
_enc_cache = None


def nvidia_present():
    return Path("/proc/driver/nvidia/version").exists()


def hw_encoders():
    """Encoders that really work here, best first. Each candidate does a tiny test encode (~0.3 s)."""
    global _enc_cache
    if _enc_cache is not None:
        return _enc_cache
    res = []
    if have("ffmpeg"):
        _, listing, _ = run(["ffmpeg", "-hide_banner", "-encoders"], 10)
        src = ["-f", "lavfi", "-i", "color=c=black:s=320x240:d=0.2"]
        if "h264_nvenc" in listing and nvidia_present():
            if run(["ffmpeg", "-v", "error", *src, "-c:v", "h264_nvenc", "-f", "null", "-"], 15)[0] == 0:
                res.append("nvenc")
        if "h264_vaapi" in listing and os.path.exists(VAAPI_DEV):
            if run(["ffmpeg", "-v", "error", "-vaapi_device", VAAPI_DEV, *src, "-vf", "format=nv12,hwupload",
                    "-c:v", "h264_vaapi", "-f", "null", "-"], 15)[0] == 0:
                res.append("vaapi")
    res.append("x264")
    _enc_cache = res
    return res


# ------------------------------------------------------------------ export
SIZE_PRESETS = [  # (label, MB or None) - Discord limits as of 2025: free 10 MB, Nitro Basic 50 MB, Nitro 500 MB
    ("Original size", None), ("Discord - 10 MB", 10), ("Discord Nitro Basic - 50 MB", 50),
    ("Discord Nitro - 500 MB", 500), ("Custom size…", -1)]


def plan_export(info, start, end, *, reencode, vertical=False, target_mb=None, squeeze=1.0):
    """What the export will do: {"reencode", "height", "fps", "vkbps", "akbps", "error", "summary"}."""
    dur = max(0.1, end - start)
    src_h = info.get("height") or 1080
    src_fps = info.get("fps") or 60
    p = {"reencode": reencode or vertical or bool(target_mb), "height": None, "fps": None, "vkbps": None,
         "akbps": 160, "error": None}
    # "side" = the short side of the output (1080 for 1920x1080 and for vertical 1080x1920). Never upscale.
    side = min(src_h, 1080) if vertical else src_h
    if target_mb:
        akbps = 96 if target_mb <= 10 else 128
        total = target_mb * 8 * 1000 * 0.94 * squeeze / dur           # kbit/s for the whole file (6 % container headroom)
        vk = int(total - akbps)
        # short clips: more bitrate than this only makes the file bigger, not better
        vk = min(vk, 16000 if side >= 1440 else 12000 if side >= 1080 else 7000 if side >= 720 else 3500)
        if vk < 120:
            secs = int(target_mb * 8 * 1000 * 0.94 / (120 + akbps))
            p["error"] = f"Too long for {target_mb} MB - trim it to {secs} s or less."
            vk = 120
        # lower the resolution when the bitrate is too small for it (looks much better than blocky 1080p)
        for limit_k, h in ((1500, 720), (700, 480), (350, 360)):
            if vk < limit_k and side > h:
                side = h
        if vk < 1200 and src_fps > 30:
            p["fps"] = 30
        p.update(vkbps=vk, akbps=akbps)
    side = side // 2 * 2
    out_h = int(side * 16 / 9) // 2 * 2 if vertical else side
    if p["reencode"]:
        p["height"] = out_h if (out_h != src_h or vertical) else None
        if not p["fps"] and src_fps > 60:
            p["fps"] = 60
    if not p["reencode"]:
        p["summary"] = "Fast cut - no re-encode, original quality (cuts snap to the nearest keyframe)."
    else:
        res = f"vertical {side}×{out_h}" if vertical else (f"{out_h}p" if p["height"] else "original resolution")
        bits = [res]
        if p["fps"]:
            bits.append(f"{p['fps']} fps")
        bits.append(f"~{p['vkbps'] / 1000:.1f} Mbit/s" if p["vkbps"] else "high quality")
        est = f" · about {min(target_mb, (p['vkbps'] + p['akbps']) * dur / 8000):.1f} MB" if target_mb else ""
        p["summary"] = "Re-encode: " + ", ".join(bits) + est + "."
    return p


def out_path(src, *, reencode, vertical=False, target_mb=None):
    src = Path(src)
    tag = "vertical" if vertical else (f"{target_mb}MB" if target_mb else "clip")
    ext = ".mp4" if reencode or vertical or target_mb else src.suffix
    EXPORTS.mkdir(parents=True, exist_ok=True)
    stem = re.sub(r"-(clip|vertical|\d+MB)(-\d+)?$", "", src.stem)
    n, dst = 1, EXPORTS / f"{stem}-{tag}{ext}"
    while dst.exists():
        n += 1
        dst = EXPORTS / f"{stem}-{tag}-{n}{ext}"
    return str(dst)


def export_cmd(src, dst, start, end, info, *, reencode, vertical=False, crop_pos=0.5, target_mb=None,
               encoder="x264", squeeze=1.0):
    """ffmpeg argv. Progress goes to stdout as key=value lines (-progress pipe:1)."""
    dur = max(0.1, end - start)
    p = plan_export(info, start, end, reencode=reencode, vertical=vertical, target_mb=target_mb, squeeze=squeeze)
    cmd = ["ffmpeg", "-hide_banner", "-nostdin", "-y", "-progress", "pipe:1", "-nostats", "-loglevel", "error"]
    if not p["reencode"]:
        return cmd + ["-ss", f"{start:.3f}", "-i", src, "-t", f"{dur:.3f}", "-map", "0:v?", "-map", "0:a?",
                      "-c", "copy", "-avoid_negative_ts", "make_zero"] + \
            (["-movflags", "+faststart"] if dst.endswith((".mp4", ".mov", ".m4v")) else []) + [dst]
    if encoder == "vaapi":
        cmd += ["-vaapi_device", VAAPI_DEV]
    cmd += ["-ss", f"{start:.3f}", "-i", src, "-t", f"{dur:.3f}", "-map", "0:v:0", "-map", "0:a:0?"]
    vf = []
    if vertical:
        cp = min(1.0, max(0.0, crop_pos))
        vf.append(f"crop=trunc(ih*9/16/2)*2:ih:trunc((iw-trunc(ih*9/16/2)*2)*{cp:.3f}):0")
        h = p["height"] or 1920
        vf.append(f"scale={int(h * 9 / 16) // 2 * 2}:{h}:flags=lanczos")
    elif p["height"]:
        vf.append(f"scale=-2:{p['height']}:flags=lanczos")
    if p["fps"]:
        vf.append(f"fps={p['fps']}")
    vk = p["vkbps"]
    if encoder == "nvenc":
        vf.append("format=yuv420p")
        cmd += ["-c:v", "h264_nvenc", "-preset", "p6", "-tune", "hq"]
        cmd += (["-rc", "vbr", "-b:v", f"{vk}k", "-maxrate", f"{int(vk * 1.2)}k", "-bufsize", f"{vk * 2}k"] if vk
                else ["-rc", "vbr", "-cq", "21", "-b:v", "0"])
    elif encoder == "vaapi":
        vf += ["format=nv12", "hwupload"]
        cmd += ["-c:v", "h264_vaapi"]
        cmd += (["-rc_mode", "VBR", "-b:v", f"{vk}k", "-maxrate", f"{int(vk * 1.2)}k"] if vk else ["-rc_mode", "CQP", "-qp", "22"])
    else:
        vf.append("format=yuv420p")
        cmd += ["-c:v", "libx264", "-preset", "medium" if vk else "veryfast"]
        cmd += (["-b:v", f"{vk}k", "-maxrate", f"{int(vk * 1.2)}k", "-bufsize", f"{vk * 2}k"] if vk else ["-crf", "20"])
    if vf:
        cmd += ["-vf", ",".join(vf)]
    cmd += ["-c:a", "aac", "-b:a", f"{p['akbps']}k", "-ac", "2", "-movflags", "+faststart", dst]
    return cmd


# ------------------------------------------------------------------ files / sharing
def rename(path, new_stem):
    p = Path(path)
    new_stem = re.sub(r"[/\x00]", "-", new_stem).strip()
    if not new_stem:
        raise ValueError("Empty name")
    dst = p.with_name(new_stem + p.suffix)
    if dst.exists() and dst != p:
        raise FileExistsError(f"{dst.name} already exists")
    p.rename(dst)
    index_move(p, dst)
    return str(dst)


def spawn(cmd):
    try:
        subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)
        return True
    except OSError:
        return False


def show_in_folder(path):
    """Dolphin selects the file; other file managers via the FileManager1 D-Bus interface; last resort: open the folder."""
    if have("dolphin"):
        return spawn(["dolphin", "--select", str(path)])
    if have("gdbus") and run(["gdbus", "call", "--session", "--dest", "org.freedesktop.FileManager1", "--object-path",
                               "/org/freedesktop/FileManager1", "--method", "org.freedesktop.FileManager1.ShowItems",
                               f"['{Path(path).as_uri()}']", ""], 5)[0] == 0:
        return True
    return spawn(["xdg-open", str(Path(path).parent)])


def open_url(url):
    return spawn(["xdg-open", url])


def open_external(path):
    for player in ("mpv", "vlc", "haruna", "celluloid"):
        if have(player):
            return spawn([player, str(path)])
    return spawn(["xdg-open", str(path)])


def copy_file_cli(path):
    """Clipboard without Qt (command line): text/uri-list, the format Dolphin uses - Discord / browsers paste it as a file."""
    uri = Path(path).resolve().as_uri() + "\r\n"
    if os.environ.get("WAYLAND_DISPLAY") and have("wl-copy"):
        try:
            subprocess.run(["wl-copy", "--type", "text/uri-list"], input=uri.encode(), timeout=5)
            return True
        except (OSError, subprocess.SubprocessError):
            pass
    if have("xclip"):
        try:
            subprocess.run(["xclip", "-selection", "clipboard", "-t", "text/uri-list"], input=uri.encode(), timeout=5)
            return True
        except (OSError, subprocess.SubprocessError):
            pass
    return False


DISCORD_BINS = ("discord", "Discord", "vesktop")


def open_discord():
    for b in DISCORD_BINS:
        if have(b):
            return spawn([b])
    for app in ("com.discordapp.Discord", "dev.vencord.Vesktop"):
        if any(Path(d, app).is_dir() for d in ("/var/lib/flatpak/app", HOME / ".local/share/flatpak/app")):
            return spawn(["flatpak", "run", app])
    return open_url("https://discord.com/app")


UPLOAD_PAGES = {
    "youtube": "https://www.youtube.com/upload",               # redirects to YouTube Studio's upload dialog
    "tiktok": "https://www.tiktok.com/tiktokstudio/upload",
}

WEBHOOK_RE = re.compile(r"^https://(?:(?:ptb|canary)\.)?discord(?:app)?\.com/api/(?:v\d+/)?webhooks/\d+/[\w-]+/?$")


def valid_webhook(url):
    return bool(WEBHOOK_RE.match((url or "").strip()))


def webhook_upload(url, path, message=""):
    """Post a file to a Discord channel webhook (multipart/form-data). Returns (ok, text). Blocking - use a thread."""
    url = url.strip().rstrip("/")
    if not valid_webhook(url):
        return False, "That is not a Discord webhook link (https://discord.com/api/webhooks/…)."
    p = Path(path)
    try:
        data = p.read_bytes()
    except OSError as e:
        return False, f"Cannot read the file: {e}"
    boundary = uuid.uuid4().hex
    payload = json.dumps({"content": message[:1900], "attachments": [{"id": 0, "filename": p.name}]})
    body = (f"--{boundary}\r\nContent-Disposition: form-data; name=\"payload_json\"\r\n"
            f"Content-Type: application/json\r\n\r\n{payload}\r\n"
            f"--{boundary}\r\nContent-Disposition: form-data; name=\"files[0]\"; filename=\"{p.name}\"\r\n"
            f"Content-Type: application/octet-stream\r\n\r\n").encode() + data + f"\r\n--{boundary}--\r\n".encode()
    req = urllib.request.Request(url + "?wait=true", data=body, method="POST", headers={
        "Content-Type": f"multipart/form-data; boundary={boundary}", "User-Agent": "PhoenixGe-Clips/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            return 200 <= r.status < 300, "Posted to Discord."
    except urllib.error.HTTPError as e:
        if e.code == 413:
            return False, "Too big for this Discord server (usually 10 MB). Export with the 'Discord - 10 MB' preset first."
        if e.code in (401, 403, 404):
            return False, "Discord refused the webhook (deleted or wrong link?). Paste it again in Share settings."
        return False, f"Discord answered {e.code}: {e.read()[:200].decode(errors='replace')}"
    except (urllib.error.URLError, OSError) as e:
        return False, f"No connection to Discord: {getattr(e, 'reason', e)}"


# ------------------------------------------------------------------ demo data
DEMO_GAMES = [  # name, lavfi source, accent text color
    ("Cyberpunk 2077", "gradients=s=640x360:c0=0xff2a6d:c1=0x05d9e8:c2=0x1a0b2e:n=3:speed=0.02:r=30", "white"),
    ("Counter-Strike 2", "gradients=s=640x360:c0=0xe8a33d:c1=0x2b3a42:c2=0x111820:n=3:speed=0.015:r=30", "white"),
    ("Elden Ring", "gradients=s=640x360:c0=0xd4af37:c1=0x3b2f1e:c2=0x0b0a08:n=3:speed=0.01:r=30", "white"),
    ("Minecraft", "life=s=160x90:mold=10:r=30:ratio=0.2:death_color=#2d6a2d:life_color=#9bd65a,scale=640:360:flags=neighbor", "white"),
    ("Hollow Knight", "mandelbrot=s=640x360:r=30:outer=normalized_iteration_count", "white"),
]


def make_demo(root):
    """Small fake library (real files made with ffmpeg) so the app can be shown and tested without games."""
    root = Path(root)
    vids, pics, data = root / "Videos", root / "Pictures", root / "data"
    set_roots(vids, pics, data)
    for d in (REPLAYS, SHOTS, EXPORTS):
        d.mkdir(parents=True, exist_ok=True)
    if not have("ffmpeg"):
        return False
    font = next((f for f in ("/usr/share/fonts/opentype/inter/Inter-Bold.otf",
                             "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf") if os.path.exists(f)), None)
    now = time.time()
    plan = [  # game index, kind, hours ago, seconds
        (0, "replay", 0.6, 30), (0, "shot", 0.7, 0), (1, "replay", 1.5, 60), (1, "replay", 1.8, 30), (1, "shot", 2.0, 0),
        (2, "replay", 26, 30), (2, "shot", 27, 0), (3, "replay", 50, 30), (3, "shot", 51, 0), (4, "replay", 75, 20),
        (0, "export", 0.5, 12), (1, "shot", 76, 0)]
    idx = {}
    for n, (gi, kind, ago, secs) in enumerate(plan):
        name, src, color = DEMO_GAMES[gi]
        t = now - ago * 3600
        stamp = datetime.fromtimestamp(t).strftime("%Y-%m-%d_%H-%M-%S")
        text = (f",drawtext=fontfile={font}:text='{name.upper()}':x=28:y=h-62:fontsize=34:fontcolor={color}@0.92"
                f":shadowcolor=black@0.6:shadowx=2:shadowy=2") if font else ""
        hud = (f",drawtext=fontfile={font}:text='%{{eif\\:138+mod(n\\,7)\\:d}} FPS':x=w-120:y=16:fontsize=20"
               f":fontcolor=0x9bff8a") if font else ""
        if kind == "shot":
            out = SHOTS / f"{name.replace(' ', '-')}-{stamp}.png"
            run(["ffmpeg", "-v", "error", "-y", "-f", "lavfi", "-i", src.replace(":r=30", ":r=30") + text,
                 "-ss", f"{n % 3}", "-frames:v", "1", str(out)], 60)
        else:
            folder = EXPORTS if kind == "export" else REPLAYS
            out = folder / (f"Replay_{stamp}.mp4" if kind == "replay" else f"Replay_{stamp}-clip.mp4")
            run(["ffmpeg", "-v", "error", "-y", "-f", "lavfi", "-i", f"{src}{text}{hud}",
                 "-f", "lavfi", "-i", f"sine=frequency={220 + 60 * gi}:sample_rate=48000",
                 "-t", "6", "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p", "-c:a", "aac",
                 "-shortest", str(out)], 120)
            if kind == "export":
                idx[str(out)] = {"game": name}
        if out.exists():
            os.utime(out, (t, t))
    # sessions so replays (named Replay_<date>.mp4) are matched to games like on a real system
    for gi, (name, _, _) in enumerate(DEMO_GAMES):
        d = PERF_ROOT / name.replace(" ", "_")
        d.mkdir(parents=True, exist_ok=True)
        (d / "sessions.jsonl").write_text("".join(
            json.dumps({"start": int(now - a * 3600 - 900), "end": int(now - a * 3600 + 30), "name": name}) + "\n"
            for g, k, a, s in plan if g == gi))
    INDEX.parent.mkdir(parents=True, exist_ok=True)
    INDEX.write_text(json.dumps(idx))
    return True
