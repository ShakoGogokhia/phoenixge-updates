#!/usr/bin/env python3
"""PhoenixGe Clips - gallery, player, trimmer and share sheet for Instant Replays, recordings and screenshots.

    phoenixge-clips              open the gallery
    phoenixge-clips FILE         open FILE in the editor
    phoenixge-clips --copy FILE  put FILE on the clipboard as a file (for scripts / the overlay) and exit
    phoenixge-clips --demo       sample library (made with ffmpeg in a temp folder) - screenshots, testing

Nothing is uploaded anywhere unless you press a button for it. "Send to Discord" uses a channel webhook that you paste
once (opt-in); everything else opens the site in your browser or puts the file on the clipboard.
"""
import os
import sys
import tempfile
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from PySide6.QtCore import QMimeData, QObject, QPoint, QProcess, QRect, QSize, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import (QAction, QColor, QDrag, QFont, QIcon, QImage, QImageReader, QKeySequence, QPainter,
                           QPainterPath, QPalette, QPen, QPixmap, QShortcut)
from PySide6.QtWidgets import (QApplication, QButtonGroup, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFileDialog,
                               QFrame, QGridLayout, QHBoxLayout, QInputDialog, QLabel, QLayout, QLineEdit, QListWidget,
                               QListWidgetItem, QMenu, QMessageBox, QProgressBar, QPushButton, QRadioButton, QScrollArea,
                               QSizePolicy, QSlider, QSpinBox, QStackedWidget, QToolButton, QVBoxLayout, QWidget,
                               QWidgetItem)

sys.path.insert(0, str(Path(__file__).resolve().parent))
import media  # noqa: E402

try:  # python3-pyside6.qtmultimedia(+widgets) - optional: without it the preview opens in mpv / VLC
    from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
    from PySide6.QtMultimediaWidgets import QVideoWidget
    HAVE_PLAYER = True
except ImportError:
    HAVE_PLAYER = False

LOGO = "/usr/share/pixmaps/phoenixge.png"
DEMO = "--demo" in sys.argv


def accent():
    try:
        import subprocess
        v = subprocess.run(["kreadconfig6", "--file", "kdeglobals", "--group", "General", "--key", "AccentColor"],
                           capture_output=True, text=True, timeout=3).stdout.strip()
        r, g, b = (int(x) for x in v.split(",")[:3])
        return QColor(r, g, b).name()
    except Exception:  # noqa: BLE001
        return "#ff7a2e"


ACC = "#ff7a2e"
BADGE_CSS = "background: rgba(0,0,0,0.65); color: white; border-radius: 6px; padding: 2px 7px; font-weight: 700;"
SOURCE_LABEL = {"replay": "Instant Replay", "recording": "Recording", "export": "Edited clip", "screenshot": "Screenshot"}


# ------------------------------------------------------------------ small widgets
class FlowLayout(QLayout):
    """Wraps tiles to the available width (Qt's classic flow layout example)."""

    def __init__(self, parent=None, spacing=14):
        super().__init__(parent)
        self.items, self.sp = [], spacing
        self.setContentsMargins(0, 0, 0, 0)

    def addItem(self, item):
        self.items.append(item)

    def count(self):
        return len(self.items)

    def itemAt(self, i):
        return self.items[i] if 0 <= i < len(self.items) else None

    def takeAt(self, i):
        return self.items.pop(i) if 0 <= i < len(self.items) else None

    def expandingDirections(self):
        return Qt.Orientation(0)

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, w):
        return self._do(QRect(0, 0, w, 0), True)

    def setGeometry(self, rect):
        super().setGeometry(rect)
        self._do(rect, False)

    def sizeHint(self):
        return self.minimumSize()

    def minimumSize(self):
        s = QSize()
        for it in self.items:
            s = s.expandedTo(it.minimumSize())
        return s

    def _do(self, rect, test):
        x, y, line = rect.x(), rect.y(), 0
        for it in self.items:
            hint = it.sizeHint()
            if x + hint.width() > rect.right() + 1 and line > 0:
                x, y, line = rect.x(), y + line + self.sp, 0
            if not test:
                it.setGeometry(QRect(QPoint(x, y), hint))
            x += hint.width() + self.sp
            line = max(line, hint.height())
        return y + line - rect.y()


def rounded(pix, w, h, radius=12):
    """Cover-crop pix to w x h with rounded corners."""
    out = QPixmap(w, h)
    out.fill(Qt.transparent)
    if pix is None or pix.isNull():
        return out
    scaled = pix.scaled(w, h, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
    p = QPainter(out)
    p.setRenderHint(QPainter.Antialiasing)
    path = QPainterPath()
    path.addRoundedRect(0, 0, w, h, radius, radius)
    p.setClipPath(path)
    p.drawPixmap(-(scaled.width() - w) // 2, -(scaled.height() - h) // 2, scaled)
    p.end()
    return out


def placeholder(w, h, text, radius=12):
    out = QPixmap(w, h)
    out.fill(Qt.transparent)
    p = QPainter(out)
    p.setRenderHint(QPainter.Antialiasing)
    path = QPainterPath()
    path.addRoundedRect(0, 0, w, h, radius, radius)
    p.fillPath(path, QColor(255, 255, 255, 14))
    p.setPen(QColor(255, 255, 255, 90))
    p.drawText(QRect(0, 0, w, h), Qt.AlignCenter, text)
    p.end()
    return out


class Loader(QObject):
    """Thumbnails + durations in worker threads, results back on the GUI thread."""
    ready = Signal(str, str, float)        # path, thumbnail file ("" = none), duration

    def __init__(self):
        super().__init__()
        self.pool = ThreadPoolExecutor(max_workers=3)

    def request(self, item):
        self.pool.submit(self._work, item["path"], item["kind"])

    def _work(self, path, kind):
        try:
            if kind == "image":
                self.ready.emit(path, path, 0.0)
                return
            dur = media.probe(path).get("duration") or 0.0
            self.ready.emit(path, media.thumbnail(path) or "", dur)
        except Exception:  # noqa: BLE001 - one broken file must not stop the gallery
            self.ready.emit(path, "", 0.0)


class Tile(QFrame):
    TW, TH = 256, 144
    clicked = Signal(dict)
    menu = Signal(dict, QPoint)

    def __init__(self, item):
        super().__init__()
        self.item, self.duration, self.press = item, 0.0, None
        self.setObjectName("tile")
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedWidth(self.TW + 12)
        lay = QVBoxLayout(self); lay.setContentsMargins(6, 6, 6, 8); lay.setSpacing(6)
        self.thumb = QLabel(); self.thumb.setFixedSize(self.TW, self.TH)
        self.thumb.setPixmap(placeholder(self.TW, self.TH, "…"))
        lay.addWidget(self.thumb)
        self.badge = QLabel(self.thumb); self.badge.setStyleSheet(BADGE_CSS + "font-size: 11px;"); self.badge.hide()
        self.kind = QLabel("▶  REPLAY" if item["source"] == "replay" else
                           {"recording": "●  REC", "export": "✂  EDIT", "screenshot": "▣  SHOT"}[item["source"]], self.thumb)
        self.kind.setStyleSheet(BADGE_CSS + "font-size: 10px;"); self.kind.adjustSize(); self.kind.move(8, 8)
        t = QLabel(item["game"]); t.setObjectName("tileTitle")
        when = time.strftime("%H:%M", time.localtime(item["mtime"]))
        s = QLabel(f"{when}  ·  {media.fmt_size(item['size'])}"); s.setObjectName("dim")
        lay.addWidget(t); lay.addWidget(s)
        self.setToolTip(item["name"])

    def set_thumb(self, file, duration):
        pix = QPixmap()
        if file:
            r = QImageReader(file)
            r.setAutoTransform(True)
            sz = r.size()
            if sz.isValid() and sz.width() > self.TW * 2:
                r.setScaledSize(sz.scaled(self.TW * 2, self.TH * 2, Qt.KeepAspectRatioByExpanding))
            pix = QPixmap.fromImage(r.read())
        self.thumb.setPixmap(rounded(pix, self.TW, self.TH) if not pix.isNull()
                             else placeholder(self.TW, self.TH, "no preview"))
        if duration:
            self.duration = duration
            self.badge.setText(media.fmt_time(duration)); self.badge.ensurePolished(); self.badge.adjustSize()
            self.badge.move(self.TW - self.badge.width() - 8, self.TH - self.badge.height() - 8); self.badge.show()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.press = e.position().toPoint()
        elif e.button() == Qt.RightButton:
            self.menu.emit(self.item, e.globalPosition().toPoint())

    def mouseMoveEvent(self, e):
        # drag the file straight into Discord, a browser upload page, Dolphin...
        if self.press is not None and (e.position().toPoint() - self.press).manhattanLength() > 12:
            self.press = None
            drag = QDrag(self)
            md = QMimeData(); md.setUrls([QUrl.fromLocalFile(self.item["path"])])
            drag.setMimeData(md)
            drag.setPixmap(self.thumb.pixmap().scaled(160, 90, Qt.KeepAspectRatio, Qt.SmoothTransformation))
            drag.exec(Qt.CopyAction)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self.press is not None:
            self.clicked.emit(self.item)
        self.press = None


class TrimBar(QWidget):
    """Filmstrip timeline with start / end handles and a playhead."""
    changed = Signal(float, float)       # start, end (seconds)
    seek = Signal(float)

    def __init__(self):
        super().__init__()
        self.duration, self.start, self.end, self.pos = 0.0, 0.0, 0.0, 0.0
        self.strip, self.drag = None, None
        self.setMinimumHeight(86)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.StrongFocus)

    def set_clip(self, duration, strip=None):
        self.duration = max(0.0, duration)
        self.start, self.end, self.pos = 0.0, self.duration, 0.0
        self.strip = QPixmap(strip) if strip else None
        self.update(); self.changed.emit(self.start, self.end)

    def set_strip(self, strip):
        self.strip = QPixmap(strip) if strip else None
        self.update()

    def set_pos(self, sec):
        self.pos = sec; self.update()

    def set_range(self, start, end):
        self.start, self.end = max(0.0, min(start, end)), min(self.duration, max(start, end))
        self.update(); self.changed.emit(self.start, self.end)

    # geometry
    def _track(self):
        return QRect(14, 18, self.width() - 28, self.height() - 34)

    def _x(self, sec):
        t = self._track()
        return t.left() + (t.width() * sec / self.duration if self.duration else 0)

    def _sec(self, x):
        t = self._track()
        return min(self.duration, max(0.0, (x - t.left()) / max(1, t.width()) * self.duration))

    def paintEvent(self, _e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        t = self._track()
        path = QPainterPath(); path.addRoundedRect(t, 8, 8)
        p.setClipPath(path)
        if self.strip and not self.strip.isNull():
            p.drawPixmap(t, self.strip)
        else:
            p.fillRect(t, QColor(255, 255, 255, 18))
        if self.duration:
            xs, xe = self._x(self.start), self._x(self.end)
            shade = QColor(8, 6, 10, 175)
            p.fillRect(QRect(t.left(), t.top(), int(xs - t.left()), t.height()), shade)
            p.fillRect(QRect(int(xe), t.top(), int(t.right() - xe + 1), t.height()), shade)
        p.setClipping(False)
        if not self.duration:
            return
        acc = QColor(ACC)
        xs, xe = self._x(self.start), self._x(self.end)
        p.setPen(QPen(acc, 3)); p.setBrush(Qt.NoBrush)
        p.drawRoundedRect(int(xs), t.top() - 1, int(xe - xs), t.height() + 2, 6, 6)
        for x in (xs, xe):  # handles
            p.setPen(Qt.NoPen); p.setBrush(acc)
            p.drawRoundedRect(int(x) - 6, t.top() - 4, 12, t.height() + 8, 5, 5)
            p.setBrush(QColor(26, 11, 6)); p.drawRoundedRect(int(x) - 1, t.top() + t.height() // 2 - 9, 2, 18, 1, 1)
        x = self._x(self.pos)  # playhead
        p.setPen(QPen(QColor("white"), 2)); p.drawLine(int(x), t.top() - 8, int(x), t.bottom() + 6)
        p.setBrush(QColor("white")); p.setPen(Qt.NoPen); p.drawEllipse(QPoint(int(x), t.top() - 9), 5, 5)
        p.setPen(QColor(255, 255, 255, 150)); f = p.font(); f.setPointSizeF(8.5); p.setFont(f)
        p.drawText(QRect(t.left(), t.bottom() + 3, 120, 14), Qt.AlignLeft, media.fmt_time(self.start, True))
        p.drawText(QRect(t.right() - 120, t.bottom() + 3, 120, 14), Qt.AlignRight, media.fmt_time(self.end, True))

    def mousePressEvent(self, e):
        if not self.duration:
            return
        x = e.position().x()
        ds, de = abs(x - self._x(self.start)), abs(x - self._x(self.end))
        if min(ds, de) < 14:
            self.drag = "start" if ds <= de else "end"
        else:
            self.drag = "pos"
            self.pos = self._sec(x); self.seek.emit(self.pos)
        self.update()

    def mouseMoveEvent(self, e):
        x = e.position().x()
        if self.drag is None:
            near = self.duration and min(abs(x - self._x(self.start)), abs(x - self._x(self.end))) < 14
            self.setCursor(Qt.SizeHorCursor if near else Qt.PointingHandCursor)
            return
        s = self._sec(x)
        if self.drag == "start":
            self.start = min(s, self.end - 0.2); self.pos = self.start; self.seek.emit(self.start)
        elif self.drag == "end":
            self.end = max(s, self.start + 0.2); self.pos = self.end; self.seek.emit(self.end)
        else:
            self.pos = s; self.seek.emit(s)
        if self.drag in ("start", "end"):
            self.changed.emit(self.start, self.end)
        self.update()

    def mouseReleaseEvent(self, _e):
        self.drag = None


# ------------------------------------------------------------------ editor
class Editor(QWidget):
    back = Signal()
    library_changed = Signal(str)       # path to select after a rescan ("" = none)

    def __init__(self, win):
        super().__init__()
        self.win, self.item, self.info, self.share_path = win, None, {}, None
        self.proc, self.export_job, self.cancelled, self.stop_at = None, None, False, None
        root = QHBoxLayout(self); root.setContentsMargins(24, 18, 24, 18); root.setSpacing(20)

        # ---- left: preview + timeline
        left = QVBoxLayout(); left.setSpacing(12)
        top = QHBoxLayout()
        b = QPushButton("←  Library"); b.setObjectName("ghost"); b.clicked.connect(self.close_clip); top.addWidget(b)
        self.title = QLabel(); self.title.setObjectName("h2"); top.addWidget(self.title, 1)
        self.chip = QLabel(); self.chip.setObjectName("chip"); top.addWidget(self.chip)
        left.addLayout(top)
        self.meta = QLabel(); self.meta.setObjectName("dim"); left.addWidget(self.meta)

        self.view = QStackedWidget(); self.view.setObjectName("viewer"); self.view.setMinimumSize(480, 270)
        self.view.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.poster = QLabel(); self.poster.setAlignment(Qt.AlignCenter); self.poster.setObjectName("poster")
        self.poster.setMinimumSize(10, 10); self.poster.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Ignored)
        self.view.addWidget(self.poster)
        self.player = None
        if HAVE_PLAYER and not DEMO:
            self.video = QVideoWidget(); self.view.addWidget(self.video)
            self.player = QMediaPlayer(self); self.audio = QAudioOutput(self); self.audio.setVolume(0.8)
            self.player.setAudioOutput(self.audio); self.player.setVideoOutput(self.video)
            self.player.positionChanged.connect(self.on_pos)
            self.player.playbackStateChanged.connect(lambda _s: self.play_btn.setText(
                "❚❚" if self.player.playbackState() == QMediaPlayer.PlayingState else "▶"))
        left.addWidget(self.view, 1)

        tr = QHBoxLayout(); tr.setSpacing(8)
        self.play_btn = QPushButton("▶"); self.play_btn.setObjectName("round"); self.play_btn.setFixedSize(44, 44)
        self.play_btn.clicked.connect(self.toggle_play); tr.addWidget(self.play_btn)
        self.timelabel = QLabel("0:00 / 0:00"); self.timelabel.setObjectName("mono"); tr.addWidget(self.timelabel)
        tr.addStretch()
        self.b_in = QPushButton("[  Start here"); self.b_in.setToolTip("Set the clip start at the playhead (I)")
        self.b_out = QPushButton("End here  ]"); self.b_out.setToolTip("Set the clip end at the playhead (O)")
        self.b_sel = QPushButton("▶  Play selection")
        self.b_reset = QPushButton("Reset"); self.b_reset.setObjectName("ghost")
        self.b_in.clicked.connect(lambda: self.bar.set_range(self.bar.pos, self.bar.end))
        self.b_out.clicked.connect(lambda: self.bar.set_range(self.bar.start, self.bar.pos))
        self.b_sel.clicked.connect(self.play_selection)
        self.b_reset.clicked.connect(lambda: self.bar.set_range(0, self.bar.duration))
        for w in (self.b_in, self.b_out, self.b_sel, self.b_reset):
            tr.addWidget(w)
        self.trimrow = QWidget(); self.trimrow.setLayout(tr)
        left.addWidget(self.trimrow)
        self.bar = TrimBar(); self.bar.changed.connect(self.on_range); self.bar.seek.connect(self.seek)
        left.addWidget(self.bar)
        self.sel = QLabel(); self.sel.setObjectName("dim"); left.addWidget(self.sel)
        root.addLayout(left, 1)

        # ---- right: export + share
        side = QScrollArea(); side.setWidgetResizable(True); side.setFrameShape(QFrame.NoFrame); side.setFixedWidth(360)
        panel = QWidget(); side.setWidget(panel)
        pl = QVBoxLayout(panel); pl.setContentsMargins(0, 0, 6, 0); pl.setSpacing(14)

        self.exp = QFrame(); self.exp.setObjectName("panel"); el = QVBoxLayout(self.exp); el.setSpacing(9)
        el.setContentsMargins(16, 14, 16, 16)
        h = QLabel("Export"); h.setObjectName("panelTitle"); el.addWidget(h)
        self.size = QComboBox()
        for label, mb in media.SIZE_PRESETS:
            self.size.addItem(label, mb)
        self.custom_mb = QSpinBox(); self.custom_mb.setRange(1, 4000); self.custom_mb.setValue(25); self.custom_mb.setSuffix(" MB")
        self.custom_mb.hide()
        row = QHBoxLayout(); row.addWidget(QLabel("Size")); row.addWidget(self.size, 1); row.addWidget(self.custom_mb); el.addLayout(row)
        self.vertical = QCheckBox("Vertical 9:16 - TikTok, Shorts, Reels")
        el.addWidget(self.vertical)
        self.cropbox = QWidget(); cl = QHBoxLayout(self.cropbox); cl.setContentsMargins(22, 0, 0, 0)
        cl.addWidget(QLabel("Crop")); self.crop = QSlider(Qt.Horizontal); self.crop.setRange(0, 100); self.crop.setValue(50)
        cl.addWidget(QLabel("left")); cl.addWidget(self.crop, 1); cl.addWidget(QLabel("right"))
        self.cropbox.hide(); el.addWidget(self.cropbox)
        self.quality = QComboBox()
        self.quality.addItem("Fast - keep original quality (instant)", "copy")
        self.quality.addItem("Precise - re-encode, frame-exact cut", "encode")
        row = QHBoxLayout(); row.addWidget(QLabel("Cut")); row.addWidget(self.quality, 1); el.addLayout(row)
        self.encoder = QComboBox(); self.encoder.addItem("Automatic (detecting…)", "auto")
        row = QHBoxLayout(); row.addWidget(QLabel("Encoder")); row.addWidget(self.encoder, 1); el.addLayout(row)
        self.plan = QLabel(); self.plan.setObjectName("dim"); self.plan.setWordWrap(True); el.addWidget(self.plan)
        self.export_btn = QPushButton("Export clip"); self.export_btn.setObjectName("primary")
        self.export_btn.clicked.connect(self.export)
        self.cancel_btn = QPushButton("Cancel"); self.cancel_btn.hide(); self.cancel_btn.clicked.connect(self.cancel_export)
        row = QHBoxLayout(); row.addWidget(self.export_btn, 1); row.addWidget(self.cancel_btn); el.addLayout(row)
        self.progress = QProgressBar(); self.progress.setRange(0, 1000); self.progress.setTextVisible(False)
        self.progress.setFixedHeight(6); self.progress.hide(); el.addWidget(self.progress)
        self.status = QLabel(); self.status.setObjectName("dim"); self.status.setWordWrap(True); el.addWidget(self.status)
        for sig in (self.size.currentIndexChanged, self.vertical.toggled, self.quality.currentIndexChanged,
                    self.custom_mb.valueChanged, self.encoder.currentIndexChanged):
            sig.connect(self.update_plan)
        self.quality.activated.connect(lambda _i: setattr(self, "user_quality", self.quality.currentData()))
        self.vertical.toggled.connect(self.cropbox.setVisible)
        self.size.currentIndexChanged.connect(lambda: self.custom_mb.setVisible(self.size.currentData() == -1))
        self.crop.valueChanged.connect(self.update_crop_preview)
        self.vertical.toggled.connect(self.update_crop_preview)
        pl.addWidget(self.exp)

        sh = QFrame(); sh.setObjectName("panel"); sl = QVBoxLayout(sh); sl.setSpacing(8); sl.setContentsMargins(16, 14, 16, 16)
        h = QLabel("Share"); h.setObjectName("panelTitle"); sl.addWidget(h)
        self.share_lbl = QLabel(); self.share_lbl.setObjectName("dim"); self.share_lbl.setWordWrap(True); sl.addWidget(self.share_lbl)
        g = QGridLayout(); g.setSpacing(8)
        acts = [("Copy file", "edit-copy", self.copy_file, "Paste it into Discord, a browser or Dolphin (Ctrl+V)"),
                ("Show in folder", "folder-open", lambda: media.show_in_folder(self.share_path), ""),
                ("Open Discord", "discord", media.open_discord, "Then paste (Ctrl+V) or drag the clip in"),
                ("Send to Discord", "mail-send", self.send_webhook, "Post to a channel through a webhook you set up once"),
                ("YouTube upload", "youtube", lambda: media.open_url(media.UPLOAD_PAGES["youtube"]),
                 "Opens YouTube Studio's upload page - choose the file there (Show in folder helps)"),
                ("TikTok upload", "tiktok", lambda: media.open_url(media.UPLOAD_PAGES["tiktok"]),
                 "Opens TikTok's upload page - export Vertical 9:16 first")]
        for i, (label, icon, fn, tip) in enumerate(acts):
            b = QPushButton(QIcon.fromTheme(icon), label); b.setObjectName("share"); b.setToolTip(tip); b.clicked.connect(fn)
            g.addWidget(b, i // 2, i % 2)
        sl.addLayout(g)
        hint = QLabel("Tip: you can also drag a clip from the library straight into Discord or a browser upload page.")
        hint.setObjectName("dim"); hint.setWordWrap(True); sl.addWidget(hint)
        pl.addWidget(sh)

        fl = QFrame(); fl.setObjectName("panel"); fll = QHBoxLayout(fl); fll.setContentsMargins(16, 12, 16, 12)
        r = QPushButton(QIcon.fromTheme("edit-rename"), "Rename"); r.clicked.connect(self.rename)
        d = QPushButton(QIcon.fromTheme("edit-delete"), "Delete"); d.setObjectName("danger"); d.clicked.connect(self.delete)
        o = QPushButton(QIcon.fromTheme("media-playback-start"), "Open in player")
        o.clicked.connect(lambda: self.item and media.open_external(self.item["path"]))
        for x in (r, o, d):
            fll.addWidget(x)
        pl.addWidget(fl)
        pl.addStretch()
        root.addWidget(side)

        for key, fn in (("Space", self.toggle_play), ("I", self.b_in.click), ("O", self.b_out.click),
                        ("Escape", self.close_clip), ("Ctrl+C", self.copy_file), ("Delete", self.delete)):
            sc = QShortcut(QKeySequence(key), self); sc.setContext(Qt.WidgetWithChildrenShortcut); sc.activated.connect(fn)
        self.fill_encoders()

    # ---------------------------------------------------------- encoders (tested in the background)
    def fill_encoders(self):
        def work():
            encs = ["nvenc", "x264"] if DEMO else media.hw_encoders()
            QTimer.singleShot(0, self, lambda: self._set_encoders(encs))
        threading.Thread(target=work, daemon=True).start()

    def _set_encoders(self, encs):
        self.encoder.blockSignals(True)
        self.encoder.clear()
        self.encoder.addItem(f"Automatic - {media.ENCODER_NAMES[encs[0]]}", encs[0])
        for e in encs:
            self.encoder.addItem(media.ENCODER_NAMES[e], e)
        if "x264" not in encs:
            self.encoder.addItem(media.ENCODER_NAMES["x264"], "x264")
        self.encoder.blockSignals(False)
        self.update_plan()

    # ---------------------------------------------------------- open / close
    def open(self, item):
        self.stop()
        self.item, self.share_path = item, item["path"]
        self.status.clear()
        is_video = item["kind"] == "video"
        self.title.setText(Path(item["path"]).name)
        self.chip.setText(f"  {item['game']}  ")
        self.info = media.probe(item["path"]) if is_video else {}
        bits = [SOURCE_LABEL[item["source"]], time.strftime("%a %-d %b %Y, %H:%M", time.localtime(item["mtime"])),
                media.fmt_size(item["size"])]
        if self.info.get("height"):
            bits.append(f"{self.info['width']}×{self.info['height']}" + (f" · {self.info['fps']:.0f} fps" if self.info.get("fps") else ""))
        self.meta.setText("   ·   ".join(bits))
        for w in (self.trimrow, self.bar, self.sel, self.exp):
            w.setVisible(is_video)
        self.load_poster(item)
        if is_video:
            dur = self.info.get("duration") or 0.0
            self.bar.set_clip(dur, None)
            threading.Thread(target=lambda: self._strip(item["path"], dur), daemon=True).start()
            if self.player:
                self.player.setSource(QUrl.fromLocalFile(item["path"]))
                self.view.setCurrentWidget(self.video)
                self.player.play(); QTimer.singleShot(150, self.player.pause)   # shows the first frame
        self.update_share_label()
        self.update_plan()

    def _strip(self, path, dur):
        s = media.filmstrip(path, dur)
        QTimer.singleShot(0, self, lambda: self.item and self.item["path"] == path and self.bar.set_strip(s))

    def load_poster(self, item):
        src = item["path"] if item["kind"] == "image" else media.thumbnail(item["path"], 1280)
        self._poster = QPixmap(src) if src else QPixmap()
        self.view.setCurrentWidget(self.poster)
        self.fit_poster()

    def fit_poster(self):
        if getattr(self, "_poster", None) is None:
            return
        w, h = max(10, self.view.width()), max(10, self.view.height())
        if self._poster.isNull():
            self.poster.setPixmap(placeholder(w, h, "Preview not available" if self.item else ""))
            return
        pm = self._poster.scaled(w, h, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        if self.vertical.isChecked() and self.item and self.item["kind"] == "video":
            pm = self.crop_overlay(pm)
        if not self.player and self.item and self.item["kind"] == "video":
            pm = self.play_overlay(pm)
        self.poster.setPixmap(rounded(pm, pm.width(), pm.height(), 14))

    def crop_overlay(self, pm):
        out = QPixmap(pm); p = QPainter(out); p.setRenderHint(QPainter.Antialiasing)
        cw = pm.height() * 9 / 16; x = (pm.width() - cw) * self.crop.value() / 100
        shade = QColor(0, 0, 0, 160)
        p.fillRect(QRect(0, 0, int(x), pm.height()), shade)
        p.fillRect(QRect(int(x + cw), 0, pm.width() - int(x + cw), pm.height()), shade)
        p.setPen(QPen(QColor(ACC), 3)); p.drawRect(QRect(int(x), 1, int(cw), pm.height() - 3))
        p.end(); return out

    def play_overlay(self, pm):
        out = QPixmap(pm); p = QPainter(out); p.setRenderHint(QPainter.Antialiasing)
        c = QPoint(out.width() // 2, out.height() // 2)
        p.setPen(Qt.NoPen); p.setBrush(QColor(0, 0, 0, 120)); p.drawEllipse(c, 38, 38)
        p.setBrush(QColor(255, 255, 255, 235))
        path = QPainterPath(); path.moveTo(c.x() - 11, c.y() - 17); path.lineTo(c.x() + 19, c.y()); path.lineTo(c.x() - 11, c.y() + 17)
        p.drawPath(path); p.end(); return out

    def update_crop_preview(self):
        if self.player and self.vertical.isChecked():
            self.player.pause(); self.view.setCurrentWidget(self.poster)
        self.fit_poster()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        QTimer.singleShot(0, self.fit_poster)

    def close_clip(self):
        self.stop()
        self.back.emit()

    def stop(self):
        if self.player:
            self.player.stop(); self.player.setSource(QUrl())

    # ---------------------------------------------------------- playback
    def toggle_play(self):
        if not self.item or self.item["kind"] != "video":
            return
        if not self.player:
            media.open_external(self.item["path"]); return
        self.view.setCurrentWidget(self.video)
        if self.player.playbackState() == QMediaPlayer.PlayingState:
            self.player.pause()
        else:
            self.stop_at = None
            self.player.play()

    def play_selection(self):
        if not self.player:
            media.open_external(self.item["path"]); return
        self.view.setCurrentWidget(self.video)
        self.stop_at = self.bar.end
        self.player.setPosition(int(self.bar.start * 1000)); self.player.play()

    def on_pos(self, ms):
        s = ms / 1000
        self.bar.set_pos(s)
        self.timelabel.setText(f"{media.fmt_time(s, True)} / {media.fmt_time(self.bar.duration)}")
        if getattr(self, "stop_at", None) and s >= self.stop_at:
            self.player.pause(); self.stop_at = None

    def seek(self, sec):
        self.timelabel.setText(f"{media.fmt_time(sec, True)} / {media.fmt_time(self.bar.duration)}")
        if self.player:
            self.view.setCurrentWidget(self.video)
            self.player.setPosition(int(sec * 1000))

    def on_range(self, start, end):
        full = abs(start) < 0.05 and abs(end - self.bar.duration) < 0.05
        self.sel.setText(("Whole clip" if full else f"Selection {media.fmt_time(start, True)} – {media.fmt_time(end, True)}")
                         + f"  ·  {media.fmt_time(end - start, True)} long")
        self.timelabel.setText(f"{media.fmt_time(self.bar.pos, True)} / {media.fmt_time(self.bar.duration)}")
        self.update_plan()

    # ---------------------------------------------------------- export
    def target_mb(self):
        mb = self.size.currentData()
        return self.custom_mb.value() if mb == -1 else mb

    def options(self):
        enc = self.encoder.currentData() or "x264"
        return dict(reencode=self.quality.currentData() == "encode", vertical=self.vertical.isChecked(),
                    target_mb=self.target_mb(), encoder="x264" if enc == "auto" else enc)

    def update_plan(self, *_):
        if not self.item or self.item["kind"] != "video":
            return
        o = self.options()
        p = media.plan_export(self.info, self.bar.start, self.bar.end, reencode=o["reencode"], vertical=o["vertical"],
                              target_mb=o["target_mb"])
        # size limits / vertical always re-encode: show "Precise" while they are on, the user's choice otherwise
        forced = bool(o["vertical"] or o["target_mb"])
        if self.quality.currentData() == "encode" and not forced and getattr(self, "user_quality", "copy") == "copy" \
                or forced and self.quality.currentData() != "encode":
            self.quality.blockSignals(True)
            self.quality.setCurrentIndex(1 if forced else 0)
            self.quality.blockSignals(False)
        self.quality.setEnabled(not forced)
        self.encoder.setEnabled(p["reencode"])
        self.plan.setText((f"⚠ {p['error']}\n" if p["error"] else "") + p["summary"] +
                          ("\nSize limits and vertical crops always re-encode." if forced else ""))
        self.plan.setStyleSheet("color:#ff8a7a;" if p["error"] else "")
        self.export_btn.setEnabled(not p["error"] and self.proc is None)

    def export(self):
        if not self.item or self.proc:
            return
        o = self.options()
        dst = media.out_path(self.item["path"], reencode=o["reencode"], vertical=o["vertical"], target_mb=o["target_mb"])
        self.export_job = dict(o, src=self.item["path"], dst=dst, start=self.bar.start, end=self.bar.end, squeeze=1.0,
                               tries=0, game=self.item["game"])
        self.run_export()

    def run_export(self):
        j = self.export_job
        cmd = media.export_cmd(j["src"], j["dst"], j["start"], j["end"], self.info, reencode=j["reencode"],
                               vertical=j["vertical"], crop_pos=self.crop.value() / 100, target_mb=j["target_mb"],
                               encoder=j["encoder"], squeeze=j["squeeze"])
        self.proc = QProcess(self)
        self.proc.readyReadStandardOutput.connect(self.on_progress)
        self.proc.finished.connect(self.on_export_done)
        self.proc.errorOccurred.connect(lambda err: err == QProcess.FailedToStart and self.on_export_done(-1, None))
        self.cancelled = False
        self.progress.setValue(0); self.progress.show(); self.cancel_btn.show(); self.export_btn.setEnabled(False)
        self.status.setText("Exporting…" if j["tries"] == 0 else "A bit too big - squeezing it once more…")
        self.proc.start(cmd[0], cmd[1:])

    def on_progress(self):
        data = bytes(self.proc.readAllStandardOutput()).decode(errors="replace")
        span = max(0.1, self.export_job["end"] - self.export_job["start"])
        for line in data.splitlines():
            if line.startswith("out_time_us=") and line[12:].strip().lstrip("-").isdigit():
                self.progress.setValue(int(min(1.0, int(line[12:]) / 1e6 / span) * 1000))

    def cancel_export(self):
        if self.proc:
            self.cancelled = True
            self.proc.kill()

    def on_export_done(self, code, _status):
        proc, self.proc = self.proc, None
        j = self.export_job
        err = bytes(proc.readAllStandardError()).decode(errors="replace").strip() if proc else ""
        self.cancel_btn.hide(); self.progress.hide()
        dst = Path(j["dst"])
        if self.cancelled or code != 0 or not dst.exists() or dst.stat().st_size == 0:
            dst.unlink(missing_ok=True)
            if not self.cancelled and j["encoder"] != "x264" and j["tries"] < 1:   # hardware encoder failed -> software
                j["encoder"], j["tries"] = "x264", j["tries"] + 1
                self.run_export(); return
            self.status.setText("Cancelled." if self.cancelled else
                                "Export failed." + (f"\n{err.splitlines()[-1]}" if err else ""))
            self.update_plan(); return
        if j["target_mb"] and dst.stat().st_size > j["target_mb"] * 1000 * 1000 and j["tries"] < 3:
            j["squeeze"] *= 0.85; j["tries"] += 1
            self.run_export(); return
        media.index_set(dst, game=j["game"], source=j["src"])
        self.share_path = str(dst)
        self.status.setText(f"✓ Saved {dst.name} ({media.fmt_size(dst.stat().st_size)}) to {dst.parent}. "
                            "Share buttons now use the new clip.")
        self.update_share_label(); self.update_plan()
        self.library_changed.emit("")

    # ---------------------------------------------------------- share
    def update_share_label(self):
        if self.share_path:
            self.share_lbl.setText(f"Sharing: <b>{Path(self.share_path).name}</b> "
                                   f"({media.fmt_size(Path(self.share_path).stat().st_size) if Path(self.share_path).exists() else ''})")

    def copy_file(self):
        if not self.share_path:
            return
        md = QMimeData(); md.setUrls([QUrl.fromLocalFile(self.share_path)])
        md.setData("x-special/gnome-copied-files", f"copy\n{QUrl.fromLocalFile(self.share_path).toString()}".encode())
        QApplication.clipboard().setMimeData(md)
        self.win.toast("Copied - paste it into Discord or a browser with Ctrl+V")

    def send_webhook(self):
        conf = media.load_conf()
        url = conf.get("webhook", "")
        if not url:
            url = WebhookDialog.ask(self)
            if not url:
                return
            conf["webhook"] = url; media.save_conf(conf)
        size = Path(self.share_path).stat().st_size
        if size > 10 * 1000 * 1000 and QMessageBox.question(
                self, "Send to Discord", f"This file is {media.fmt_size(size)}. Most Discord servers accept 10 MB through "
                "webhooks.\n\nSend anyway? (Or export with the 'Discord - 10 MB' size first.)") != QMessageBox.Yes:
            return
        game = self.item["game"] if self.item else ""
        self.status.setText("Sending to Discord…")
        path = self.share_path

        def work():
            ok, msg = media.webhook_upload(url, path, f"{game} - clipped with PhoenixGe" if game and game != "Desktop" else "")
            QTimer.singleShot(0, self, lambda: (self.status.setText(("✓ " if ok else "✗ ") + msg), self.win.toast(msg)))
        threading.Thread(target=work, daemon=True).start()

    # ---------------------------------------------------------- file
    def rename(self):
        if not self.item:
            return
        p = Path(self.item["path"])
        name, ok = QInputDialog.getText(self, "Rename", "New name:", text=p.stem)
        if not ok or not name.strip() or name.strip() == p.stem:
            return
        try:
            new = media.rename(p, name)
        except (OSError, ValueError) as e:
            QMessageBox.warning(self, "Rename", str(e)); return
        self.item = dict(self.item, path=new, name=Path(new).name)
        if self.share_path == str(p):
            self.share_path = new
        self.title.setText(Path(new).name); self.update_share_label()
        self.library_changed.emit(new)

    def delete(self):
        if not self.item:
            return
        p = self.item["path"]
        if QMessageBox.question(self, "Delete", f"Move {Path(p).name} to the Trash?") != QMessageBox.Yes:
            return
        self.stop()
        from PySide6.QtCore import QFile
        if not QFile.moveToTrash(p):
            if QMessageBox.question(self, "Delete", "The Trash is not available here. Delete permanently?") != QMessageBox.Yes:
                return
            Path(p).unlink(missing_ok=True)
        self.win.toast(f"{Path(p).name} moved to the Trash")
        self.item = None
        self.library_changed.emit("")
        self.back.emit()


class WebhookDialog(QDialog):
    @staticmethod
    def ask(parent, current=""):
        d = WebhookDialog(parent, current)
        return d.edit.text().strip() if d.exec() == QDialog.Accepted else None

    def __init__(self, parent, current):
        super().__init__(parent)
        self.setWindowTitle("Send to Discord - set up once")
        lay = QVBoxLayout(self); lay.setSpacing(10)
        t = QLabel("<b>Post clips to a Discord channel</b><br><br>"
                   "Discord ▸ your server ▸ channel settings (⚙) ▸ <b>Integrations</b> ▸ <b>Webhooks</b> ▸ "
                   "<b>New Webhook</b> ▸ <b>Copy Webhook URL</b>, then paste it here.<br><br>"
                   "Only the clips you send go there. The link is stored on this PC only "
                   "(~/.config/phoenixge/clips.json, readable only by you). Anyone with the link can post to that "
                   "channel, so keep it private. Servers usually accept up to 10 MB.")
        t.setWordWrap(True); t.setTextFormat(Qt.RichText); t.setMinimumWidth(460); lay.addWidget(t)
        self.edit = QLineEdit(current); self.edit.setPlaceholderText("https://discord.com/api/webhooks/…")
        lay.addWidget(self.edit)
        self.err = QLabel(); self.err.setStyleSheet("color:#ff8a7a;"); lay.addWidget(self.err)
        bb = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.check); bb.rejected.connect(self.reject); lay.addWidget(bb)

    def check(self):
        if media.valid_webhook(self.edit.text()):
            self.accept()
        else:
            self.err.setText("That does not look like a Discord webhook link.")


# ------------------------------------------------------------------ main window
class Clips(QWidget):
    def __init__(self, open_file=None):
        super().__init__()
        self.setWindowTitle("PhoenixGe Clips")
        self.setWindowIcon(QIcon.fromTheme("phoenixge-clips", QIcon(LOGO)))
        self.resize(1320, 820); self.setMinimumSize(900, 560)
        self.items, self.tiles, self.filter = [], {}, ("all", None)
        self.loader = Loader(); self.loader.ready.connect(self.on_thumb)
        self.thumbs = {}
        self.setStyleSheet(STYLE.replace("ACC", ACC))

        root = QHBoxLayout(self); root.setContentsMargins(0, 0, 0, 0); root.setSpacing(0)
        side = QFrame(); side.setObjectName("sidebar"); side.setFixedWidth(240)
        sl = QVBoxLayout(side); sl.setContentsMargins(14, 18, 14, 14); sl.setSpacing(6)
        brand = QHBoxLayout()
        logo = QLabel(); logo.setPixmap(QPixmap(LOGO).scaled(34, 34, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        brand.addWidget(logo)
        name = QLabel("Clips"); name.setObjectName("brand"); brand.addWidget(name); brand.addStretch()
        sl.addLayout(brand); sl.addSpacing(10)
        self.nav = QListWidget(); self.nav.setObjectName("nav"); self.nav.currentItemChanged.connect(self.on_nav)
        sl.addWidget(self.nav, 1)
        self.foot = QLabel(); self.foot.setObjectName("dim"); self.foot.setWordWrap(True); sl.addWidget(self.foot)
        b = QPushButton(QIcon.fromTheme("folder-videos"), "Open Replays folder"); b.setObjectName("ghost")
        b.clicked.connect(lambda: (media.REPLAYS.mkdir(parents=True, exist_ok=True), media.spawn(["xdg-open", str(media.REPLAYS)])))
        sl.addWidget(b)
        root.addWidget(side)

        self.stack = QStackedWidget(); root.addWidget(self.stack, 1)
        # gallery
        gal = QWidget(); gl = QVBoxLayout(gal); gl.setContentsMargins(28, 22, 28, 0); gl.setSpacing(14)
        head = QHBoxLayout()
        self.heading = QLabel("All media"); self.heading.setObjectName("h1"); head.addWidget(self.heading)
        self.count = QLabel(); self.count.setObjectName("dim"); head.addWidget(self.count, 0, Qt.AlignBottom); head.addStretch()
        self.kinds = QButtonGroup(self)
        for i, (k, label) in enumerate((("all", "All"), ("video", "Videos"), ("image", "Screenshots"))):
            kb = QPushButton(label); kb.setCheckable(True); kb.setObjectName("seg"); kb.setChecked(i == 0)
            kb.setProperty("kind", k); self.kinds.addButton(kb, i); head.addWidget(kb)
        self.kinds.buttonClicked.connect(lambda _b: self.render())
        head.addSpacing(10)
        self.search = QLineEdit(); self.search.setPlaceholderText("Search games and files…"); self.search.setFixedWidth(240)
        self.search.setClearButtonEnabled(True); self.search.textChanged.connect(lambda _t: self.render())
        head.addWidget(self.search)
        rb = QToolButton(); rb.setIcon(QIcon.fromTheme("view-refresh")); rb.setText("⟳"); rb.setToolTip("Refresh (F5)")
        rb.clicked.connect(self.rescan); head.addWidget(rb)
        gl.addLayout(head)
        self.scroll = QScrollArea(); self.scroll.setWidgetResizable(True); self.scroll.setFrameShape(QFrame.NoFrame)
        self.body = QWidget(); self.bl = QVBoxLayout(self.body); self.bl.setContentsMargins(0, 0, 8, 24); self.bl.setSpacing(10)
        self.scroll.setWidget(self.body); gl.addWidget(self.scroll, 1)
        self.stack.addWidget(gal)
        self.editor = Editor(self); self.editor.back.connect(lambda: self.stack.setCurrentIndex(0))
        self.editor.library_changed.connect(lambda _p: self.rescan())
        self.stack.addWidget(self.editor)

        self.toast_lbl = QLabel(self); self.toast_lbl.setObjectName("toast"); self.toast_lbl.hide()
        QShortcut(QKeySequence("F5"), self, self.rescan)
        QShortcut(QKeySequence("Ctrl+F"), self, lambda: (self.stack.setCurrentIndex(0), self.search.setFocus()))
        self.rescan()
        if open_file:
            p = Path(open_file).resolve()
            it = next((i for i in self.items if Path(i["path"]) == p), None)
            if it is None and p.exists():
                st = p.stat()
                it = {"path": str(p), "name": p.name, "kind": "image" if p.suffix.lower() in media.IMAGE_EXT else "video",
                      "source": media.source_of(p), "mtime": st.st_mtime, "size": st.st_size, "game": "Desktop"}
            if it:
                self.open_item(it)

    # ---------------------------------------------------------- data
    def rescan(self):
        self.items = media.scan()
        cur = self.filter
        self.nav.blockSignals(True); self.nav.clear()

        def add(text, key, count, icon=None, header=False):
            it = QListWidgetItem(text if header else f"{text}")
            if header:
                it.setFlags(Qt.NoItemFlags); it.setData(Qt.UserRole, None)
                f = it.font(); f.setPointSizeF(8.5); f.setBold(True); it.setFont(f)
            else:
                it.setData(Qt.UserRole, key)
                if icon:
                    it.setIcon(QIcon.fromTheme(icon))
                it.setData(Qt.UserRole + 1, count)
                it.setText(f"{text}")
                it.setToolTip(f"{count} item(s)")
            self.nav.addItem(it)
            if not header:
                badge = QLabel(str(count)); badge.setObjectName("navcount")
                w = QWidget(); hl = QHBoxLayout(w); hl.setContentsMargins(0, 0, 10, 0); hl.addStretch(); hl.addWidget(badge)
                self.nav.setItemWidget(it, w)
            return it

        by = lambda f: sum(1 for i in self.items if f(i))  # noqa: E731
        add("LIBRARY", None, 0, header=True)
        add("All media", ("all", None), len(self.items), "view-media-recent")
        add("Instant Replays", ("source", "replay"), by(lambda i: i["source"] == "replay"), "media-record")
        add("Edited clips", ("source", "export"), by(lambda i: i["source"] == "export"), "edit-cut")
        add("Recordings", ("source", "recording"), by(lambda i: i["source"] == "recording"), "camera-video")
        add("Screenshots", ("source", "screenshot"), by(lambda i: i["source"] == "screenshot"), "image-x-generic")
        games = {}
        for i in self.items:
            games.setdefault(i["game"], [0, 0])
            games[i["game"]][0] += 1
            games[i["game"]][1] = max(games[i["game"]][1], i["mtime"])
        if games:
            sp = QListWidgetItem(""); sp.setFlags(Qt.NoItemFlags); sp.setSizeHint(QSize(10, 10)); self.nav.addItem(sp)
            add("GAMES", None, 0, header=True)
            for g, (n, _) in sorted(games.items(), key=lambda kv: -kv[1][1]):
                add(g, ("game", g), n, "applications-games" if g != "Desktop" else "user-desktop")
        sel = 1
        for r in range(self.nav.count()):
            if self.nav.item(r).data(Qt.UserRole) == cur:
                sel = r
        self.nav.setCurrentRow(sel)
        self.nav.blockSignals(False)
        self.filter = self.nav.currentItem().data(Qt.UserRole) or ("all", None)
        total = sum(i["size"] for i in self.items)
        self.foot.setText(f"{len(self.items)} files · {media.fmt_size(total)}\nReplays: {self._short(media.REPLAYS)}\n"
                          f"Screenshots: {self._short(media.SHOTS)}")
        self.render()

    @staticmethod
    def _short(p):
        try:
            return "~/" + str(Path(p).relative_to(Path.home()))
        except ValueError:
            return str(p)

    def on_nav(self, cur, _prev):
        key = cur.data(Qt.UserRole) if cur else None
        if key is None:
            return
        self.filter = key
        self.stack.setCurrentIndex(0)
        self.render()

    def visible_items(self):
        kind_btn = self.kinds.checkedButton()
        kind = kind_btn.property("kind") if kind_btn else "all"
        f, v = self.filter
        q = self.search.text().strip().lower()
        out = []
        for i in self.items:
            if f == "source" and i["source"] != v or f == "game" and i["game"] != v:
                continue
            if kind != "all" and i["kind"] != kind:
                continue
            if q and q not in i["name"].lower() and q not in i["game"].lower():
                continue
            out.append(i)
        return out

    def render(self):
        while self.bl.count():
            it = self.bl.takeAt(0)
            if it.widget():
                it.widget().hide(); it.widget().deleteLater()
        self.tiles = {}
        f, v = self.filter
        self.heading.setText({"all": "All media", "game": v or ""}.get(f) or
                             {"replay": "Instant Replays", "export": "Edited clips", "recording": "Recordings",
                              "screenshot": "Screenshots"}[v])
        items = self.visible_items()
        vids = sum(1 for i in items if i["kind"] == "video")
        self.count.setText(f"{vids} clip{'s' * (vids != 1)} · {len(items) - vids} screenshot{'s' * (len(items) - vids != 1)}")
        if not items:
            self.bl.addWidget(self.empty_state()); self.bl.addStretch(); return
        groups = {}
        for i in items:
            groups.setdefault(media.day_label(i["mtime"]), []).append(i)
        for day, its in groups.items():
            h = QLabel(day); h.setObjectName("day"); self.bl.addWidget(h)
            box = QWidget(); fl = FlowLayout(box)
            for i in its:
                t = Tile(i); t.clicked.connect(self.open_item); t.menu.connect(self.context_menu)
                fl.addWidget(t); self.tiles[i["path"]] = t
                if i["path"] in self.thumbs:
                    t.set_thumb(*self.thumbs[i["path"]])
                else:
                    self.loader.request(i)
            self.bl.addWidget(box)
        self.bl.addStretch()

    def empty_state(self):
        w = QFrame(); w.setObjectName("empty"); l = QVBoxLayout(w); l.setContentsMargins(40, 40, 40, 40); l.setSpacing(10)
        t = QLabel("No clips here yet"); t.setObjectName("h2"); l.addWidget(t, 0, Qt.AlignHCenter)
        x = QLabel("Turn on <b>Instant Replay</b> (PhoenixGe Center ▸ Gaming, or the overlay with <b>Meta+G</b>) and press "
                   "<b>Save replay</b> after a great moment - the last 30-60 seconds land here.<br>"
                   "Screenshots from the overlay show up here too.")
        x.setObjectName("dim"); x.setWordWrap(True); x.setAlignment(Qt.AlignCenter); x.setTextFormat(Qt.RichText); l.addWidget(x)
        return w

    def on_thumb(self, path, file, dur):
        self.thumbs[path] = (file, dur)
        t = self.tiles.get(path)
        if t:
            t.set_thumb(file, dur)

    def open_item(self, item):
        self.editor.open(item)
        self.stack.setCurrentIndex(1)

    def context_menu(self, item, pos):
        m = QMenu(self)
        m.addAction("Open", lambda: self.open_item(item))
        m.addAction("Open in player", lambda: media.open_external(item["path"]))
        m.addAction("Copy file", lambda: self._copy(item["path"]))
        m.addAction("Show in folder", lambda: media.show_in_folder(item["path"]))
        m.addSeparator()
        m.addAction("Rename…", lambda: (self.open_item(item), self.editor.rename()))
        m.addAction("Move to Trash", lambda: (self.open_item(item), self.editor.delete()))
        m.exec(pos)

    def _copy(self, path):
        self.editor.share_path = path
        self.editor.copy_file()

    def toast(self, text):
        self.toast_lbl.setText(text); self.toast_lbl.adjustSize()
        self.toast_lbl.move((self.width() - self.toast_lbl.width()) // 2, self.height() - self.toast_lbl.height() - 28)
        self.toast_lbl.show(); self.toast_lbl.raise_()
        QTimer.singleShot(3200, self.toast_lbl.hide)


STYLE = """
QWidget { font-size: 13px; }
#sidebar { background: palette(alternate-base); border-right: 1px solid rgba(255,255,255,0.06); }
#brand { font-size: 20px; font-weight: 800; letter-spacing: 0.5px; }
#nav { background: transparent; border: none; outline: none; }
#nav::item { padding: 8px 10px; border-radius: 9px; margin: 1px 0; }
#nav::item:selected { background: ACC33; color: ACC; }
#nav::item:hover:!selected { background: rgba(255,255,255,0.05); }
#navcount { color: palette(placeholder-text); font-size: 11px; }
#h1 { font-size: 26px; font-weight: 800; }
#h2 { font-size: 17px; font-weight: 700; }
#day { font-size: 15px; font-weight: 700; padding-top: 10px; }
#dim { color: palette(placeholder-text); }
#mono { font-family: "JetBrains Mono", monospace; color: palette(placeholder-text); }
#tile { border-radius: 14px; background: transparent; }
#tile:hover { background: rgba(255,255,255,0.06); }
#tileTitle { font-weight: 600; }
#chip { background: ACC2a; color: ACC; border-radius: 11px; padding: 3px 4px; font-weight: 600; }
#viewer, #poster { background: #0b0a0d; border-radius: 14px; }
#panel { background: palette(alternate-base); border-radius: 14px; border: 1px solid ACC22; }
#panelTitle { font-size: 15px; font-weight: 700; }
#empty { background: palette(alternate-base); border-radius: 16px; }
QPushButton { padding: 7px 14px; border-radius: 9px; background: rgba(255,255,255,0.06);
              border: 1px solid rgba(255,255,255,0.08); }
QPushButton:hover { background: rgba(255,255,255,0.11); border-color: ACC66; }
QPushButton:disabled { color: palette(placeholder-text); }
QPushButton#primary { background: ACC; color: #1a0b06; font-weight: 700; border: none; padding: 10px 16px; }
QPushButton#primary:disabled { background: rgba(255,255,255,0.08); color: palette(placeholder-text); }
QPushButton#ghost { background: transparent; border: none; }
QPushButton#ghost:hover { background: rgba(255,255,255,0.07); }
QPushButton#round { border-radius: 22px; background: ACC; color: #1a0b06; font-size: 15px; font-weight: 800; border: none; padding: 0; }
QPushButton#share { text-align: left; padding: 9px 12px; }
QPushButton#danger { color: #ff8a7a; }
QPushButton#seg { border-radius: 9px; padding: 6px 14px; }
QPushButton#seg:checked { background: ACC; color: #1a0b06; font-weight: 700; border: none; }
QProgressBar { background: rgba(255,255,255,0.08); border: none; border-radius: 3px; }
QProgressBar::chunk { background: ACC; border-radius: 3px; }
#toast { background: rgba(20,16,22,0.94); color: white; border: 1px solid ACC66; border-radius: 12px; padding: 10px 18px; }
"""


def dark_palette(app):
    """Used for --demo / when no Plasma color scheme is around: the Ember look."""
    app.setStyle("Fusion")
    p = QPalette()
    for role, c in ((QPalette.Window, "#151116"), (QPalette.WindowText, "#f3ece6"), (QPalette.Base, "#1c171d"),
                    (QPalette.AlternateBase, "#1f1a21"), (QPalette.Text, "#f3ece6"), (QPalette.Button, "#2a2329"),
                    (QPalette.ButtonText, "#f3ece6"), (QPalette.Highlight, ACC), (QPalette.HighlightedText, "#1a0b06"),
                    (QPalette.PlaceholderText, "#9a8f95"), (QPalette.ToolTipBase, "#1f1a21"), (QPalette.ToolTipText, "#f3ece6")):
        p.setColor(role, QColor(c))
    app.setPalette(p)


def main():
    global ACC
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if "--copy" in sys.argv:
        ok = bool(args) and media.copy_file_cli(args[0])
        sys.exit(0 if ok else 1)
    app = QApplication(sys.argv[:1])
    app.setApplicationName("phoenixge-clips"); app.setDesktopFileName("phoenixge-clips")
    ACC = accent()
    if DEMO:
        root = Path(tempfile.mkdtemp(prefix="phoenixge-clips-demo-"))
        media.make_demo(root)
    if DEMO or not os.environ.get("KDE_FULL_SESSION"):
        if DEMO or app.palette().color(QPalette.Window).lightness() > 128 and not os.environ.get("XDG_CURRENT_DESKTOP"):
            dark_palette(app)
    w = Clips(args[0] if args else None)
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
