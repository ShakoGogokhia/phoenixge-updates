#!/bin/sh
# Register an already copied Epic game with Heroic (via the legendary that ships inside Heroic).
#   heroic-import.sh APP_NAME GAME_FOLDER
# APP_NAME = Epic "AppName" from the Windows manifest (*.item), e.g. Sugar for Rocket League.
# Heroic must be logged in to Epic once (legendary needs the account to know the game).
set -u
APP="$1"; DIR="$2"
FID=com.heroicgameslauncher.hgl

if [ ! -d "$DIR" ]; then echo "Folder not found: $DIR"; exit 2; fi

if flatpak info "$FID" >/dev/null 2>&1; then
  KIND=flatpak
  CFG="$HOME/.var/app/$FID/config/heroic/legendaryConfig/legendary"
else
  KIND=native
  CFG="$HOME/.config/heroic/legendaryConfig/legendary"
fi
[ -f "$CFG/user.json" ] || { [ -f "$HOME/.config/legendary/user.json" ] && CFG="$HOME/.config/legendary"; }
if [ ! -f "$CFG/user.json" ]; then
  echo "Heroic is not logged in to Epic yet. Open Heroic > Log in > Epic Games, then try again."
  exit 3
fi

# Heroic reads the installed games only when it starts -> close it, it is reopened by the user afterwards
if [ "$KIND" = flatpak ]; then
  flatpak ps --columns=application 2>/dev/null | grep -qx "$FID" && { echo "Closing Heroic…"; flatpak kill "$FID"; sleep 2; }
else
  pkill -x heroic 2>/dev/null && { echo "Closing Heroic…"; sleep 2; }
fi

# legendary inside Heroic: resources/app.asar.unpacked/build/bin/<arch>/linux/legendary (path changed between versions -> search)
FIND='for f in /app/bin/heroic/resources/app.asar.unpacked/build/bin/*/linux/legendary \
              /app/bin/heroic/resources/app.asar.unpacked/build/bin/linux/legendary \
              /opt/Heroic/resources/app.asar.unpacked/build/bin/*/linux/legendary \
              /opt/Heroic/resources/app.asar.unpacked/build/bin/linux/legendary \
              /usr/lib/heroic/resources/app.asar.unpacked/build/bin/*/linux/legendary; do
        [ -x "$f" ] && { echo "$f"; exit 0; }; done
      f=$(find /app/bin/heroic /opt/Heroic /usr/lib/heroic -type f -name legendary 2>/dev/null | head -n1)
      [ -n "$f" ] && { echo "$f"; exit 0; }
      command -v legendary'

IMPORT='"$LEG" -y import --with-dlcs --platform Windows "$1" "$2"'

if [ "$KIND" = flatpak ]; then
  # ~/Games/Heroic is already allowed; anything else needs a permission for the sandbox
  case "$DIR" in "$HOME/Games/Heroic"/*) ;; *) flatpak override --user --filesystem="$DIR" "$FID" ;; esac
  flatpak run --command=sh "$FID" -c "LEG=\$($FIND); [ -n \"\$LEG\" ] || { echo 'legendary not found inside Heroic'; exit 4; };
      echo \"Using \$LEG\"; export LEGENDARY_CONFIG_PATH='$CFG'; $IMPORT" sh "$APP" "$DIR"
  RC=$?
else
  LEG=$(sh -c "$FIND")
  [ -n "$LEG" ] || { echo "legendary not found (is Heroic installed?)"; exit 4; }
  echo "Using $LEG"
  LEGENDARY_CONFIG_PATH="$CFG" "$LEG" -y import --with-dlcs --platform Windows "$APP" "$DIR"
  RC=$?
fi

if [ $RC -eq 0 ] && grep -q "\"$APP\"" "$CFG/installed.json" 2>/dev/null; then
  echo "Imported $APP into Heroic. Start Heroic - the game shows as installed."
  exit 0
fi
echo "Import failed ($RC). In Heroic you can also do it by hand: the game > Install > Import game > choose $DIR"
exit 1
