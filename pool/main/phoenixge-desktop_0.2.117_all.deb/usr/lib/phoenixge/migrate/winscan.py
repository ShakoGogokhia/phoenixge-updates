"""Windows side of "Move from Windows": find Windows partitions, open them read-only, read what is installed.

No Qt in here (testable from the command line):
  python3 winscan.py                 list partitions (JSON)
  python3 winscan.py MOUNTPOINT      full scan of an already mounted Windows partition (JSON)

Nothing in this module writes to a Windows partition. Mounting is always read-only (udisksctl -o ro).
"""
import json
import os
import re
import shutil
import subprocess
import sys
import uuid
import xml.etree.ElementTree as ET
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import regf  # noqa: E402

KNOWN_FOLDERS = [  # (our id, label, User Shell Folders value name)
    ("Desktop", "Desktop", "Desktop"),
    ("Documents", "Documents", "Personal"),
    ("Pictures", "Pictures", "My Pictures"),
    ("Music", "Music", "My Music"),
    ("Videos", "Videos", "My Video"),
    ("Downloads", "Downloads", "{374DE290-123F-4565-9164-39C4925E467B}"),
]
SKIP_USERS = {"public", "default", "default user", "all users", "defaultapppool", "wdagutilityaccount"}


# ------------------------------------------------------------------ helpers
def run(cmd, timeout=30, input=None):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, input=input)
        return p.returncode, p.stdout, p.stderr
    except FileNotFoundError:
        return 127, "", f"{cmd[0]}: not installed"
    except subprocess.TimeoutExpired:
        return 124, "", f"{cmd[0]}: timed out"


def ci(base, *parts):
    """Path below `base`, matching each part case-insensitively (NTFS names are case-insensitive, Linux is not).
    Returns the path even if it doesn't exist (then with the given spelling)."""
    p = Path(base)
    for part in parts:
        for sub in [x for x in re.split(r"[\\/]+", str(part)) if x]:
            exact = p / sub
            if exact.exists():
                p = exact
                continue
            low = sub.lower()
            try:
                match = next((e for e in os.scandir(p) if e.name.lower() == low), None)
            except OSError:
                match = None
            p = Path(match.path) if match else exact
    return p


def human(n):
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit in ("B", "KB") else f"{n:.1f} {unit}"
        n /= 1024


def dir_size(path, stop=None):
    """Bytes below `path` (no symlinks). `stop` = callable returning True to abort early."""
    total, stack = 0, [str(path)]
    while stack:
        if stop and stop():
            break
        try:
            with os.scandir(stack.pop()) as it:
                for e in it:
                    try:
                        if e.is_dir(follow_symlinks=False):
                            stack.append(e.path)
                        elif e.is_file(follow_symlinks=False):
                            total += e.stat(follow_symlinks=False).st_size
                    except OSError:
                        pass
        except OSError:
            pass
    return total


def free_space(path):
    p = Path(path)
    while not p.exists() and p != p.parent:
        p = p.parent
    try:
        return shutil.disk_usage(p).free
    except OSError:
        return 0


def read_text(path):
    raw = Path(path).read_bytes()
    for bom, enc in ((b"\xef\xbb\xbf", "utf-8-sig"), (b"\xff\xfe", "utf-16"), (b"\xfe\xff", "utf-16")):
        if raw.startswith(bom):
            return raw.decode(enc, "replace")
    return raw.decode("utf-8", "replace")


# ------------------------------------------------------------------ VDF (Steam)
def vdf_parse(text):
    """Valve KeyValues text -> nested dict (keys kept as written; use vget for case-insensitive access)."""
    root, stack, key = {}, [], None
    cur = root
    for m in re.finditer(r'"((?:[^"\\]|\\.)*)"|(\{)|(\})|(//[^\n]*)', text):
        if m.group(4):
            continue
        if m.group(2):
            new = {}
            if key is not None:
                cur[key] = new
            stack.append(cur); cur, key = new, None
        elif m.group(3):
            cur = stack.pop() if stack else root
            key = None
        else:
            s = re.sub(r"\\(.)", r"\1", m.group(1))
            if key is None:
                key = s
            else:
                cur[key] = s; key = None
    return root


def vget(d, key, default=None):
    if not isinstance(d, dict):
        return default
    low = key.lower()
    for k, v in d.items():
        if k.lower() == low:
            return v
    return default


# ------------------------------------------------------------------ partitions
def lsblk():
    code, out, _ = run(["lsblk", "-J", "-b", "-o", "NAME,PATH,FSTYPE,LABEL,SIZE,MOUNTPOINT,TYPE,PARTUUID,PARTTYPENAME,MODEL,RM"])
    if code != 0:
        return []
    try:
        devs = json.loads(out).get("blockdevices", [])
    except ValueError:
        return []
    flat = []

    def walk(d, parent=None, disk=None):
        d = dict(d); d["parent"] = parent; d["disk"] = disk
        flat.append(d)
        for c in d.pop("children", None) or []:
            walk(c, d, disk or (d.get("model") or d.get("name")))
    for d in devs:
        walk(d)
    return flat


def partitions():
    """Candidate Windows partitions. kind: ntfs | bitlocker (locked) | unknown (maybe encrypted)."""
    out = []
    for d in lsblk():
        fs = (d.get("fstype") or "").lower()
        ptype = (d.get("parttypename") or "")
        size = int(d.get("size") or 0)
        if d.get("type") == "loop" or "recovery" in ptype.lower():
            continue
        kind = None
        if fs in ("ntfs", "ntfs3"):
            kind = "ntfs"
        elif fs == "bitlocker":
            kind = "bitlocker"
        elif not fs and d.get("type") == "part" and "microsoft basic data" in ptype.lower() and size > 8 << 30:
            kind = "unknown"
        if not kind:
            continue
        par = d.get("parent") or {}
        out.append(dict(path=d.get("path") or "/dev/" + d["name"], label=d.get("label") or "", size=size, kind=kind,
                        mount=d.get("mountpoint") or "",
                        partuuid=(d.get("partuuid") or par.get("partuuid") or "").lower(),
                        disk=d.get("disk") or "", unlocked_from=par.get("path") if d.get("type") == "crypt" else "",
                        removable=str(d.get("rm")) in ("1", "True", "true")))
    # a BitLocker partition that is already unlocked shows up twice (locked parent + ntfs child): mark the parent
    unlocked = {p["unlocked_from"] for p in out if p["unlocked_from"]}
    for p in out:
        if p["kind"] == "bitlocker" and p["path"] in unlocked:
            p["kind"] = "bitlocker-open"
    return out


def mount_ro(dev):
    """Mount read-only with udisks (asks for the password only if the policy wants it). -> (mountpoint, error)."""
    for p in partitions():
        if p["path"] == dev and p["mount"]:
            return p["mount"], ""
    code, out, err = run(["udisksctl", "mount", "-b", dev, "-o", "ro"], timeout=180)
    msg = (out + err).strip()
    for p in partitions():
        if p["path"] == dev and p["mount"]:
            return p["mount"], ""
    m = re.search(r" at (/\S+?)\.?$", out.strip())
    if code == 0 and m:
        return m.group(1), ""
    return "", explain_mount_error(msg)


def explain_mount_error(msg):
    low = msg.lower()
    if "hibernat" in low or "unclean" in low or "unsafe state" in low or "dirty" in low:
        return ("Windows did not shut down completely (Fast Startup or hibernation), so the drive is locked.\n"
                "Fix: start Windows, open Terminal (Admin) and run   powercfg /h off   then choose Shut down "
                "(not Restart) and come back here.\n\n" + msg)
    if "notauthorized" in low or "not authorized" in low or "dismissed" in low:
        return "Opening the drive needs your password. Try again and enter it in the dialog.\n\n" + msg
    if "wrong fs type" in low or "unknown filesystem" in low:
        return "Linux could not read this file system (ntfs3/ntfs-3g missing?).\n\n" + msg
    return msg or "Could not open the drive."


def unlock_bitlocker(dev, recovery_key):
    """Unlock with the 48-digit recovery key (or the BitLocker password). -> (cleartext device, error)."""
    key = recovery_key.strip()
    if re.fullmatch(r"[\d\s-]+", key):
        digits = re.sub(r"\D", "", key)
        if len(digits) == 48:
            key = "-".join(digits[i:i + 6] for i in range(0, 48, 6))
    rt = Path(os.environ.get("XDG_RUNTIME_DIR") or "/tmp")
    kf = rt / f"phoenixge-bitlocker-{os.getpid()}.key"
    try:
        fd = os.open(kf, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(key)
        code, out, err = run(["udisksctl", "unlock", "-b", dev, "--key-file", str(kf)], timeout=180)
    finally:
        try:
            kf.unlink()
        except OSError:
            pass
    m = re.search(r" as (/dev/\S+?)\.?$", out.strip())
    if code == 0 and m:
        return m.group(1), ""
    msg = (out + err).strip()
    low = msg.lower()
    if "wrong" in low or "failed to activate" in low or "no key available" in low:
        return "", "The key was not accepted. Check the 48-digit recovery key (8 groups of 6 digits).\n\n" + msg
    if "not supported" in low or "unknown" in low:
        return "", ("This Linux can't unlock this BitLocker drive (e.g. a newer encryption mode). Turn BitLocker / "
                    "Device encryption off in Windows instead.\n\n" + msg)
    return "", msg or "Unlock failed."


BITLOCKER_HELP = (
    "This drive is encrypted with BitLocker (on many laptops it's called \"Device encryption\" and is on by default).\n\n"
    "Option 1 - unlock it here with the recovery key: 48 digits, find it at https://account.microsoft.com/devices/recoverykey "
    "(sign in with the Microsoft account used on that PC) or on a printout/USB you saved.\n\n"
    "Option 2 - turn encryption off in Windows: Settings > Privacy & security > Device encryption > Off "
    "(or Control Panel > BitLocker > Turn off). Decrypting takes a while; then shut down and come back.\n\n"
    "We only read the drive - Windows and BitLocker stay as they are.")

HIBERNATION_HELP = (
    "Windows is not fully shut down (Fast Startup / hibernation is on). The drive was opened read-only, so it's safe, "
    "but the newest files you saved right before shutting down might be missing here.\n\n"
    "For a clean copy: start Windows, open Terminal (Admin), run   powercfg /h off   then Shut down "
    "(hold Shift while clicking Shut down) and start PhoenixGe again.")


def hibernated(mnt):
    """True if hiberfil.sys contains an image (hibernation or Fast Startup), so Windows will resume from it."""
    f = ci(mnt, "hiberfil.sys")
    try:
        with open(f, "rb") as fh:
            sig = fh.read(4).lower()
        return sig in (b"hibr", b"rstr", b"wake")
    except OSError:
        return False


def is_windows(mnt):
    return ci(mnt, "Windows", "System32").is_dir() and ci(mnt, "Windows", "System32", "config", "SOFTWARE").is_file()


# ------------------------------------------------------------------ the Windows installation
class Windows:
    """A Windows installation on a mounted partition + the other mounted NTFS partitions (for D:, E: …)."""

    def __init__(self, mnt, others=(), parts=None):
        self.mnt = Path(mnt)
        self.others = [Path(o) for o in others if Path(o) != self.mnt]
        self._soft = self._sys = None
        self.letters = {}  # "D" -> mountpoint (from MountedDevices + PARTUUID)
        self.parts = parts or []
        self.errors = []
        self._map_letters()

    # ---- hives
    def hive(self, name):
        try:
            return regf.Hive(ci(self.mnt, "Windows", "System32", "config", name))
        except Exception as e:
            self.errors.append(f"{name} hive: {e}")
            return None

    @property
    def software(self):
        if self._soft is None:
            self._soft = self.hive("SOFTWARE") or False
        return self._soft or None

    @property
    def system(self):
        if self._sys is None:
            self._sys = self.hive("SYSTEM") or False
        return self._sys or None

    def info(self):
        k = self.software.open(r"Microsoft\Windows NT\CurrentVersion") if self.software else None
        if not k:
            return dict(name="Windows", version="", build="")
        name = k.value("ProductName", "Windows")
        build = str(k.value("CurrentBuildNumber", k.value("CurrentBuild", "")) or "")
        if name.startswith("Windows 10") and build.isdigit() and int(build) >= 22000:
            name = name.replace("Windows 10", "Windows 11", 1)  # ProductName still says 10 on Windows 11
        return dict(name=name, version=k.value("DisplayVersion", "") or "", build=build)

    # ---- drive letters
    def _map_letters(self):
        sysh = self.system
        if not sysh:
            return
        k = sysh.open("MountedDevices")
        if not k:
            return
        by_uuid = {p["partuuid"]: p["mount"] for p in self.parts if p.get("partuuid") and p.get("mount")}
        for name, data in k.values().items():
            m = re.fullmatch(r"\\DosDevices\\([A-Z]):", name)
            if not m or not isinstance(data, bytes):
                continue
            if data.startswith(b"DMIO:ID:") and len(data) >= 24:
                pu = str(uuid.UUID(bytes_le=data[8:24]))
                if pu in by_uuid:
                    self.letters[m.group(1)] = Path(by_uuid[pu])

    def resolve(self, winpath):
        """'D:\\Games\\X' -> Path on a mounted partition, or None. Unknown letters: try every partition."""
        if not winpath:
            return None
        winpath = winpath.strip().strip('"')
        m = re.match(r"^([A-Za-z]):[\\/]*(.*)$", winpath)
        if not m:
            return None
        letter, rest = m.group(1).upper(), m.group(2)
        cands = []
        if letter == "C":
            cands.append(self.mnt)
        if letter in self.letters:
            cands.append(self.letters[letter])
        cands += [self.mnt] + self.others
        for base in cands:
            p = ci(base, rest)
            if p.exists():
                return p
        return None

    def expand(self, s, user=None):
        if not isinstance(s, str):
            return ""
        env = {"systemdrive": "C:", "systemroot": r"C:\Windows", "windir": r"C:\Windows",
               "programfiles": r"C:\Program Files", "programfiles(x86)": r"C:\Program Files (x86)",
               "programdata": r"C:\ProgramData", "public": r"C:\Users\Public"}
        if user:
            env.update({"userprofile": rf"C:\Users\{user}", "appdata": rf"C:\Users\{user}\AppData\Roaming",
                        "localappdata": rf"C:\Users\{user}\AppData\Local", "username": user,
                        "homepath": rf"\Users\{user}", "homedrive": "C:"})
        return re.sub(r"%([^%]+)%", lambda m: env.get(m.group(1).lower(), m.group(0)), s)

    # ---- users
    def users(self):
        out = []
        base = ci(self.mnt, "Users")
        try:
            entries = sorted(os.scandir(base), key=lambda e: e.name.lower())
        except OSError:
            return out
        for e in entries:
            if not e.is_dir(follow_symlinks=False) or e.name.lower() in SKIP_USERS or e.name.startswith((".", "$")):
                continue
            if not ci(e.path, "NTUSER.DAT").exists():
                continue
            out.append(e.name)
        return out

    def user_hive(self, user):
        try:
            return regf.Hive(ci(self.mnt, "Users", user, "NTUSER.DAT"))
        except Exception as e:
            self.errors.append(f"NTUSER.DAT of {user}: {e}")
            return None

    def user_folders(self, user):
        """[(id, label, Path or None, note)] with OneDrive / moved folders resolved via User Shell Folders."""
        h = self.user_hive(user)
        usf = h.open(r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders") if h else None
        out = []
        for fid, label, vname in KNOWN_FOLDERS:
            path, note = None, ""
            raw = usf.value(vname) if usf else None
            if raw:
                path = self.resolve(self.expand(raw, user))
                if "onedrive" in raw.lower():
                    note = "in OneDrive - files that are only online (cloud icon in Windows) aren't on the disk"
            if path is None:
                p = ci(self.mnt, "Users", user, label)
                path = p if p.is_dir() else None
            out.append((fid, label, path, note))
        return out

    # ---- installed programs
    def programs(self):
        """Installed programs from the Uninstall keys (64 + 32 bit + every user's own installs)."""
        seen, out = set(), []

        def add_from(key, scope, user=None):
            if not key:
                return
            for sub in key.subkeys():
                v = sub.values()
                name = (v.get("DisplayName") or "").strip() if isinstance(v.get("DisplayName"), str) else ""
                if not name or v.get("SystemComponent") == 1 or v.get("ParentKeyName") or \
                        str(v.get("ReleaseType", "")).lower() in ("update", "hotfix", "security update", "service pack") or \
                        re.search(r"\(KB\d{6,}\)|^KB\d{6,}", name):
                    continue
                key_ = name.lower()
                if key_ in seen:
                    continue
                seen.add(key_)
                loc = v.get("InstallLocation") if isinstance(v.get("InstallLocation"), str) else ""
                icon = v.get("DisplayIcon") if isinstance(v.get("DisplayIcon"), str) else ""
                exe = ""
                if icon:
                    exe = re.sub(r",\s*-?\d+$", "", icon).strip().strip('"')
                    if not exe.lower().endswith(".exe"):
                        exe = ""
                if not loc and exe:
                    loc = exe.rsplit("\\", 1)[0]
                out.append(dict(name=name, publisher=str(v.get("Publisher") or ""), version=str(v.get("DisplayVersion") or ""),
                                location=self.expand(loc, user), exe=self.expand(exe, user), scope=scope,
                                size_kb=v.get("EstimatedSize") if isinstance(v.get("EstimatedSize"), int) else 0,
                                key=sub.name))
        s = self.software
        if s:
            add_from(s.open(r"Microsoft\Windows\CurrentVersion\Uninstall"), "64-bit")
            add_from(s.open(r"WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"), "32-bit")
        for u in self.users():
            h = self.user_hive(u)
            if h:
                add_from(h.open(r"Software\Microsoft\Windows\CurrentVersion\Uninstall"), f"user {u}", u)
        out.sort(key=lambda p: p["name"].lower())
        return out

    # ---- games
    def epic_games(self):
        out = []
        mdir = ci(self.mnt, "ProgramData", "Epic", "EpicGamesLauncher", "Data", "Manifests")
        for item in sorted(mdir.glob("*.item")) if mdir.is_dir() else []:
            g = parse_epic_item(item)
            if not g:
                continue
            g["path"] = self.resolve(g["install_location"])
            out.append(g)
        return out

    def steam_root(self):
        s = self.software
        for kp in (r"WOW6432Node\Valve\Steam", r"Valve\Steam"):
            k = s.open(kp) if s else None
            p = self.resolve(k.value("InstallPath", "")) if k else None
            if p and p.is_dir():
                return p
        for rest in (r"Program Files (x86)\Steam", r"Program Files\Steam"):
            p = ci(self.mnt, rest)
            if p.is_dir():
                return p
        return None

    def steam_games(self):
        root = self.steam_root()
        if not root:
            return []
        libs = [root]
        lf = ci(root, "steamapps", "libraryfolders.vdf")
        if lf.is_file():
            for path in steam_library_paths(read_text(lf)):
                p = self.resolve(path)
                if p and p not in libs:
                    libs.append(p)
        out = []
        for lib in libs:
            sa = ci(lib, "steamapps")
            for acf in sorted(sa.glob("appmanifest_*.acf")) if sa.is_dir() else []:
                g = parse_acf(acf)
                if not g:
                    continue
                g["path"] = ci(sa, "common", g["installdir"])
                if g["path"].is_dir():
                    out.append(g)
        return out

    def gog_games(self):
        out, seen = [], set()
        s = self.software
        k = s.open(r"WOW6432Node\GOG.com\Games") if s else None
        for sub in k.subkeys() if k else []:
            v = sub.values()
            p = self.resolve(v.get("path") or v.get("PATH") or "")
            name = v.get("gameName") or v.get("GAMENAME") or sub.name
            if p and p.is_dir() and str(p) not in seen:
                seen.add(str(p))
                out.append(dict(store="GOG", id=str(v.get("gameID") or sub.name), name=name, path=p, size=0))
        for base in (r"Program Files (x86)\GOG Galaxy\Games", r"GOG Games"):
            d = ci(self.mnt, base)
            for e in (sorted(d.iterdir()) if d.is_dir() else []):
                if e.is_dir() and str(e) not in seen and list(e.glob("goggame-*.info")):
                    seen.add(str(e))
                    out.append(dict(store="GOG", id="", name=e.name, path=e, size=0))
        return out

    def ubisoft_games(self):
        out = []
        s = self.software
        k = s.open(r"WOW6432Node\Ubisoft\Launcher\Installs") if s else None
        for sub in k.subkeys() if k else []:
            p = self.resolve(sub.value("InstallDir", ""))
            if p and p.is_dir():
                out.append(dict(store="Ubisoft Connect", id=sub.name, name=p.name, path=p, size=0))
        return out

    def other_launcher_games(self, programs=None):
        """EA app and Battle.net games: from the Uninstall list by publisher."""
        out = []
        for prog in programs if programs is not None else self.programs():
            pub, name = prog["publisher"].lower(), prog["name"]
            if "electronic arts" in pub and not re.search(r"\bEA app\b|Origin\b|EA Desktop", name):
                store = "EA app"
            elif "blizzard" in pub and "battle.net" not in name.lower():
                store = "Battle.net"
            elif "riot games" in pub and "riot client" not in name.lower():
                store = "Riot"
            else:
                continue
            p = self.resolve(prog["location"])
            out.append(dict(store=store, id=prog["key"], name=name, path=p if p and p.is_dir() else None,
                            size=(prog["size_kb"] or 0) * 1024))
        return out

    def store_apps_note(self):
        """Microsoft Store / Xbox games can't be copied (encrypted packages). Return the folders found."""
        found = []
        for base in [self.mnt] + self.others:
            for rest in ("XboxGames", r"Program Files\ModifiableWindowsApps"):
                p = ci(base, rest)
                if p.is_dir():
                    try:
                        found += [e.name for e in os.scandir(p) if e.is_dir()]
                    except OSError:
                        pass
        return sorted(set(found))

    # ---- browsers, wallpaper, Wi-Fi
    def browsers(self, user):
        out = []
        local = ci(self.mnt, "Users", user, "AppData", "Local")
        for name, rel in (("Google Chrome", r"Google\Chrome\User Data"), ("Microsoft Edge", r"Microsoft\Edge\User Data"),
                          ("Brave", r"BraveSoftware\Brave-Browser\User Data"), ("Vivaldi", r"Vivaldi\User Data"),
                          ("Opera", None)):
            d = ci(local, rel) if rel else ci(self.mnt, "Users", user, "AppData", "Roaming", "Opera Software", "Opera Stable")
            if not d.is_dir():
                continue
            profiles = [d] if name == "Opera" else [p for p in sorted(d.iterdir()) if p.is_dir() and
                                                    (p.name == "Default" or p.name.startswith("Profile "))]
            for p in profiles:
                bm = ci(p, "Bookmarks")
                if bm.is_file():
                    out.append(dict(browser=name, profile=chromium_profile_name(d, p.name), kind="chromium", bookmarks=bm))
        ff = ci(self.mnt, "Users", user, "AppData", "Roaming", "Mozilla", "Firefox", "Profiles")
        for p in sorted(ff.iterdir()) if ff.is_dir() else []:
            places = ci(p, "places.sqlite")
            if places.is_file() and places.stat().st_size > 0:
                out.append(dict(browser="Firefox", profile=p.name.split(".", 1)[-1], kind="firefox", bookmarks=places,
                                profile_dir=p))
        return out

    def wallpaper(self, user):
        p = ci(self.mnt, "Users", user, "AppData", "Roaming", "Microsoft", "Windows", "Themes", "TranscodedWallpaper")
        if p.is_file() and p.stat().st_size > 1000:
            return p
        h = self.user_hive(user)
        k = h.open(r"Control Panel\Desktop") if h else None
        wp = self.resolve(self.expand(k.value("WallPaper", ""), user)) if k else None
        return wp if wp and wp.is_file() else None

    def wifi(self):
        out = []
        d = ci(self.mnt, "ProgramData", "Microsoft", "Wlansvc", "Profiles", "Interfaces")
        for x in sorted(d.rglob("*.xml")) if d.is_dir() else []:
            try:
                root = ET.fromstring(x.read_bytes())
            except ET.ParseError:
                continue
            ns = {"w": root.tag.split("}")[0].strip("{")} if root.tag.startswith("{") else {}
            pre = "w:" if ns else ""
            name = root.findtext(f"{pre}name", namespaces=ns) or ""
            auth = root.findtext(f".//{pre}authentication", namespaces=ns) or ""
            if name and name not in [w["ssid"] for w in out]:
                out.append(dict(ssid=name, security=auth))
        return out


# ------------------------------------------------------------------ parsers (pure, unit-tested)
def parse_epic_item(path):
    """Epic Games Launcher manifest (*.item, JSON). Skips DLC, Unreal Engine/plugins and unfinished installs."""
    try:
        j = json.loads(read_text(path))
    except (OSError, ValueError):
        return None
    app = j.get("AppName") or ""
    main = j.get("MainGameAppName") or app
    cats = [c.lower() for c in j.get("AppCategories") or []]
    if not app or main != app or j.get("bIsIncompleteInstall") or (cats and "games" not in cats):
        return None
    loc = j.get("InstallLocation") or ""
    return dict(store="Epic", id=app, name=j.get("DisplayName") or app, install_location=loc,
                folder=re.split(r"[\\/]", loc.rstrip("\\/"))[-1] if loc else app,
                size=int(j.get("InstallSize") or 0), exe=j.get("LaunchExecutable") or "",
                namespace=j.get("CatalogNamespace") or "", version=j.get("AppVersionString") or "")


def steam_library_paths(text):
    """Paths of all Steam libraries in libraryfolders.vdf (new format: "0" { "path" "..." }, old: "1" "D:\\\\Steam")."""
    d = vdf_parse(text)
    lf = vget(d, "libraryfolders") or vget(d, "LibraryFolders") or {}
    out = []
    for k, v in lf.items():
        if isinstance(v, dict) and vget(v, "path"):
            out.append(vget(v, "path"))
        elif isinstance(v, str) and k.isdigit():
            out.append(v)
    return out


STEAM_TOOL_IDS = {"228980", "1070560", "1391110", "1628350", "1493710", "2180100", "1826330", "1161040", "250820"}


def parse_acf(path):
    try:
        st = vget(vdf_parse(read_text(path)), "AppState") or {}
    except OSError:
        return None
    appid, name, idir = vget(st, "appid", ""), vget(st, "name", ""), vget(st, "installdir", "")
    if not appid or not idir or appid in STEAM_TOOL_IDS or re.match(r"^(Proton|Steamworks Common|Steam Linux Runtime)", name):
        return None
    try:
        flags = int(vget(st, "StateFlags", "4"))
    except ValueError:
        flags = 4
    if not flags & 4:
        return None
    try:
        size = int(vget(st, "SizeOnDisk", "0"))
    except ValueError:
        size = 0
    return dict(store="Steam", id=appid, name=name or idir, installdir=idir, size=size, acf=Path(path))


def chromium_profile_name(user_data, folder):
    try:
        ls = json.loads(read_text(Path(user_data) / "Local State"))
        return ls["profile"]["info_cache"][folder].get("name") or folder
    except Exception:
        return folder


# ------------------------------------------------------------------ CLI (debugging in the VM)
def _jsonable(o):
    if isinstance(o, Path):
        return str(o)
    if isinstance(o, bytes):
        return o.hex()
    return str(o)


def main(argv):
    if len(argv) < 2:
        print(json.dumps(partitions(), indent=1, default=_jsonable))
        return 0
    parts = partitions()
    w = Windows(argv[1], [p["mount"] for p in parts if p["mount"]], parts)
    rep = dict(info=w.info(), hibernated=hibernated(argv[1]), letters=w.letters, users=w.users(),
               epic=w.epic_games(), steam=w.steam_games(), gog=w.gog_games(), ubisoft=w.ubisoft_games())
    progs = w.programs()
    rep["other"] = w.other_launcher_games(progs)
    rep["programs"] = progs
    rep["store_apps"] = w.store_apps_note()
    rep["folders"] = {u: w.user_folders(u) for u in rep["users"]}
    rep["browsers"] = {u: w.browsers(u) for u in rep["users"]}
    rep["wifi"] = w.wifi()
    rep["errors"] = w.errors
    print(json.dumps(rep, indent=1, default=_jsonable))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
