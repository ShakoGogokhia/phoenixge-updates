#!/usr/bin/env python3
"""Move from Windows - copy games, find replacements for programs, bring files and settings over.

  phoenixge-migrate                 open the wizard
  phoenixge-migrate --page games    open on a page (drive | games | programs | files)

Windows is only ever READ: its partitions are mounted read-only via udisks (no root; the system may ask for the
password once). Everything is copied into the user's home. Root is only used for Debian packages (pkexec apt-install.sh).
"""
import os
import shlex
import sys
import threading
from pathlib import Path

from PySide6.QtCore import QObject, QProcess, QProcessEnvironment, QSize, Qt, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices, QIcon, QPixmap
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit,
                               QListWidget, QListWidgetItem, QMessageBox, QPlainTextEdit, QProgressBar, QPushButton,
                               QScrollArea, QStackedWidget, QVBoxLayout, QWidget)

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import actions  # noqa: E402
import appmap  # noqa: E402
import winscan  # noqa: E402
from winscan import human  # noqa: E402

LOGO = "/usr/share/pixmaps/phoenixge.png"
APT = "/usr/lib/phoenixge/apt-install.sh"
SPACE_MARGIN = 2 << 30  # keep 2 GB free


def accent():
    try:
        v = os.popen("kreadconfig6 --file kdeglobals --group General --key AccentColor 2>/dev/null").read().strip()
        r, g, b = (int(x) for x in v.split(",")[:3])
        return QColor(r, g, b).name()
    except Exception:
        return "#ff7a2e"


# ------------------------------------------------------------------ small widgets (same look as PhoenixGe Center)
class Card(QFrame):
    def __init__(self, title="", text=""):
        super().__init__()
        self.setObjectName("card")
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(18, 14, 18, 14)
        self.lay.setSpacing(8)
        if title:
            t = QLabel(title); t.setObjectName("cardTitle"); t.setWordWrap(True); self.lay.addWidget(t)
        if text:
            self.text = QLabel(text); self.text.setWordWrap(True); self.text.setObjectName("dim")
            self.text.setTextInteractionFlags(Qt.TextSelectableByMouse | Qt.LinksAccessibleByMouse)
            self.text.setOpenExternalLinks(True)
            self.lay.addWidget(self.text)


def tilde(p):
    """Shorter paths in the UI: /home/me/Games -> ~/Games."""
    s, h = str(p), str(Path.home())
    return "~" + s[len(h):] if s.startswith(h) else s


def dim(text):
    lab = QLabel(text); lab.setObjectName("dim"); lab.setWordWrap(True)
    return lab


def button(text, cb, primary=False):
    b = QPushButton(text)
    if primary:
        b.setObjectName("primary")
    b.clicked.connect(lambda _=False: cb())
    return b


class Page(QWidget):
    """Scrollable page with a title; `body` can be cleared and refilled."""

    def __init__(self, title, subtitle=""):
        super().__init__()
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        inner = QWidget(); lay = QVBoxLayout(inner); lay.setContentsMargins(36, 30, 36, 30); lay.setSpacing(14)
        h = QLabel(title); h.setObjectName("h1"); lay.addWidget(h)
        if subtitle:
            lay.addWidget(dim(subtitle))
        self.bodyw = QWidget(); self.body = QVBoxLayout(self.bodyw)
        self.body.setContentsMargins(0, 0, 0, 0); self.body.setSpacing(12)
        lay.addWidget(self.bodyw); lay.addStretch()
        scroll.setWidget(inner); outer.addWidget(scroll)

    def clear(self):
        def wipe(layout):
            while layout.count():
                it = layout.takeAt(0)
                if it.widget():
                    it.widget().deleteLater()
                elif it.layout():
                    wipe(it.layout())
        wipe(self.body)

    def add(self, w):
        (self.body.addLayout if hasattr(w, "addWidget") and not isinstance(w, QWidget) else self.body.addWidget)(w)
        return w


class Bg(QObject):
    """Run a function in a thread, call `done(result)` back in the GUI thread."""
    sig = Signal(object, object)

    def __init__(self):
        super().__init__()
        self.sig.connect(lambda cb, res: cb(res))

    def run(self, fn, done):
        def work():
            try:
                res = fn()
            except Exception as e:  # shown to the user, never crash the wizard
                res = e
            self.sig.emit(done, res)
        threading.Thread(target=work, daemon=True).start()


# ------------------------------------------------------------------ copy queue (rsync with progress) + command runner
class Queue(QObject):
    changed = Signal()

    def __init__(self, bar, label, log, cancel):
        super().__init__()
        self.bar, self.label, self.log, self.cancel_btn = bar, label, log, cancel
        self.jobs, self.proc, self.cur, self.results = [], None, None, []
        cancel.clicked.connect(self.cancel)

    def queued_bytes(self):
        return sum(j.get("size", 0) for j in self.jobs) + (self.cur.get("size", 0) if self.cur else 0)

    def busy(self):
        return self.cur is not None

    def add(self, job):
        """job: title, src, dst, size, after=[("py", fn) | ("cmd", argv)], done=callable(ok, message)"""
        self.jobs.append(job)
        self.label.parentWidget().show()
        if not self.cur:
            self._next()

    def _next(self):
        if not self.jobs:
            self.cur = None
            self.bar.setValue(100)
            self.label.setText("All done ✓  " + "  ".join(self.results[-3:]))
            self.cancel_btn.hide()
            self.changed.emit()
            return
        self.cur = self.jobs.pop(0)
        self.cancel_btn.show()
        self.bar.setValue(0)
        self.label.setText(f"Copying {self.cur['title']}…  ({len(self.jobs)} more waiting)")
        Path(self.cur["dst"]).mkdir(parents=True, exist_ok=True)
        self._start(actions.rsync_cmd(self.cur["src"], self.cur["dst"]), self._copied)

    def _start(self, argv, finished):
        p = QProcess(self)
        env = QProcessEnvironment.systemEnvironment(); env.insert("LC_ALL", "C")
        p.setProcessEnvironment(env)
        p.setProcessChannelMode(QProcess.MergedChannels)
        buf = {"s": ""}

        def out():
            buf["s"] += bytes(p.readAllStandardOutput()).decode(errors="replace")
            *lines, buf["s"] = buf["s"].replace("\r", "\n").split("\n")
            for line in lines:
                pr = actions.parse_progress(line)
                if pr and self.cur:
                    self.bar.setValue(pr[1])
                    self.label.setText(f"Copying {self.cur['title']}…  {pr[1]}%  {human(pr[0])}  {pr[2]}  "
                                       f"~{pr[3]} left  ({len(self.jobs)} more waiting)")
                elif line.strip():
                    self.log.appendPlainText(line.rstrip())
        p.readyReadStandardOutput.connect(out)
        p.finished.connect(lambda code, _s: finished(code))
        p.errorOccurred.connect(lambda e: e == QProcess.ProcessError.FailedToStart and finished(127))
        self.proc = p
        self.log.appendPlainText("$ " + " ".join(shlex.quote(a) for a in argv))
        p.start(argv[0], argv[1:])

    def _copied(self, code):
        if self.cur is None:
            return
        if code == 127:
            return self._finish(False, "rsync is missing (sudo apt install rsync)")
        if code not in (0, 23, 24):
            return self._finish(False, f"copy failed (rsync {code}) - see details")
        self.partial = code in (23, 24)
        self._after(list(self.cur.get("after", [])))

    def _after(self, steps):
        if self.cur is None:
            return
        if not steps:
            return self._finish(True, "some files could not be read (e.g. online-only OneDrive files) - the rest is copied"
                                if self.partial else "")
        kind, what = steps.pop(0)
        if kind == "py":
            try:
                msg = what()
                if msg:
                    self.log.appendPlainText(str(msg))
            except Exception as e:
                return self._finish(False, f"{e}")
            self._after(steps)
        else:
            self.label.setText(f"Setting up {self.cur['title']}…")
            self.bar.setRange(0, 0)
            self._start(what, lambda code: (self.bar.setRange(0, 100),
                                            self._after(steps) if code == 0 else
                                            self._finish(False, "copied, but the import step failed - see details")))

    def _finish(self, ok, msg):
        job, self.cur, self.proc = self.cur, None, None
        self.results.append(("✓ " if ok else "✗ ") + job["title"])
        self.log.appendPlainText(f"— {job['title']}: {'done' if ok else 'FAILED'} {msg}")
        if job.get("done"):
            job["done"](ok, msg)
        self._next()

    def cancel(self):
        self.jobs.clear()
        if self.proc:
            self.cur = None
            self.proc.kill()
        self.label.setText("Cancelled. Copied files stay; starting the same copy again continues where it stopped.")
        self.cancel_btn.hide()
        self.bar.setRange(0, 100)


class Runner:
    def __init__(self, log):
        self.log, self.procs = log, []

    def run(self, argv, done=None):
        p = QProcess()
        p.setProcessChannelMode(QProcess.MergedChannels)
        p.readyReadStandardOutput.connect(lambda: self.log.appendPlainText(bytes(p.readAllStandardOutput()).decode(errors="replace").rstrip()))
        p.finished.connect(lambda code, _s: self._end(p, done, code))
        p.errorOccurred.connect(lambda e: e == QProcess.ProcessError.FailedToStart and self._end(p, done, 127))
        self.procs.append(p)
        self.log.appendPlainText("$ " + " ".join(argv))
        p.start(argv[0], argv[1:])

    def _end(self, p, done, code):
        if p in self.procs:
            self.procs.remove(p)
            self.log.appendPlainText(f"— finished ({code})")
            if done:
                done(code)


# ------------------------------------------------------------------ main window
class Mover(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Move from Windows")
        self.setWindowIcon(QIcon.fromTheme("phoenixge-migrate", QIcon(LOGO)))
        self.resize(1180, 780)
        self.setMinimumSize(780, 540)
        acc = accent()
        self.setStyleSheet(f"""
            QWidget {{ font-size: 13px; }}
            #sidebar {{ background: palette(alternate-base); }}
            #side {{ background: transparent; border: none; padding: 10px; }}
            #side::item {{ padding: 10px 14px; border-radius: 10px; margin: 2px 0; }}
            #side::item:selected {{ background: {acc}33; color: {acc}; }}
            #h1 {{ font-size: 26px; font-weight: 700; }}
            #h2 {{ font-size: 17px; font-weight: 700; margin-top: 8px; }}
            #dim {{ color: palette(placeholder-text); }}
            #warn {{ color: #e8a33d; }}
            #ok {{ color: #4caf50; }}
            #card {{ background: palette(alternate-base); border-radius: 14px; border: 1px solid {acc}22; }}
            #warncard {{ background: palette(alternate-base); border-radius: 14px; border: 1px solid #e8a33d; }}
            #cardTitle {{ font-size: 15px; font-weight: 600; }}
            QPushButton {{ padding: 7px 14px; border-radius: 10px; }}
            QPushButton#primary {{ background: {acc}; color: #1a0b06; font-weight: 600; border: none; }}
            QPushButton#primary:disabled {{ background: {acc}55; }}
            QProgressBar {{ border-radius: 6px; height: 12px; text-align: center; }}
            QProgressBar::chunk {{ background: {acc}; border-radius: 6px; }}
        """)
        self.bg = Bg()
        self.win = None          # winscan.Windows once a Windows partition is open
        self.parts = []
        self.mounted = {}        # device -> mountpoint
        self.scan = {}           # cached scan results
        self.installed = actions.flatpaks()

        root = QHBoxLayout(self); root.setContentsMargins(0, 0, 0, 0); root.setSpacing(0)
        side = QVBoxLayout(); side.setContentsMargins(0, 0, 0, 0)
        brand = QLabel(); brand.setPixmap(QPixmap(LOGO).scaled(56, 56, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        brand.setAlignment(Qt.AlignCenter); brand.setContentsMargins(0, 18, 0, 6)
        name = QLabel("Move from Windows"); name.setAlignment(Qt.AlignCenter); name.setStyleSheet("font-weight:700;font-size:15px;")
        self.nav = QListWidget(); self.nav.setObjectName("side"); self.nav.setIconSize(QSize(20, 20))
        self.nav.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        side.addWidget(brand); side.addWidget(name); side.addWidget(self.nav)
        sidew = QWidget(); sidew.setLayout(side); sidew.setFixedWidth(230)
        sidew.setObjectName("sidebar"); sidew.setAttribute(Qt.WA_StyledBackground, True)

        self.stack = QStackedWidget()
        right = QVBoxLayout(); right.setContentsMargins(0, 0, 0, 0); right.setSpacing(0); right.addWidget(self.stack, 1)
        # progress strip
        strip = QFrame(); strip.setObjectName("card"); sl = QVBoxLayout(strip); sl.setContentsMargins(16, 10, 16, 10)
        row = QHBoxLayout()
        self.qlabel = QLabel(""); self.qlabel.setWordWrap(True)
        self.cancel_btn = QPushButton("Cancel"); self.cancel_btn.hide()
        details = QPushButton("Details"); details.setCheckable(True)
        row.addWidget(self.qlabel, 1); row.addWidget(self.cancel_btn); row.addWidget(details)
        self.bar = QProgressBar(); self.bar.setRange(0, 100)
        self.log = QPlainTextEdit(); self.log.setReadOnly(True); self.log.setMaximumHeight(170); self.log.hide()
        details.toggled.connect(self.log.setVisible)
        sl.addLayout(row); sl.addWidget(self.bar); sl.addWidget(self.log)
        strip.hide()
        right.addWidget(strip)
        root.addWidget(sidew); root.addLayout(right, 1)

        self.queue = Queue(self.bar, self.qlabel, self.log, self.cancel_btn)
        self.runner = Runner(self.log)
        self.strip = strip

        self.pages = {}
        for key, title, icon, sub in [
                ("drive", "Windows drive", "drive-harddisk",
                 "Find Windows on this PC and open it read-only. Windows itself is never changed."),
                ("games", "Games", "applications-games",
                 "Copy installed games instead of downloading them again. Epic games go to Heroic, Steam games to Steam."),
                ("programs", "Programs", "applications-other",
                 "What you had installed on Windows, and what to use here. Most have a Linux version - one click installs it."),
                ("files", "Files & settings", "folder-documents",
                 "Your documents, pictures, music, bookmarks and wallpaper. Copies go into a \"From Windows\" folder - "
                 "nothing in your home is overwritten.")]:
            QListWidgetItem(QIcon.fromTheme(icon), title, self.nav)
            pg = Page(title if key != "drive" else "Move from Windows", sub)
            self.pages[key] = pg
            self.stack.addWidget(pg)
        self.nav.currentRowChanged.connect(self.go)
        self.fill_drive()
        self.nav.setCurrentRow(0)

    def show_strip(self):
        self.strip.show()

    def go(self, row):
        self.stack.setCurrentIndex(row)
        key = list(self.pages)[row]
        if key != "drive":
            getattr(self, "fill_" + key)()

    def need_windows(self, pg):
        if self.win:
            return False
        pg.clear()
        c = Card("Open Windows first", "Go to \"Windows drive\" and open the Windows partition.")
        c.lay.addWidget(button("Windows drive", lambda: self.nav.setCurrentRow(0), True), 0, Qt.AlignLeft)
        pg.add(c)
        return True

    def busy(self, pg, text):
        pg.clear()
        pg.add(dim(text))

    # ================================================================ drive page
    def fill_drive(self):
        pg = self.pages["drive"]
        pg.clear()
        self.parts = winscan.partitions()
        for p in self.parts:
            if p["mount"]:
                self.mounted[p["path"]] = p["mount"]
        if self.win:
            info = self.win.info()
            c = Card(f"✓ {info['name']} {info['version']} is open (read-only)",
                     f"From {self.win.mnt}. Continue with Games, Programs and Files & settings.")
            r = QHBoxLayout()
            for i, t in enumerate(("Games", "Programs", "Files & settings"), 1):
                r.addWidget(button(t, lambda i=i: self.nav.setCurrentRow(i), i == 1))
            r.addStretch(); c.lay.addLayout(r); pg.add(c)
            if winscan.hibernated(self.win.mnt):
                w = Card("Windows is not fully shut down", winscan.HIBERNATION_HELP); w.setObjectName("warncard"); pg.add(w)
        if not self.parts:
            c = Card("No Windows found on this PC",
                     "No NTFS or BitLocker partition was found. If Windows is on another disk or a USB drive, connect it "
                     "and press Look again.")
            c.lay.addWidget(button("Look again", self.fill_drive), 0, Qt.AlignLeft)
            pg.add(c)
            return
        if not self.win:
            top = Card("How it works", "1. Open the Windows drive (read-only - nothing on Windows changes).  "
                                       "2. Pick games, programs and files.  3. They're copied to PhoenixGe. "
                                       "Windows keeps working as before.")
            r = QHBoxLayout()
            r.addWidget(button("Open all Windows drives (read-only)", self.open_all, True))
            r.addWidget(button("Look again", self.fill_drive)); r.addStretch()
            top.lay.addLayout(r); pg.add(top)
        h = QLabel("Drives"); h.setObjectName("h2"); pg.add(h)
        for p in self.parts:
            pg.add(self.part_card(p))

    def part_card(self, p):
        label = p["label"] or ("BitLocker drive" if p["kind"].startswith("bitlocker") else "NTFS drive")
        c = Card(f"{label}  ·  {human(p['size'])}", f"{p['path']}  ·  {p['disk']}" + ("  ·  removable" if p["removable"] else ""))
        st = QLabel(); st.setWordWrap(True); c.lay.addWidget(st)
        r = QHBoxLayout()
        mnt = self.mounted.get(p["path"])
        if p["kind"] == "bitlocker":
            st.setText(winscan.BITLOCKER_HELP); st.setObjectName("warn")
            key = QLineEdit(); key.setPlaceholderText("Recovery key: 123456-123456-… (48 digits)")
            key.setEchoMode(QLineEdit.PasswordEchoOnEdit)
            r.addWidget(key, 1)
            r.addWidget(button("Unlock (read-only)", lambda: self.unlock(p, key.text(), st), True))
            r.addWidget(button("Get my key", lambda: QDesktopServices.openUrl(
                QUrl("https://account.microsoft.com/devices/recoverykey"))))
        elif p["kind"] == "bitlocker-open":
            st.setText("Unlocked - open the drive below it.")
        elif p["kind"] == "unknown":
            st.setText("Unknown contents - maybe encrypted with a tool Linux can't read (VeraCrypt?), or empty.")
        elif mnt:
            win = winscan.is_windows(mnt)
            st.setText(("✓ Windows - " if win else "✓ Open - ") + f"read-only at {mnt}"); st.setObjectName("ok")
            r.addWidget(button("Show files", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(mnt))))
            if win and (not self.win or str(self.win.mnt) != mnt):
                r.addWidget(button("Use this Windows", lambda: self.use_windows(mnt), True))
        else:
            st.setText("Not open yet."); st.setObjectName("dim")
            r.addWidget(button("Open (read-only)", lambda: self.open_one(p, st), True))
        r.addStretch(); c.lay.addLayout(r)
        return c

    def open_one(self, p, st=None, then=None):
        if st:
            st.setText("Opening… (the system may ask for your password)")

        def done(res):
            mnt, err = res if isinstance(res, tuple) else ("", str(res))
            if mnt:
                self.mounted[p["path"]] = mnt
            elif st:
                st.setText(err); st.setObjectName("warn"); st.setStyleSheet("color:#e8a33d")
            if then:
                then()
            elif mnt:
                self.after_mount()
        self.bg.run(lambda: winscan.mount_ro(p["path"]), done)

    def open_all(self):
        todo = [p for p in self.parts if p["kind"] == "ntfs" and not self.mounted.get(p["path"]) and p["size"] > 1 << 30]
        self.busy(self.pages["drive"], "Opening Windows drives read-only… (the system may ask for your password)")

        def step():
            if todo:
                self.open_one(todo.pop(0), then=step)
            else:
                self.after_mount()
        step()

    def after_mount(self):
        self.parts = winscan.partitions()
        for p in self.parts:
            if p["mount"]:
                self.mounted[p["path"]] = p["mount"]
        if not self.win:
            wins = [m for m in self.mounted.values() if winscan.is_windows(m)]
            if wins:
                self.use_windows(wins[0])
                return
        self.fill_drive()

    def use_windows(self, mnt):
        self.win = winscan.Windows(mnt, list(self.mounted.values()), self.parts)
        self.scan = {}
        self.fill_drive()

    def unlock(self, p, key, st):
        if len(key.strip()) < 8:
            st.setText("Enter the 48-digit recovery key first."); return
        st.setText("Unlocking… (the system may ask for your password)")

        def done(res):
            dev, err = res if isinstance(res, tuple) else ("", str(res))
            if not dev:
                st.setText(err); return
            self.parts = winscan.partitions()
            child = next((x for x in self.parts if x["path"] == dev or x["unlocked_from"] == p["path"]), None)
            if child:
                self.open_one(child)
            else:
                self.fill_drive()
        self.bg.run(lambda: winscan.unlock_bitlocker(p["path"], key), done)

    # ================================================================ games page
    def scan_games(self):
        w = self.win
        progs = w.programs()
        games = w.epic_games() + w.steam_games() + w.gog_games() + w.ubisoft_games() + w.other_launcher_games(progs)
        for g in games:
            if not g.get("size") and g.get("path"):
                g["size"] = winscan.dir_size(g["path"])
        return dict(games=games, programs=progs, store_apps=w.store_apps_note())

    def ensure_scan(self, pg, then):
        if "games" in self.scan:
            return then()
        self.busy(pg, "Reading what's installed on Windows…")

        def done(res):
            if isinstance(res, Exception):
                pg.clear(); pg.add(Card("Could not read Windows", str(res))); return
            self.scan.update(res)
            then()
        self.bg.run(self.scan_games, done)

    def fill_games(self):
        pg = self.pages["games"]
        if self.need_windows(pg):
            return
        self.ensure_scan(pg, self._games_ui)

    def _games_ui(self):
        pg = self.pages["games"]
        pg.clear()
        games = self.scan["games"]
        heroic = actions.heroic_kind()
        sroot, sflat = actions.steam_root()
        # launcher status
        st = Card("Game launchers on PhoenixGe")
        r = QHBoxLayout()
        if any(g["store"] == "Epic" for g in games):
            if not heroic:
                r.addWidget(self.flatpak_btn(actions.HEROIC_ID, "Install Heroic (for Epic)"))
            elif not actions.epic_logged_in():
                r.addWidget(dim("Heroic: log in to Epic once, then come back."))
                r.addWidget(button("Open Heroic", lambda: QProcess.startDetached(
                    "flatpak" if heroic == "flatpak" else "heroic", ["run", actions.HEROIC_ID] if heroic == "flatpak" else [])))
            else:
                ok = QLabel("Heroic ✓ logged in to Epic"); ok.setObjectName("ok"); r.addWidget(ok)
        if any(g["store"] == "Steam" for g in games):
            if not sroot:
                r.addWidget(self.flatpak_btn(actions.STEAM_ID, "Install Steam"))
            else:
                ok = QLabel(f"Steam ✓ ({'Flatpak' if sflat else 'system'})"); ok.setObjectName("ok"); r.addWidget(ok)
        r.addWidget(button("Look again", lambda: (self.scan.clear(), self.fill_games())))
        r.addStretch(); st.lay.addLayout(r); pg.add(st)

        if not games:
            pg.add(Card("No games found", "No Epic, Steam, GOG, Ubisoft, EA or Battle.net games were found on the open drives. "
                                          "Games on another drive (D:, E:) are found once that drive is open too."))
        self.game_checks = []
        for store in ("Epic", "Steam", "GOG", "Ubisoft Connect", "EA app", "Battle.net", "Riot"):
            lst = [g for g in games if g["store"] == store]
            if not lst:
                continue
            h = QLabel(store if store != "Epic" else "Epic Games"); h.setObjectName("h2"); pg.add(h)
            if store in actions.STORE_ADVICE:
                pg.add(dim(actions.STORE_ADVICE[store]))
            for g in lst:
                pg.add(self.game_row(g, heroic, sroot))
        if self.scan.get("store_apps"):
            pg.add(Card("Microsoft Store / Xbox games: can't be moved",
                        "Found: " + ", ".join(self.scan["store_apps"][:12]) +
                        ". These are encrypted Windows packages and Game Pass doesn't run on Linux. Xbox Cloud Gaming works in "
                        "the browser; many of these games are also on Steam."))
        if self.game_checks:
            bar = QHBoxLayout()
            self.games_sum = QLabel(); bar.addWidget(self.games_sum, 1)
            bar.addWidget(button("Copy selected games", self.copy_games, True))
            pg.add(bar)
            self.update_game_sum()

    def game_row(self, g, heroic, sroot):
        c = Card()
        top = QHBoxLayout()
        cb = QCheckBox(g["name"]); cb.setStyleSheet("font-weight:600;font-size:14px;")
        top.addWidget(cb, 1)
        top.addWidget(dim(human(g["size"]) if g.get("size") else ""))
        c.lay.addLayout(top)
        status = ""
        ac = appmap.suggest(g["name"])
        ok = g.get("path") is not None
        if not ok:
            status = "Game folder not found on the open drives (installed on a drive that isn't open?)."
        elif ac["verdict"] == "no":
            status = "⚠ " + ac["note"]
        elif g["store"] == "Epic":
            if actions.epic_imported(g["id"]):
                status, ok = "Already in Heroic ✓", False
            else:
                status = f"→ {tilde(actions.HEROIC_GAMES / g['folder'])}, then added to Heroic" + ("" if heroic else " (install Heroic first)")
        elif g["store"] == "Steam":
            if not sroot:
                status, ok = "Install Steam first (button above), start it once and sign in.", False
            elif (Path(sroot) / "steamapps" / Path(g["acf"]).name).exists():
                status, ok = "Already in Steam ✓", False
            else:
                status = f"→ Steam library, then Steam checks the files"
        else:
            status = f"→ {tilde(actions.other_target(g['store'], g['name']))} (then follow the tip above)"
        lab = dim(status); c.lay.addWidget(lab)
        cb.setEnabled(ok)
        cb.setChecked(ok and ac["verdict"] != "no" and g["store"] in ("Epic", "Steam"))
        cb.toggled.connect(lambda _on: self.update_game_sum())
        self.game_checks.append((cb, g, lab))
        return c

    def update_game_sum(self):
        total = sum(g.get("size", 0) for cb, g, _ in self.game_checks if cb.isChecked())
        free = winscan.free_space(actions.GAMES_DIR)
        self.games_sum.setText(f"Selected: {human(total)}  ·  free on PhoenixGe: {human(free)}")
        self.games_sum.setObjectName("warn" if total + SPACE_MARGIN > free else "dim")
        self.games_sum.setStyleSheet("color:#e8a33d" if total + SPACE_MARGIN > free else "")

    def copy_games(self):
        sel = [(cb, g, lab) for cb, g, lab in self.game_checks if cb.isChecked() and cb.isEnabled()]
        if not sel:
            return
        if not self.space_ok(sum(g.get("size", 0) for _c, g, _l in sel), actions.GAMES_DIR):
            return
        if any(g["store"] == "Steam" for _c, g, _l in sel) and actions.steam_running():
            m = QMessageBox(QMessageBox.Warning, "Close Steam", "Steam is running. It only notices the moved games after a "
                            "restart - close Steam now? (It's started again by you after copying.)", parent=self)
            close = m.addButton("Close Steam", QMessageBox.AcceptRole); m.addButton(QMessageBox.Cancel); m.exec()
            if m.clickedButton() != close:
                return
            _root, flat = actions.steam_root()
            QProcess.startDetached(*(("flatpak", ["run", actions.STEAM_ID, "-shutdown"]) if flat else ("steam", ["-shutdown"])))
        self.show_strip()
        for cb, g, lab in sel:
            cb.setEnabled(False); cb.setChecked(False)
            lab.setText("Waiting to copy…")
            job = dict(title=g["name"], src=str(g["path"]), size=g.get("size", 0),
                       done=lambda ok, msg, lab=lab, g=g: lab.setText(self.game_done_text(g, ok, msg)))
            if g["store"] == "Epic":
                dst = actions.HEROIC_GAMES / g["folder"]
                job.update(dst=str(dst), after=[("cmd", actions.heroic_import_cmd(g["id"], dst))])
            elif g["store"] == "Steam":
                root, _flat = actions.steam_root()
                job.update(dst=str(actions.steam_target(root, g["installdir"])),
                           after=[("py", lambda a=g["acf"], r=root: f"Steam manifest: {actions.steam_finish(a, r)}")])
            else:
                job.update(dst=str(actions.other_target(g["store"], g["name"])))
            self.queue.add(job)

    def game_done_text(self, g, ok, msg):
        if not ok:
            return "✗ " + msg + ("  - you can import by hand: Heroic > the game > Install > Import game." if g["store"] == "Epic" else "")
        tip = {"Epic": actions.HEROIC_AFTER, "Steam": actions.STEAM_AFTER}.get(g["store"], actions.STORE_ADVICE.get(g["store"], ""))
        return "✓ Copied. " + (msg + " " if msg else "") + tip

    def space_ok(self, need, target):
        free = winscan.free_space(target) - self.queue.queued_bytes()
        if need + SPACE_MARGIN <= free:
            return True
        QMessageBox.warning(self, "Not enough space",
                            f"This needs {human(need)}, but PhoenixGe has only {human(max(free, 0))} free "
                            f"(keeping {human(SPACE_MARGIN)} spare). Pick fewer items or free some space.")
        return False

    def flatpak_btn(self, fid, label):
        b = QPushButton(label); b.setObjectName("primary")

        def done(code):
            self.installed = actions.flatpaks()
            b.setText("Installed ✓" if code == 0 else "Retry"); b.setEnabled(code != 0)
            if code == 0:
                cur = list(self.pages)[self.nav.currentRow()]
                if cur != "drive":
                    getattr(self, "fill_" + cur)()

        def click():
            b.setEnabled(False); b.setText("Installing…"); self.show_strip(); self.log.show()
            self.runner.run(["flatpak", "install", "-y", "--noninteractive", "flathub", fid], done)
        b.clicked.connect(click)
        return b

    # ================================================================ programs page
    def fill_programs(self):
        pg = self.pages["programs"]
        if self.need_windows(pg):
            return
        self.ensure_scan(pg, self._programs_ui)

    def _programs_ui(self, query=""):
        pg = self.pages["programs"]
        pg.clear()
        progs = self.scan["programs"]
        for p in progs:
            p.setdefault("s", appmap.suggest(p["name"]))
        top = QHBoxLayout()
        search = QLineEdit(query); search.setPlaceholderText(f"Search {len(progs)} Windows programs…")
        search.returnPressed.connect(lambda: self._programs_ui(search.text()))
        top.addWidget(search, 1)
        todo = sorted({p["s"]["options"][0][1] for p in progs if p["s"]["verdict"] == "linux" and p["s"]["options"]
                       and p["s"]["options"][0][0] == "flatpak" and p["s"]["options"][0][1] not in self.installed})
        if todo:
            b = QPushButton(f"Install all {len(todo)} Linux versions"); b.setObjectName("primary")
            b.setToolTip("\n".join(todo))

            def all_done(code, b=b):
                self.installed = actions.flatpaks()
                b.setText("Done ✓" if code == 0 else "Some failed - see details"); self._programs_ui(search.text())

            def install_all(b=b):
                b.setEnabled(False); b.setText("Installing…"); self.show_strip(); self.log.show()
                self.runner.run(["flatpak", "install", "-y", "--noninteractive", "flathub", *todo], all_done)
            b.clicked.connect(install_all)
            top.addWidget(b)
        pg.add(top)
        q = query.strip().lower()
        shown = [p for p in progs if not q or q in p["name"].lower() or q in p["publisher"].lower()]
        for verdict in appmap.VERDICT_ORDER:
            lst = [p for p in shown if p["s"]["verdict"] == verdict]
            if not lst:
                continue
            h = QLabel(f"{appmap.VERDICT_LABELS[verdict]}  ({len(lst)})"); h.setObjectName("h2"); pg.add(h)
            if verdict == "windows":
                pg.add(dim("No Linux version. Small/portable programs often run with phoenix-run (Wine): \"Copy & add to menu\" "
                           "copies the program folder and makes a menu entry. Big programs with drivers, services or "
                           "licence checks usually need their installer instead (download it and double-click it here)."))
            if verdict == "notneeded":
                box = QCheckBox(f"Show {len(lst)} drivers, runtimes and tools that Linux doesn't need")
                pg.add(box)
                holder = QWidget(); hl = QVBoxLayout(holder); hl.setContentsMargins(0, 0, 0, 0); hl.setSpacing(6)
                for p in lst:
                    hl.addWidget(self.prog_row(p, compact=True))
                holder.hide(); box.toggled.connect(holder.setVisible); pg.add(holder)
                continue
            for p in lst:
                pg.add(self.prog_row(p))

    def prog_row(self, p, compact=False):
        s = p["s"]
        row = QFrame(); row.setObjectName("card")
        lay = QHBoxLayout(row); lay.setContentsMargins(16, 8 if compact else 10, 16, 8 if compact else 10)
        txt = QVBoxLayout(); txt.setSpacing(2)
        n = QLabel(p["name"]); n.setStyleSheet("font-weight:600;"); n.setWordWrap(True); txt.addWidget(n)
        meta = " · ".join(x for x in (p["publisher"], p["version"]) if x)
        if s["note"] and not compact:
            meta = (meta + "\n" if meta else "") + s["note"]
        if meta:
            txt.addWidget(dim(meta))
        lay.addLayout(txt, 1)
        if compact:
            return row
        for kind, ident, label in s["options"][:3]:
            lay.addWidget(self.option_btn(kind, ident, label))
        if s["verdict"] == "windows":
            loc = self.win.resolve(p["location"]) if p["location"] else None
            if loc and loc.is_dir() and (p["size_kb"] or 0) < 4 << 20:
                lay.addWidget(button("Copy & add to menu", lambda p=p, loc=loc: self.copy_program(p, loc)))
        return row

    def option_btn(self, kind, ident, label):
        if kind == "flatpak":
            have = ident in self.installed
            b = QPushButton(f"Open {label}" if have else f"Install {label}")
            if not have:
                b.setObjectName("primary")
            st = {"have": have}

            def done(code):
                self.installed = actions.flatpaks()
                st["have"] = code == 0
                b.setText(f"Open {label}" if code == 0 else "Retry"); b.setEnabled(True)

            def click():
                if st["have"]:
                    QProcess.startDetached("flatpak", ["run", ident]); return
                b.setEnabled(False); b.setText("Installing…"); self.show_strip(); self.log.show()
                self.runner.run(["flatpak", "install", "-y", "--noninteractive", "flathub", ident], done)
            b.clicked.connect(click)
            b.setToolTip(f"Flathub: {ident}")
            return b
        if kind == "apt":
            b = QPushButton(f"Install {label}"); b.setToolTip("Debian: " + ident)

            def click():
                b.setEnabled(False); b.setText("Installing…"); self.show_strip(); self.log.show()
                self.runner.run(["pkexec", "/bin/sh", APT, *ident.split()],
                                lambda code: (b.setText("Installed ✓" if code == 0 else "Retry"), b.setEnabled(code != 0)))
            b.clicked.connect(click)
            return b
        if kind == "run":
            argv = shlex.split(ident)
            return button(f"Open {label}", lambda: QProcess.startDetached(argv[0], argv[1:]))
        return button(f"{label} ↗", lambda: QDesktopServices.openUrl(QUrl(ident)))

    def copy_program(self, p, loc):
        size = (p["size_kb"] or 0) * 1024 or winscan.dir_size(loc)
        dst = actions.win_app_target(p["name"])
        if not self.space_ok(size, dst):
            return
        self.show_strip()

        def after():
            exe = actions.find_exe(dst, p.get("exe", ""))
            if not exe:
                raise RuntimeError("copied, but no .exe found in the folder")
            return f"Menu entry: {actions.make_win_launcher(p['name'], exe)} -> phoenix-run {exe}"
        self.queue.add(dict(title=p["name"], src=str(loc), dst=str(dst), size=size, after=[("py", after)],
                            done=lambda ok, msg: QMessageBox.information(
                                self, p["name"], (f"Copied to {dst} and added to the start menu (runs with phoenix-run). "
                                                  "If it doesn't start, it probably needs its installer - download it and "
                                                  "double-click it.") if ok else msg)))

    # ================================================================ files & settings page
    def fill_files(self):
        pg = self.pages["files"]
        if self.need_windows(pg):
            return
        users = self.win.users()
        if not users:
            pg.clear(); pg.add(Card("No Windows user folders found", f"Looked in {self.win.mnt}/Users.")); return
        self.cur_user = getattr(self, "cur_user", None) if getattr(self, "cur_user", None) in users else \
            next((u for u in users if u.lower() == os.environ.get("USER", "").lower()), users[0])
        self._files_ui(users)

    def _files_ui(self, users):
        pg = self.pages["files"]
        pg.clear()
        u = self.cur_user
        top = QHBoxLayout(); top.addWidget(QLabel("Windows user:"))
        combo = QComboBox(); combo.addItems(users); combo.setCurrentText(u)
        combo.currentTextChanged.connect(lambda t: (setattr(self, "cur_user", t), self._files_ui(users)))
        top.addWidget(combo); top.addStretch(); pg.add(top)

        # ---- folders
        fc = Card("Your folders", "Copied into the matching PhoenixGe folder, inside \"From Windows\" "
                                  "(e.g. Documents/From Windows). Copying again only adds what's new.")
        self.folder_checks = []
        grid = QGridLayout(); grid.setHorizontalSpacing(16)
        for i, (fid, label, path, note) in enumerate(self.win.user_folders(u)):
            cb = QCheckBox(label); cb.setEnabled(path is not None); cb.setChecked(path is not None and fid_default(fid))
            size = QLabel("not found" if path is None else "measuring…"); size.setObjectName("dim")
            grid.addWidget(cb, i, 0); grid.addWidget(size, i, 1)
            grid.addWidget(dim(f"→ {tilde(actions.folder_target(fid))}" + (f"   ({note})" if note else "")), i, 2)
            self.folder_checks.append([cb, fid, label, path, 0, size])
            if path is not None:
                def measured(n, entry=self.folder_checks[-1]):
                    entry[4] = n if isinstance(n, int) else 0
                    try:
                        entry[5].setText(human(entry[4]))
                    except RuntimeError:  # page was rebuilt meanwhile
                        pass
                self.bg.run(lambda p=path: winscan.dir_size(p), measured)
        grid.setColumnStretch(2, 1)
        fc.lay.addLayout(grid)
        fc.lay.addWidget(button("Copy selected folders", self.copy_folders, True), 0, Qt.AlignLeft)
        pg.add(fc)

        # ---- browsers
        br = self.win.browsers(u)
        bc = Card("Browser bookmarks",
                  "Saved as a bookmarks file in Documents/From Windows. Import it in Firefox: Bookmarks > Manage bookmarks > "
                  "Import and Backup > Import Bookmarks from HTML (Chrome/Edge: Bookmarks > Import). "
                  "Easiest for everything incl. passwords and extensions: sign in to the browser's sync (Firefox account, "
                  "Google, Microsoft). Saved passwords can't be read from the Windows drive (Windows encrypts them) - "
                  "export them in Windows as CSV if you don't use sync.")
        if not br:
            bc.lay.addWidget(dim("No Chrome, Edge, Brave, Vivaldi, Opera or Firefox profile found for this user."))
        for e in br:
            r = QHBoxLayout()
            r.addWidget(QLabel(f"{e['browser']} - {e['profile']}"), 1)
            st = dim("")
            r.addWidget(st)
            r.addWidget(button("Save bookmarks", lambda e=e, st=st: self.save_bookmarks(e, st)))
            bc.lay.addLayout(r)
        pg.add(bc)

        # ---- wallpaper
        wp = self.win.wallpaper(u)
        wc = Card("Wallpaper")
        if wp:
            r = QHBoxLayout()
            thumb = QLabel(); pm = QPixmap(str(wp))
            if not pm.isNull():
                thumb.setPixmap(pm.scaled(220, 124, Qt.KeepAspectRatio, Qt.SmoothTransformation))
            r.addWidget(thumb)
            st = dim("Your Windows desktop picture.")
            col = QVBoxLayout(); col.addWidget(st)
            col.addWidget(button("Use as wallpaper", lambda: self.use_wallpaper(wp, st), True), 0, Qt.AlignLeft)
            r.addLayout(col, 1); wc.lay.addLayout(r)
        else:
            wc.lay.addWidget(dim("No custom wallpaper found (Windows default or a slideshow)."))
        pg.add(wc)

        # ---- Wi-Fi
        wifi = self.win.wifi()
        pg.add(Card("Wi-Fi networks",
                    ("Saved on Windows: " + ", ".join(w["ssid"] for w in wifi[:20]) + ". " if wifi else "No saved Wi-Fi networks found. ") +
                    "Their passwords can't be copied: Windows encrypts them with a key that only works inside the running "
                    "Windows. To see a password, run in Windows Terminal:  netsh wlan show profile name=\"NAME\" key=clear  "
                    "- or just connect again here (click the network icon in the taskbar)."))

        # ---- honest list
        pg.add(Card("What doesn't move automatically",
                    "• Game saves outside the cloud: most Steam/Epic/GOG games sync saves; for others copy "
                    "Documents/My Games or Saved Games (Documents is above).\n"
                    "• Saved browser passwords and Windows credentials (encrypted by Windows) - use browser sync or a CSV export.\n"
                    "• Microsoft Store apps and Game Pass games.\n"
                    "• Licences/activations of paid Windows programs - deactivate on Windows first if the program has a limit.\n"
                    "• Outlook mail: export a .pst in Outlook or simply add the mail account to Thunderbird.\n"
                    "• OneDrive files that are only online - get them at onedrive.live.com."))

    def copy_folders(self):
        sel = [e for e in self.folder_checks if e[0].isChecked() and e[3] is not None]
        if not sel:
            return
        if not self.space_ok(sum(e[4] for e in sel), Path.home()):
            return
        self.show_strip()
        for cb, fid, label, path, size, lab in sel:
            cb.setChecked(False)
            lab.setText("waiting…")
            self.queue.add(dict(title=label, src=str(path), dst=str(actions.folder_target(fid)), size=size,
                                done=lambda ok, msg, lab=lab, s=size: lab.setText(
                                    (f"✓ {human(s)} copied" + (f" - {msg}" if msg else "")) if ok else f"✗ {msg}")))

    def save_bookmarks(self, e, st):
        try:
            f, n = actions.export_bookmarks(e)
            st.setText(f"✓ {n} bookmarks → {f.name}")
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(f.parent)))
        except Exception as ex:
            st.setText(f"✗ {ex}")

    def use_wallpaper(self, wp, st):
        try:
            dest, ok = actions.apply_wallpaper(wp)
            st.setText(f"✓ Set as wallpaper ({dest})" if ok else f"Copied to {dest}. Right-click the desktop > "
                                                                  "Configure Desktop to choose it.")
        except Exception as ex:
            st.setText(f"✗ {ex}")

    def closeEvent(self, e):
        if self.queue.busy():
            if QMessageBox.question(self, "Copy in progress", "Stop copying and close? Starting the same copy later "
                                                              "continues where it stopped.") != QMessageBox.Yes:
                e.ignore(); return
            self.queue.cancel()
        e.accept()


def fid_default(fid):
    """Pre-tick the usual personal folders; Downloads is often huge and full of installers."""
    return fid in ("Desktop", "Documents", "Pictures", "Music", "Videos")


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Move from Windows")
    app.setDesktopFileName("phoenixge-migrate")
    w = Mover()
    if "--page" in sys.argv:
        i = sys.argv.index("--page")
        want = sys.argv[i + 1].lower() if len(sys.argv) > i + 1 else ""
        keys = list(w.pages)
        if want in keys:
            w.nav.setCurrentRow(keys.index(want))
    w.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
