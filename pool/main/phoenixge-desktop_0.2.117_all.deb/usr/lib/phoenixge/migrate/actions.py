"""Linux side of "Move from Windows": where things go and the small steps after copying. No Qt in here.

Writes only into the user's home. Nothing here needs root.
"""
import html
import json
import os
import re
import shutil
import sqlite3
import subprocess
import tempfile
from pathlib import Path

HOME = Path.home()
HERE = Path(__file__).resolve().parent
HEROIC_ID = "com.heroicgameslauncher.hgl"
STEAM_ID = "com.valvesoftware.Steam"
GAMES_DIR = HOME / "Games"
HEROIC_GAMES = GAMES_DIR / "Heroic"  # the Heroic Flatpak may write here (--filesystem=~/Games/Heroic)
WIN_APPS = HOME / "Windows Apps"


def sh(cmd, timeout=20):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout).stdout.strip()
    except Exception:
        return ""


def flatpaks():
    return set(sh(["flatpak", "list", "--app", "--columns=application"]).split())


def xdg_dir(name):
    """XDG user dir (localized names!) - DOCUMENTS, PICTURES, MUSIC, VIDEOS, DOWNLOAD, DESKTOP."""
    p = sh(["xdg-user-dir", name])
    return Path(p) if p and p != str(HOME) else HOME / name.capitalize()


FOLDER_XDG = {"Desktop": "DESKTOP", "Documents": "DOCUMENTS", "Pictures": "PICTURES", "Music": "MUSIC",
              "Videos": "VIDEOS", "Downloads": "DOWNLOAD"}


def folder_target(fid):
    """Windows folder -> '<Linux folder>/From Windows' (never mixed into / overwriting existing files)."""
    return xdg_dir(FOLDER_XDG[fid]) / "From Windows"


def safe_name(s):
    s = re.sub(r"[^\w .+()-]", "_", s).strip(" .")
    return s or "game"


# ------------------------------------------------------------------ Steam
def steam_root():
    """(root, is_flatpak) of the Linux Steam, or (None, None). Prefers the Flatpak if both exist."""
    cands = [(HOME / ".var/app/com.valvesoftware.Steam/.local/share/Steam", True),
             (HOME / ".local/share/Steam", False), (HOME / ".steam/debian-installation", False), (HOME / ".steam/steam", False)]
    for root, flat in cands:
        if (root / "steamapps").is_dir() or (root / "steam.sh").exists() or (root / "ubuntu12_32").is_dir():
            return root.resolve(), flat
    if STEAM_ID in flatpaks():  # installed but never started: create the library folder it will use
        return cands[0]
    return None, None


def steam_running():
    return bool(sh(["pgrep", "-x", "steam"])) or bool(sh(["pgrep", "-f", "ubuntu12_32/steam"]))


def steam_target(root, installdir):
    return Path(root) / "steamapps/common" / installdir


def steam_finish(acf_src, root):
    """Put the Windows appmanifest next to the copied game so Steam sees it as installed and only verifies it."""
    sa = Path(root) / "steamapps"
    sa.mkdir(parents=True, exist_ok=True)
    text = Path(acf_src).read_text(encoding="utf-8", errors="replace")
    # Windows paths in the manifest mean nothing here; Steam rewrites them. Make it check the files on next start.
    text = re.sub(r'(\n\s*"LauncherPath"\s*)"[^"]*"', r'\1""', text)
    dst = sa / Path(acf_src).name
    dst.write_text(text, encoding="utf-8")
    return dst


STEAM_AFTER = ("Start Steam: it finds the game and checks the files (\"Verifying\"), then downloads only what is missing. "
               "Windows-only games use Proton automatically. If Steam wants to download the whole game, open the game's "
               "Properties > Compatibility, tick \"Force the use of a specific Steam Play tool\" (Proton), restart Steam. "
               "Games with a native Linux version download their Linux files instead.")


# ------------------------------------------------------------------ Heroic (Epic)
def heroic_kind():
    """'flatpak' | 'native' | None"""
    if HEROIC_ID in flatpaks():
        return "flatpak"
    if shutil.which("heroic") or Path("/opt/Heroic/heroic").exists():
        return "native"
    return None


def heroic_config():
    flat = HOME / ".var/app/com.heroicgameslauncher.hgl/config/heroic"
    return flat if flat.exists() or heroic_kind() == "flatpak" else HOME / ".config/heroic"


def legendary_config():
    for p in (heroic_config() / "legendaryConfig/legendary", HOME / ".config/legendary"):
        if (p / "user.json").exists():
            return p
    return heroic_config() / "legendaryConfig/legendary"


def epic_logged_in():
    return (legendary_config() / "user.json").exists()


def epic_imported(app_name):
    try:
        return app_name in json.loads((legendary_config() / "installed.json").read_text())
    except Exception:
        return False


def heroic_import_cmd(app_name, path):
    return ["sh", str(HERE / "heroic-import.sh"), app_name, str(path)]


HEROIC_AFTER = ("Open Heroic: the game is in your library as installed. Heroic sets up Wine/Proton on the first start. "
                "If Heroic was open, close it completely and start it again (or Library > Refresh).")


# ------------------------------------------------------------------ advice for launchers we can't import
STORE_ADVICE = {
    "GOG": "Heroic can take over the copied folder: Heroic > log in to GOG > the game > Install > \"Import game\" > "
           "choose the copied folder.",
    "Ubisoft Connect": "Install Ubisoft Connect with Lutris (lutris.net, 'Ubisoft Connect'), copy the game into that Wine "
                       "prefix's 'Program Files (x86)/Ubisoft/Ubisoft Game Launcher/games' and use 'Locate installed game'.",
    "EA app": "Install the EA app through Lutris; in the EA app use 'Locate game' on the copied folder. Many EA games work "
              "better from Steam if you own them there. Games with EA Javelin anti-cheat (Battlefield 6/2042, FC) don't run on Linux.",
    "Battle.net": "Install Battle.net with Lutris, copy the game into its prefix and use 'Locate the game' in Battle.net.",
    "Riot": "Valorant and League of Legends use the Vanguard kernel anti-cheat - they can't run on Linux.",
}


def other_target(store, name):
    return GAMES_DIR / safe_name(store) / safe_name(name)


# ------------------------------------------------------------------ Windows programs (portable copy + phoenix-run)
def win_app_target(name):
    return WIN_APPS / safe_name(name)


def make_win_launcher(name, exe):
    """Start-menu entry that opens a copied Windows program with phoenix-run."""
    apps = HOME / ".local/share/applications"
    apps.mkdir(parents=True, exist_ok=True)
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "app"
    f = apps / f"phoenixge-win-{slug}.desktop"
    # Desktop Entry spec: quote-level escaping of " ` $ \, then string-level escaping of \, and %% for a literal %
    q = re.sub(r'([\\"`$])', r"\\\1", str(exe)).replace("\\", "\\\\").replace("%", "%%")
    f.write_text("[Desktop Entry]\nType=Application\n"
                 f"Name={name}\nComment=Windows program (moved from Windows, runs with phoenix-run)\n"
                 f'Exec=phoenix-run "{q}"\nIcon=wine\nCategories=Wine;\nTerminal=false\n', encoding="utf-8")
    return f


def find_exe(folder, hint=""):
    """The program's main .exe inside a copied folder (by the Windows DisplayIcon name, else the biggest exe)."""
    folder = Path(folder)
    if hint:
        want = hint.replace("\\", "/").rsplit("/", 1)[-1].lower()
        for p in folder.rglob("*"):
            if p.name.lower() == want and p.is_file():
                return p
    exes = [p for p in folder.rglob("*.exe") if p.is_file() and not re.search(r"unins|setup|update|crash|helper|install", p.name, re.I)]
    return max(exes, key=lambda p: p.stat().st_size, default=None)


# ------------------------------------------------------------------ bookmarks
def chromium_bookmarks(path):
    """Chrome/Edge 'Bookmarks' JSON -> tree [{title, url} | {title, children}]."""
    data = json.loads(Path(path).read_text(encoding="utf-8", errors="replace"))

    def conv(n):
        if n.get("type") == "url":
            return dict(title=n.get("name") or n.get("url"), url=n.get("url"))
        return dict(title=n.get("name") or "", children=[conv(c) for c in n.get("children", [])])
    roots = data.get("roots", {})
    names = {"bookmark_bar": "Bookmarks bar", "other": "Other bookmarks", "synced": "Mobile bookmarks"}
    return [dict(title=names.get(k, k), children=conv(v)["children"]) for k, v in roots.items()
            if isinstance(v, dict) and v.get("children")]


def firefox_bookmarks(places):
    """places.sqlite (copied to a temp dir first: the source is read-only and may have a -wal file) -> tree."""
    with tempfile.TemporaryDirectory() as td:
        for suffix in ("", "-wal"):
            src = Path(str(places) + suffix)
            if src.exists():
                shutil.copy2(src, Path(td) / ("places.sqlite" + suffix))
        con = sqlite3.connect(Path(td) / "places.sqlite")
        try:
            rows = con.execute("SELECT b.id, b.parent, b.type, b.title, p.url, b.position FROM moz_bookmarks b "
                               "LEFT JOIN moz_places p ON p.id = b.fk ORDER BY b.parent, b.position").fetchall()
        finally:
            con.close()
    kids = {}
    for bid, parent, typ, title, url, _pos in rows:
        kids.setdefault(parent, []).append((bid, typ, title, url))

    def build(pid, depth=0):
        out = []
        for bid, typ, title, url in kids.get(pid, []):
            if typ == 1 and url and not url.startswith("place:"):
                out.append(dict(title=title or url, url=url))
            elif typ == 2 and depth < 30:
                ch = build(bid, depth + 1)
                if ch:
                    out.append(dict(title=title or "", children=ch))
        return out
    names = {"toolbar": "Bookmarks toolbar", "menu": "Bookmarks menu", "unfiled": "Other bookmarks", "mobile": "Mobile bookmarks"}
    out = []
    for bid, typ, title, url in kids.get(1, []):  # 1 = root; its children: menu, toolbar, tags, unfiled, mobile
        if title == "tags":
            continue
        ch = build(bid)
        if ch:
            out.append(dict(title=names.get(title, title), children=ch))
    return out


def count_links(tree):
    return sum(count_links(n["children"]) if "children" in n else 1 for n in tree)


def bookmarks_html(tree, title="Bookmarks"):
    """Netscape bookmark file - every browser imports it (Firefox: Bookmarks > Manage > Import and Backup > Import HTML)."""
    out = ["<!DOCTYPE NETSCAPE-Bookmark-file-1>",
           '<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">',
           f"<TITLE>{html.escape(title)}</TITLE>", f"<H1>{html.escape(title)}</H1>", "<DL><p>"]

    def emit(nodes, ind):
        for n in nodes:
            if "children" in n:
                out.append(f"{ind}<DT><H3>{html.escape(n['title'])}</H3>")
                out.append(f"{ind}<DL><p>")
                emit(n["children"], ind + "    ")
                out.append(f"{ind}</DL><p>")
            else:
                out.append(f'{ind}<DT><A HREF="{html.escape(n["url"], quote=True)}">{html.escape(n["title"])}</A>')
    emit(tree, "    ")
    out.append("</DL><p>")
    return "\n".join(out) + "\n"


def export_bookmarks(entry):
    """Browser entry from winscan.Windows.browsers() -> written HTML file path, link count."""
    tree = firefox_bookmarks(entry["bookmarks"]) if entry["kind"] == "firefox" else chromium_bookmarks(entry["bookmarks"])
    dest = xdg_dir("DOCUMENTS") / "From Windows"
    dest.mkdir(parents=True, exist_ok=True)
    f = dest / safe_name(f"Bookmarks - {entry['browser']} ({entry['profile']}).html")
    f.write_text(bookmarks_html(tree, f"{entry['browser']} bookmarks"), encoding="utf-8")
    return f, count_links(tree)


# ------------------------------------------------------------------ wallpaper
def apply_wallpaper(src):
    head = Path(src).read_bytes()[:8]
    ext = ".png" if head.startswith(b"\x89PNG") else ".bmp" if head.startswith(b"BM") else ".jpg"
    dest = xdg_dir("PICTURES") / f"Windows wallpaper{ext}"
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dest)
    ok = subprocess.run(["plasma-apply-wallpaperimage", str(dest)], capture_output=True).returncode == 0 \
        if shutil.which("plasma-apply-wallpaperimage") else False
    return dest, ok


# ------------------------------------------------------------------ rsync
def rsync_cmd(src, dst):
    """Copy a folder (contents of src into dst). No symlinks/permissions from NTFS; resumable; progress for the UI."""
    return ["rsync", "-rt", "--partial", "--info=progress2", "--no-inc-recursive", "--chmod=Du=rwx,Dgo=rx,Fu=rw,Fgo=r",
            "--exclude=System Volume Information", "--exclude=$RECYCLE.BIN", "--exclude=desktop.ini", "--exclude=Thumbs.db",
            str(src).rstrip("/") + "/", str(dst)]


PROGRESS_RE = re.compile(r"^\s*([\d,.]+)\s+(\d+)%\s+(\S+/s)\s+(\d+:\d+:\d+)")


def parse_progress(line):
    """'  1,234,567  12%  10.50MB/s  0:01:23 (xfr#…)' -> (bytes, percent, speed, eta) or None."""
    m = PROGRESS_RE.match(line)
    if not m:
        return None
    return int(re.sub(r"[,.]", "", m.group(1))), int(m.group(2)), m.group(3), m.group(4)
