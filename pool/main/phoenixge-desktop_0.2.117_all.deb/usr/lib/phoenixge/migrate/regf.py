"""Tiny read-only parser for Windows registry hive files (regf), pure Python, no dependencies.

Enough for the migration wizard: open SOFTWARE / SYSTEM / NTUSER.DAT from an (offline, read-only) Windows
partition, walk keys, read values. Transaction logs (.LOG1/.LOG2) are NOT replayed: on a hibernated or
crashed Windows the very latest changes may be missing - fine for "which programs are installed".

    hive = Hive("/media/me/Windows/Windows/System32/config/SOFTWARE")
    key = hive.open(r"Microsoft\\Windows\\CurrentVersion\\Uninstall")
    for sub in key.subkeys(): print(sub.name, sub.value("DisplayName"))
"""
import struct

REG_NONE, REG_SZ, REG_EXPAND_SZ, REG_BINARY, REG_DWORD, REG_DWORD_BE, REG_LINK, REG_MULTI_SZ = 0, 1, 2, 3, 4, 5, 6, 7
REG_QWORD = 11
HBIN = 0x1000  # cell offsets are relative to the first hive bin


class HiveError(Exception):
    pass


def _name(raw, compressed):
    return raw.decode("latin-1") if compressed else raw.decode("utf-16-le", "replace")


def _sz(data):
    s = data.decode("utf-16-le", "replace") if len(data) % 2 == 0 else data[:-1].decode("utf-16-le", "replace")
    return s.split("\x00", 1)[0]


class Hive:
    def __init__(self, path):
        with open(path, "rb") as f:
            self.buf = f.read()
        if self.buf[:4] != b"regf" or len(self.buf) < HBIN + 32:
            raise HiveError(f"{path}: not a registry hive")
        self.minor = struct.unpack_from("<I", self.buf, 0x18)[0]
        self.root_off = struct.unpack_from("<I", self.buf, 0x24)[0]

    def cell(self, off):
        """Return the data of the cell at hive offset `off` (without its 4 byte size field)."""
        pos = HBIN + off
        if off in (0, 0xFFFFFFFF) or pos + 4 > len(self.buf):
            raise HiveError(f"bad cell offset {off:#x}")
        size = struct.unpack_from("<i", self.buf, pos)[0]
        size = -size if size < 0 else size  # negative = allocated (normal); tolerate free cells too
        if size < 4 or pos + size > len(self.buf):
            raise HiveError(f"bad cell size at {off:#x}")
        return memoryview(self.buf)[pos + 4: pos + size]

    def root(self):
        return Key(self, self.root_off)

    def open(self, path):
        """Key by backslash path relative to the root (case-insensitive), or None."""
        k = self.root()
        for part in [p for p in path.replace("/", "\\").split("\\") if p]:
            k = k.subkey(part)
            if k is None:
                return None
        return k


class Key:
    def __init__(self, hive, off):
        self.hive, self.off = hive, off
        d = hive.cell(off)
        if bytes(d[:2]) != b"nk":
            raise HiveError(f"no nk record at {off:#x}")
        self._d = d
        flags = struct.unpack_from("<H", d, 2)[0]
        self.n_sub, = struct.unpack_from("<I", d, 20)
        self.sub_off, = struct.unpack_from("<I", d, 28)
        self.n_val, = struct.unpack_from("<I", d, 36)
        self.val_off, = struct.unpack_from("<I", d, 40)
        nlen, = struct.unpack_from("<H", d, 72)
        self.name = _name(bytes(d[76:76 + nlen]), flags & 0x20)

    def __repr__(self):
        return f"<Key {self.name}>"

    # ---- subkeys
    def _list_offsets(self, off, depth=0):
        if depth > 4:
            return []
        d = self.hive.cell(off)
        sig = bytes(d[:2])
        n, = struct.unpack_from("<H", d, 2)
        if sig in (b"lf", b"lh"):
            return [struct.unpack_from("<I", d, 4 + i * 8)[0] for i in range(n)]
        if sig == b"li":
            return [struct.unpack_from("<I", d, 4 + i * 4)[0] for i in range(n)]
        if sig == b"ri":
            out = []
            for i in range(n):
                out += self._list_offsets(struct.unpack_from("<I", d, 4 + i * 4)[0], depth + 1)
            return out
        raise HiveError(f"unknown subkey list {sig!r}")

    def subkeys(self):
        if not self.n_sub or self.sub_off in (0, 0xFFFFFFFF):
            return []
        out = []
        for o in self._list_offsets(self.sub_off):
            try:
                out.append(Key(self.hive, o))
            except HiveError:
                continue
        return out

    def subkey(self, name):
        low = name.lower()
        for k in self.subkeys():
            if k.name.lower() == low:
                return k
        return None

    # ---- values
    def _values(self):
        if not self.n_val or self.val_off in (0, 0xFFFFFFFF):
            return []
        lst = self.hive.cell(self.val_off)
        out = []
        for i in range(min(self.n_val, len(lst) // 4)):
            try:
                out.append(_Value(self.hive, struct.unpack_from("<I", lst, i * 4)[0]))
            except HiveError:
                continue
        return out

    def values(self):
        """dict name -> python value (str, int, list[str] or bytes). Default value is under ''."""
        out = {}
        for v in self._values():
            try:
                out[v.name] = v.value()
            except HiveError:
                pass
        return out

    def value(self, name, default=None):
        low = name.lower()
        for v in self._values():
            if v.name.lower() == low:
                try:
                    return v.value()
                except HiveError:
                    return default
        return default


class _Value:
    def __init__(self, hive, off):
        self.hive = hive
        d = hive.cell(off)
        if bytes(d[:2]) != b"vk":
            raise HiveError(f"no vk record at {off:#x}")
        nlen, = struct.unpack_from("<H", d, 2)
        self.size, self.data_off, self.type = struct.unpack_from("<III", d, 4)
        flags, = struct.unpack_from("<H", d, 16)
        self.name = _name(bytes(d[20:20 + nlen]), flags & 1)
        self._d = d

    def raw(self):
        size = self.size
        if size & 0x80000000:  # data stored in the offset field itself
            return bytes(self._d[8:8 + (size & 0x7FFFFFFF)])[:4]
        if size == 0:
            return b""
        d = self.hive.cell(self.data_off)
        if size > 16344 and self.hive.minor >= 4 and bytes(d[:2]) == b"db":  # big data: list of segments
            n, seg_list = struct.unpack_from("<HI", d, 2)
            segs = self.hive.cell(seg_list)
            out = b""
            for i in range(n):
                part = self.hive.cell(struct.unpack_from("<I", segs, i * 4)[0])
                out += bytes(part[:16344])
            return out[:size]
        return bytes(d[:size])

    def value(self):
        data, t = self.raw(), self.type
        if t in (REG_SZ, REG_EXPAND_SZ, REG_LINK):
            return _sz(data)
        if t == REG_MULTI_SZ:
            s = data.decode("utf-16-le", "replace")
            return [x for x in s.split("\x00") if x]
        if t == REG_DWORD and len(data) >= 4:
            return struct.unpack_from("<I", data)[0]
        if t == REG_DWORD_BE and len(data) >= 4:
            return struct.unpack_from(">I", data)[0]
        if t == REG_QWORD and len(data) >= 8:
            return struct.unpack_from("<Q", data)[0]
        return data
