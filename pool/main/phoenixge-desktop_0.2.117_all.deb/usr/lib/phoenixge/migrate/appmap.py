"""Windows program -> what to use on PhoenixGe. Curated, honest.

Each rule: (regex on the Windows DisplayName, verdict, [options], note)
  verdict  linux    = same app or a very good replacement exists for Linux
           windows  = no Linux version; the Windows version may run with phoenix-run / Bottles
           builtin  = already part of PhoenixGe, nothing to install
           notneeded= drivers, runtimes, Windows-only tools - Linux does this itself
           no       = can't move (kernel anti-cheat, Windows-only system tool, no working alternative)
  option   (kind, id, label)  kind: flatpak (Flathub id) | apt (Debian packages) | run (command to open) | web (URL)
First matching rule wins, so put specific names before generic ones.
"""
import re

F, A, R, W = "flatpak", "apt", "run", "web"

RULES = [
    # ---------------- browsers
    (r"google chrome", "linux", [(F, "com.google.Chrome", "Google Chrome")], "Sign in to Chrome to get bookmarks, passwords and extensions back."),
    (r"microsoft edge(?! webview| update)", "linux", [(F, "com.microsoft.Edge", "Microsoft Edge")], "Sign in to Edge to sync everything."),
    (r"mozilla firefox|^firefox", "builtin", [(R, "firefox-esr", "Firefox"), (F, "org.mozilla.firefox", "Firefox (newest)")],
     "Firefox is built in. Sign in to Firefox Sync, or import bookmarks on the Files & settings page."),
    (r"brave", "linux", [(F, "com.brave.Browser", "Brave")], ""),
    (r"opera gx|^opera", "linux", [(F, "com.opera.Opera", "Opera")], "Opera GX itself has no Linux version; normal Opera does."),
    (r"vivaldi", "linux", [(F, "com.vivaldi.Vivaldi", "Vivaldi")], ""),
    (r"tor browser", "linux", [(F, "org.torproject.torbrowser-launcher", "Tor Browser")], ""),
    # ---------------- chat & calls
    (r"discord", "linux", [(F, "com.discordapp.Discord", "Discord")], ""),
    (r"telegram", "linux", [(F, "org.telegram.desktop", "Telegram")], ""),
    (r"viber", "linux", [(F, "com.viber.Viber", "Viber")], ""),
    (r"whatsapp", "linux", [(F, "com.rtosta.zapzap", "ZapZap (WhatsApp)"), (W, "https://web.whatsapp.com", "WhatsApp Web")],
     "No official WhatsApp app for Linux; ZapZap wraps WhatsApp Web."),
    (r"^signal\b(?!rgb)", "linux", [(F, "org.signal.Signal", "Signal")], ""),
    (r"^zoom|zoom workplace", "linux", [(F, "us.zoom.Zoom", "Zoom")], ""),
    (r"microsoft teams|^teams", "linux", [(F, "com.github.IsmaelMartinez.teams_for_linux", "Teams for Linux"),
                                          (W, "https://teams.microsoft.com", "Teams in the browser")],
     "Microsoft dropped the Teams Linux app; the community app or the browser work."),
    (r"skype", "linux", [(W, "https://teams.live.com", "Teams (free)")], "Skype was shut down by Microsoft in 2025."),
    (r"slack", "linux", [(F, "com.slack.Slack", "Slack")], ""),
    (r"^element\b", "linux", [(F, "im.riot.Riot", "Element")], ""),
    (r"teamspeak", "linux", [(F, "com.teamspeak.TeamSpeak3", "TeamSpeak")], ""),
    (r"mumble", "linux", [(F, "info.mumble.Mumble", "Mumble")], ""),
    (r"thunderbird", "linux", [(F, "org.mozilla.Thunderbird", "Thunderbird")], "Copy the profile or just add your mail account again."),
    (r"outlook|mailbird|em client", "linux", [(F, "org.mozilla.Thunderbird", "Thunderbird"), (W, "https://outlook.live.com", "Outlook on the web")], ""),
    # ---------------- office & documents
    (r"microsoft (office|365)|office 16|microsoft word|microsoft excel|microsoft powerpoint", "linux",
     [(F, "org.onlyoffice.desktopeditors", "ONLYOFFICE (looks like Office)"), (F, "org.libreoffice.LibreOffice", "LibreOffice"),
      (W, "https://www.office.com", "Office on the web (free)")],
     "Microsoft Office has no Linux version. ONLYOFFICE opens .docx/.xlsx/.pptx best; Office on the web is the real thing."),
    (r"wps office", "linux", [(F, "com.wps.Office", "WPS Office")], ""),
    (r"libreoffice", "linux", [(F, "org.libreoffice.LibreOffice", "LibreOffice")], ""),
    (r"onlyoffice", "linux", [(F, "org.onlyoffice.desktopeditors", "ONLYOFFICE")], ""),
    (r"adobe acrobat|acrobat reader|foxit|pdf-xchange|sumatra", "builtin", [(R, "okular", "Okular (PDF)")],
     "Okular is built in: read, fill forms, sign and annotate PDFs."),
    (r"notepad\+\+", "builtin", [(R, "kate", "Kate"), (F, "com.github.dail8859.NotepadNext", "NotepadNext (Notepad++ look)")], ""),
    (r"sublime text", "linux", [(F, "com.sublimehq.SublimeText", "Sublime Text")], ""),
    (r"obsidian", "linux", [(F, "md.obsidian.Obsidian", "Obsidian")], "Copy your vault folder (Files & settings) and open it."),
    (r"notion", "linux", [(W, "https://www.notion.so", "Notion in the browser")], "No official Linux app."),
    (r"evernote", "linux", [(W, "https://www.evernote.com", "Evernote web")], ""),
    (r"todoist", "linux", [(F, "com.todoist.Todoist", "Todoist")], ""),
    (r"calibre", "linux", [(F, "com.calibre_ebook.calibre", "calibre")], ""),
    (r"zotero", "linux", [(F, "org.zotero.Zotero", "Zotero")], ""),
    (r"\banki\b", "linux", [(F, "net.ankiweb.Anki", "Anki")], ""),
    (r"geogebra", "linux", [(F, "org.geogebra.GeoGebra", "GeoGebra")], ""),
    (r"kindle", "linux", [(F, "com.calibre_ebook.calibre", "calibre"), (W, "https://read.amazon.com", "Kindle Cloud Reader")], ""),
    # ---------------- media
    (r"spotify", "linux", [(F, "com.spotify.Client", "Spotify")], ""),
    (r"vlc", "builtin", [(R, "vlc", "VLC")], ""),
    (r"potplayer|mpc-hc|mpc-be|kmplayer|gom player|k-lite", "builtin", [(R, "vlc", "VLC"), (F, "io.mpv.Mpv", "mpv")],
     "VLC plays everything; codecs are built in, no codec packs needed."),
    (r"itunes|apple music", "linux", [(F, "org.strawberrymusicplayer.strawberry", "Strawberry"), (W, "https://music.apple.com", "Apple Music web")], ""),
    (r"foobar2000|winamp|aimp|musicbee|mediamonkey", "linux", [(F, "org.strawberrymusicplayer.strawberry", "Strawberry"), (R, "elisa", "Elisa")], ""),
    (r"\bkodi\b", "linux", [(F, "tv.kodi.Kodi", "Kodi")], ""),
    (r"\bplex\b", "linux", [(F, "tv.plex.PlexDesktop", "Plex")], ""),
    (r"obs studio", "linux", [(F, "com.obsproject.Studio", "OBS Studio")], "Scenes: export them in Windows OBS (Scene Collection > Export)."),
    (r"audacity", "linux", [(F, "org.audacityteam.Audacity", "Audacity")], ""),
    (r"handbrake", "linux", [(F, "fr.handbrake.ghb", "HandBrake")], ""),
    (r"shotcut", "linux", [(F, "org.shotcut.Shotcut", "Shotcut")], ""),
    (r"davinci resolve", "linux", [(W, "https://www.blackmagicdesign.com/products/davinciresolve", "DaVinci Resolve for Linux")],
     "Resolve has an official Linux version (needs an NVIDIA card)."),
    (r"premiere|vegas|filmora|capcut|camtasia|powerdirector", "linux",
     [(F, "org.kde.kdenlive", "Kdenlive"), (F, "org.shotcut.Shotcut", "Shotcut")], "Projects don't convert; finished videos open fine."),
    (r"after effects", "linux", [(F, "fr.natron.Natron", "Natron"), (F, "org.blender.Blender", "Blender")], "No Linux version; these are the closest."),
    (r"fl studio|ableton|cubase|reaper", "windows", [(F, "fm.reaper.Reaper", "REAPER (has a Linux version)"), (F, "com.bitwig.BitwigStudio", "Bitwig Studio"),
                                                    (F, "io.lmms.LMMS", "LMMS")],
     "FL Studio/Ableton/Cubase: no Linux version (FL Studio runs fairly well with Wine/Bottles)."),
    (r"deezer|tidal", "linux", [(W, "https://www.deezer.com", "Web player")], ""),
    # ---------------- graphics & design
    (r"photoshop", "linux", [(F, "org.kde.krita", "Krita"), (F, "org.gimp.GIMP", "GIMP"), (W, "https://www.photopea.com", "Photopea (opens .psd)")],
     "No Photoshop for Linux. Photopea in the browser looks and works like it and opens .psd files."),
    (r"lightroom", "linux", [(F, "org.darktable.Darktable", "darktable"), (F, "com.rawtherapee.RawTherapee", "RawTherapee")], ""),
    (r"illustrator|coreldraw|affinity designer", "linux", [(F, "org.inkscape.Inkscape", "Inkscape")], ""),
    (r"indesign|affinity publisher", "linux", [(F, "net.scribus.Scribus", "Scribus")], ""),
    (r"affinity photo", "linux", [(F, "org.kde.krita", "Krita"), (F, "org.gimp.GIMP", "GIMP")], ""),
    (r"paint\.net|paintshop", "linux", [(F, "com.github.PintaProject.Pinta", "Pinta"), (F, "org.kde.krita", "Krita")], ""),
    (r"\bgimp\b", "linux", [(F, "org.gimp.GIMP", "GIMP")], ""),
    (r"krita", "linux", [(F, "org.kde.krita", "Krita")], ""),
    (r"inkscape", "linux", [(F, "org.inkscape.Inkscape", "Inkscape")], ""),
    (r"blender", "linux", [(F, "org.blender.Blender", "Blender")], ""),
    (r"figma", "linux", [(W, "https://www.figma.com", "Figma in the browser"), (F, "com.authormore.penpotdesktop", "Penpot")], ""),
    (r"\bcanva\b", "linux", [(W, "https://www.canva.com", "Canva in the browser")], ""),
    (r"irfanview|xnview|faststone|honeyview|picasa", "builtin", [(R, "gwenview", "Gwenview")], ""),
    (r"autocad|draftsight|sketchup|fusion 360|solidworks|revit|3ds max", "linux",
     [(F, "org.freecad.FreeCAD", "FreeCAD"), (F, "org.librecad.librecad", "LibreCAD")],
     "These have no Linux version and don't run well in Wine. FreeCAD / LibreCAD read DWG/DXF/STEP."),
    # ---------------- development
    (r"microsoft visual studio code|^visual studio code", "linux", [(F, "com.visualstudio.code", "VS Code")],
     "Turn on Settings Sync in Windows VS Code (or sign in here) to get extensions and settings."),
    (r"visual studio (community|professional|enterprise|build tools|installer)|^microsoft visual studio \d", "linux",
     [(F, "com.jetbrains.Rider", "JetBrains Rider (.NET)"), (F, "com.visualstudio.code", "VS Code")],
     "Visual Studio (not Code) is Windows-only."),
    (r"^cursor\b", "linux", [(W, "https://www.cursor.com/downloads", "Cursor (AppImage)")], ""),
    (r"intellij idea community", "linux", [(F, "com.jetbrains.IntelliJ-IDEA-Community", "IntelliJ IDEA CE")], ""),
    (r"intellij idea", "linux", [(F, "com.jetbrains.IntelliJ-IDEA-Ultimate", "IntelliJ IDEA Ultimate")], ""),
    (r"pycharm community", "linux", [(F, "com.jetbrains.PyCharm-Community", "PyCharm CE")], ""),
    (r"pycharm", "linux", [(F, "com.jetbrains.PyCharm-Professional", "PyCharm Professional")], ""),
    (r"webstorm", "linux", [(F, "com.jetbrains.WebStorm", "WebStorm")], ""),
    (r"jetbrains rider|^rider\b", "linux", [(F, "com.jetbrains.Rider", "Rider")], ""),
    (r"clion", "linux", [(F, "com.jetbrains.CLion", "CLion")], ""),
    (r"android studio", "linux", [(F, "com.google.AndroidStudio", "Android Studio")], ""),
    (r"unity hub|^unity \d", "linux", [(F, "com.unity.UnityHub", "Unity Hub")], ""),
    (r"godot", "linux", [(F, "org.godotengine.Godot", "Godot")], ""),
    (r"epic games launcher", "linux", [(F, "com.heroicgameslauncher.hgl", "Heroic (Epic + GOG)")],
     "Your Epic games can be moved on the Games page."),
    (r"github desktop", "linux", [(F, "io.github.shiftey.Desktop", "GitHub Desktop")], ""),
    (r"^git( version|$)|git for windows", "linux", [(A, "git", "git")], ""),
    (r"^python \d|python launcher", "builtin", [(R, "konsole", "python3 in the Terminal")], "Python 3 is built in."),
    (r"node\.js", "linux", [(A, "nodejs npm", "Node.js")], ""),
    (r"java\b|jdk|jre|openjdk|temurin", "linux", [(A, "default-jdk", "Java (OpenJDK)")], ""),
    (r"docker desktop", "linux", [(A, "docker.io docker-compose", "Docker"), (F, "io.podman_desktop.PodmanDesktop", "Podman Desktop")], ""),
    (r"postman", "linux", [(F, "com.getpostman.Postman", "Postman")], ""),
    (r"dbeaver|heidisql|mysql workbench|navicat|sql server management", "linux", [(F, "io.dbeaver.DBeaverCommunity", "DBeaver")], ""),
    (r"xampp|wamp|laragon", "linux", [(A, "apache2 mariadb-server php libapache2-mod-php php-mysql", "Apache + MariaDB + PHP")], ""),
    (r"arduino", "linux", [(F, "cc.arduino.IDE2", "Arduino IDE")], ""),
    (r"putty|mobaxterm|termius|kitty", "builtin", [(R, "konsole", "Terminal (ssh built in)"), (A, "putty", "PuTTY")], ""),
    (r"winscp|cyberduck", "builtin", [(R, "dolphin", "Dolphin (type sftp://server)"), (F, "org.filezillaproject.Filezilla", "FileZilla")], ""),
    (r"filezilla", "linux", [(F, "org.filezillaproject.Filezilla", "FileZilla")], ""),
    (r"wireshark", "linux", [(F, "org.wireshark.Wireshark", "Wireshark")], ""),
    (r"nmap|zenmap|burp suite|metasploit", "linux", [(R, "phoenix-toolbox", "Kali Toolbox")], "Security tools are in the Kali Toolbox."),
    (r"virtualbox|vmware (workstation|player)", "linux", [(F, "org.gnome.Boxes", "GNOME Boxes"), (A, "virt-manager", "virt-manager")], ""),
    (r"windows subsystem for linux|^wsl", "notneeded", [], "You're on Linux now."),
    (r"matlab", "linux", [(F, "org.octave.Octave", "GNU Octave"), (W, "https://www.mathworks.com/downloads", "MATLAB for Linux")],
     "MATLAB has an official Linux version (same license)."),
    (r"packet tracer", "linux", [(W, "https://www.netacad.com", "Packet Tracer for Linux (.deb)")], ""),
    # ---------------- utilities
    (r"7-zip|winrar|winzip|peazip|bandizip", "builtin", [(R, "ark", "Ark")], "Ark opens zip, rar, 7z, tar - right-click any archive."),
    (r"qbittorrent", "linux", [(F, "org.qbittorrent.qBittorrent", "qBittorrent")], ""),
    (r"utorrent|bittorrent|vuze|deluge", "linux", [(F, "org.qbittorrent.qBittorrent", "qBittorrent")], ""),
    (r"teamviewer", "linux", [(W, "https://www.teamviewer.com/download/linux/", "TeamViewer for Linux (.deb)")], ""),
    (r"anydesk", "linux", [(F, "com.anydesk.Anydesk", "AnyDesk")], ""),
    (r"rustdesk", "linux", [(F, "com.rustdesk.RustDesk", "RustDesk")], ""),
    (r"parsec", "linux", [(F, "com.parsecgaming.parsec", "Parsec")], ""),
    (r"moonlight", "linux", [(F, "com.moonlight_stream.Moonlight", "Moonlight")], ""),
    (r"keepass(?!xc)", "builtin", [(R, "keepassxc", "KeePassXC")], "KeePassXC opens your .kdbx file directly."),
    (r"keepassxc", "builtin", [(R, "keepassxc", "KeePassXC")], ""),
    (r"bitwarden", "linux", [(F, "com.bitwarden.desktop", "Bitwarden")], ""),
    (r"1password", "linux", [(W, "https://1password.com/downloads/linux", "1Password for Linux")], ""),
    (r"dropbox", "linux", [(F, "com.dropbox.Client", "Dropbox")], ""),
    (r"\bmega(sync)?\b", "linux", [(F, "nz.mega.MEGAsync", "MEGA")], ""),
    (r"onedrive", "linux", [(W, "https://onedrive.live.com", "OneDrive on the web")],
     "No official OneDrive app for Linux. Use the web, or connect it in Dolphin via rclone."),
    (r"google drive|backup and sync", "linux", [(R, "systemsettings kcm_kaccounts", "Online Accounts"), (W, "https://drive.google.com", "Google Drive web")], ""),
    (r"icloud", "linux", [(W, "https://www.icloud.com", "iCloud web")], ""),
    (r"protonvpn|proton vpn", "linux", [(F, "com.protonvpn.www", "Proton VPN")], ""),
    (r"nordvpn|expressvpn|surfshark|mullvad", "linux", [(W, "https://www.google.com/search?q=linux+app", "Official Linux app (.deb)")],
     "These all ship a Linux .deb; WireGuard/OpenVPN configs also import in PhoenixGe Center > Security."),
    (r"openvpn|wireguard", "builtin", [(R, "phoenixge-center --page security", "PhoenixGe Center > Security")], ""),
    (r"sharex|greenshot|lightshot|snagit|snipping", "builtin", [(R, "spectacle", "Spectacle (Print Screen)"), (F, "org.flameshot.Flameshot", "Flameshot")], ""),
    (r"^everything|listary|wox|flow launcher|powertoys", "builtin", [(R, "krunner", "KRunner (Alt+Space)")], "Search apps and files with Alt+Space."),
    (r"ccleaner|bleachbit|glary|advanced systemcare|iobit|driver booster|driver easy|revo uninstaller", "notneeded",
     [(F, "org.bleachbit.BleachBit", "BleachBit")], "Not needed: Linux doesn't collect registry junk, and drivers come with the system."),
    (r"rufus|balena|etcher|unetbootin|ventoy", "linux", [(F, "io.gitlab.adhami3310.Impression", "Impression (write ISO to USB)")], ""),
    (r"cpu-z|gpu-z|hwinfo|hwmonitor|speccy|aida64|crystaldisk|open hardware monitor|libre hardware monitor", "builtin",
     [(R, "plasma-systemmonitor", "System Monitor"), (F, "io.github.thetumultuousunicornofdarkness.cpu-x", "CPU-X")], ""),
    (r"f\.lux", "builtin", [(R, "systemsettings kcm_nightlight", "Night Light")], ""),
    (r"rainmeter|wallpaper engine|lively wallpaper", "builtin", [(R, "phoenixge-center --page themes", "Themes + desktop widgets")],
     "Plasma widgets and the live fire wallpaper do this. Wallpaper Engine: the 'Wallpaper Engine' Plasma plugin needs Steam."),
    (r"malwarebytes|avast|\bavg\b|norton|mcafee|kaspersky|\beset\b|bitdefender|avira|windows defender|\bpanda\b", "notneeded",
     [(F, "com.gitlab.davem.ClamTk", "ClamTk (virus scan of files)")],
     "Windows viruses don't run on Linux. Firewall + updates are on by default."),
    # ---------------- gaming launchers & tools
    (r"^steam$|steam client", "linux", [(F, "com.valvesoftware.Steam", "Steam")], "Your Steam games can be moved on the Games page."),
    (r"gog galaxy", "linux", [(F, "com.heroicgameslauncher.hgl", "Heroic (GOG)")], ""),
    (r"ea app|^origin$|ea desktop", "windows", [(F, "net.lutris.Lutris", "Lutris (EA app installer)")],
     "The EA app runs through Lutris/Steam with mixed results; many EA games are on Steam too."),
    (r"ubisoft connect|uplay", "windows", [(F, "net.lutris.Lutris", "Lutris (Ubisoft Connect installer)")], "Works through Lutris for most games."),
    (r"battle\.net", "windows", [(F, "net.lutris.Lutris", "Lutris (Battle.net installer)")], "Works well through Lutris."),
    (r"riot client|valorant|league of legends|vanguard", "no", [],
     "Riot's Vanguard anti-cheat blocks Linux - Valorant and League can't run here. Keep Windows for them."),
    (r"ea sports fc|battlefield (2042|6|vi)|apex legends|call of duty|warzone|destiny 2|pubg|rainbow six siege|"
     r"escape from tarkov|fortnite", "no", [],
     "This game's anti-cheat blocks Linux (see areweanticheatyet.com) - keep Windows for it, or use cloud gaming."),
    (r"faceit", "no", [], "FACEIT anti-cheat is Windows-only. CS2 itself works on Linux (normal matchmaking)."),
    (r"fortnite", "no", [], "Epic blocks Fortnite on Linux. GeForce NOW / Xbox Cloud in the browser can run it."),
    (r"minecraft launcher|^minecraft", "linux", [(F, "org.prismlauncher.PrismLauncher", "Prism Launcher")], "Java edition runs natively; Bedrock doesn't."),
    (r"roblox", "linux", [(F, "org.vinegarhq.Sober", "Sober (Roblox)")], "Sober is an unofficial Roblox player for Linux."),
    (r"xbox|gaming services", "no", [], "Xbox app / Game Pass PC games don't run on Linux; Xbox Cloud Gaming works in the browser."),
    (r"geforce experience|nvidia app", "builtin", [(R, "phoenixge-center --page drivers", "PhoenixGe Center > Drivers"),
                                                   (F, "com.leinardi.gwe", "GreenWithEnvy")],
     "The NVIDIA driver is installed by PhoenixGe; Instant Replay is in Center > Gaming."),
    (r"amd software|radeon software|adrenalin", "builtin", [(A, "corectrl", "CoreCtrl")], "AMD drivers are built into Linux."),
    (r"msi afterburner|rivatuner", "builtin", [(R, "phoenixge-center --page gaming", "MangoHud FPS overlay")], ""),
    (r"razer synapse|razer cortex", "linux", [(F, "org.openrgb.OpenRGB", "OpenRGB")], "RGB works with OpenRGB; macros/DPI need the openrazer driver."),
    (r"logitech g hub|logitech gaming|logi options", "linux", [(A, "solaar", "Solaar"), (F, "org.freedesktop.Piper", "Piper")], ""),
    (r"icue|corsair", "linux", [(F, "org.openrgb.OpenRGB", "OpenRGB"), (A, "ckb-next", "ckb-next")], ""),
    (r"steelseries|armoury crate|aura sync|signalrgb|nzxt cam|msi center|mystic light", "linux", [(F, "org.openrgb.OpenRGB", "OpenRGB")], ""),
    (r"ds4windows|dualsensex", "builtin", [], "PlayStation and Xbox controllers work out of the box (Steam Input for remapping)."),
    # ---------------- not needed (drivers, runtimes, OEM tools)
    (r"visual c\+\+|\.net (framework|runtime|desktop)|microsoft \.net|directx|vcredist|windows sdk|windows driver kit|"
     r"webview2|update health|windows pc health|microsoft update|gaming services|edge update|"
     r"intel\(r\)|intel® |realtek|nvidia (graphics|physx|hd audio|frameview|usbc|install)|amd (chipset|ryzen master)|"
     r"synaptics|\belan\b|dolby|waves maxx|lenovo|dell |hp (support|smart|wolf)|\basus|\bacer\b|msi (sdk|true)|"
     r"teams machine-wide|office 16 click-to-run|microsoft 365 apps.*(click|license)|bonjour|vulkan run|openal|"
     r"microsoft gameinput|easy ?anti ?cheat|battleye|epic online services", "notneeded", [],
     "Driver, runtime or manufacturer tool - Linux brings its own (Wine/Proton include the Windows runtimes)."),
]

_COMPILED = [(re.compile(rx, re.I), verdict, opts, note) for rx, verdict, opts, note in RULES]


def suggest(name):
    """-> dict(verdict, options, note). Unknown programs: 'windows' (try the Windows version, honestly flagged)."""
    for rx, verdict, opts, note in _COMPILED:
        if rx.search(name):
            return dict(verdict=verdict, options=list(opts), note=note, known=True)
    return dict(verdict="windows", options=[], known=False,
                note="No Linux version known. Many small Windows programs run with phoenix-run (Wine). Search Discover for an alternative.")


VERDICT_LABELS = {
    "linux": "Linux version / replacement",
    "builtin": "Already built into PhoenixGe",
    "windows": "Run the Windows version (may work)",
    "notneeded": "Not needed on Linux",
    "no": "Can't move to Linux",
}
VERDICT_ORDER = ["linux", "builtin", "windows", "no", "notneeded"]
