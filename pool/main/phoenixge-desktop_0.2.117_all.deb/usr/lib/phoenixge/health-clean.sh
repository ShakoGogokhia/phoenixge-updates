#!/bin/sh
# PhoenixGe Center > Health > Clean up (run with pkexec).   health-clean.sh [apt] [kernels] [flatpak] [journal]
#   apt      apt-get clean (downloaded .deb files)
#   kernels  purge old kernels - keeps the RUNNING kernel and the newest other one - then apt-get autoremove --purge
#   flatpak  flatpak uninstall --system --unused
#   journal  journalctl --vacuum-size=200M
# User files (caches, trash) are NOT handled here - the Center deletes those as the user.
set -u
export LC_ALL=C DEBIAN_FRONTEND=noninteractive
[ "$#" -gt 0 ] || { echo "nothing selected"; exit 2; }
for a in "$@"; do
  case "$a" in apt|kernels|flatpak|journal) ;; *) echo "unknown item: $a"; exit 2 ;; esac
done
before=$(df -B1 --output=avail / | tail -n1)
rc=0
for a in "$@"; do
  case "$a" in
    apt)
      echo "== Deleting downloaded update packages"
      apt-get clean || rc=1 ;;
    kernels)
      echo "== Removing old kernels and unneeded packages"
      if [ -d /run/live ]; then echo "live session - skipped"; continue; fi
      running=$(uname -r)
      rels=$(dpkg-query -W -f='${db:Status-Abbrev} ${Package}\n' 'linux-image-[0-9]*' 2>/dev/null \
             | awk '$1 ~ /^ii/ {print $2}' | sed -e 's/^linux-image-//' -e 's/-unsigned$//' -e 's/-dbg$//' | sort -uV)
      newest_other=$(printf '%s\n' "$rels" | grep -vxF "$running" | tail -n1)
      echo "running: $running   kept as fallback: ${newest_other:-none}"
      pkgs=""
      for r in $rels; do
        [ "$r" = "$running" ] && continue
        [ "$r" = "$newest_other" ] && continue
        for p in "linux-image-$r" "linux-image-$r-unsigned" "linux-image-$r-dbg" "linux-headers-$r"; do
          dpkg-query -W -f='${db:Status-Abbrev}' "$p" 2>/dev/null | grep -q '^ii' && pkgs="$pkgs $p"
        done
      done
      if [ -n "$pkgs" ]; then
        echo "purging:$pkgs"
        # shellcheck disable=SC2086
        apt-get purge -y $pkgs || rc=1
      else
        echo "no old kernels"
      fi
      apt-get autoremove --purge -y || rc=1 ;;
    flatpak)
      echo "== Removing unused Flatpak runtimes"
      if command -v flatpak >/dev/null 2>&1; then flatpak uninstall --system --unused -y --noninteractive || rc=1; fi ;;
    journal)
      echo "== Shrinking system logs to 200 MB"
      journalctl --vacuum-size=200M || rc=1 ;;
  esac
done
after=$(df -B1 --output=avail / | tail -n1)
echo "Freed on /: $(( (after - before) / 1048576 )) MB"
exit $rc
