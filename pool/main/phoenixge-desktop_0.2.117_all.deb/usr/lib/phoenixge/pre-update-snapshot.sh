#!/bin/sh
# PhoenixGe safe updates: make a Timeshift snapshot before packages change.
# Called by apt (DPkg::Pre-Invoke, /etc/apt/apt.conf.d/80phoenixge-snapshot - covers apt, Discover/PackageKit,
# PhoenixGe Center) and by phoenixge-update (--force). Never fails the caller.
#   pre-update-snapshot.sh [--force] [--reason TEXT]
# Rate limit: one snapshot per hour unless --force. Keeps the newest $KEEP pre-update snapshots.
set +e
FORCE=0; REASON=update
while [ $# -gt 0 ]; do
  case "$1" in
    --force) FORCE=1 ;;
    --reason) shift; REASON=$(printf '%s' "$1" | tr -cd 'A-Za-z0-9 ._-') ;;
  esac
  shift
done
TAG="PhoenixGe pre-update"
KEEP=${PHOENIXGE_SNAPSHOT_KEEP:-5}
STATE=/var/lib/phoenixge
STAMP=$STATE/pre-update-snapshot.stamp
LOG=/var/log/phoenixge-snapshots.log
say() { echo "PhoenixGe: $*" >&2; }

[ "$(id -u)" = 0 ] || exit 0
[ -n "$PHOENIXGE_NO_SNAPSHOT" ] && exit 0
[ -f "$STATE/no-pre-update-snapshot" ] && exit 0
# live session, ISO build chroot, Calamares target chroot, containers without systemd
[ -d /run/live ] && exit 0
[ -d /run/systemd/system ] || exit 0
if command -v systemd-detect-virt >/dev/null 2>&1 && systemd-detect-virt --quiet --chroot; then exit 0; fi
command -v timeshift >/dev/null 2>&1 || exit 0
# backups not set up yet (PhoenixGe Center > Backups / first-boot setup writes this)
[ -f /etc/timeshift/timeshift.json ] || exit 0
if grep -q 'phoenixge.snapshot=' /proc/cmdline 2>/dev/null; then
  say "running from a snapshot - no new snapshot (run 'sudo phoenixge-rollback --make-permanent' first)."
  exit 0
fi
if [ "$FORCE" = 0 ] && [ -n "$(find "$STAMP" -mmin -60 2>/dev/null)" ]; then exit 0; fi

mkdir -p "$STATE"
# one at a time (apt can call dpkg several times in one run)
exec 9>/run/phoenixge-pre-update-snapshot.lock
flock -n 9 || exit 0

say "saving the current system state before the update (Timeshift)..."
echo "=== $(date '+%F %T') pre-update snapshot ($REASON)" >> "$LOG"
if timeout 1800 timeshift --create --comments "$TAG ($REASON)" --tags O --scripted >> "$LOG" 2>&1; then
  touch "$STAMP"
  say "snapshot saved. If the system does not start after the update, pick"
  say "'PhoenixGe - restore previous state' in the boot menu, or run: sudo phoenixge-rollback"
else
  say "could not save a snapshot (see $LOG) - continuing with the update."
  exit 0
fi

# keep only the newest $KEEP pre-update snapshots (daily/boot ones are rotated by Timeshift itself)
timeshift --list --scripted 2>/dev/null | grep "$TAG" \
  | grep -oE '[0-9]{4}-[0-9]{2}-[0-9]{2}_[0-9]{2}-[0-9]{2}-[0-9]{2}' | sort -r | tail -n +"$((KEEP + 1))" \
  | while read -r OLD; do
      echo "deleting old pre-update snapshot $OLD" >> "$LOG"
      timeout 600 timeshift --delete --snapshot "$OLD" --scripted >> "$LOG" 2>&1
    done

# btrfs: put the new snapshot into the GRUB menu right away
[ -x /usr/lib/phoenixge/snapshot-menu-refresh.sh ] && /usr/lib/phoenixge/snapshot-menu-refresh.sh >> "$LOG" 2>&1
exit 0
