#!/bin/sh
# Flutter SDK (official way: git clone of the stable channel) into ~/development/flutter, added to PATH.
set -e
command -v git >/dev/null || { echo "Install the 'Developer pack' first (needs git)."; exit 1; }
D="$HOME/development/flutter"
if [ -d "$D" ]; then git -C "$D" pull --ff-only; else mkdir -p "$HOME/development"; git clone --depth 1 -b stable https://github.com/flutter/flutter.git "$D"; fi
mkdir -p "$HOME/.config/environment.d"
echo "PATH=$D/bin:\${PATH}" > "$HOME/.config/environment.d/phoenixge-flutter.conf"
grep -q 'development/flutter/bin' "$HOME/.bashrc" 2>/dev/null || echo 'export PATH="$HOME/development/flutter/bin:$PATH"' >> "$HOME/.bashrc"
"$D/bin/flutter" --version
echo "Flutter ready. Android: also install Android Studio (Store > Android dev), then run: flutter doctor"
