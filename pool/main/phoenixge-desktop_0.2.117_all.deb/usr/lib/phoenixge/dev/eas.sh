#!/bin/sh
# Expo / EAS CLI for React Native: builds Android locally or in the cloud, iOS in the cloud (Expo's Macs).
set -e
command -v npm >/dev/null || { echo "Install the 'Developer pack' first (needs Node.js/npm)."; exit 1; }
mkdir -p "$HOME/.npm-global"
npm config set prefix "$HOME/.npm-global"
grep -q '.npm-global/bin' "$HOME/.bashrc" 2>/dev/null || echo 'export PATH="$HOME/.npm-global/bin:$PATH"' >> "$HOME/.bashrc"
npm install -g eas-cli
"$HOME/.npm-global/bin/eas" --version
echo "Ready. New app: npx create-expo-app myapp ; iPhone build: eas build -p ios (needs an Apple developer account)"
