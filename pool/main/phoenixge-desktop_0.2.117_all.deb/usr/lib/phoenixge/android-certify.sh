#!/bin/sh
# Print the Android ID that must be registered at https://www.google.com/android/uncertified (Google Play images).
D=/opt/waydroid_script
[ -x "$D/venv/bin/python3" ] || { echo "Run 'ARM support' once first (it installs the helper)."; exit 1; }
"$D/venv/bin/python3" "$D/main.py" certified
