#!/bin/sh
# Tell the user (once per login) that the NVIDIA driver is installed and a restart is needed.
F=/var/lib/phoenixge/nvidia-reboot-needed
[ -f "$F" ] || exit 0
notify-send -a PhoenixGe -i /usr/share/pixmaps/phoenixge.png "NVIDIA დრაივერი დაყენდა" \
  "თამაშებისთვის სრული სიჩქარე რომ ჩაირთოს, გადატვირთე კომპიუტერი. (Secure Boot ჩართულია? მაშინ BIOS-ში გამორთე ან MOK დაადასტურე.)"
