#!/bin/sh
# PhoenixGe "Reset system" (PhoenixGe Center > Reset): bring the OS back to its factory state, KEEP /home.
#
#   sysreset-system.sh --status              method + factory point (no root needed)
#   sysreset-system.sh --plan [--full]       what a reset would do (no root needed; prints PLANHASH at the end)
#   sysreset-system.sh --apply HASH [--full] [--flatpaks] [--keep-apps]       (root) do it
#   sysreset-system.sh --flatpak-plan        system Flatpaks that are not part of the factory state
#
# Two methods:
#   snapshot  btrfs + a "PhoenixGe factory state" Timeshift snapshot (made by sysreset-factory-snapshot.sh at the end of
#             the first-boot setup): the system subvolume @ is swapped for the factory one (old system kept as a
#             snapshot), user accounts / passwords, Wi-Fi and hostname of TODAY are copied into it. Restart needed.
#   apt       everything else (ext4, or btrfs without a factory snapshot): apps you installed with apt are purged,
#             factory packages you removed come back, packages whose files were changed are reinstalled
#             (--full: every package), PhoenixGe's /etc defaults are re-applied (apply-system.sh).
# /home is NEVER touched by this script. --apply refuses to run when the plan changed since the user saw it (HASH).
set -u
export LC_ALL=C
STATE=/var/lib/phoenixge
FB_LIST=$STATE/factory-packages.installed.txt     # recorded on the installed system at the end of first boot
ISO_LIST=/usr/share/phoenixge/factory-packages.txt # recorded at ISO build time (hook 0900)
FB_FLATPAKS=$STATE/factory-flatpaks.txt
SNAPTAG="PhoenixGe factory state"
LOG=/var/log/phoenixge-reset.log
TMP=${TMPDIR:-/tmp}/phoenixge-reset.$$
mkdir -p "$TMP"; trap 'rm -rf "$TMP"' EXIT INT TERM

# never removed by a reset: boot chain, kernels, drivers, firmware, file systems, PhoenixGe itself, the desktop
PROTECT='^(linux-(image|headers|modules|kbuild|base|libc-dev)|nvidia|libnvidia|xserver-xorg-video|firmware-|.*-firmware$|.*-dkms$|dkms$|grub|shim|efibootmgr|mokutil|os-prober|cryptsetup|lvm2|mdadm|btrfs-progs|e2fsprogs|dosfstools|ntfs-3g|exfatprogs|phoenixge|timeshift|sudo$|systemd|network-manager|plasma-|kwin|sddm|intel-microcode|amd64-microcode|apt|dpkg|base-files|init$|locales)'
# set up by PhoenixGe's own first-boot steps (gaming / developer profiles): not "your apps"
FIRSTBOOT_PKGS='gamescope build-essential git cmake clang gdb python3-pip python3-venv pipx nodejs npm default-jdk golang rustc cargo php composer sqlite3 neovim adb fastboot docker.io docker-compose waydroid'
# only in the live ISO (Calamares removes them on install) - never "reinstall" these
LIVEONLY='^(live-|calamares|user-setup|squashfs-tools|memtest86|syslinux|isolinux|grub-pc-bin|grub-efi-amd64-bin|grub-efi-ia32-bin|.*-live$|debian-installer|eject$)'

die() { echo "ERROR: $*" >&2; exit 1; }

is_btrfs_at() {
  [ "$(findmnt -no FSTYPE /)" = btrfs ] || return 1
  case ",$(findmnt -no OPTIONS /)," in *,subvol=/@,*|*,subvol=@,*) return 0 ;; esac
  return 1
}
factory_snapshot() { # the factory point recorded by sysreset-factory-snapshot.sh (checked against Timeshift as root)
  N=$(cat "$STATE/factory-snapshot" 2>/dev/null)
  [ "$(id -u)" = 0 ] || { echo "$N"; return 0; }
  command -v timeshift >/dev/null 2>&1 && [ -f /etc/timeshift/timeshift.json ] || return 0
  L=$(timeshift --list --scripted 2>/dev/null | grep "$SNAPTAG" | grep -oE '[0-9]{4}-[0-9]{2}-[0-9]{2}_[0-9]{2}-[0-9]{2}-[0-9]{2}' | sort)
  if [ -n "$N" ] && printf '%s
' "$L" | grep -qx "$N"; then echo "$N"; else printf '%s
' "$L" | tail -n 1; fi
}
manifest() { # path<TAB>kind
  if [ -s "$FB_LIST" ]; then printf '%s\tfirstboot\n' "$FB_LIST"
  elif [ -s "$ISO_LIST" ]; then printf '%s\tiso\n' "$ISO_LIST"
  else printf '\tnone\n'; fi
}
method() {
  if is_btrfs_at && [ -n "$(factory_snapshot)" ]; then echo snapshot; else echo apt; fi
}

status() {
  M=$(manifest)
  echo "method=$(method)"
  echo "btrfs=$(is_btrfs_at && echo 1 || echo 0)"
  echo "factory_snapshot=$(factory_snapshot)"
  echo "manifest=$(printf '%s' "$M" | cut -f1)"
  echo "manifest_kind=$(printf '%s' "$M" | cut -f2)"
  [ -f "$STATE/factory-recorded" ] && echo "factory_recorded=$(cat "$STATE/factory-recorded")"
  [ -d /run/live ] && echo "live=1"
  echo "timeshift=$(command -v timeshift >/dev/null 2>&1 && echo 1 || echo 0)"
}

installed_pkgs() { dpkg-query -W -f='${db:Status-Status} ${Package}\n' 2>/dev/null | awk '$1=="installed"{print $2}' | sort -u; }

compute_plan() { # writes $TMP/remove $TMP/missing $TMP/changed $TMP/sim $TMP/blocked
  FULL=$1
  installed_pkgs > "$TMP/installed"
  MF=$(manifest | cut -f1); KIND=$(manifest | cut -f2)
  : > "$TMP/remove"; : > "$TMP/missing"; : > "$TMP/changed"; : > "$TMP/sim"; : > "$TMP/blocked"
  if [ -n "$MF" ]; then
    sed 's/:.*//' "$MF" | grep -E '^[a-z0-9][a-z0-9+.-]*$' | sort -u > "$TMP/factory"
    printf '%s\n' $FIRSTBOOT_PKGS | sort -u > "$TMP/fbpkgs"
    # your apps: installed by hand (apt-mark manual), not part of the factory state, not protected
    apt-mark showmanual 2>/dev/null | sed 's/:.*//' | sort -u > "$TMP/manual"
    comm -12 "$TMP/manual" "$TMP/installed" | comm -23 - "$TMP/factory" | grep -Ev "$PROTECT" > "$TMP/remove.0" || true
    if [ "$KIND" = iso ]; then comm -23 "$TMP/remove.0" "$TMP/fbpkgs" > "$TMP/remove"; else cp "$TMP/remove.0" "$TMP/remove"; fi
    # factory packages that are gone now (not the live-only ones)
    comm -13 "$TMP/installed" "$TMP/factory" | grep -Ev "$LIVEONLY" > "$TMP/missing" || true
    # everything apt would purge with them (packages that need them) - must not touch factory or protected packages.
    # (no --autoremove here: old orphans from upgrades are factory packages and would block every reset)
    if [ -s "$TMP/remove" ]; then
      # shellcheck disable=SC2046
      apt-get -s -q purge $(cat "$TMP/remove") 2>/dev/null | sed -n 's/^Purg \([^ :]*\).*/\1/p' | sort -u > "$TMP/sim"
      { grep -Fxf "$TMP/factory" "$TMP/sim" | grep -Fvxf "$TMP/remove"; grep -E "$PROTECT" "$TMP/sim"; } | sort -u > "$TMP/blocked" || true
    fi
  fi
  # packages whose installed files differ from Debian's (not counting config files in /etc)
  if [ "$FULL" = 1 ]; then
    comm -12 "$TMP/installed" "${TMP}/factory" 2>/dev/null > "$TMP/changed" || cp "$TMP/installed" "$TMP/changed"
  else
    dpkg --verify 2>/dev/null | awk '$2!="c" && ($1 ~ /^..5/ || $1=="missing") {print $NF}' | grep '^/' | head -n 4000 > "$TMP/files" || true
    if [ -s "$TMP/files" ]; then
      xargs -r dpkg -S < "$TMP/files" 2>/dev/null | sed 's/: .*//' | tr ',' '\n' | sed 's/^ *//; s/:.*//'         | grep -E '^[a-z0-9][a-z0-9+.-]*$' | sort -u > "$TMP/changed" || true
    fi
  fi
}

plan() {
  FULL=${1:-0}
  M=$(method)
  echo "METHOD $M"
  if [ "$M" = snapshot ]; then
    echo "SNAPSHOT $(factory_snapshot)"
    echo "PLANHASH $(printf 'snapshot %s' "$(factory_snapshot)" | md5sum | cut -c1-12)"
    return 0
  fi
  echo "MANIFEST $(manifest | cut -f2)"
  compute_plan "$FULL"
  sed 's/^/REMOVE /' "$TMP/remove"
  comm -23 "$TMP/sim" "$TMP/remove" | sed 's/^/ALSO /'
  sed 's/^/BLOCKED /' "$TMP/blocked"
  sed 's/^/MISSING /' "$TMP/missing"
  sed 's/^/CHANGED /' "$TMP/changed"
  echo "PLANHASH $(cat "$TMP/remove" "$TMP/missing" | md5sum | cut -c1-12)"
}

flatpak_plan() { # system Flatpak apps not in the factory list (all of them when there is no list)
  command -v flatpak >/dev/null 2>&1 || return 0
  flatpak list --system --app --columns=application 2>/dev/null | sort -u > "$TMP/fp"
  if [ -s "$FB_FLATPAKS" ]; then sort -u "$FB_FLATPAKS" | comm -23 "$TMP/fp" -; else cat "$TMP/fp"; fi
}

# ------------------------------------------------------------------ apply
keep_today_into() { # NEWROOT: copy today's accounts/passwords, Wi-Fi, hostname, timezone into the restored system
  N=$1
  for f in passwd shadow group gshadow subuid subgid hostname hosts timezone; do
    [ -f "/etc/$f" ] && cp -a "/etc/$f" "$N/etc/$f"
  done
  [ -L /etc/localtime ] && cp -a /etc/localtime "$N/etc/localtime"
  if [ -d /etc/NetworkManager/system-connections ]; then
    mkdir -p "$N/etc/NetworkManager/system-connections"
    cp -a /etc/NetworkManager/system-connections/. "$N/etc/NetworkManager/system-connections/"
  fi
  # the factory point itself (written after its snapshot was taken, so the snapshot doesn't know it)
  mkdir -p "$N$STATE"
  for f in factory-snapshot factory-recorded factory-packages.installed.txt factory-flatpaks.txt; do
    [ -f "$STATE/$f" ] && cp -a "$STATE/$f" "$N$STATE/$f"
  done
}

apply_snapshot() {
  S=$(factory_snapshot)
  [ -n "$S" ] || die "no factory snapshot"
  echo "Restoring the factory state ($S). Your files in /home are not touched."
  /usr/bin/phoenixge-rollback --restore "$S" --yes || die "Timeshift could not restore the factory snapshot."
  # Timeshift made a new @ from the snapshot (top level of the btrfs volume): bring today's accounts etc. into it
  DEV=$(findmnt -no SOURCE / | sed 's/\[.*//')
  MNT=$TMP/top; mkdir -p "$MNT"
  if mount -o subvolid=5 "$DEV" "$MNT" 2>/dev/null; then
    if [ -d "$MNT/@/etc" ]; then
      keep_today_into "$MNT/@"
      echo "Kept: user accounts and passwords, Wi-Fi networks, computer name, time zone."
    fi
    umount "$MNT"
  else
    echo "Note: could not open the restored system to copy accounts/Wi-Fi - passwords are the ones from the factory point."
  fi
  echo "DONE - restart the computer to start the factory system."
}

apply_apt() {
  FULL=$1; FLATPAKS=$2; KEEPAPPS=$3
  export DEBIAN_FRONTEND=noninteractive
  APTOPT="-y -q -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold"
  [ -x /usr/lib/phoenixge/pre-update-snapshot.sh ] && sh /usr/lib/phoenixge/pre-update-snapshot.sh --force --reason reset
  echo "--- repairing the package database"
  dpkg --configure -a
  # shellcheck disable=SC2086
  apt-get $APTOPT -f install
  NET=1
  echo "--- updating package lists"
  apt-get -q update || { NET=0; echo "No internet / mirror unreachable - packages can't be downloaded, only removed."; }
  if [ "$KEEPAPPS" = 0 ] && [ -s "$TMP/remove" ]; then
    if [ -s "$TMP/blocked" ]; then
      echo "!!! Not removing your apps: apt would also remove system packages:"; sed 's/^/    /' "$TMP/blocked"
    else
      echo "--- removing apps that were installed after setup ($(wc -l < "$TMP/remove"))"
      # shellcheck disable=SC2046,SC2086
      apt-get $APTOPT purge $(cat "$TMP/remove")
    fi
  fi
  if [ "$NET" = 1 ] && [ -s "$TMP/missing" ]; then
    echo "--- installing factory packages that were removed ($(wc -l < "$TMP/missing"))"
    # one by one would be slow; a package that no longer exists in Debian is skipped
    # shellcheck disable=SC2046,SC2086
    apt-get $APTOPT install $(cat "$TMP/missing") || \
      for p in $(cat "$TMP/missing"); do apt-get $APTOPT install "$p" || echo "    skipped $p"; done
  fi
  CORE=""
  for p in phoenixge-desktop plasma-desktop plasma-workspace kwin-wayland kwin-x11 sddm systemd network-manager \
           dolphin konsole plasma-nm plasma-pa powerdevil; do
    grep -qx "$p" "$TMP/installed" && CORE="$CORE $p"
  done
  if [ "$NET" = 1 ]; then
    LIST=$(cat "$TMP/changed"; printf '%s\n' $CORE)
    LIST=$(printf '%s\n' $LIST | sort -u | grep -Fxf "$TMP/installed" || true)
    N=$(printf '%s\n' $LIST | grep -c . || true)
    echo "--- reinstalling $N system packages (fresh files from Debian/PhoenixGe)"
    # shellcheck disable=SC2086
    [ -n "$LIST" ] && { apt-get $APTOPT install --reinstall $LIST || \
      for p in $LIST; do apt-get $APTOPT install --reinstall "$p" >/dev/null 2>&1 || echo "    skipped $p"; done; }
  fi
  echo "--- PhoenixGe defaults in /etc"
  sh /usr/lib/phoenixge/apply-system.sh || true
  if [ "$FLATPAKS" = 1 ] && command -v flatpak >/dev/null 2>&1; then
    APPS=$(flatpak_plan)
    if [ -n "$APPS" ]; then
      echo "--- removing Flatpak apps: $(echo $APPS)"
      # shellcheck disable=SC2086
      flatpak uninstall --system -y --noninteractive $APPS
      flatpak uninstall --system -y --noninteractive --unused
    fi
    # no factory list: everything was removed -> let first-boot setup install the profile's apps again
    [ -s "$FB_FLATPAKS" ] || rm -f "$STATE"/fb-games.done "$STATE"/fb-replay.done "$STATE"/fb-rgb.done \
                                   "$STATE"/fb-gpu.done "$STATE"/fb-devapps.done "$STATE"/firstboot-v2.done
  fi
  apt-get -y -q autoremove >/dev/null 2>&1 || true
  echo "DONE - restart the computer to finish."
}

apply() {
  WANT=$1; FULL=$2; FLATPAKS=$3; KEEPAPPS=$4
  [ "$(id -u)" = 0 ] || die "run as root (pkexec)"
  [ -d /run/live ] && die "this is the live session - nothing to reset."
  exec 9>/run/phoenixge-reset.lock; flock -n 9 || die "a reset is already running"
  echo "=== $(date '+%F %T') PhoenixGe reset (full=$FULL flatpaks=$FLATPAKS keep-apps=$KEEPAPPS)"
  M=$(method)
  if [ "$M" = snapshot ]; then
    GOT=$(printf 'snapshot %s' "$(factory_snapshot)" | md5sum | cut -c1-12)
    [ "$GOT" = "$WANT" ] || die "the system changed since the plan was shown - open the Reset page again."
    # system Flatpaks live in @ -> they go back to the factory state with it
    apply_snapshot
  else
    compute_plan "$FULL"
    GOT=$(cat "$TMP/remove" "$TMP/missing" | md5sum | cut -c1-12)
    [ "$GOT" = "$WANT" ] || die "the system changed since the plan was shown - open the Reset page again."
    apply_apt "$FULL" "$FLATPAKS" "$KEEPAPPS"
  fi
}

CMD=${1:-}; [ $# -gt 0 ] && shift
FULL=0; FLATPAKS=0; KEEPAPPS=0; HASH=""
case "$CMD" in --apply) HASH=${1:-}; [ $# -gt 0 ] && shift ;; esac
for a in "$@"; do
  case "$a" in --full) FULL=1 ;; --flatpaks) FLATPAKS=1 ;; --keep-apps) KEEPAPPS=1 ;; esac
done
case "$CMD" in
  --status) status ;;
  --plan) plan "$FULL" ;;
  --flatpak-plan) flatpak_plan ;;
  --apply)
    [ -n "$HASH" ] || die "--apply needs the plan hash"
    { ( apply "$HASH" "$FULL" "$FLATPAKS" "$KEEPAPPS" ); echo $? > "$TMP/rc"; } 2>&1 | tee -a "$LOG"
    exit "$(cat "$TMP/rc" 2>/dev/null || echo 1)" ;;
  *) sed -n '2,16p' "$0" | sed 's/^# \{0,1\}//'; exit 2 ;;
esac
