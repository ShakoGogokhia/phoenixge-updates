// PhoenixGe Laptop: system tray quick toggles - battery protection, smart battery, graphics mode.
// Everything goes through /usr/bin/phoenixge-laptop (status --json, set ...). Hidden on computers without a battery.
import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.components as PlasmaComponents3
import org.kde.plasma.extras as PlasmaExtras
import org.kde.plasma.plasma5support as P5Support
import org.kde.kirigami as Kirigami

PlasmoidItem {
    id: root

    readonly property string cli: "python3 /usr/bin/phoenixge-laptop"
    readonly property string statusCmd: cli + " status --json --fast"
    property var st: ({})
    property string message: ""
    property bool working: false

    readonly property bool laptop: st.laptop === true
    readonly property var bat: st.battery || ({})
    readonly property var smart: st.smart || ({})
    readonly property var charge: st.charge || ({})
    readonly property var gpu: st.gpu || ({})
    readonly property bool showGpu: gpu.hybrid === true || gpu.integrated_active === true || gpu.effective === "nvidia"

    Plasmoid.icon: !laptop ? "computer-laptop" : (st.on_battery ? "battery-good" : (charge.protect ? "battery-good-charging" : "computer-laptop"))
    Plasmoid.status: laptop ? PlasmaCore.Types.ActiveStatus : PlasmaCore.Types.HiddenStatus
    toolTipMainText: "Laptop"
    toolTipSubText: !laptop ? "" : [
        (bat.percent !== undefined ? bat.percent + "%" : "") + (bat.time ? " - " + bat.time + (st.on_battery ? " left" : " to full") : ""),
        charge.supported ? ("Battery protection " + (charge.once ? "paused (charging to 100% once)" : (charge.protect ? "on" : "off"))) : "",
        showGpu ? ("Graphics: " + modeName(gpu.effective) + (gpu.reboot_pending ? " (restart needed)" : "")) : ""
    ].filter(function (s) { return s !== ""; }).join("\n")

    function modeName(m) {
        return ({ auto: "Automatic", hybrid: "Hybrid", integrated: "Integrated only", nvidia: "NVIDIA only", single: "Single GPU" })[m] || (m || "")
    }
    function refresh() { exec.connectSource(statusCmd) }
    function run(args) {
        working = true
        message = ""
        exec.connectSource(cli + " " + args + " 2>&1")
    }

    P5Support.DataSource {
        id: exec
        engine: "executable"
        connectedSources: []
        onNewData: (source, data) => {
            disconnectSource(source)
            if (source === root.statusCmd) {
                try { root.st = JSON.parse(data.stdout || "{}") } catch (e) { root.st = ({}) }
                return
            }
            if (source.indexOf(root.cli) !== 0) return   // restart / open Center: no result to show
            root.working = false
            var lines = String(data.stdout || "").trim().split("\n")
            root.message = data["exit code"] === 0 ? lines[lines.length - 1] : ("Not changed. " + lines[lines.length - 1])
            root.refresh()
        }
    }

    Timer {
        interval: root.expanded ? 5000 : 60000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: root.refresh()
    }
    onExpandedChanged: if (expanded) refresh()

    component Badge: Rectangle {
        property string mode: "auto"
        readonly property color tint: mode === "auto" ? Kirigami.Theme.positiveTextColor
                                    : (mode === "manual" ? Kirigami.Theme.neutralTextColor : Kirigami.Theme.disabledTextColor)
        implicitWidth: badgeText.implicitWidth + Kirigami.Units.largeSpacing
        implicitHeight: badgeText.implicitHeight + 2
        radius: height / 2
        color: "transparent"
        border.color: tint
        PlasmaComponents3.Label {
            id: badgeText
            anchors.centerIn: parent
            text: ({ auto: "Automatic", manual: "Manual", off: "Off" })[parent.mode] || parent.mode
            color: parent.tint
            font.pointSize: Kirigami.Theme.smallFont.pointSize
            font.bold: true
        }
    }

    component SectionTitle: RowLayout {
        property string title
        property string mode
        Layout.fillWidth: true
        Layout.topMargin: Kirigami.Units.smallSpacing
        Kirigami.Heading { text: parent.title; level: 4 }
        Badge { mode: parent.mode }
        Item { Layout.fillWidth: true }
    }

    component Hint: PlasmaComponents3.Label {
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        opacity: 0.75
        font.pointSize: Kirigami.Theme.smallFont.pointSize
    }

    fullRepresentation: PlasmaExtras.Representation {
        Layout.minimumWidth: Kirigami.Units.gridUnit * 20
        Layout.preferredWidth: Kirigami.Units.gridUnit * 22
        Layout.minimumHeight: Kirigami.Units.gridUnit * 16
        Layout.preferredHeight: col.implicitHeight + Kirigami.Units.gridUnit * 4
        collapseMarginsHint: true

        header: PlasmaExtras.PlasmoidHeading {
            RowLayout {
                anchors.fill: parent
                Kirigami.Heading { text: "Laptop"; level: 3; Layout.fillWidth: true }
                PlasmaComponents3.Label {
                    text: root.bat.percent !== undefined
                          ? root.bat.percent + "%" + (root.bat.time ? "  ·  " + root.bat.time + (root.st.on_battery ? " left" : " to full") : "")
                          : ""
                    opacity: 0.8
                }
            }
        }

        ColumnLayout {
            id: col
            anchors.fill: parent
            anchors.margins: Kirigami.Units.largeSpacing
            spacing: Kirigami.Units.smallSpacing

            // ---------------- battery protection
            SectionTitle { title: "Battery protection"; mode: root.charge.supported ? (root.charge.mode || "auto") : "off" }
            RowLayout {
                visible: root.charge.supported === true
                Layout.fillWidth: true
                PlasmaComponents3.Switch {
                    id: protectSwitch
                    text: root.charge.once ? "Charging to 100% once" : "Stop charging early"
                    checked: root.charge.protect === true && root.charge.once !== true
                    enabled: !root.working
                    onToggled: {
                        root.run("set charge " + (checked ? "on" : "off"))
                        checked = Qt.binding(function () { return root.charge.protect === true && root.charge.once !== true })
                    }
                }
                Item { Layout.fillWidth: true }
                PlasmaComponents3.CheckBox {
                    text: "Automatic"
                    checked: root.charge.mode === "auto"
                    enabled: !root.working
                    onToggled: {
                        root.run(checked ? "set charge auto" : "set charge " + (root.charge.protect ? "on" : "off"))
                        checked = Qt.binding(function () { return root.charge.mode === "auto" })
                    }
                }
            }
            Hint {
                visible: root.charge.supported === true
                text: root.charge.once ? "Protection comes back when the battery is full or the charger is unplugged."
                      : (root.charge.protect ? "Stops at " + (root.charge.stop_text || "") + "." : "Charges to 100%.")
            }
            PlasmaComponents3.Button {
                visible: root.charge.supported === true && (root.charge.protect === true || root.charge.once === true)
                text: root.charge.once ? "Cancel - protect again" : "Charge to 100% once"
                icon.name: "battery-full-charging"
                enabled: !root.working
                onClicked: root.run(root.charge.once ? "set charge-once-cancel" : "set charge-once")
            }
            Hint {
                visible: root.charge.supported !== true
                text: "This laptop doesn't let Linux limit charging."
            }

            // ---------------- smart battery
            SectionTitle { title: "Smart battery"; mode: root.smart.mode || "auto" }
            RowLayout {
                Layout.fillWidth: true
                PlasmaComponents3.Switch {
                    text: "Save power when unplugged"
                    checked: root.smart.mode !== "off"
                    enabled: !root.working
                    onToggled: {
                        root.run("set battery " + (checked ? "auto" : "off"))
                        checked = Qt.binding(function () { return root.smart.mode !== "off" })
                    }
                }
                Item { Layout.fillWidth: true }
                PlasmaComponents3.CheckBox {
                    text: "Automatic"
                    checked: root.smart.mode === "auto"
                    enabled: !root.working && root.smart.mode !== "off"
                    onToggled: {
                        root.run("set battery " + (checked ? "auto" : "manual"))
                        checked = Qt.binding(function () { return root.smart.mode === "auto" })
                    }
                }
            }
            Hint {
                text: root.smart.mode === "off" ? "Nothing changes when you unplug the charger."
                      : (root.smart.mode === "manual" ? "Your own choices (PhoenixGe Center > Devices)."
                         : "Unplugged: Battery saver and 60 Hz. Plugged in: your settings come back.")
            }

            // ---------------- graphics
            SectionTitle { visible: root.showGpu; title: "Graphics"; mode: root.gpu.mode === "auto" ? "auto" : "manual" }
            RowLayout {
                visible: root.showGpu && root.gpu.effective !== "nvidia" && root.gpu.live !== true
                Layout.fillWidth: true
                PlasmaComponents3.ComboBox {
                    id: gpuBox
                    Layout.fillWidth: true
                    textRole: "text"
                    valueRole: "value"
                    enabled: !root.working
                    model: {
                        var m = [{ text: "Automatic (Hybrid)", value: "auto" }, { text: "Hybrid", value: "hybrid" }]
                        if (root.gpu.can_integrated) m.push({ text: "Integrated only - NVIDIA off", value: "integrated" })
                        return m
                    }
                    currentIndex: Math.max(0, indexOfValue(root.gpu.mode || "auto"))
                    onActivated: {
                        if (currentValue !== root.gpu.mode) root.run("set gpu " + currentValue)
                        currentIndex = Qt.binding(function () { return Math.max(0, indexOfValue(root.gpu.mode || "auto")) })
                    }
                }
            }
            Hint {
                visible: root.showGpu
                text: root.gpu.effective === "nvidia"
                      ? "NVIDIA only (set in the BIOS, F2 > GPU Working Mode)."
                      : ("Now: " + root.modeName(root.gpu.effective)
                         + (root.gpu.dgpu_state ? ", NVIDIA " + root.gpu.dgpu_state : "") + "."
                         + (root.gpu.driver === false && root.gpu.has_nvidia ? " NVIDIA driver not installed yet." : "")
                         + " NVIDIA only: switch it in the BIOS (F2).")
            }
            RowLayout {
                visible: root.gpu.reboot_pending === true
                PlasmaComponents3.Label { text: "Restart needed"; font.bold: true; Layout.fillWidth: true }
                PlasmaComponents3.Button {
                    text: "Restart"
                    icon.name: "system-reboot"
                    onClicked: exec.connectSource("qdbus6 org.kde.LogoutPrompt /LogoutPrompt promptReboot || systemctl reboot")
                }
            }

            // ---------------- footer
            PlasmaComponents3.BusyIndicator {
                visible: root.working
                running: root.working
                Layout.alignment: Qt.AlignHCenter
                Layout.preferredHeight: Kirigami.Units.gridUnit * 2
            }
            Hint { visible: root.message !== ""; text: root.message }
            Item { Layout.fillHeight: true }
            RowLayout {
                Layout.fillWidth: true
                PlasmaComponents3.Button {
                    visible: root.st.automatic === false
                    text: "Reset to automatic"
                    icon.name: "edit-undo"
                    enabled: !root.working
                    onClicked: root.run("reset")
                }
                Item { Layout.fillWidth: true }
                PlasmaComponents3.Button {
                    text: "More settings…"
                    icon.name: "configure"
                    onClicked: exec.connectSource("phoenixge-center --page devices >/dev/null 2>&1 &")
                }
            }
        }
    }
}
