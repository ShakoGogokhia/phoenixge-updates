/*
    PhoenixGe Board - the desktop widgets drawn on the design boards (design/<Theme>.dc.html).
    One applet, several modes (config "mode"):
      greeting  "PHOENIXGE OS / Hello, user / date"              (Ash, Pastel)
      title     big title + subtitle                              (Borjgali, Obsidian wordmark)
      cards     shortcut cards in a grid  items: "Title|Sub|action"   (Ash)
      rows      shortcut rows with tile icons  items: "Title|Sub|action|icon"  (Borjgali)
      chips     round pill buttons  items: "Title|action"         (Pastel)
      stats     CPU / RAM / disk (/ GPU / temp) bars              (Glass, Cyber)
      games     installed games as big cards, click = play        (Kolkhi game center, Cyber, Game Mode)
      todo      editable day plan, items: "x:done text" / "text"   (Forest)
      music     now playing (MPRIS)                               (Inferno)
      fetch     terminal-style system info                        (Obsidian)
    action: "app:<desktop-id>" launches an app, anything else is opened as a URL.
    SPDX-License-Identifier: GPL-2.0-or-later
*/
pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.kirigami as Kirigami
import org.kde.plasma.plasma5support as P5Support
import org.kde.plasma.private.kicker as Kicker
import org.kde.ksysguard.sensors as Sensors
import org.kde.plasma.private.mpris as Mpris
import org.kde.coreaddons as KCoreAddons

PlasmoidItem {
    id: root
    readonly property var cfg: Plasmoid.configuration
    readonly property color fg: cfg.fg
    readonly property color dim: cfg.dim
    readonly property color accent: cfg.accent
    readonly property color cardColor: Qt.rgba(Qt.color(cfg.card).r, Qt.color(cfg.card).g, Qt.color(cfg.card).b, cfg.cardAlpha)
    readonly property string fontName: cfg.font
    property date now: new Date()

    Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground
    preferredRepresentation: fullRepresentation
    Timer { interval: 30000; running: true; repeat: true; onTriggered: root.now = new Date() }

    KCoreAddons.KUser { id: kuser }

    // ---- helpers
    P5Support.DataSource {
        id: exec
        engine: "executable"
        connectedSources: []
        onNewData: (source, data) => {
            if (source.indexOf("df ") >= 0) root.diskText = (data.stdout || "").trim();
            else if (source.indexOf("sysinfo") >= 0) root.fetchText = (data.stdout || "").trim();
            disconnectSource(source);
        }
    }
    property string diskText: ""
    property string fetchText: ""
    function run(cmd) { exec.connectSource(cmd); }
    function act(action) {
        if (!action) return;
        action = String(action).replace("$HOME", kuser.homeDir);
        if (action.indexOf("app:") === 0) run("kioclient exec /usr/share/applications/" + action.slice(4) + ".desktop || gtk-launch " + action.slice(4));
        else Qt.openUrlExternally(action);
    }
    function field(item, i) { var p = String(item).split("|"); return p.length > i ? p[i] : ""; }

    fullRepresentation: Item {
        Layout.preferredWidth: 200
        Layout.preferredHeight: 80
        Layout.minimumWidth: 60
        Layout.minimumHeight: 40
        Loader {
            anchors.fill: parent
            sourceComponent: ({
                greeting: greeting, title: title, cards: cards, rows: rows, chips: chips, stats: stats,
                games: games, todo: todo, music: music, fetch: fetch
            })[root.cfg.mode] || greeting
        }
    }

    component Card: Rectangle {
        radius: root.cfg.radius
        color: root.cardColor
        border.color: Qt.rgba(root.fg.r, root.fg.g, root.fg.b, 0.08)
    }
    component Label2: Text { font.family: root.fontName; color: root.fg; elide: Text.ElideRight }

    // ------------------------------------------------------------ greeting / title
    Component {
        id: greeting
        ColumnLayout {
            spacing: 6
            Label2 { text: root.cfg.subtitle || "PHOENIXGE OS"; font.pixelSize: 12; font.letterSpacing: 2; color: root.dim }
            Label2 {
                Layout.fillWidth: true
                text: (root.cfg.title || "Hello") + ", " + (kuser.loginName || "")
                font.pixelSize: root.cfg.big; font.weight: Font.Bold
            }
            Label2 { text: Qt.locale().toString(root.now, "dddd, d MMMM · HH:mm"); font.pixelSize: 15; color: root.dim }
            Item { Layout.fillHeight: true }
        }
    }
    Component {
        id: title
        ColumnLayout {
            spacing: 4
            Label2 { text: root.cfg.title || "PhoenixGe"; font.pixelSize: root.cfg.big; font.weight: Font.Bold; textFormat: Text.StyledText }
            Label2 { text: root.cfg.subtitle; visible: text.length > 0; font.pixelSize: 14; font.letterSpacing: 3; color: root.accent }
            Item { Layout.fillHeight: true }
        }
    }

    // ------------------------------------------------------------ cards / rows / chips
    Component {
        id: cards
        GridLayout {
            columns: 2
            rowSpacing: 12; columnSpacing: 12
            Component.onCompleted: root.run("df -B1G --output=avail,size / | tail -1")
            Repeater {
                model: root.cfg.items
                Card {
                    id: c
                    required property var modelData
                    required property int index
                    readonly property bool disk: root.field(modelData, 2) === "disk"
                    Layout.fillWidth: true; Layout.fillHeight: true
                    color: disk ? Qt.rgba(0.17, 0.13, 0.11, 0.95) : root.cardColor
                    ColumnLayout {
                        anchors.fill: parent; anchors.margins: 16; spacing: 4
                        Label2 { text: root.field(c.modelData, 0); font.pixelSize: 11; color: c.disk ? "#e8d9cf" : root.dim; Layout.fillWidth: true }
                        Label2 {
                            Layout.fillWidth: true
                            text: c.disk ? (root.diskText ? root.diskText.split(/\s+/)[0] + " GB free" : "…") : root.field(c.modelData, 1)
                            font.pixelSize: 17; font.weight: Font.DemiBold; color: c.disk ? "#ffffff" : root.fg
                        }
                        Rectangle {
                            visible: c.disk
                            Layout.fillWidth: true; Layout.preferredHeight: 4; radius: 2; color: Qt.rgba(1, 1, 1, 0.15)
                            Rectangle {
                                height: parent.height; radius: 2; color: root.accent
                                width: { var p = root.diskText.split(/\s+/); return p.length > 1 ? parent.width * (1 - Number(p[0]) / Number(p[1])) : 0; }
                            }
                        }
                        Label2 { visible: !c.disk; text: root.field(c.modelData, 3) || "Open ›"; font.pixelSize: 11; color: root.accent }
                    }
                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: root.act(root.field(c.modelData, 2)) }
                }
            }
        }
    }
    Component {
        id: rows
        ColumnLayout {
            spacing: 10
            Repeater {
                model: root.cfg.items
                Card {
                    id: r
                    required property var modelData
                    Layout.fillWidth: true; Layout.preferredHeight: 52
                    RowLayout {
                        anchors.fill: parent; anchors.leftMargin: 12; anchors.rightMargin: 12; spacing: 12
                        Kirigami.Icon { source: root.field(r.modelData, 3) || "applications-other"; Layout.preferredWidth: 28; Layout.preferredHeight: 28 }
                        ColumnLayout {
                            spacing: 0; Layout.fillWidth: true
                            Label2 { text: root.field(r.modelData, 0); font.pixelSize: 13; font.weight: Font.DemiBold; Layout.fillWidth: true }
                            Label2 { text: root.field(r.modelData, 1); font.pixelSize: 11; color: root.dim; Layout.fillWidth: true }
                        }
                    }
                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: root.act(root.field(r.modelData, 2)) }
                }
            }
            Item { Layout.fillHeight: true }
        }
    }
    Component {
        id: chips
        Flow {
            spacing: 10
            Repeater {
                model: root.cfg.items
                Rectangle {
                    id: chip
                    required property var modelData
                    required property int index
                    height: 38; width: chipText.implicitWidth + 44; radius: 19
                    color: Qt.rgba(1, 1, 1, 0.75)
                    border.color: Qt.rgba(0, 0, 0, 0.05)
                    Rectangle {
                        x: 12; anchors.verticalCenter: parent.verticalCenter; width: 12; height: 12; radius: 6
                        color: ["#f06595", "#ff922b", "#9775fa", "#38d9a9", "#4dabf7"][chip.index % 5]
                    }
                    Label2 { id: chipText; x: 32; anchors.verticalCenter: parent.verticalCenter; text: root.field(chip.modelData, 0); font.pixelSize: 13; font.weight: Font.DemiBold }
                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: root.act(root.field(chip.modelData, 1)) }
                }
            }
        }
    }

    // ------------------------------------------------------------ stats
    Component {
        id: stats
        Card {
            ColumnLayout {
                anchors.fill: parent; anchors.margins: 16; spacing: 12
                Label2 { text: root.cfg.title; font.pixelSize: 12; color: root.dim; visible: text.length > 0 }
                Repeater {
                    model: root.cfg.items.length ? root.cfg.items : ["CPU|cpu/all/usage|%", "RAM|memory/physical/usedPercent|%", "Disk|disk/all/usedPercent|%"]
                    ColumnLayout {
                        id: st
                        required property var modelData
                        Layout.fillWidth: true; spacing: 5
                        Sensors.Sensor { id: sensor; sensorId: root.field(st.modelData, 1); updateRateLimit: 2000 }
                        readonly property real v: Number(sensor.value) || 0
                        readonly property bool pct: root.field(st.modelData, 2) === "%"
                        RowLayout {
                            Layout.fillWidth: true
                            Label2 { text: root.field(st.modelData, 0); font.pixelSize: 12; Layout.fillWidth: true; font.letterSpacing: 1 }
                            Label2 { text: st.pct ? Math.round(st.v) + "%" : sensor.formattedValue; font.pixelSize: 12; font.weight: Font.DemiBold }
                        }
                        Rectangle {
                            Layout.fillWidth: true; Layout.preferredHeight: 4; radius: 2
                            color: Qt.rgba(root.fg.r, root.fg.g, root.fg.b, 0.12)
                            Rectangle { height: parent.height; radius: 2; color: root.accent; width: parent.width * Math.min(1, (st.pct ? st.v : st.v) / 100) }
                        }
                    }
                }
                Item { Layout.fillHeight: true }
            }
        }
    }

    // ------------------------------------------------------------ games
    Kicker.RootModel {
        id: appsRoot
        autoPopulate: false
        appletInterface: root
        flat: true; sorted: true; showSeparators: false; showAllApps: false; showTopLevelItems: false
        showRecentApps: false; showRecentDocs: false; showPowerSession: false; showFavoritesPlaceholder: false
        Component.onCompleted: refresh()
    }
    readonly property var gamesModel: {
        for (var i = 0; i < appsRoot.count; ++i) {
            var name = String(appsRoot.data(appsRoot.index(i, 0), Qt.DisplayRole));
            if (name === "Games" || name === "თამაშები") return appsRoot.modelForRow(i);
        }
        return null;
    }
    Component {
        id: games
        Card {
            ColumnLayout {
                anchors.fill: parent; anchors.margins: 16; spacing: 12
                RowLayout {
                    Layout.fillWidth: true
                    Label2 { text: root.cfg.title || "Phoenix Game Center"; font.pixelSize: 13; font.weight: Font.DemiBold; Layout.fillWidth: true }
                    Repeater { model: ["#7a7a7a", "#7a7a7a", root.accent]; Rectangle { required property var modelData; width: 8; height: 8; radius: 4; color: modelData } }
                }
                GridView {
                    id: grid
                    Layout.fillWidth: true; Layout.fillHeight: true
                    clip: true; interactive: false
                    cellWidth: width / 3; cellHeight: cellWidth * 0.82
                    model: root.gamesModel
                    delegate: Item {
                        id: gcell
                        required property int index
                        required property var model
                        width: grid.cellWidth; height: grid.cellHeight
                        Rectangle {
                            anchors.fill: parent; anchors.margins: 5; radius: 10
                            gradient: Gradient {
                                GradientStop { position: 0; color: ["#2a9d8f", "#bc6c25", "#588157", "#e76f51", "#8338ec", "#3a86ff"][gcell.index % 6] }
                                GradientStop { position: 1; color: ["#264653", "#6f1d1b", "#344e41", "#9d0208", "#3a0ca3", "#023e8a"][gcell.index % 6] }
                            }
                            Kirigami.Icon { anchors { right: parent.right; top: parent.top; margins: 8 } width: 26; height: 26; source: gcell.model.decoration }
                            Label2 {
                                anchors { left: parent.left; right: parent.right; bottom: parent.bottom; margins: 10 }
                                text: gcell.model.display; color: "#ffffff"; font.pixelSize: 13; font.weight: Font.Bold
                            }
                            MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: root.gamesModel.trigger(gcell.index, "", null) }
                        }
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------ todo
    Component {
        id: todo
        Card {
            ColumnLayout {
                anchors.fill: parent; anchors.margins: 16; spacing: 8
                Label2 { text: root.cfg.title || "Today"; font.pixelSize: 15; font.weight: Font.Bold }
                Repeater {
                    model: root.cfg.items
                    RowLayout {
                        id: t
                        required property var modelData
                        required property int index
                        readonly property bool done: String(modelData).indexOf("x:") === 0
                        spacing: 10
                        Rectangle {
                            width: 16; height: 16; radius: 4
                            color: t.done ? root.accent : "transparent"
                            border.color: root.accent; border.width: 2
                            MouseArea {
                                anchors.fill: parent
                                onClicked: {
                                    var l = root.cfg.items.slice();
                                    l[t.index] = t.done ? String(t.modelData).slice(2) : "x:" + t.modelData;
                                    Plasmoid.configuration.items = l;
                                }
                            }
                        }
                        Label2 { text: t.done ? String(t.modelData).slice(2) : t.modelData; font.pixelSize: 13; font.strikeout: false }
                    }
                }
                Item { Layout.fillHeight: true }
            }
        }
    }

    // ------------------------------------------------------------ music
    Mpris.Mpris2Model { id: mpris }
    Component {
        id: music
        Card {
            RowLayout {
                anchors.fill: parent; anchors.margins: 12; spacing: 12
                Rectangle {
                    Layout.preferredWidth: 48; Layout.preferredHeight: 48; radius: 8
                    gradient: Gradient {
                        orientation: Gradient.Horizontal
                        GradientStop { position: 0; color: root.accent }
                        GradientStop { position: 1; color: "#ffb36b" }
                    }
                    Image { anchors.fill: parent; source: mpris.currentPlayer ? mpris.currentPlayer.artUrl : ""; fillMode: Image.PreserveAspectCrop; visible: status === Image.Ready }
                }
                ColumnLayout {
                    Layout.fillWidth: true; spacing: 3
                    Label2 { text: mpris.currentPlayer ? (mpris.currentPlayer.artist || "Now playing") : "Music"; font.pixelSize: 11; color: root.dim; Layout.fillWidth: true }
                    Label2 { text: mpris.currentPlayer ? (mpris.currentPlayer.track || "") : "Nothing playing"; font.pixelSize: 14; font.weight: Font.Bold; Layout.fillWidth: true }
                    Rectangle {
                        Layout.fillWidth: true; Layout.preferredHeight: 3; radius: 1.5; color: Qt.rgba(1, 1, 1, 0.15)
                        Rectangle {
                            height: parent.height; radius: 1.5; color: root.accent
                            width: mpris.currentPlayer && mpris.currentPlayer.length > 0 ? parent.width * mpris.currentPlayer.position / mpris.currentPlayer.length : parent.width * 0.6
                        }
                    }
                }
            }
            MouseArea { anchors.fill: parent; onClicked: if (mpris.currentPlayer) mpris.currentPlayer.PlayPause() }
        }
    }

    // ------------------------------------------------------------ fetch
    Component {
        id: fetch
        Rectangle {
            radius: 8
            color: Qt.rgba(0.06, 0.06, 0.08, 0.92)
            border.color: Qt.rgba(1, 1, 1, 0.1)
            Component.onCompleted: root.run("sh /usr/lib/phoenixge/sysinfo.sh")
            Rectangle {
                id: bar
                width: parent.width; height: 26; radius: 8; color: Qt.rgba(1, 1, 1, 0.04)
                Label2 { x: 12; anchors.verticalCenter: parent.verticalCenter; text: kuser.loginName + "@phoenixge: ~"; font.family: "JetBrains Mono"; font.pixelSize: 11; color: root.dim }
            }
            RowLayout {
                anchors { left: parent.left; right: parent.right; top: bar.bottom; bottom: parent.bottom; margins: 14 }
                spacing: 16
                Image { source: "/usr/share/pixmaps/phoenixge.png"; Layout.preferredWidth: 70; Layout.preferredHeight: 70; fillMode: Image.PreserveAspectFit; Layout.alignment: Qt.AlignTop }
                Text {
                    Layout.fillWidth: true; Layout.alignment: Qt.AlignTop
                    font.family: "JetBrains Mono"; font.pixelSize: 12; color: root.fg; textFormat: Text.StyledText; lineHeight: 1.25
                    readonly property var l: root.fetchText.split("\n")
                    text: "<font color='" + root.accent + "'><b>" + kuser.loginName + "@phoenixge</b></font><br>"
                        + "<font color='" + root.accent + "'>OS:</font> PhoenixGe OS 0.1 x86_64<br>"
                        + "<font color='" + root.accent + "'>Base:</font> " + (l[0] || "Debian") + "<br>"
                        + "<font color='" + root.accent + "'>Kernel:</font> " + (l[1] || "") + "<br>"
                        + "<font color='" + root.accent + "'>DE:</font> KDE Plasma 6<br>"
                        + "<font color='" + root.accent + "'>Hardware:</font> " + (l[2] || "") + "<br>"
                        + "<font color='" + root.accent + "'>Games:</font> Steam · Lutris · Flathub"
                }
            }
        }
    }
}
