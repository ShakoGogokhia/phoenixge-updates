// PhoenixGe desktop clock: big 24h time + date, styled per theme (values written by the theme layout)
import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore

PlasmoidItem {
    id: root
    property date now: new Date()
    readonly property var cfg: Plasmoid.configuration
    readonly property int hAlign: cfg.align === "left" ? Text.AlignLeft : (cfg.align === "center" ? Text.AlignHCenter : Text.AlignRight)

    Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground
    preferredRepresentation: fullRepresentation

    Timer { interval: 1000; running: true; repeat: true; triggeredOnStart: true; onTriggered: root.now = new Date() }

    fullRepresentation: ColumnLayout {
        Layout.preferredWidth: Math.max(time.implicitWidth, date.implicitWidth) + 8
        Layout.preferredHeight: time.implicitHeight + date.implicitHeight + 8
        spacing: 4
        Text {
            id: time
            Layout.fillWidth: true
            horizontalAlignment: root.hAlign
            text: Qt.formatTime(root.now, "HH:mm")
            color: root.cfg.timeColor
            font.family: root.cfg.font
            font.pixelSize: root.cfg.timeSize
            font.weight: root.cfg.timeWeight
            font.letterSpacing: root.cfg.letterSpacing
            lineHeightMode: Text.FixedHeight
            lineHeight: root.cfg.timeSize
        }
        Text {
            id: date
            Layout.fillWidth: true
            horizontalAlignment: root.hAlign
            text: Qt.locale().toString(root.now, root.cfg.dateFormat)
            color: root.cfg.dateColor
            font.family: root.cfg.font
            font.pixelSize: root.cfg.dateSize
        }
    }
}
