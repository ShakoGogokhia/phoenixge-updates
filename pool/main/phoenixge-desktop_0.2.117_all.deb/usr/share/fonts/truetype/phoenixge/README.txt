Fonts used by the PhoenixGe themes, from github.com/google/fonts (SIL Open Font License 1.1):
Sora, Outfit, Manrope, Space Grotesk, Rajdhani, Nunito, Fraunces.
Inter, IBM Plex, JetBrains Mono and Noto Sans Georgian come from Debian packages.
