[Appearance]
ColorScheme=PhoenixGe-inferno
Font=JetBrains Mono,11,-1,5,400,0,0,0,0,0,0,0,0,0,0,1

[General]
Name=PhoenixGe Inferno Neon
Parent=FALLBACK/
