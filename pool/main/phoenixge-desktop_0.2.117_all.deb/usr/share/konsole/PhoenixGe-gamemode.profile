[Appearance]
ColorScheme=PhoenixGe-gamemode
Font=JetBrains Mono,11,-1,5,400,0,0,0,0,0,0,0,0,0,0,1

[General]
Name=PhoenixGe Game Mode
Parent=FALLBACK/
