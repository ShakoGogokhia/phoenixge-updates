[Appearance]
ColorScheme=PhoenixGe-mono
Font=IBM Plex Mono,11,-1,5,400,0,0,0,0,0,0,0,0,0,0,1

[General]
Name=PhoenixGe Mono
Parent=FALLBACK/
