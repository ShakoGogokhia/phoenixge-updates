[Appearance]
ColorScheme=PhoenixGe-ember
Font=JetBrains Mono,11,-1,5,400,0,0,0,0,0,0,0,0,0,0,1

[General]
Name=PhoenixGe Ember
Parent=FALLBACK/
