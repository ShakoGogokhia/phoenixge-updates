// PhoenixGe login screen - built from design/Ember-Login.dc.html
// big clock, glass card with avatar ring, name, password pill with arrow button,
// keyboard layout + session at bottom-left, PHOENIXGE wordmark, restart/power at bottom-right.
import QtQuick
import QtQuick.Layouts

Rectangle {
    id: root
    width: 1440
    height: 900
    color: "#0d0806"

    readonly property string fontName: config.font || "Sora"
    readonly property color fg: config.fg || "#f5ede6"
    readonly property color dim: config.dim || "#cdb3a2"
    readonly property color accent: config.accent || "#ff7a2e"
    property int userIndex: userModel.lastIndex >= 0 ? userModel.lastIndex : 0
    property int sessionIndex: sessionModel.lastIndex >= 0 ? sessionModel.lastIndex : 0
    property date now: new Date()
    property bool failed: false

    function userField(role) {
        var idx = userModel.index(userIndex, 0);
        return userModel.data(idx, role);
    }
    readonly property string userName: userModel.count > 0 ? (userField(Qt.UserRole + 1) || "") : ""
    readonly property string realName: userModel.count > 0 ? (userField(Qt.UserRole + 2) || "") : ""
    function login() { failed = false; sddm.login(userName, password.text, sessionIndex); }

    Connections {
        target: sddm
        function onLoginFailed() { root.failed = true; password.text = ""; password.forceActiveFocus(); }
    }
    Timer { interval: 1000; running: true; repeat: true; onTriggered: root.now = new Date() }

    Image {
        anchors.fill: parent
        source: config.background || ""
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
    }
    Rectangle { anchors.fill: parent; color: Qt.rgba(13/255, 8/255, 6/255, 0.35) }

    // ---- clock
    Column {
        anchors.horizontalCenter: parent.horizontalCenter
        y: parent.height * 0.10
        spacing: 10
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: Qt.formatTime(root.now, "HH:mm")
            color: root.fg
            font.family: root.fontName; font.pixelSize: Math.round(root.height * 0.15); font.weight: Font.Light
            font.letterSpacing: -4
        }
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: Qt.locale().toString(root.now, "dddd, d MMMM")
            color: "#e8c9b4"
            font.family: root.fontName; font.pixelSize: 20
        }
    }

    // ---- card
    Rectangle {
        id: card
        width: 400; height: cardCol.implicitHeight + 60
        anchors.horizontalCenter: parent.horizontalCenter
        y: parent.height * 0.47
        radius: 18
        color: Qt.rgba(28/255, 15/255, 11/255, Number(config.cardAlpha || 0.82))
        border.color: Qt.rgba(1, 138/255, 61/255, 0.28)

        ColumnLayout {
            id: cardCol
            anchors.fill: parent
            anchors.margins: 30
            spacing: 14

            // avatar ring (gradient orange -> pink like the design)
            Rectangle {
                Layout.alignment: Qt.AlignHCenter
                width: 96; height: 96; radius: 48
                gradient: Gradient {
                    orientation: Gradient.Vertical
                    GradientStop { position: 0; color: "#ffb070" }
                    GradientStop { position: 1; color: "#e0446a" }
                }
                Rectangle {
                    anchors.centerIn: parent
                    width: 92; height: 92; radius: 46
                    color: "#211009"
                    Image { anchors.centerIn: parent; source: "user.svg"; width: 40; height: 40; sourceSize: Qt.size(80, 80) }
                }
            }
            Text {
                Layout.alignment: Qt.AlignHCenter
                text: root.realName || root.userName
                color: root.fg
                font.family: root.fontName; font.pixelSize: 22; font.weight: Font.Bold
            }

            // password pill
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 48
                radius: 24
                color: Qt.rgba(1, 1, 1, 0.06)
                border.color: root.failed ? "#ff4d4d" : Qt.rgba(1, 138/255, 61/255, 0.55)
                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 20
                    anchors.rightMargin: 5
                    spacing: 10
                    Image { source: "lock.svg"; Layout.preferredWidth: 15; Layout.preferredHeight: 15; sourceSize: Qt.size(30, 30) }
                    TextInput {
                        id: password
                        Layout.fillWidth: true
                        echoMode: TextInput.Password
                        passwordCharacter: "•"
                        color: root.fg
                        font.family: root.fontName; font.pixelSize: 15
                        focus: true
                        clip: true
                        Keys.onReturnPressed: root.login()
                        Keys.onEnterPressed: root.login()
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            visible: !password.text
                            text: root.failed ? "Wrong password - try again" : "Password"
                            color: root.failed ? "#ff8a8a" : root.dim
                            font: password.font
                        }
                    }
                    Rectangle {
                        Layout.preferredWidth: 38; Layout.preferredHeight: 38
                        radius: 19
                        color: root.accent
                        Image { anchors.centerIn: parent; source: "arrow.svg"; width: 18; height: 18; sourceSize: Qt.size(36, 36) }
                        MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: root.login() }
                    }
                }
            }
            Text {
                Layout.alignment: Qt.AlignHCenter
                visible: userModel.count > 1
                text: "Switch user  ›"
                color: "#ffb070"
                font.family: root.fontName; font.pixelSize: 13
                MouseArea {
                    anchors.fill: parent
                    cursorShape: Qt.PointingHandCursor
                    onClicked: root.userIndex = (root.userIndex + 1) % userModel.count
                }
            }
        }
    }

    // ---- bottom left: keyboard layout + session
    Row {
        anchors { left: parent.left; bottom: parent.bottom; margins: 36 }
        spacing: 10
        Rectangle {
            visible: keyboard.layouts.length > 0
            height: 40; width: kbRow.width + 8
            radius: 12
            color: Qt.rgba(1, 1, 1, 0.04)
            border.color: Qt.rgba(1, 1, 1, 0.12)
            Row {
                id: kbRow
                anchors.centerIn: parent
                spacing: 4
                Repeater {
                    model: keyboard.layouts
                    Rectangle {
                        required property var modelData
                        required property int index
                        width: 46; height: 32; radius: 9
                        color: keyboard.currentLayout === index ? root.accent : "transparent"
                        Text {
                            anchors.centerIn: parent
                            text: String(parent.modelData.shortName).toUpperCase()
                            color: keyboard.currentLayout === parent.index ? "#1a0b06" : root.fg
                            font.family: root.fontName; font.pixelSize: 13; font.weight: Font.DemiBold
                        }
                        MouseArea { anchors.fill: parent; onClicked: keyboard.currentLayout = parent.index }
                    }
                }
            }
        }
        Rectangle {
            height: 40; width: sessRow.width + 32
            radius: 12
            color: Qt.rgba(1, 1, 1, 0.04)
            border.color: Qt.rgba(1, 1, 1, 0.12)
            Row {
                id: sessRow
                anchors.centerIn: parent
                spacing: 10
                Image { anchors.verticalCenter: parent.verticalCenter; source: "screen.svg"; width: 16; height: 16; sourceSize: Qt.size(32, 32) }
                Text {
                    id: sessName
                    anchors.verticalCenter: parent.verticalCenter
                    color: root.fg
                    font.family: root.fontName; font.pixelSize: 13
                    text: sessionModel.data(sessionModel.index(root.sessionIndex, 0), Qt.UserRole + 4) || "Plasma"
                }
            }
            MouseArea {
                anchors.fill: parent
                cursorShape: Qt.PointingHandCursor
                onClicked: root.sessionIndex = (root.sessionIndex + 1) % Math.max(1, sessionModel.rowCount())
            }
        }
    }

    // ---- wordmark
    Text {
        anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: 42 }
        textFormat: Text.StyledText
        text: "PHOENIX<font color=\"" + root.accent + "\"><b>GE</b></font>"
        color: root.dim
        font.family: root.fontName; font.pixelSize: 13; font.letterSpacing: 7
    }

    // ---- bottom right: restart + power
    Row {
        anchors { right: parent.right; bottom: parent.bottom; margins: 36 }
        spacing: 10
        Repeater {
            model: [{ icon: "restart.svg", act: "reboot" }, { icon: "power.svg", act: "poweroff" }]
            Rectangle {
                required property var modelData
                width: 42; height: 42; radius: 12
                color: hover.containsMouse ? Qt.rgba(1, 1, 1, 0.10) : Qt.rgba(1, 1, 1, 0.04)
                border.color: Qt.rgba(1, 1, 1, 0.12)
                Image { anchors.centerIn: parent; source: parent.modelData.icon; width: 18; height: 18; sourceSize: Qt.size(36, 36) }
                MouseArea {
                    id: hover
                    anchors.fill: parent
                    hoverEnabled: true
                    onClicked: parent.modelData.act === "reboot" ? sddm.reboot() : sddm.powerOff()
                }
            }
        }
    }

    Component.onCompleted: password.forceActiveFocus()
}
