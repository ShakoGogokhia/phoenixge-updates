"""PhoenixGe tweaks for DeepFaceLive (run with DeepFaceLive's own Python, from its app folder).

  deepfacelive_setup.py patch            stream output -> virtual webcam when $PHOENIXGE_VCAM is set (idempotent)
  deepfacelive_setup.py preset USERDIR   good starting settings: webcam 0, YoloV5 + FaceMesh + DFM swap on the GPU,
                                         Keanu Reeves model, output = swapped picture, virtual camera on.
                                         Only fills in what is missing/broken; the user's own choices stay.
"""
import sys
from pathlib import Path

APP = Path.cwd()
sys.path.insert(0, str(APP))

STREAMER = APP / "xlib/streamer/FFMPEGStreamer.py"
MARK = "# PhoenixGe: virtual webcam"


def patch():
    """DeepFaceLive's 'mpegts udp://' output starts ffmpeg; with PHOENIXGE_VCAM=/dev/videoN it writes to that v4l2
    device instead (the virtual camera "PhoenixGe Camera")."""
    s = STREAMER.read_text()
    if MARK in s:
        return print("streamer already patched")
    old = """                '-i', '-',
                '-f', 'mpegts',
                '-q:v', '2',
                f'udp://{self._addr}:{self._port}'
        ]"""
    new = """                '-i', '-',
        ]
        """ + MARK + """ (PHOENIXGE_VCAM=/dev/videoN set by the launcher)
        import os
        vcam = os.environ.get('PHOENIXGE_VCAM')
        if vcam and os.path.exists(vcam):
            args = [a for a in args if a != '-re'] + ['-f', 'v4l2', '-pix_fmt', 'yuv420p', vcam]
        else:
            args += ['-f', 'mpegts', '-q:v', '2', f'udp://{self._addr}:{self._port}']"""
    if old not in s:
        sys.exit("FFMPEGStreamer.py changed upstream - virtual camera patch not applied")
    STREAMER.write_text(s.replace(old, new))
    print("streamer patched for the virtual camera")


def preset(userdir):
    import apps.DeepFaceLive.backend  # noqa: F401  (imports every backend module)
    from modelhub import DFLive
    from xlib import onnxruntime as lib_ort
    from xlib.db import KeyValueDB
    M = lambda n: sys.modules["apps.DeepFaceLive.backend." + n]  # noqa: E731

    settings = Path(userdir) / "settings"
    settings.mkdir(parents=True, exist_ok=True)
    db = KeyValueDB(settings / "states.dat")
    d = db._data
    devs = lib_ort.get_available_devices_info()
    gpu = next((x for x in devs if "CUDA" in str(x)), devs[0] if devs else None)
    print("device:", gpu)

    # one chain: camera -> detect -> landmarks -> align -> DFM swap -> merge -> output
    for k, on in {"FileSource": False, "CameraSource": True, "FaceDetector": True, "FaceMarker": True,
                  "FaceAligner": True, "FaceAnimator": False, "FaceSwapInsight": False, "FaceSwapDFM": True,
                  "FrameAdjuster": True, "FaceMerger": True, "StreamOutput": True}.items():
        d[f"{k}_host_onoff"] = on

    CS = M("CameraSource")
    cs = d.get("CameraSource_worker_state") or CS.WorkerState()
    if cs.driver not in (CS._DriverType.COMPATIBLE, CS._DriverType.GSTREAMER):  # DirectShow/MSMF are Windows-only
        cs.driver = CS._DriverType.COMPATIBLE
    if cs.device_idx is None:
        cs.device_idx = 0
    d["CameraSource_worker_state"] = cs

    FD = M("FaceDetector")
    fd = d.get("FaceDetector_worker_state") or FD.WorkerState()
    if fd.detector_type is None:
        fd.detector_type = FD.DetectorType.YOLOV5
    for st in (fd.YoloV5_state, fd.center_face_state, fd.S3FD_state):
        if st.device is None:
            st.device = gpu
    d["FaceDetector_worker_state"] = fd

    FM = M("FaceMarker")
    fm = d.get("FaceMarker_worker_state") or FM.WorkerState()
    if fm.marker_type is None:
        fm.marker_type = FM.MarkerType.GOOGLE_FACEMESH
    for st in (fm.google_facemesh_state, fm.insightface_2d106_state):
        if st.device is None:
            st.device = gpu
    d["FaceMarker_worker_state"] = fm

    SW = M("FaceSwapDFM")
    sw = d.get("FaceSwapDFM_worker_state") or SW.WorkerState()
    if sw.device is None:
        sw.device = gpu
    if sw.model is None:
        models = DFLive.get_available_models_info(Path(userdir) / "dfm_models")
        sw.model = next((m for m in models if m.get_name() == "Keanu Reeves"), None)
    d["FaceSwapDFM_worker_state"] = sw

    SO = M("StreamOutput")
    so = d.get("StreamOutput_worker_state") or SO.WorkerState()
    # what other apps see: the swapped picture, the plain camera picture while no face is found
    so.source_type = SO.SourceType.MERGED_FRAME_OR_SOURCE_FRAME
    so.is_streaming = True
    d["StreamOutput_worker_state"] = so

    db._save_data()
    print("preset written:", settings / "states.dat")


if __name__ == "__main__":
    {"patch": lambda: patch(), "preset": lambda: preset(sys.argv[2])}[sys.argv[1]]()
