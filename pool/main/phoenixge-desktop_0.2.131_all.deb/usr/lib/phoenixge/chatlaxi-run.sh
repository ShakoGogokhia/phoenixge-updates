#!/bin/sh
# Start ChatlaxiAI on the fast graphics card.
# Its llama.cpp Vulkan backend takes the FIRST Vulkan device; on laptops (Intel + NVIDIA) that is the slow Intel iGPU,
# so a 12B model ran on Intel with shared RAM. With a working NVIDIA GPU we show Vulkan only the NVIDIA driver.
# CHATLAXI_ANY_GPU=1 turns this off.
if [ -z "${CHATLAXI_ANY_GPU:-}" ] && [ -z "${VK_DRIVER_FILES:-}${VK_ICD_FILENAMES:-}" ] \
   && [ -e /dev/nvidia0 ] && command -v nvidia-smi >/dev/null 2>&1 && nvidia-smi -L >/dev/null 2>&1; then
  for f in /usr/share/vulkan/icd.d/nvidia_icd.json /etc/vulkan/icd.d/nvidia_icd.json; do
    if [ -f "$f" ]; then export VK_DRIVER_FILES="$f" VK_ICD_FILENAMES="$f"; break; fi
  done
fi
exec /opt/chatlaxi-ai/chatlaxi_ai "$@"
