#!/bin/sh
# PhoenixGe desktop at login: the Trash + shortcuts to the PhoenixGe apps, so a new user sees what PhoenixGe offers.
# Every shortcut is placed ONCE (stamp in $DONE): one the user deletes stays deleted; an app added in a later
# PhoenixGe version shows up once on existing systems too. (v3 had a clean desktop with only the Trash.)
DESK=$(xdg-user-dir DESKTOP 2>/dev/null)
[ -n "$DESK" ] || DESK="$HOME/Desktop"
DONE="$HOME/.local/share/phoenixge/desktop-icons.done"
mkdir -p "$DESK" "$(dirname "$DONE")" "$HOME/Games" "$HOME/Windows Apps"

# one-time cleanup of the shortcuts from earlier PhoenixGe versions (only files PhoenixGe created)
if ! grep -qx "v3-clean" "$DONE" 2>/dev/null; then
  for f in 01-home 02-games 03-windows-apps 05-center 06-store 07-android 08-themes 09-gamemode \
           phoenixge-center phoenix-toolbox ge.chatlaxi.ai firefox-esr net.lutris.Lutris com.valvesoftware.Steam \
           com.heroicgameslauncher.hgl com.discordapp.Discord org.prismlauncher.PrismLauncher; do
    rm -f "$DESK/$f.desktop"
  done
  echo "v3-clean" >> "$DONE"
fi

if ! grep -qx "04-trash" "$DONE" 2>/dev/null; then
  printf '[Desktop Entry]\nType=Link\nName=Trash\nURL=trash:/\nIcon=phoenixge-trash\n' > "$DESK/04-trash.desktop"
  chmod +x "$DESK/04-trash.desktop"
  echo "04-trash" >> "$DONE"
fi

# PhoenixGe apps (design order = date order, the desktop sorts by date). Skipped when the app is not installed.
T=$(date +%s); i=0
[ -f "$DESK/04-trash.desktop" ] && touch -d "@$T" "$DESK/04-trash.desktop"   # Trash stays first
for app in phoenixge-center phoenixge-games phoenixge-clips phoenixge-deals phoenixge-migrate phoenix-toolbox; do
  i=$((i+1))
  grep -qx "v4:$app" "$DONE" 2>/dev/null && continue
  src=/usr/share/applications/$app.desktop
  [ -f "$src" ] || continue
  cp "$src" "$DESK/$app.desktop" && chmod +x "$DESK/$app.desktop" && touch -d "@$((T+i))" "$DESK/$app.desktop"
  echo "v4:$app" >> "$DONE"
done
