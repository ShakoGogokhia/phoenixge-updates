#!/bin/sh
# Virtual webcam "PhoenixGe Camera" (/dev/video10) for DeepFaceLive / OBS: apps write video into it, and Discord, Zoom,
# Chrome, Firefox see it as a normal webcam. Run as root (pkexec). Kept loaded at every boot.
set -e
NR=10
if ! modinfo v4l2loopback >/dev/null 2>&1; then
  export DEBIAN_FRONTEND=noninteractive
  apt-get update
  apt-get install -y v4l2loopback-dkms v4l2loopback-utils "linux-headers-$(uname -r)" || apt-get install -y v4l2loopback-dkms v4l2loopback-utils
fi
# exclusive_caps=1: Chrome/WebRTC only list "capture" devices; max_buffers=2: low latency
echo "options v4l2loopback devices=1 video_nr=$NR card_label=\"PhoenixGe Camera\" exclusive_caps=1 max_buffers=2" \
  > /etc/modprobe.d/phoenixge-vcam.conf
echo v4l2loopback > /etc/modules-load.d/phoenixge-vcam.conf
# usable by the logged-in user (DeepFaceLive writes, browsers/Discord read); without this it is root-only (0600)
cat > /etc/udev/rules.d/70-phoenixge-vcam.rules <<R
SUBSYSTEM=="video4linux", ATTR{name}=="PhoenixGe Camera", GROUP="video", MODE="0660", TAG+="uaccess"
R
udevadm control --reload-rules 2>/dev/null || true
if ! grep -q '^v4l2loopback ' /proc/modules; then
  modprobe v4l2loopback
elif [ ! -e /dev/video$NR ]; then
  modprobe -r v4l2loopback 2>/dev/null && modprobe v4l2loopback || true
fi
udevadm trigger --subsystem-match=video4linux 2>/dev/null || true
udevadm settle 2>/dev/null || true
[ -e /dev/video$NR ] || { echo "The virtual camera did not appear (/dev/video$NR). Is Secure Boot blocking the module?"; exit 1; }
echo "Virtual camera ready: /dev/video$NR \"PhoenixGe Camera\""
