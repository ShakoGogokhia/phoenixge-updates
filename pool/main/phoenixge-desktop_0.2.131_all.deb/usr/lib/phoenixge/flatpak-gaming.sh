#!/bin/sh
# PhoenixGe: GPU pieces that Flatpak games (Steam, Heroic, Lutris, ...) need from Flathub. Installs what is missing:
#  * NVIDIA: org.freedesktop.Platform.GL{,32}.nvidia-<host driver version with dashes>. Without it Flatpak games
#    silently run on the integrated GPU (or software rendering).
#  * MangoHud Vulkan layer for every Freedesktop runtime branch the launchers use: FPS counter + FPS recording for
#    games started straight from the launcher (overrides: gaming/flatpak_mangohud.py).
# No-op without system Flatpak apps or when the disk is too full.
[ -d /run/live ] && exit 0
command -v flatpak >/dev/null 2>&1 || exit 0
flatpak --system list --app --columns=application 2>/dev/null | grep -q . || exit 0
free_ok() { FREE=$(df -Pk /var/lib/flatpak 2>/dev/null | awk 'NR==2{print $4}'); [ "${FREE:-0}" -gt "$1" ]; }
H=$(flatpak --system list --runtime --columns=application,branch 2>/dev/null)
MISS=""
# MangoHud layer: one per runtime branch of the game launchers
for b in $(flatpak --system list --app --columns=application,runtime 2>/dev/null |
           awk '$1 ~ /^(com.heroicgameslauncher.hgl|com.valvesoftware.Steam|net.lutris.Lutris)$/ {split($2,r,"/"); if (r[1]=="org.freedesktop.Platform") print r[3]}' | sort -u); do
  echo "$H" | grep -q "^org.freedesktop.Platform.VulkanLayer.MangoHud[[:space:]]*$b\$" || MISS="$MISS org.freedesktop.Platform.VulkanLayer.MangoHud//$b"
done
V=$(cat /sys/module/nvidia/version 2>/dev/null)
[ -n "$V" ] || V=$(dpkg-query -W -f='${Version}' nvidia-driver-libs 2>/dev/null | sed 's/-.*//')
case "$V" in [0-9]*.[0-9]*)   # NVIDIA driver present
  N=nvidia-$(echo "$V" | tr . -)
  for e in GL GL32; do echo "$H" | grep -q "^org.freedesktop.Platform.$e.$N[[:space:]]" || MISS="$MISS org.freedesktop.Platform.$e.$N"; done ;;
esac
[ -n "$MISS" ] || exit 0
# NVIDIA GL needs ~1 GB, the MangoHud layer a few MB
case "$MISS" in *nvidia*) NEED=3000000 ;; *) NEED=300000 ;; esac
free_ok $NEED || { echo "flatpak-gaming: not enough free disk space, not installing$MISS"; exit 0; }
echo "flatpak-gaming: installing$MISS"
flatpak remote-add --if-not-exists --system flathub https://dl.flathub.org/repo/flathub.flatpakrepo &&
  flatpak install --system --noninteractive -y flathub $MISS
