"""PhoenixGe Center > Developer: databases in Docker, https://NAME.test sites, new projects, share localhost,
phone over Wi-Fi, local AI copilot for VS Code, deploy to a server, server monitor, secrets vault.

build(center) -> QWidget          work: devkit_core.py, root parts: /usr/lib/phoenixge/devkit-root.sh (pkexec)
python3 devkit.py                 the page alone
"""
import re
import shutil
import subprocess
import sys
import threading
from pathlib import Path

from PySide6.QtCore import QProcess, Qt, QTimer, QUrl
from PySide6.QtGui import QDesktopServices, QGuiApplication
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFileDialog, QFormLayout, QGridLayout,
                               QHBoxLayout, QInputDialog, QLabel, QLineEdit, QMessageBox, QPlainTextEdit, QPushButton,
                               QSpinBox, QVBoxLayout, QWidget)

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import devkit_core as dk  # noqa: E402
from systools_ui import GREEN, GREY, RED, YELLOW, Bridge, dim, dot, ui  # noqa: E402

CORE = str(HERE / "devkit_core.py")


class _Main(Bridge):
    """Lives in the UI thread; results of worker threads come back through its (queued) signal."""

    def __init__(self):
        super().__init__()
        self.result.connect(self.call)

    def call(self, item):
        done, res = item
        done(res)


_MAIN = None


def bg(fn, done):
    """Run fn() in a thread, done(result) back on the UI thread."""
    global _MAIN
    if _MAIN is None:
        _MAIN = _Main()

    def work():
        try:
            res = fn()
        except Exception as e:  # noqa: BLE001
            print("devkit:", repr(e), file=sys.stderr)
            return
        _MAIN.result.emit((done, res))
    threading.Thread(target=work, daemon=True).start()


def clear(layout):
    while layout.count():
        it = layout.takeAt(0)
        if it.widget():
            it.widget().deleteLater()
        elif it.layout():
            clear(it.layout())


def btn(text, fn, primary=False, tip=""):
    b = QPushButton(text)
    b.clicked.connect(fn)
    if primary:
        b.setObjectName("primary")
    if tip:
        b.setToolTip(tip)
    return b


def left(layout, w):
    layout.addWidget(w, 0, Qt.AlignLeft)


def copy(text):
    QGuiApplication.clipboard().setText(text)


def open_url(url):
    QDesktopServices.openUrl(QUrl(url))


class DevPage(QWidget):
    def __init__(self, center):
        super().__init__()
        self.center = center
        Card, page, _F = ui(center)
        self.Card = Card
        w, lay = page("Developer", "Everything for coding on PhoenixGe: databases, https://NAME.test sites, new projects, "
                                   "sharing, your phone for Flutter, a local AI copilot, deploying and watching your servers, "
                                   "and a safe place for .env files.")
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0); outer.addWidget(w)
        self.vault_pw = None
        self.tunnel = None
        self.cards = {}
        for key, title, text in [
            ("db", "Databases", "MySQL, PostgreSQL, Redis and Mailpit run in Docker, only reachable from this computer. "
                                "They use memory only while switched on."),
            ("sites", "Local sites (https://NAME.test)", "A real https address for a project that runs on a port, e.g. "
                                                        "https://shop.test -> localhost:8000. No certificate warnings."),
            ("new", "New project", "A ready project in ~/Projects with git. Laravel also gets its own MySQL database, "
                                   "test e-mails in Mailpit and https://NAME.test."),
            ("share", "Show localhost to a friend", "A temporary public https link to a port on this computer (Cloudflare "
                                                    "tunnel). Works behind any router; stops when you press Stop."),
            ("phone", "Android phone over Wi-Fi", "For flutter run / adb without a cable, and the phone screen on the PC."),
            ("ai", "AI copilot for VS Code", "A code model (Qwen2.5-Coder 7B) on your graphics card + the VS Code extension "
                                             "Continue: autocomplete, chat, explain and fix code. Free, offline, private."),
            ("deploy", "Deploy to a server", "One button: ssh to your server, git pull, composer/npm, migrate, restart."),
            ("mon", "Server monitor", "Your websites are checked every 2 minutes by a tray icon; you get a notification "
                                      "when one goes down or comes back."),
            ("vault", "Secrets vault", ".env files and API keys encrypted with one password (AES-256). Put them into a "
                                       "project with one click. git never commits .env files on this computer."),
        ]:
            c = Card(title, text)
            c.body = QVBoxLayout(); c.lay.addLayout(c.body)
            self.cards[key] = c
            lay.addWidget(c)
        lay.addStretch()
        self.shown_once = False

    def showEvent(self, e):
        super().showEvent(e)
        if not self.shown_once:
            self.shown_once = True
            dk.global_gitignore()
            for f in (self.fill_db, self.fill_sites, self.fill_new, self.fill_share, self.fill_phone, self.fill_ai,
                      self.fill_deploy, self.fill_mon, self.fill_vault):
                f()

    def log(self, text):
        self.center.runner.log.show()
        self.center.runner.log.appendPlainText(text)

    def body(self, key):
        b = self.cards[key].body
        clear(b)
        return b

    # ------------------------------------------------------------------ databases
    def fill_db(self):
        b = self.body("db")
        b.addWidget(dim("Checking Docker…"))
        bg(lambda: (dk.docker_ok(), {k: (dk.service_state(k), dk.service_autostarts(k)) for k in dk.SERVICES}),
           self._db_done)

    def _db_done(self, res):
        state, svc = res
        b = self.body("db")
        if state == "missing":
            b.addWidget(dim("Docker is not installed."))
            left(b, btn("Install Docker", lambda: self.center.runner.root(
                "/usr/lib/phoenixge/apt-install.sh", ["docker.io", "docker-compose"], lambda c: self.fill_db()), True))
            return
        if state == "denied":
            b.addWidget(dim("Docker is installed, but this account can't use it yet: log out and in again "
                            "(you were added to the docker group)."))
            return
        if state == "stopped":
            b.addWidget(dim("The Docker service is not running."))
            left(b, btn("Start Docker", lambda: self.center.runner.run(
                "pkexec", ["systemctl", "enable", "--now", "docker"], lambda c: self.fill_db()), True))
            return
        pw = dk.load()["passwords"]
        g = QGridLayout(); g.setHorizontalSpacing(12)
        for i, (k, (title, image, ports, _env, _vol, note)) in enumerate(dk.SERVICES.items()):
            st, auto = svc[k]
            run = st == "running"
            g.addWidget(dot(GREEN if run else GREY, 12, st), i, 0)
            g.addWidget(QLabel(f"<b>{title}</b>"), i, 1)
            port = ", ".join(f"127.0.0.1:{h}" for h, _c in ports)
            extra = note
            if k in pw:
                extra = f"{note}, password {pw[k]}"
            info = QLabel(f"{port} · {extra}"); info.setObjectName("dim")
            info.setTextInteractionFlags(Qt.TextSelectableByMouse)
            g.addWidget(info, i, 2)
            g.addWidget(btn("Stop" if run else "Start", lambda _=False, k=k, run=run: self.db_toggle(k, run)), i, 3)
            cb = QCheckBox("with the computer"); cb.setChecked(auto); cb.setEnabled(st != "none")
            cb.setToolTip("Start automatically when the computer starts")
            cb.toggled.connect(lambda on, k=k: dk.service_autostart(k, on))
            g.addWidget(cb, i, 4)
            if k in pw:
                g.addWidget(btn("Copy password", lambda _=False, k=k: copy(pw[k])), i, 5)
            if k == "mailpit" and run:
                g.addWidget(btn("Open inbox", lambda: open_url("http://localhost:8025")), i, 5)
        g.setColumnStretch(2, 1)
        b.addLayout(g)
        row = QHBoxLayout()
        row.addWidget(btn("Open DBeaver (connected)", self.dbeaver, True,
                          "DBeaver with 'PhoenixGe MySQL' and 'PhoenixGe PostgreSQL' already set up, passwords saved"))
        row.addWidget(btn("New database…", self.new_database))
        row.addWidget(btn("Refresh", self.fill_db))
        row.addStretch()
        b.addLayout(row)

    def db_toggle(self, k, running):
        title = dk.SERVICES[k][0]
        self.log(f"{'Stopping' if running else 'Starting'} {title}… (the first start downloads it, can take a few minutes)")
        bg(lambda: dk.service_stop(k) if running else dk.service_start(k),
           lambda r: (self.log(("✓ " if r[0] else "✗ ") + (r[1][-300:] if not r[0] else f"{title} {'stopped' if running else 'running'}")),
                      self.fill_db()))

    def new_database(self):
        kinds = [k for k in ("mysql", "postgres") if dk.service_state(k) == "running"]
        if not kinds:
            return QMessageBox.information(self, "New database", "Start MySQL or PostgreSQL first.")
        kind = kinds[0]
        if len(kinds) > 1:
            kind, ok = QInputDialog.getItem(self, "New database", "Where?", kinds, 0, False)
            if not ok:
                return
        name, ok = QInputDialog.getText(self, "New database", "Name (letters, digits, _):")
        if ok and name:
            bg(lambda: dk.create_database(kind, name.strip()), lambda r: self.log(("✓ " if r[0] else "✗ ") + r[1]))

    def dbeaver(self):
        def go(_code=0):
            try:
                dk.dbeaver_config()
            except Exception as e:  # noqa: BLE001
                self.log(f"DBeaver setup: {e}")
            QProcess.startDetached("flatpak", ["run", dk.DBEAVER_ID])
        if dk.dbeaver_installed():
            go()
        else:
            self.log("Installing DBeaver (Flathub)…")
            self.center.runner.run("flatpak", ["install", "-y", "--noninteractive", "flathub", dk.DBEAVER_ID],
                                   lambda c: c == 0 and go())

    # ------------------------------------------------------------------ local sites
    def fill_sites(self):
        b = self.body("sites")
        cfg = dk.load()
        if not dk.caddy_ready():
            b.addWidget(dim("First a one-time setup: the Caddy web server (HTTPS on port 443 only, port 80 stays free) "
                            "and a local certificate authority your browsers trust."))
            left(b, btn("Set up (asks for your password)", self.sites_setup, True))
            return
        if cfg["sites"]:
            g = QGridLayout(); g.setHorizontalSpacing(12)
            for i, (name, port) in enumerate(sorted(cfg["sites"].items())):
                up = dk.port_open(port)
                g.addWidget(dot(GREEN if up else GREY, 12, "running" if up else f"nothing runs on port {port}"), i, 0)
                link = QLabel(f'<a href="{dk.site_url(name)}">{dk.site_url(name)}</a>')
                link.setOpenExternalLinks(True)
                g.addWidget(link, i, 1)
                g.addWidget(dim(f"→ localhost:{port}" + ("" if up else "  (not running)")), i, 2)
                g.addWidget(btn("Remove", lambda _=False, n=name: self.site_rm(n)), i, 3)
            g.setColumnStretch(2, 1)
            b.addLayout(g)
        row = QHBoxLayout()
        self.site_name = QLineEdit(); self.site_name.setPlaceholderText("name, e.g. shop"); self.site_name.setMaximumWidth(200)
        self.site_port = QSpinBox(); self.site_port.setRange(1024, 65535); self.site_port.setValue(dk.free_port(8000))
        row.addWidget(QLabel("https://")); row.addWidget(self.site_name); row.addWidget(QLabel(".test  →  localhost:"))
        row.addWidget(self.site_port)
        row.addWidget(btn("Add", lambda: self.site_add(self.site_name.text(), self.site_port.value()), True))
        row.addStretch()
        b.addLayout(row)
        b.addWidget(dim("Laravel: php artisan serve --port 8000 · Vite/React: npm run dev -- --port 5173 · "
                        "Node: PORT=3000 npm run dev. Sub-domains work too (api.shop.test)."))

    def sites_setup(self):
        self.center.runner.root(dk.ROOT_HELPER, ["setup"], lambda c: (c == 0 and self._trusted(), self.fill_sites()))

    def _trusted(self):
        done = dk.trust_ca_in_browsers()
        self.log("Browsers that trust the local certificates: " + (", ".join(Path(d).parts[-3] for d in done) or "none yet"))

    def site_add(self, name, port, done=None):
        name = re.sub(r"[^a-z0-9-]", "-", name.strip().lower()).strip("-")
        if not name:
            return QMessageBox.information(self, "Local site", "Type a name, e.g. shop")

        def after(code):
            if code == 0:
                c = dk.load(); c["sites"][name] = int(port); dk.save(c)
                self._trusted()
            self.fill_sites()
            if done:
                done(code)
        self.center.runner.root(dk.ROOT_HELPER, ["site-add", name, str(port)], after)

    def site_rm(self, name):
        def after(code):
            if code == 0:
                c = dk.load(); c["sites"].pop(name, None); dk.save(c)
            self.fill_sites()
        self.center.runner.root(dk.ROOT_HELPER, ["site-rm", name], after)

    # ------------------------------------------------------------------ new project
    def fill_new(self):
        b = self.body("new")
        f = QFormLayout()
        self.tpl = QComboBox()
        for k, (title, desc) in dk.TEMPLATES.items():
            self.tpl.addItem(f"{title} - {desc}", k)
        self.tpl_name = QLineEdit(); self.tpl_name.setPlaceholderText("my-app")
        self.tpl_extra = QCheckBox("MySQL database + https://NAME.test + Mailpit")
        self.tpl_extra.setChecked(True)
        self.tpl.currentIndexChanged.connect(lambda: self.tpl_extra.setVisible(self.tpl.currentData() == "laravel"))
        f.addRow("Type", self.tpl); f.addRow("Name", self.tpl_name); f.addRow("", self.tpl_extra)
        b.addLayout(f)
        row = QHBoxLayout()
        row.addWidget(btn("Create in ~/Projects", self.create_project, True)); row.addStretch()
        b.addLayout(row)

    def create_project(self):
        kind = self.tpl.currentData()
        name = self.tpl_name.text().strip()
        if kind == "flutter":
            name = re.sub(r"[^a-z0-9_]", "_", name.lower())
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,60}", name or ""):
            return QMessageBox.information(self, "New project", "Type a name: letters, digits, - and _.")
        folder = dk.PROJECTS / name
        if folder.exists():
            return QMessageBox.information(self, "New project", f"{folder} already exists.")
        need = {"laravel": "composer", "node": "npm", "react": "npm"}.get(kind)
        if kind == "flutter" and not dk.flutter_bin():
            return QMessageBox.information(self, "New project", "Install Flutter first: Store > Android dev > Flutter SDK.")
        if need and not shutil.which(need):
            return QMessageBox.information(self, "New project", f"{need} is missing: Store > Coding > Developer pack.")
        if kind == "laravel" and not self._php_ok():
            self.log("Laravel needs a few PHP extensions - installing them first…")
            return self.center.runner.root(dk.ROOT_HELPER, ["php"], lambda c: c == 0 and self.create_project())
        dk.PROJECTS.mkdir(parents=True, exist_ok=True)
        extra = kind == "laravel" and self.tpl_extra.isChecked()
        self.center.runner.run("sh", ["-c", dk.template_commands(kind, name, folder)],
                               lambda code: self._created(code, kind, name, folder, extra))

    def _php_ok(self):
        out = subprocess.run(["php", "-m"], capture_output=True, text=True).stdout.lower().split()
        return all(m in out for m in ("dom", "xml", "pdo_mysql", "pdo_sqlite", "mbstring", "curl"))

    def _created(self, code, kind, name, folder, extra):
        if code != 0:
            return self.log("✗ The project could not be created - see above.")
        if kind != "laravel" or not extra:
            return self._project_ready(folder, kind)
        db = re.sub(r"[^A-Za-z0-9_]", "_", name)
        site = re.sub(r"[^a-z0-9-]", "-", name.lower()).strip("-")

        def work():
            notes = []
            for k in ("mysql", "mailpit"):
                ok, out = dk.service_start(k)
                if not ok:
                    notes.append(f"{k}: {out[-200:]}")
            ok, out = dk.create_database("mysql", db)
            notes.append(out)
            notes += dk.laravel_after(folder, db if ok else None)
            if ok:
                r = subprocess.run(["php", "artisan", "migrate", "--force", "--no-interaction"], cwd=folder,
                                   capture_output=True, text=True)
                notes.append("migrations done" if r.returncode == 0 else r.stdout[-300:] + r.stderr[-300:])
            return notes
        self.log("Laravel: MySQL database, Mailpit, https://%s.test…" % site)

        def after(notes):
            self.log("  " + "\n  ".join(notes))
            self.fill_db()
            port = dk.free_port(8000)
            self.site_add(site, port, lambda c: self._project_ready(folder, kind, port, site))
        bg(work, after)

    def _project_ready(self, folder, kind, port=None, site=None):
        run = {"laravel": f"php artisan serve --port {port or 8000}", "node": "npm run dev", "react": "npm run dev",
               "flutter": "flutter run"}[kind]
        msg = f"✓ {folder}\n  start it: cd {folder} && {run}"
        if site:
            msg += f"\n  then open {dk.site_url(site)}"
        self.log(msg)
        cmd = dk.code_cmd()
        if cmd and QMessageBox.question(self, "New project", f"{folder.name} is ready.\n\nOpen it in VS Code?") == QMessageBox.Yes:
            QProcess.startDetached(cmd[0], cmd[1:] + [str(folder)])

    # ------------------------------------------------------------------ share localhost
    def fill_share(self):
        b = self.body("share")
        row = QHBoxLayout()
        self.share_port = QSpinBox(); self.share_port.setRange(1, 65535); self.share_port.setValue(8000)
        row.addWidget(QLabel("Port")); row.addWidget(self.share_port)
        running = self.tunnel is not None
        row.addWidget(btn("Stop sharing" if running else "Share", self.share_stop if running else self.share_start, not running))
        row.addStretch()
        b.addLayout(row)
        self.share_lab = QLabel(""); self.share_lab.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.share_lab.setOpenExternalLinks(True)
        b.addWidget(self.share_lab)
        if running:
            self._share_show()

    def share_start(self):
        port = self.share_port.value()
        if not dk.port_open(port):
            if QMessageBox.question(self, "Share", f"Nothing answers on localhost:{port} yet. Share it anyway?") != QMessageBox.Yes:
                return
        if not dk.cloudflared_bin():
            self.log("Getting cloudflared…")
            return self.center.runner.run(sys.executable, [dk.__file__, "cloudflared-install"],
                                          lambda c: c == 0 and self.share_start())
        p = QProcess(self)
        p.setProcessChannelMode(QProcess.MergedChannels)
        self.tunnel, self.tunnel_url, self.tunnel_port, self.tunnel_ready = p, "", port, False
        p.readyReadStandardOutput.connect(self._share_read)
        p.finished.connect(self._share_ended)
        p.start(dk.cloudflared_bin(), ["tunnel", "--no-autoupdate", "--url", f"http://localhost:{port}"])
        self.fill_share()
        self.share_lab.setText("Opening the tunnel… (about 15 seconds)")

    def _share_read(self):
        out = bytes(self.tunnel.readAllStandardOutput()).decode(errors="replace")
        m = dk.TUNNEL_RE.search(out)
        if m and not self.tunnel_url:
            self.tunnel_url = m.group(0)
        if "Registered tunnel connection" in out and not self.tunnel_ready:
            # the new name needs a few seconds in DNS; opening it earlier gets "not found" cached for minutes
            QTimer.singleShot(8000, self._share_ready)

    def _share_ready(self):
        if self.tunnel is None or not self.tunnel_url or self.tunnel_ready:
            return
        self.tunnel_ready = True
        copy(self.tunnel_url)
        self.log(f"Shared localhost:{self.tunnel_port} → {self.tunnel_url} (link copied)")
        self._share_show()

    def _share_show(self):
        if self.tunnel_url and self.tunnel_ready:
            self.share_lab.setText(f'<b>{self.tunnel_url}</b> → localhost:{self.tunnel_port} · link copied · '
                                   f'<a href="{self.tunnel_url}">open</a>')

    def share_stop(self):
        if self.tunnel:
            self.tunnel.terminate()

    def _share_ended(self, *_a):
        self.tunnel = None
        self.fill_share()
        self.share_lab.setText("Sharing stopped.")

    # ------------------------------------------------------------------ phone over Wi-Fi
    def fill_phone(self):
        b = self.body("phone")
        if not shutil.which("adb"):
            b.addWidget(dim("adb is missing."))
            left(b, btn("Install Android tools", lambda: self.center.runner.root(
                "/usr/lib/phoenixge/apt-install.sh", ["adb", "fastboot"], lambda c: self.fill_phone()), True))
            return
        b.addWidget(dim("Looking for phones…"))
        bg(dk.adb_devices, self._phone_done)

    def _phone_done(self, devs):
        b = self.body("phone")
        if devs:
            for serial, state, model in devs:
                wifi = ":" in serial
                row = QHBoxLayout()
                ok = state == "device"
                row.addWidget(dot(GREEN if ok else YELLOW, 12, state))
                row.addWidget(QLabel(f"<b>{model or serial}</b> · {'Wi-Fi' if wifi else 'USB'} · {serial}" +
                                     ("" if ok else f" · {state} (allow USB debugging on the phone)")))
                row.addStretch()
                if ok and not wifi:
                    row.addWidget(btn("Switch to Wi-Fi", lambda _=False, s=serial: self.phone_wifi(s), True,
                                      "After this you can unplug the cable"))
                if ok:
                    row.addWidget(btn("Show screen", lambda _=False, s=serial: self.scrcpy(s)))
                if wifi:
                    row.addWidget(btn("Disconnect", lambda _=False, s=serial: (subprocess.run(["adb", "disconnect", s]),
                                                                              self.fill_phone())))
                b.addLayout(row)
        else:
            b.addWidget(dim("No phone found. Either plug it in with USB once (Developer options > USB debugging on), "
                            "or pair it over Wi-Fi (Android 11+)."))
        row = QHBoxLayout()
        row.addWidget(btn("Pair over Wi-Fi…", self.phone_pair))
        row.addWidget(btn("Refresh", self.fill_phone))
        row.addStretch()
        b.addLayout(row)

    def phone_wifi(self, serial):
        self.log("Switching the phone to Wi-Fi…")
        bg(lambda: dk.adb_usb_to_wifi(serial), lambda r: (self.log(("✓ " if r[0] else "✗ ") + r[1] +
                                                                   ("\n  You can unplug the cable now." if r[0] else "")),
                                                          self.fill_phone()))

    def phone_pair(self):
        d = QDialog(self); d.setWindowTitle("Pair a phone over Wi-Fi")
        lay = QVBoxLayout(d)
        lay.addWidget(dim("On the phone: Settings > Developer options > Wireless debugging > Pair device with pairing code. "
                          "Type what it shows. The phone and this computer must be on the same Wi-Fi."))
        f = QFormLayout()
        hp = QLineEdit(); hp.setPlaceholderText("192.168.1.23:37123  (IP address & port)")
        code = QLineEdit(); code.setPlaceholderText("123456")
        conn = QLineEdit(); conn.setPlaceholderText("optional: the IP address & port on the Wireless debugging screen")
        f.addRow("Pairing address", hp); f.addRow("Pairing code", code); f.addRow("Connect address", conn)
        lay.addLayout(f)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel); lay.addWidget(bb)
        bb.accepted.connect(d.accept); bb.rejected.connect(d.reject)
        if d.exec() != QDialog.Accepted:
            return
        self.log("Pairing…")
        bg(lambda: dk.adb_pair(hp.text().strip(), code.text().strip(), conn.text().strip()),
           lambda r: (self.log(("✓ " if r[0] else "✗ ") + r[1]), self.fill_phone()))

    def scrcpy(self, serial):
        if shutil.which("scrcpy"):
            QProcess.startDetached("scrcpy", ["-s", serial, "--window-title", "Phone"])
        else:
            self.log("Installing scrcpy…")
            self.center.runner.root("/usr/lib/phoenixge/apt-install.sh", ["-b", "scrcpy"],
                                    lambda c: c == 0 and QProcess.startDetached("scrcpy", ["-s", serial]))

    # ------------------------------------------------------------------ AI copilot
    def fill_ai(self):
        b = self.body("ai")
        s = dk.copilot_state()
        if not s["installed"]:
            b.addWidget(dim("Downloads ~4.5 GB (model + llama.cpp). Uses ~6 GB of graphics memory while it runs - stop it "
                            "for big games, ChatlaxiAI or DeepFaceLive."))
            left(b, btn("Set up AI copilot", self.ai_install, True))
            return
        row = QHBoxLayout()
        row.addWidget(dot(GREEN if s["running"] else GREY, 14))
        row.addWidget(QLabel("<b>Running</b> on 127.0.0.1:%d" % dk.COP_PORT if s["running"] else "<b>Stopped</b>"))
        row.addStretch()
        row.addWidget(btn("Stop" if s["running"] else "Start", lambda: self.ai_toggle(not s["running"]), not s["running"]))
        cb = QCheckBox("start when I log in"); cb.setChecked(s["enabled"])
        cb.toggled.connect(lambda on: dk.copilot_enable(on))
        row.addWidget(cb)
        b.addLayout(row)
        row = QHBoxLayout()
        if s["running"]:
            row.addWidget(btn("Test speed", self.ai_test))
        cmd = dk.code_cmd()
        if cmd:
            row.addWidget(btn("Open VS Code", lambda: QProcess.startDetached(cmd[0], cmd[1:])))
        if not s["extension"]:
            row.addWidget(btn("Install the VS Code extension", self.ai_install))
        row.addStretch()
        b.addLayout(row)
        b.addWidget(dim("In VS Code: the Continue icon on the left = chat about your code; ghost text while typing = "
                        "autocomplete (Tab accepts); select code + Ctrl+I = change it with an instruction."))

    def ai_install(self):
        self.log("Setting up the AI copilot - the download takes a while…")
        self.center.runner.run(sys.executable, [dk.__file__, "copilot-install"], lambda c: self.fill_ai())

    def ai_toggle(self, on):
        dk.copilot_start(on)
        QTimer.singleShot(4000 if on else 500, self.fill_ai)

    def ai_test(self):
        self.log("Asking the copilot…")

        def go():
            try:
                return dk.copilot_ask("Write a one-line Python function that reverses a string.", 80)
            except Exception as e:  # noqa: BLE001
                return (f"error: {e}", 0, 0)
        bg(go, lambda r: self.log(f"{r[0].strip()}\n  → {r[1]:.0f} tokens/second, {r[2]:.1f} s"))

    # ------------------------------------------------------------------ deploy
    def fill_deploy(self):
        b = self.body("deploy")
        cfg = dk.load()
        key = dk.ssh_key()
        for i, d in enumerate(cfg["deploy"]):
            row = QHBoxLayout()
            row.addWidget(QLabel(f"<b>{d['name']}</b>"))
            row.addWidget(dim(f"{d['host']}:{d['path']}"), 1)
            row.addWidget(btn("Deploy", lambda _=False, d=d: self.deploy(d), True))
            row.addWidget(btn("Test", lambda _=False, d=d: self.deploy(d, test=True)))
            row.addWidget(btn("Edit", lambda _=False, i=i: self.deploy_edit(i)))
            row.addWidget(btn("Remove", lambda _=False, i=i: self.deploy_rm(i)))
            b.addLayout(row)
        row = QHBoxLayout()
        row.addWidget(btn("Add a server…", lambda: self.deploy_edit(None), not cfg["deploy"]))
        row.addWidget(btn("Copy my SSH key to a server…", self.ssh_copy,
                          tip="Deploying logs in with your SSH key - this puts it on the server once (asks the server "
                              "password one time)"))
        row.addStretch()
        b.addLayout(row)
        b.addWidget(dim(f"SSH key: {key}" if key else "No SSH key yet - 'Copy my SSH key' makes one."))

    def deploy_edit(self, idx):
        cfg = dk.load()
        cur = cfg["deploy"][idx] if idx is not None else {"name": "", "host": "", "port": 22, "path": "/var/www/",
                                                          "preset": "Laravel", "cmd": dk.DEPLOY_PRESETS["Laravel"]}
        d = QDialog(self); d.setWindowTitle("Deploy target"); d.resize(640, 360)
        lay = QVBoxLayout(d); f = QFormLayout()
        name = QLineEdit(cur["name"]); name.setPlaceholderText("airlink.ge")
        host = QLineEdit(cur["host"]); host.setPlaceholderText("user@server or user@1.2.3.4")
        port = QSpinBox(); port.setRange(1, 65535); port.setValue(int(cur.get("port") or 22))
        path = QLineEdit(cur["path"])
        preset = QComboBox(); preset.addItems(list(dk.DEPLOY_PRESETS))
        preset.setCurrentText(cur.get("preset", "Custom"))
        cmd = QPlainTextEdit(cur["cmd"]); cmd.setMaximumHeight(90)
        preset.currentTextChanged.connect(lambda t: dk.DEPLOY_PRESETS[t] and cmd.setPlainText(dk.DEPLOY_PRESETS[t]))
        for label, wdg in (("Name", name), ("SSH login", host), ("SSH port", port), ("Folder on the server", path),
                           ("Type", preset), ("Commands", cmd)):
            f.addRow(label, wdg)
        lay.addLayout(f)
        bb = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel); lay.addWidget(bb)
        bb.accepted.connect(d.accept); bb.rejected.connect(d.reject)
        if d.exec() != QDialog.Accepted or not host.text().strip() or not path.text().strip():
            return
        new = {"name": name.text().strip() or host.text().strip(), "host": host.text().strip(), "port": port.value(),
               "path": path.text().strip(), "preset": preset.currentText(), "cmd": cmd.toPlainText().strip()}
        cfg = dk.load()
        if idx is None:
            cfg["deploy"].append(new)
        else:
            cfg["deploy"][idx] = new
        dk.save(cfg)
        self.fill_deploy()

    def deploy_rm(self, idx):
        cfg = dk.load()
        if QMessageBox.question(self, "Deploy", f"Remove {cfg['deploy'][idx]['name']}?") == QMessageBox.Yes:
            cfg["deploy"].pop(idx); dk.save(cfg); self.fill_deploy()

    def deploy(self, d, test=False):
        if not test and QMessageBox.question(self, "Deploy", f"Deploy {d['name']} now?\n\n{d['host']}:{d['path']}\n\n"
                                             f"{d['cmd']}") != QMessageBox.Yes:
            return
        args = dk.deploy_command(dict(d, cmd="git status -sb | head -1; git log -1 --oneline") if test else d)
        self.log(f"== {'Testing' if test else 'Deploying'} {d['name']}")
        self.center.runner.run(args[0], args[1:], lambda c: self.log(
            ("✓ " if c == 0 else "✗ ") + (f"{d['name']}: connection OK" if test else f"{d['name']} deployed") if c == 0 else
            "✗ Failed. Code 255 = can't log in: press 'Copy my SSH key to a server' once."))

    def ssh_copy(self):
        target, ok = QInputDialog.getText(self, "SSH key", "Server login (user@server):")
        if not ok or not target.strip():
            return
        target = target.strip()
        script = ("[ -f ~/.ssh/id_ed25519 ] || ssh-keygen -t ed25519 -N '' -f ~/.ssh/id_ed25519; "
                  f"ssh-copy-id -o StrictHostKeyChecking=accept-new '{target}' && echo && echo 'Done - you can close this window.'; "
                  "read -r _")
        QProcess.startDetached("konsole", ["--hold", "-e", "sh", "-c", script])
        QTimer.singleShot(3000, self.fill_deploy)

    # ------------------------------------------------------------------ monitor
    def fill_mon(self):
        b = self.body("mon")
        cfg = dk.load()
        self.mon_rows = {}
        for i, url in enumerate(cfg["monitors"]):
            row = QHBoxLayout()
            d = dot(GREY, 12, "checking…"); row.addWidget(d)
            row.addWidget(QLabel(f'<a href="{url}">{url}</a>', openExternalLinks=True))
            st = dim("checking…"); row.addWidget(st, 1)
            row.addWidget(btn("Remove", lambda _=False, u=url: self.mon_rm(u)))
            b.addLayout(row)
            self.mon_rows[url] = (d, st)
        row = QHBoxLayout()
        self.mon_url = QLineEdit(); self.mon_url.setPlaceholderText("https://example.ge")
        row.addWidget(self.mon_url, 1)
        row.addWidget(btn("Watch", self.mon_add, True))
        if cfg["monitors"]:
            row.addWidget(btn("Check now", self.fill_mon))
        b.addLayout(row)
        for url in cfg["monitors"]:
            bg(lambda u=url: (u, dk.check_url(u)), self._mon_done)

    def _mon_done(self, res):
        url, (ok, text) = res
        if url in self.mon_rows:
            d, st = self.mon_rows[url]
            d.setStyleSheet(f"background:{GREEN if ok else RED}; border-radius:6px;")
            st.setText(("up · " if ok else "") + text)

    def mon_add(self):
        url = self.mon_url.text().strip()
        if not url:
            return
        if not re.match(r"https?://", url):
            url = "https://" + url
        cfg = dk.load()
        if url not in cfg["monitors"]:
            cfg["monitors"].append(url); dk.save(cfg)
        self._mon_tray()
        self.fill_mon()

    def mon_rm(self, url):
        cfg = dk.load()
        cfg["monitors"] = [u for u in cfg["monitors"] if u != url]; dk.save(cfg)
        self._mon_tray()
        self.fill_mon()

    def _mon_tray(self):
        """Tray icon on while there is something to watch (also at every login)."""
        on = bool(dk.load()["monitors"])
        dk.monitor_autostart(on)
        subprocess.run(["pkill", "-f", r"^\S*python3\S* \S*devkit_tray\.py"], capture_output=True)
        if on:
            QProcess.startDetached(sys.executable, [str(HERE / "devkit_tray.py")])

    # ------------------------------------------------------------------ vault
    def fill_vault(self):
        b = self.body("vault")
        if not dk.vault_exists():
            row = QHBoxLayout(); row.addWidget(btn("Create the vault…", self.vault_create, True)); row.addStretch()
            b.addLayout(row)
            return
        if self.vault_pw is None:
            row = QHBoxLayout()
            row.addWidget(dot(GREY, 12)); row.addWidget(QLabel(f"Locked · {len(dk.vault_items())} items"))
            row.addWidget(btn("Unlock…", self.vault_unlock, True)); row.addStretch()
            b.addLayout(row)
            return
        for name in dk.vault_items():
            row = QHBoxLayout()
            row.addWidget(QLabel(f"<b>{name}</b>"), 1)
            row.addWidget(btn("Put into a project…", lambda _=False, n=name: self.vault_to_project(n), True))
            row.addWidget(btn("View / edit", lambda _=False, n=name: self.vault_edit(n)))
            row.addWidget(btn("Delete", lambda _=False, n=name: self.vault_del(n)))
            b.addLayout(row)
        row = QHBoxLayout()
        row.addWidget(btn("Add a .env file…", self.vault_add_file))
        row.addWidget(btn("Add text / API key…", lambda: self.vault_edit(None)))
        row.addWidget(btn("Lock", self.vault_lock))
        row.addStretch()
        b.addLayout(row)

    def vault_create(self):
        p1, ok = QInputDialog.getText(self, "Secrets vault", "New vault password (don't forget it - it can't be recovered):",
                                      QLineEdit.Password)
        if not ok or len(p1) < 6:
            return ok and QMessageBox.information(self, "Secrets vault", "At least 6 characters.")
        p2, ok = QInputDialog.getText(self, "Secrets vault", "The same password again:", QLineEdit.Password)
        if not ok or p1 != p2:
            return ok and QMessageBox.information(self, "Secrets vault", "The passwords are different.")
        if dk.vault_create(p1):
            self.vault_pw = p1
        self.fill_vault()

    def vault_unlock(self):
        pw, ok = QInputDialog.getText(self, "Secrets vault", "Vault password:", QLineEdit.Password)
        if ok:
            if dk.vault_unlock(pw):
                self.vault_pw = pw
                QTimer.singleShot(30 * 60 * 1000, self.vault_lock)   # locks itself after 30 minutes
            else:
                QMessageBox.warning(self, "Secrets vault", "Wrong password.")
        self.fill_vault()

    def vault_lock(self):
        self.vault_pw = None
        self.fill_vault()

    def vault_add_file(self):
        f, _ = QFileDialog.getOpenFileName(self, "Add a .env file", str(dk.PROJECTS), "All files (*)",
                                           options=QFileDialog.DontUseNativeDialog | QFileDialog.DontResolveSymlinks)
        if not f:
            return
        p = Path(f)
        name, ok = QInputDialog.getText(self, "Secrets vault", "Name in the vault:", text=f"{p.parent.name} {p.name}")
        if ok and name.strip():
            dk.vault_put(name.strip(), p.read_text(errors="replace"), self.vault_pw)
            self.log(f"✓ {p} saved in the vault")
            self.fill_vault()

    def vault_edit(self, name):
        d = QDialog(self); d.setWindowTitle(name or "New secret"); d.resize(640, 420)
        lay = QVBoxLayout(d)
        n = QLineEdit(name or ""); n.setPlaceholderText("name, e.g. airlink production .env")
        n.setReadOnly(bool(name))
        t = QPlainTextEdit(dk.vault_get(name, self.vault_pw) if name else "")
        t.setPlaceholderText("API_KEY=...")
        lay.addWidget(n); lay.addWidget(t)
        bb = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel); lay.addWidget(bb)
        bb.accepted.connect(d.accept); bb.rejected.connect(d.reject)
        if d.exec() == QDialog.Accepted and n.text().strip():
            dk.vault_put(n.text().strip(), t.toPlainText(), self.vault_pw)
            self.fill_vault()

    def vault_to_project(self, name):
        folder = QFileDialog.getExistingDirectory(self, "Which project?", str(dk.PROJECTS))
        if not folder:
            return
        fname, ok = QInputDialog.getText(self, "Secrets vault", "File name in the project:", text=".env")
        if not ok or not fname.strip():
            return
        target, tracked = dk.vault_to_project(name, folder, self.vault_pw, fname.strip())
        self.log(f"✓ {name} → {target}" + (" (the old file was kept as .bak)" if Path(str(target) + ".bak").exists() else ""))
        if tracked:
            QMessageBox.warning(self, "Secrets vault", f"{fname} is already committed in this git repository! Remove it "
                                f"from git (git rm --cached {fname}) and change the keys in it.")

    def vault_del(self, name):
        if QMessageBox.question(self, "Secrets vault", f"Delete {name} from the vault?") == QMessageBox.Yes:
            dk.vault_delete(name)
            self.fill_vault()


def build(center):
    return DevPage(center)


if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication
    app = QApplication(sys.argv)

    class _Host(QWidget):
        def __init__(self):
            super().__init__()
            lay = QVBoxLayout(self); self.log = QPlainTextEdit(); self.log.setMaximumHeight(160); self.log.hide()
            import center as cmod
            self.runner = cmod.Runner(self.log)
            lay.addWidget(build(self)); lay.addWidget(self.log)
    h = _Host(); h.resize(1100, 800); h.show()
    sys.exit(app.exec())
