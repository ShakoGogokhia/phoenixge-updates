#!/usr/bin/env python3
"""PhoenixGe server monitor: tray icon (green = all websites up, red = one is down), checks every 2 minutes,
notification when a site goes down or comes back. The list: Center > Developer > Server monitor
(~/.config/phoenixge/devkit.json "monitors"). Started at login only while that list is not empty.
"""
import subprocess
import sys
import threading
from pathlib import Path

from PySide6.QtCore import QObject, QProcess, QTimer, Signal
from PySide6.QtGui import QAction, QColor, QIcon, QPainter, QPixmap
from PySide6.QtWidgets import QApplication, QMenu, QSystemTrayIcon

sys.path.insert(0, str(Path(__file__).resolve().parent))
import devkit_core as dk  # noqa: E402

EVERY_MS = 120_000


def icon(color):
    pm = QPixmap(64, 64); pm.fill(QColor(0, 0, 0, 0))
    p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing)
    base = QIcon.fromTheme("network-server").pixmap(64, 64)
    if not base.isNull():
        p.drawPixmap(0, 0, base)
    p.setBrush(QColor(color)); p.setPen(QColor("#111")); p.drawEllipse(34, 34, 28, 28)
    p.end()
    return QIcon(pm)


class Monitor(QObject):
    checked = Signal(dict)

    def __init__(self):
        super().__init__()
        self.state = {}          # url -> (ok, text)
        self.tray = QSystemTrayIcon(icon("#8b949e"))
        self.tray.setToolTip("PhoenixGe server monitor")
        self.menu = QMenu()
        self.tray.setContextMenu(self.menu)
        self.tray.activated.connect(lambda r: r == QSystemTrayIcon.Trigger and self.open_center())
        self.checked.connect(self.show)
        self.tray.show()
        self.timer = QTimer(); self.timer.timeout.connect(self.check); self.timer.start(EVERY_MS)
        self.check()

    def check(self):
        urls = dk.load()["monitors"]
        if not urls:
            QApplication.quit()
            return
        threading.Thread(target=lambda: self.checked.emit({u: dk.check_url(u) for u in urls}), daemon=True).start()

    def show(self, res):
        for url, (ok, text) in res.items():
            old = self.state.get(url)
            if old is not None and old[0] != ok:
                self.notify(f"{'✓ back up' if ok else '✗ DOWN'}: {url}", text, critical=not ok)
            elif old is None and not ok:
                self.notify(f"✗ DOWN: {url}", text, critical=True)
        self.state = res
        down = [u for u, (ok, _t) in res.items() if not ok]
        self.tray.setIcon(icon("#f85149" if down else "#3fb950"))
        self.tray.setToolTip("PhoenixGe server monitor\n" + "\n".join(
            f"{'✓' if ok else '✗'} {u}  ({t})" for u, (ok, t) in res.items()))
        self.menu.clear()
        for u, (ok, t) in res.items():
            a = QAction(f"{'🟢' if ok else '🔴'} {u}  ·  {t}", self.menu)
            a.triggered.connect(lambda _=False, u=u: QProcess.startDetached("xdg-open", [u]))
            self.menu.addAction(a)
        self.menu.addSeparator()
        self.menu.addAction("Check now", self.check)
        self.menu.addAction("Edit the list…", self.open_center)
        self.menu.addAction("Quit (until next login)", QApplication.quit)

    def notify(self, title, text, critical=False):
        subprocess.Popen(["notify-send", "-a", "PhoenixGe server monitor", "-i", "network-server",
                          "-u", "critical" if critical else "normal", title, text])

    def open_center(self):
        QProcess.startDetached("phoenixge-center", ["--page", "developer"])


if __name__ == "__main__":
    import fcntl
    lock_path = Path.home() / ".cache/phoenixge/devmon.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    lock = open(lock_path, "w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        sys.exit(0)   # already running
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    m = Monitor()
    sys.exit(app.exec())
