#!/usr/bin/env python3
"""PhoenixGe Center > Developer - the work behind the page (no Qt here; also a small CLI).

  Databases     MySQL / PostgreSQL / Redis / Mailpit in Docker (ports only on 127.0.0.1), DBeaver pre-connected
  Local sites   https://NAME.test -> 127.0.0.1:PORT (Caddy + mkcert, root part: /usr/lib/phoenixge/devkit-root.sh)
  Templates     Laravel / Flutter / Node API / React (Vite) in ~/Projects
  Share         cloudflared quick tunnel (https://xxx.trycloudflare.com -> localhost:PORT)
  Copilot       llama.cpp server (Vulkan, NVIDIA preferred) + Qwen2.5-Coder 7B + VS Code "Continue"
  Deploy        ssh USER@HOST 'cd PATH && git pull && ...'
  Monitor       URLs checked by devkit_tray.py (tray icon + notifications)
  Vault         .env files / API keys encrypted with gpg (AES-256, one password), git ignores .env everywhere

CLI: devkit_core.py copilot-install | copilot-serve | cloudflared-install | dbeaver-config | status
"""
import json
import os
import re
import secrets
import shutil
import socket
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.request
from pathlib import Path

HOME = Path.home()
CFG_FILE = HOME / ".config/phoenixge/devkit.json"
DATA = HOME / ".local/share/phoenixge"
BIN = HOME / ".local/bin"
PROJECTS = HOME / "Projects"
ROOT_HELPER = "/usr/lib/phoenixge/devkit-root.sh"
CA_PEM = "/etc/phoenixge/dev-ca/rootCA.pem"
UA = {"User-Agent": "PhoenixGe-Center"}
# services/autostart point at the installed copy (not a development checkout)
SELF_DIR = Path("/usr/lib/phoenixge/center") if Path("/usr/lib/phoenixge/center/devkit_core.py").exists() \
    else Path(__file__).resolve().parent


# ------------------------------------------------------------------ config
def load():
    try:
        c = json.loads(CFG_FILE.read_text())
    except (OSError, ValueError):
        c = {}
    c.setdefault("sites", {})
    c.setdefault("deploy", [])
    c.setdefault("monitors", [])
    pw = c.setdefault("passwords", {})
    if not all(k in pw for k in ("mysql", "postgres")):   # made once, then kept (the containers are created with them)
        for k in ("mysql", "postgres"):
            pw.setdefault(k, secrets.token_urlsafe(12).replace("-", "x").replace("_", "y"))
        save(c)
    return c


def save(c):
    CFG_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = CFG_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(c, indent=2, ensure_ascii=False))
    os.chmod(tmp, 0o600)
    tmp.replace(CFG_FILE)


def run(cmd, timeout=30, **kw):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, **kw)
        return r.returncode, (r.stdout + r.stderr).strip()
    except (OSError, subprocess.TimeoutExpired) as e:
        return 1, str(e)


def port_open(port, host="127.0.0.1", timeout=0.3):
    try:
        with socket.create_connection((host, int(port)), timeout=timeout):
            return True
    except OSError:
        return False


def download(url, dest, label=""):
    """Download with progress lines (for the Center log)."""
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_name(dest.name + ".part")
    req = urllib.request.Request(url, headers=UA)
    have = part.stat().st_size if part.exists() else 0
    if have:
        req.add_header("Range", f"bytes={have}-")
    with urllib.request.urlopen(req, timeout=60) as r:
        if have and r.status != 206:
            have = 0
        total = have + int(r.headers.get("Content-Length") or 0)
        with open(part, "ab" if have else "wb") as f:
            done, last = have, 0
            while True:
                b = r.read(1 << 20)
                if not b:
                    break
                f.write(b)
                done += len(b)
                if time.time() - last > 2:
                    last = time.time()
                    pct = f"{done * 100 // total}%" if total else ""
                    print(f"  {label} {done >> 20} / {total >> 20} MB {pct}", flush=True)
    part.replace(dest)


# ------------------------------------------------------------------ databases (docker)
SERVICES = {
    # key: (title, image, container port(s), env, volume path, note)
    "mysql": ("MySQL 8.4", "mysql:8.4", [(3306, 3306)], lambda pw: {"MYSQL_ROOT_PASSWORD": pw["mysql"]},
              "/var/lib/mysql", "user root"),
    "postgres": ("PostgreSQL 17", "postgres:17", [(5432, 5432)], lambda pw: {"POSTGRES_PASSWORD": pw["postgres"]},
                 "/var/lib/postgresql/data", "user postgres"),
    "redis": ("Redis 7", "redis:7-alpine", [(6379, 6379)], lambda pw: {}, "/data", "no password"),
    "mailpit": ("Mailpit (test e-mails)", "axllent/mailpit", [(1025, 1025), (8025, 8025)], lambda pw: {}, None,
                "catches every e-mail your app sends"),
}


def docker_ok():
    if not shutil.which("docker"):
        return "missing"
    code, out = run(["docker", "info", "--format", "{{.ServerVersion}}"], timeout=8)
    if code == 0:
        return "ok"
    return "denied" if "permission denied" in out.lower() else "stopped"


def service_state(key):
    code, out = run(["docker", "inspect", "-f", "{{.State.Status}}", f"phoenixge-{key}"], timeout=8)
    return out if code == 0 else "none"


def service_start(key):
    """Create the container the first time (data in a docker volume), start it after that. -> (ok, text)"""
    title, image, ports, env, vol, _ = SERVICES[key]
    name = f"phoenixge-{key}"
    st = service_state(key)
    if st == "running":
        return True, f"{title} is running"
    if st != "none":
        code, out = run(["docker", "start", name], timeout=60)
        return code == 0, out
    pw = load()["passwords"]
    cmd = ["docker", "run", "-d", "--quiet", "--name", name, "--restart", "no"]
    for host, cont in ports:
        cmd += ["-p", f"127.0.0.1:{host}:{cont}"]
    for k, v in env(pw).items():
        cmd += ["-e", f"{k}={v}"]
    if vol:
        cmd += ["-v", f"{name}-data:{vol}"]
    cmd.append(image)
    code, out = run(cmd, timeout=900)   # first start pulls the image
    return code == 0, out[-400:]


def service_stop(key):
    code, out = run(["docker", "stop", f"phoenixge-{key}"], timeout=60)
    return code == 0, out


def service_autostart(key, on):
    run(["docker", "update", "--restart", "unless-stopped" if on else "no", f"phoenixge-{key}"])


def service_autostarts(key):
    code, out = run(["docker", "inspect", "-f", "{{.HostConfig.RestartPolicy.Name}}", f"phoenixge-{key}"], timeout=8)
    return code == 0 and out == "unless-stopped"


def create_database(kind, name):
    """New empty database in the running MySQL/Postgres container. -> (ok, text)"""
    pw = load()["passwords"]
    if not re.fullmatch(r"[A-Za-z0-9_]{1,60}", name):
        return False, "Database names: letters, digits and _ only"
    if kind == "mysql":
        for _ in range(30):  # a fresh MySQL needs some seconds before it accepts connections
            code, out = run(["docker", "exec", "-e", f"MYSQL_PWD={pw['mysql']}", "phoenixge-mysql", "mysql", "-uroot",
                             "-e", f"CREATE DATABASE IF NOT EXISTS `{name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"])
            if code == 0:
                return True, f"MySQL database {name} ready"
            time.sleep(2)
        return False, out
    for _ in range(30):
        code, out = run(["docker", "exec", "phoenixge-postgres", "psql", "-U", "postgres", "-tAc",
                         f"SELECT 1 FROM pg_database WHERE datname='{name}'"])
        if code == 0:
            if out.strip() == "1":
                return True, f"PostgreSQL database {name} exists"
            code, out = run(["docker", "exec", "phoenixge-postgres", "createdb", "-U", "postgres", name])
            return code == 0, out or f"PostgreSQL database {name} ready"
        time.sleep(2)
    return False, out


# ------------------------------------------------------------------ DBeaver
DBEAVER_ID = "io.dbeaver.DBeaverCommunity"
DBEAVER_KEY = bytes.fromhex("babb4a9f774ab853c96c2d653dfe544a")   # DBeaver's fixed key for credentials-config.json


def dbeaver_dir():
    return HOME / ".var/app" / DBEAVER_ID / "data/DBeaverData/workspace6/General/.dbeaver"


def dbeaver_installed():
    return run(["flatpak", "info", DBEAVER_ID], timeout=10)[0] == 0


def _dbeaver_crypt(data, decrypt=False):
    if decrypt:
        iv, body = data[:16], data[16:]
        code = subprocess.run(["openssl", "enc", "-d", "-aes-128-cbc", "-K", DBEAVER_KEY.hex(), "-iv", iv.hex()],
                              input=body, capture_output=True)
        return code.stdout if code.returncode == 0 else b""
    iv = os.urandom(16)
    r = subprocess.run(["openssl", "enc", "-aes-128-cbc", "-K", DBEAVER_KEY.hex(), "-iv", iv.hex()],
                       input=data, capture_output=True, check=True)
    return iv + r.stdout


def dbeaver_config():
    """Add (or refresh) "PhoenixGe MySQL" + "PhoenixGe PostgreSQL" connections with saved passwords."""
    pw = load()["passwords"]
    d = dbeaver_dir()
    d.mkdir(parents=True, exist_ok=True)
    ds_file = d / "data-sources.json"
    try:
        ds = json.loads(ds_file.read_text())
    except (OSError, ValueError):
        ds = {"folders": {}, "connections": {}}
    conns = ds.setdefault("connections", {})
    conns["phoenixge-mysql"] = {
        "provider": "mysql", "driver": "mysql8", "name": "PhoenixGe MySQL", "save-password": True,
        "configuration": {"host": "127.0.0.1", "port": "3306", "url": "jdbc:mysql://127.0.0.1:3306/",
                          "configurationType": "MANUAL", "home": "mysql_client", "type": "dev", "auth-model": "native",
                          "properties": {"allowPublicKeyRetrieval": "true", "useSSL": "false"}}}
    conns["phoenixge-postgres"] = {
        "provider": "postgresql", "driver": "postgres-jdbc", "name": "PhoenixGe PostgreSQL", "save-password": True,
        "configuration": {"host": "127.0.0.1", "port": "5432", "database": "postgres",
                          "url": "jdbc:postgresql://127.0.0.1:5432/postgres", "configurationType": "MANUAL",
                          "type": "dev", "auth-model": "native",
                          "provider-properties": {"@dbeaver-show-non-default-db@": "true"}}}
    ds_file.write_text(json.dumps(ds, indent=1))
    cred_file = d / "credentials-config.json"
    try:
        creds = json.loads(_dbeaver_crypt(cred_file.read_bytes(), decrypt=True) or b"{}")
    except (OSError, ValueError):
        creds = {}
    creds["phoenixge-mysql"] = {"#connection": {"user": "root", "password": pw["mysql"]}}
    creds["phoenixge-postgres"] = {"#connection": {"user": "postgres", "password": pw["postgres"]}}
    cred_file.write_bytes(_dbeaver_crypt(json.dumps(creds).encode()))
    print("DBeaver: PhoenixGe MySQL + PhoenixGe PostgreSQL connections saved")


# ------------------------------------------------------------------ local sites (*.test)
def caddy_ready():
    return Path("/etc/caddy/phoenixge.d").is_dir() and Path(CA_PEM).exists()


def site_url(name):
    return f"https://{name}.test"


def nss_dbs():
    """Browser certificate stores of this user: Chrome/Chromium/Edge (also Flatpak) + every Firefox profile."""
    dbs = [HOME / ".pki/nssdb"]
    dbs += [p / ".pki/nssdb" for p in (HOME / ".var/app").glob("*") if p.name in (
        "com.google.Chrome", "org.chromium.Chromium", "com.microsoft.Edge", "com.brave.Browser", "com.vivaldi.Vivaldi")]
    for base in (HOME / ".mozilla/firefox", HOME / ".config/mozilla/firefox",
                 HOME / ".var/app/org.mozilla.firefox/.mozilla/firefox"):
        dbs += [p for p in base.glob("*") if (p / "cert9.db").exists()]
    return dbs


def trust_ca_in_browsers():
    """Our local CA into every browser store of this user (system store + Firefox policy are done as root)."""
    if not (shutil.which("certutil") and Path(CA_PEM).exists()):
        return []
    done = []
    for db in nss_dbs():
        if not (db / "cert9.db").exists():
            if db.name != "nssdb":
                continue
            db.mkdir(parents=True, exist_ok=True)
            run(["certutil", "-N", "--empty-password", "-d", f"sql:{db}"])
        code, _ = run(["certutil", "-A", "-d", f"sql:{db}", "-t", "C,,", "-n", "PhoenixGe local development CA",
                       "-i", CA_PEM])
        if code == 0:
            done.append(str(db))
    return done


def site_up(name):
    try:
        import ssl
        ctx = ssl.create_default_context(cafile=CA_PEM) if Path(CA_PEM).exists() else None
        with urllib.request.urlopen(urllib.request.Request(site_url(name), headers=UA), timeout=3, context=ctx) as r:
            return r.status
    except urllib.error.HTTPError as e:
        return e.code
    except Exception:  # noqa: BLE001
        return 0


# ------------------------------------------------------------------ project templates
TEMPLATES = {
    "laravel": ("Laravel", "PHP web app + MySQL database + https://NAME.test"),
    "flutter": ("Flutter", "Android / iOS / web / desktop app"),
    "node": ("Node.js API", "Express server with hot reload"),
    "react": ("React (Vite)", "React + TypeScript web app"),
}
ENV_IGNORE = ["# PhoenixGe: never commit secrets", ".env", ".env.*", "!.env.example"]


def flutter_bin():
    for p in (shutil.which("flutter"), HOME / "flutter/bin/flutter", HOME / "development/flutter/bin/flutter",
              HOME / ".local/share/flutter/bin/flutter"):
        if p and Path(p).exists():
            return str(p)
    return None


def global_gitignore():
    """~/.config/git/ignore is git's default global ignore file: .env and keys never get committed anywhere."""
    p = HOME / ".config/git/ignore"
    try:
        cur = p.read_text().splitlines()
    except OSError:
        cur = []
    add = [l for l in ENV_IGNORE if l not in cur]
    if add:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("\n".join(cur + ([""] if cur else []) + add) + "\n")
    return p


def template_commands(kind, name, folder):
    """Shell script that creates the project (runs in a log window)."""
    q = lambda s: "'" + str(s).replace("'", "'\\''") + "'"  # noqa: E731
    f = q(folder)
    if kind == "laravel":
        return (f"set -e; cd {q(folder.parent)}; composer create-project --no-interaction laravel/laravel {q(name)}; "
                f"cd {f}; git init -q 2>/dev/null || true")
    if kind == "flutter":
        fl = flutter_bin() or "flutter"
        org = "ge.phoenix"
        return f"set -e; cd {q(folder.parent)}; {q(fl)} create --org {org} {q(name)}; cd {f}; git init -q 2>/dev/null || true"
    if kind == "node":
        return (f"set -e; mkdir -p {f}; cd {f}; npm init -y >/dev/null; npm pkg set type=module "
                f"scripts.dev='node --watch index.js' scripts.start='node index.js'; npm install express\n"
                "cat > index.js <<'JS'\n"
                "import express from 'express';\n\n"
                "const app = express();\napp.use(express.json());\n\n"
                "app.get('/', (req, res) => res.json({ hello: 'PhoenixGe' }));\n\n"
                "const port = process.env.PORT || 3000;\n"
                "app.listen(port, () => console.log(`http://localhost:${port}`));\n"
                "JS\n"
                "printf 'node_modules/\\n.env\\n' > .gitignore; printf 'PORT=3000\\n' > .env.example; "
                "git init -q 2>/dev/null || true")
    if kind == "react":
        return (f"set -e; cd {q(folder.parent)}; npm create --yes vite@latest {q(name)} -- --template react-ts "
                f"--no-interactive; cd {f}; npm install; "
                # Vite answers only to localhost by default: also allow https://NAME.test (Caddy)
                "sed -i \"s|plugins: \\[react()\\],|plugins: [react()],\\n  server: { allowedHosts: ['.test'] },|\" vite.config.ts; "
                "git init -q 2>/dev/null || true")
    raise ValueError(kind)


def laravel_after(folder, db=None):
    """Laravel: database in the PhoenixGe MySQL, trusted proxy (https://NAME.test via Caddy), mail -> Mailpit."""
    folder = Path(folder)
    env = folder / ".env"
    notes = []
    if env.exists():
        s = env.read_text()

        def setv(s, k, v):
            line = f"{k}={v}"
            if re.search(rf"^#?\s*{k}=.*$", s, re.M):
                return re.sub(rf"^#?\s*{k}=.*$", line, s, count=1, flags=re.M)
            return s.rstrip("\n") + "\n" + line + "\n"
        name = folder.name
        s = setv(s, "APP_URL", site_url(re.sub(r"[^a-z0-9-]", "-", name.lower())))
        if db:
            pw = load()["passwords"]["mysql"]
            for k, v in (("DB_CONNECTION", "mysql"), ("DB_HOST", "127.0.0.1"), ("DB_PORT", "3306"),
                         ("DB_DATABASE", db), ("DB_USERNAME", "root"), ("DB_PASSWORD", pw)):
                s = setv(s, k, v)
            notes.append(f"database {db} (MySQL)")
        for k, v in (("MAIL_MAILER", "smtp"), ("MAIL_HOST", "127.0.0.1"), ("MAIL_PORT", "1025")):
            s = setv(s, k, v)
        env.write_text(s)
    app = folder / "bootstrap/app.php"
    try:
        s = app.read_text()
        if "trustProxies" not in s:
            s2 = re.sub(r"(->withMiddleware\(function \(Middleware \$middleware\)(?:: void)? \{\n)",
                        r"\1        $middleware->trustProxies(at: '*'); // PhoenixGe: https://NAME.test via Caddy\n", s, count=1)
            if s2 != s:
                app.write_text(s2)
                notes.append("trusted proxy")
    except OSError:
        pass
    return notes


def free_port(start=8000):
    used = set(int(p) for p in load()["sites"].values())
    p = start
    while p in used or port_open(p):
        p += 1
    return p


# ------------------------------------------------------------------ share (cloudflared)
def cloudflared_bin():
    return shutil.which("cloudflared") or (str(BIN / "cloudflared") if (BIN / "cloudflared").exists() else None)


def cloudflared_install():
    print("Downloading cloudflared (Cloudflare tunnel)…", flush=True)
    download("https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64",
             BIN / "cloudflared", "cloudflared")
    os.chmod(BIN / "cloudflared", 0o755)
    print("cloudflared ready:", run([str(BIN / "cloudflared"), "--version"])[1])


TUNNEL_RE = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com")


# ------------------------------------------------------------------ AI copilot (llama.cpp + Continue)
COP = DATA / "copilot"
COP_PORT = 8090
COP_MODEL = ("Qwen2.5-Coder-7B-Instruct-Q4_K_M.gguf",
             "https://huggingface.co/bartowski/Qwen2.5-Coder-7B-Instruct-GGUF/resolve/main/"
             "Qwen2.5-Coder-7B-Instruct-Q4_K_M.gguf", 4683074336)
COP_UNIT = HOME / ".config/systemd/user/phoenixge-copilot.service"
CODE_FLATPAK = "com.visualstudio.code"
CONTINUE_CFG = HOME / ".continue/config.yaml"


def copilot_server_bin():
    hits = sorted(COP.glob("llama/**/llama-server"))
    return hits[0] if hits else None


def copilot_state():
    """dict(installed, running, model, server, extension)"""
    m = COP / "models" / COP_MODEL[0]
    return dict(server=bool(copilot_server_bin()), model=m.exists(),
                installed=bool(copilot_server_bin()) and m.exists() and COP_UNIT.exists(),
                running=port_open(COP_PORT),
                enabled=run(["systemctl", "--user", "is-enabled", "phoenixge-copilot"])[1] == "enabled",
                extension=continue_installed())


def code_cmd():
    """VS Code: native `code` or the Flatpak."""
    if shutil.which("code"):
        return ["code"]
    if run(["flatpak", "info", CODE_FLATPAK], timeout=10)[0] == 0:
        return ["flatpak", "run", CODE_FLATPAK]
    return None


def continue_installed():
    for d in (HOME / ".vscode/extensions", HOME / ".var/app" / CODE_FLATPAK / "data/vscode/extensions"):
        if any(d.glob("continue.continue-*")):
            return True
    return False


def write_continue_config():
    cfg = f"""# PhoenixGe AI copilot (Center > Developer): local model, nothing leaves this computer.
name: PhoenixGe local AI
version: 1.0.0
schema: v1
models:
  - name: Qwen2.5 Coder 7B (local)
    provider: llama.cpp
    model: qwen2.5-coder-7b
    apiBase: http://127.0.0.1:{COP_PORT}
    roles:
      - chat
      - edit
      - apply
      - autocomplete
    defaultCompletionOptions:
      contextLength: 16384
      maxTokens: 2048
    autocompleteOptions:
      debounceDelay: 250
      maxPromptTokens: 2048
"""
    if CONTINUE_CFG.exists() and "PhoenixGe" not in CONTINUE_CFG.read_text():
        shutil.copy2(CONTINUE_CFG, CONTINUE_CFG.with_suffix(".yaml.before-phoenixge"))
    CONTINUE_CFG.parent.mkdir(parents=True, exist_ok=True)
    CONTINUE_CFG.write_text(cfg)


def copilot_install():
    COP.mkdir(parents=True, exist_ok=True)
    if not copilot_server_bin():
        print("Getting llama.cpp (Vulkan build)…", flush=True)
        req = urllib.request.Request("https://api.github.com/repos/ggml-org/llama.cpp/releases?per_page=10", headers=UA)
        rel = json.load(urllib.request.urlopen(req, timeout=30))
        asset = next(a for r in rel for a in r.get("assets", []) if re.search(r"bin-ubuntu-vulkan-x64\.tar\.gz$", a["name"]))
        tgz = COP / asset["name"]
        download(asset["browser_download_url"], tgz, "llama.cpp")
        shutil.rmtree(COP / "llama", ignore_errors=True)
        with tarfile.open(tgz) as t:
            t.extractall(COP / "llama", filter="data")
        tgz.unlink()
        print("llama.cpp:", copilot_server_bin(), flush=True)
    m = COP / "models" / COP_MODEL[0]
    if not m.exists():
        free = shutil.disk_usage(HOME).free
        if free < COP_MODEL[2] + 3 * 2**30:
            sys.exit(f"Needs ~{COP_MODEL[2] // 2**30 + 3} GB free in your home folder, only {free // 2**30} GB free.")
        print("Downloading the code model Qwen2.5-Coder 7B (4.4 GB)…", flush=True)
        download(COP_MODEL[1], m, "model")
    COP_UNIT.parent.mkdir(parents=True, exist_ok=True)
    COP_UNIT.write_text(f"""[Unit]
Description=PhoenixGe AI copilot (local code model for VS Code)

[Service]
ExecStart=/usr/bin/python3 {SELF_DIR / 'devkit_core.py'} copilot-serve
Restart=on-failure
RestartSec=5

[Install]
WantedBy=default.target
""")
    run(["systemctl", "--user", "daemon-reload"])
    write_continue_config()
    print("Continue config:", CONTINUE_CFG, flush=True)
    code = code_cmd()
    if code and not continue_installed():
        print("Installing the VS Code extension Continue…", flush=True)
        c, out = run(code + ["--install-extension", "Continue.continue", "--force"], timeout=300)
        print(out[-500:], flush=True)
    elif not code:
        print("VS Code is not installed - install it in Store > Coding, then press Set up again for the extension.")
    print("AI copilot installed.", flush=True)


def copilot_serve():
    """systemd user service: llama-server on 127.0.0.1:8090, on the NVIDIA GPU when there is one."""
    srv = copilot_server_bin()
    if not srv:
        sys.exit("llama-server missing - Center > Developer > AI copilot > Set up")
    env = dict(os.environ)
    nv = [f for f in ("/usr/share/vulkan/icd.d/nvidia_icd.json", "/etc/vulkan/icd.d/nvidia_icd.json") if Path(f).exists()]
    if nv and Path("/dev/nvidia0").exists() and run(["nvidia-smi", "-L"], timeout=10)[0] == 0:
        env["VK_DRIVER_FILES"] = env["VK_ICD_FILENAMES"] = nv[0]   # first Vulkan device = Intel iGPU on laptops
    env["LD_LIBRARY_PATH"] = f"{srv.parent}:{env.get('LD_LIBRARY_PATH', '')}"
    os.execve(str(srv), [str(srv), "-m", str(COP / "models" / COP_MODEL[0]), "--alias", "qwen2.5-coder-7b",
                         "--host", "127.0.0.1", "--port", str(COP_PORT), "-ngl", "99", "-c", "16384",
                         "--parallel", "2", "--cache-reuse", "256"], env)


def copilot_start(on=True):
    return run(["systemctl", "--user", "start" if on else "stop", "phoenixge-copilot"], timeout=30)


def copilot_enable(on):
    return run(["systemctl", "--user", "enable" if on else "disable", "phoenixge-copilot"], timeout=30)


def copilot_ask(prompt, max_tokens=64):
    body = json.dumps({"model": "qwen2.5-coder-7b", "messages": [{"role": "user", "content": prompt}],
                       "max_tokens": max_tokens}).encode()
    req = urllib.request.Request(f"http://127.0.0.1:{COP_PORT}/v1/chat/completions", body,
                                 {"Content-Type": "application/json"})
    t = time.time()
    with urllib.request.urlopen(req, timeout=120) as r:
        d = json.load(r)
    tm = d.get("timings", {})
    return d["choices"][0]["message"]["content"], tm.get("predicted_per_second", 0), time.time() - t


# ------------------------------------------------------------------ deploy
DEPLOY_PRESETS = {
    "Laravel": "git pull --ff-only && composer install --no-dev --optimize-autoloader --no-interaction && "
               "php artisan migrate --force && php artisan optimize && (php artisan queue:restart || true)",
    "Node.js (pm2)": "git pull --ff-only && npm ci && (npm run build --if-present) && pm2 reload all",
    "Static / git only": "git pull --ff-only",
    "Custom": "",
}


def deploy_command(d):
    q = lambda s: "'" + str(s).replace("'", "'\\''") + "'"  # noqa: E731
    remote = f"set -e; cd {q(d['path'])}; echo \"== $(hostname): $(pwd)\"; {d['cmd']}"
    args = ["-o", "BatchMode=yes", "-o", "ConnectTimeout=15", "-o", "StrictHostKeyChecking=accept-new"]
    if d.get("port"):
        args += ["-p", str(d["port"])]
    return ["ssh", *args, d["host"], remote]


def ssh_key():
    for n in ("id_ed25519", "id_ecdsa", "id_rsa"):
        if (HOME / ".ssh" / n).exists():
            return HOME / ".ssh" / n
    return None


# ------------------------------------------------------------------ monitor
MON_STATE = HOME / ".cache/phoenixge/devmon.json"
MON_AUTOSTART = HOME / ".config/autostart/phoenixge-devmon.desktop"


def check_url(url, timeout=10):
    """-> (ok, text). Up = any answer below 500 within the timeout."""
    t = time.time()
    try:
        req = urllib.request.Request(url, headers=UA, method="GET")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            code = r.status
    except urllib.error.HTTPError as e:
        code = e.code
    except Exception as e:  # noqa: BLE001
        reason = getattr(e, "reason", e)
        return False, f"down ({str(reason)[:60]})"
    ms = int((time.time() - t) * 1000)
    return code < 500, f"{code}, {ms} ms"


def monitor_autostart(on):
    if on:
        MON_AUTOSTART.parent.mkdir(parents=True, exist_ok=True)
        MON_AUTOSTART.write_text(f"""[Desktop Entry]
Type=Application
Name=PhoenixGe server monitor
Comment=Tray icon: are my websites up?
Exec=/usr/bin/python3 {SELF_DIR / 'devkit_tray.py'}
Icon=network-server
X-KDE-autostart-after=panel
""")
    else:
        MON_AUTOSTART.unlink(missing_ok=True)


# ------------------------------------------------------------------ vault (gpg, AES-256)
VAULT = DATA / "vault"
VAULT_CHECK = VAULT / ".check.gpg"


def _gpg(args, data, password):
    r, w = os.pipe()
    os.write(w, password.encode() + b"\n")
    os.close(w)
    try:
        p = subprocess.run(["gpg", "--batch", "--yes", "--quiet", "--pinentry-mode", "loopback", "--passphrase-fd", str(r),
                            *args], input=data, capture_output=True, pass_fds=(r,), timeout=30)
    finally:
        os.close(r)
    return p.returncode == 0, p.stdout, p.stderr.decode(errors="replace")


def vault_exists():
    return VAULT_CHECK.exists()


def vault_create(password):
    VAULT.mkdir(parents=True, exist_ok=True)
    os.chmod(VAULT, 0o700)
    ok, out, err = _gpg(["--symmetric", "--cipher-algo", "AES256", "-o", "-"], b"phoenixge-vault", password)
    if ok:
        VAULT_CHECK.write_bytes(out)
    return ok


def vault_unlock(password):
    ok, out, _ = _gpg(["--decrypt"], VAULT_CHECK.read_bytes(), password)
    return ok and out == b"phoenixge-vault"


def vault_items():
    return sorted(p.stem for p in VAULT.glob("*.gpg") if not p.name.startswith("."))


def vault_put(name, text, password):
    name = re.sub(r"[^\w.\- ]", "_", name).strip() or "secret"
    ok, out, err = _gpg(["--symmetric", "--cipher-algo", "AES256", "-o", "-"], text.encode(), password)
    if not ok:
        raise RuntimeError(err)
    p = VAULT / f"{name}.gpg"
    p.write_bytes(out)
    os.chmod(p, 0o600)
    return name


def vault_get(name, password):
    ok, out, err = _gpg(["--decrypt"], (VAULT / f"{name}.gpg").read_bytes(), password)
    if not ok:
        raise RuntimeError(err)
    return out.decode()


def vault_delete(name):
    (VAULT / f"{name}.gpg").unlink(missing_ok=True)


def vault_to_project(name, folder, password, filename=".env"):
    """Write the secret into the project and make sure git ignores it there too."""
    folder = Path(folder)
    target = folder / filename
    if target.exists():
        shutil.copy2(target, target.with_name(target.name + ".bak"))
    target.write_text(vault_get(name, password))
    os.chmod(target, 0o600)
    gi = folder / ".gitignore"
    lines = gi.read_text().splitlines() if gi.exists() else []
    if filename not in lines and ".env" not in lines:
        gi.write_text("\n".join(lines + [filename]) + "\n")
    tracked = run(["git", "-C", str(folder), "ls-files", "--error-unmatch", filename])[0] == 0
    return target, tracked


# ------------------------------------------------------------------ phone (adb over Wi-Fi)
def adb_devices():
    """[(serial, state, model)]"""
    code, out = run(["adb", "devices", "-l"], timeout=15)
    devs = []
    for line in out.splitlines()[1:]:
        f = line.split()
        if len(f) >= 2 and not line.startswith("*"):
            model = next((x.split(":", 1)[1] for x in f if x.startswith("model:")), "")
            devs.append((f[0], f[1], model.replace("_", " ")))
    return devs


def adb_usb_to_wifi(serial):
    """Phone on USB -> adb over Wi-Fi (port 5555). -> (ok, text)"""
    code, out = run(["adb", "-s", serial, "shell", "ip", "-f", "inet", "-o", "addr", "show", "wlan0"], timeout=15)
    m = re.search(r"inet (\d+\.\d+\.\d+\.\d+)", out)
    if not m:
        return False, "The phone is not on Wi-Fi (no wlan0 address). Connect it to the same Wi-Fi as this computer."
    ip = m.group(1)
    run(["adb", "-s", serial, "tcpip", "5555"], timeout=20)
    time.sleep(2)
    code, out = run(["adb", "connect", f"{ip}:5555"], timeout=20)
    return "connected" in out, out


def adb_pair(hostport, code_, connect_hostport=""):
    c, out = run(["adb", "pair", hostport, code_], timeout=30)
    if "Successfully paired" not in out:
        return False, out
    if connect_hostport:
        c, out2 = run(["adb", "connect", connect_hostport], timeout=20)
        return "connected" in out2, out + "\n" + out2
    # Android announces the connect port via mDNS; adb connects by itself after pairing
    time.sleep(3)
    return True, out


# ------------------------------------------------------------------ CLI
if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "status"
    if cmd == "copilot-install":
        copilot_install()
    elif cmd == "copilot-serve":
        copilot_serve()
    elif cmd == "cloudflared-install":
        cloudflared_install()
    elif cmd == "dbeaver-config":
        dbeaver_config()
    elif cmd == "status":
        print("docker:", docker_ok())
        for k in SERVICES:
            print(f"  {k}: {service_state(k)}")
        print("caddy ready:", caddy_ready(), "sites:", load()["sites"])
        print("copilot:", copilot_state())
        print("cloudflared:", cloudflared_bin())
    else:
        sys.exit(__doc__)
