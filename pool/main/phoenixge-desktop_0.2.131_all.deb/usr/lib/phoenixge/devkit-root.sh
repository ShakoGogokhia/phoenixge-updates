#!/bin/sh
# PhoenixGe Center > Developer: the parts that need root (run with pkexec).
#   devkit-root.sh setup               Caddy (local web server) + mkcert CA, trusted by the system and Firefox
#   devkit-root.sh site-add NAME PORT  https://NAME.test -> http://127.0.0.1:PORT  (/etc/hosts + certificate + Caddy)
#   devkit-root.sh site-rm NAME
#   devkit-root.sh php                 PHP extensions Laravel needs (dom/xml, mysql, pgsql, sqlite, bcmath, gd)
set -e
CA=/etc/phoenixge/dev-ca            # rootCA.pem (public, readable) + rootCA-key.pem (root only)
SITES=/etc/caddy/phoenixge.d
CERTS=/etc/caddy/phoenixge-certs
export DEBIAN_FRONTEND=noninteractive

need() {  # install missing packages
  miss=""
  for p in "$@"; do dpkg -s "$p" >/dev/null 2>&1 || miss="$miss $p"; done
  [ -z "$miss" ] && return 0
  echo "Installing:$miss"
  apt-get update -q || true
  apt-get install -y $miss
}

hosts_set() {  # hosts_set NAME add|rm  - keeps our names between markers in /etc/hosts
  python3 - "$1" "$2" <<'PY'
import re, sys
name, op = sys.argv[1], sys.argv[2]
p = "/etc/hosts"
s = open(p).read()
B, E = "# phoenixge-dev begin", "# phoenixge-dev end"
m = re.search(re.escape(B) + r"\n(.*?)" + re.escape(E) + r"\n?", s, re.S)
names = set(m.group(1).split()) - {"127.0.0.1", "::1"} if m else set()
names.discard(name)
if op == "add":
    names.add(name)
block = (B + "\n" + "".join(f"127.0.0.1 {n}\n::1 {n}\n" for n in sorted(names)) + E + "\n") if names else ""
s = (s[:m.start()] + block + s[m.end():]) if m else (s.rstrip("\n") + "\n" + block)
open(p, "w").write(s)
PY
}

setup() {
  need caddy mkcert libnss3-tools
  mkdir -p "$CA" "$SITES" "$CERTS"
  chmod 755 "$CA"
  if [ ! -f "$CA/rootCA-key.pem" ]; then
    CAROOT="$CA" TRUST_STORES=system mkcert -install
  else
    CAROOT="$CA" TRUST_STORES=system mkcert -install >/dev/null
  fi
  chmod 644 "$CA/rootCA.pem"; chmod 600 "$CA/rootCA-key.pem"
  # Firefox (all profiles, also new ones): trust the system CAs + ours
  for d in /usr/lib/firefox-esr/distribution /usr/lib/firefox/distribution; do
    [ -d "$(dirname "$d")" ] || continue
    mkdir -p "$d"
    python3 - "$d/policies.json" "$CA/rootCA.pem" <<'PY'
import json, sys, os
p, ca = sys.argv[1], sys.argv[2]
d = json.load(open(p)) if os.path.exists(p) else {}
c = d.setdefault("policies", {}).setdefault("Certificates", {})
c["ImportEnterpriseRoots"] = True
c["Install"] = sorted(set(c.get("Install", [])) | {ca})
json.dump(d, open(p, "w"), indent=2)
PY
  done
  # Caddy: our sites live in phoenixge.d/*.caddy. Only HTTPS (443): port 80 stays free for Apache/nginx/dev servers.
  CF=/etc/caddy/Caddyfile
  if ! grep -q "PhoenixGe" "$CF" 2>/dev/null; then
    if [ ! -s "$CF" ] || [ "$(grep -vE '^\s*(#|$)' "$CF" | grep -v phoenixge.d | tr -d ' \t\n')" = ":80{root*/usr/share/caddyfile_server}" ]; then
      [ -f "$CF" ] && cp "$CF" "$CF.debian-default"
      cat > "$CF" <<EOF
# PhoenixGe local sites (Center > Developer): https://NAME.test -> 127.0.0.1:PORT.
# Only HTTPS on 443 - port 80 stays free (Apache, nginx, dev servers). Debian's default file: Caddyfile.debian-default
{
	auto_https disable_redirects
}
import $SITES/*.caddy
EOF
    else   # the owner's own Caddyfile: just add our sites
      grep -q "phoenixge.d" "$CF" || printf '\nimport %s/*.caddy\n' "$SITES" >> "$CF"
    fi
  fi
  [ -n "$(ls "$SITES" 2>/dev/null)" ] || echo "# PhoenixGe local sites" > "$SITES/00-phoenixge.caddy"
  systemctl enable caddy >/dev/null 2>&1 || true
  systemctl restart caddy
  echo "Local web server ready (Caddy). CA: $CA/rootCA.pem"
}

case "$1" in
  setup) setup ;;
  site-add)
    NAME=$(echo "$2" | tr 'A-Z' 'a-z'); PORT="$3"
    echo "$NAME" | grep -Eq '^[a-z0-9]([a-z0-9-]{0,40}[a-z0-9])?$' || { echo "Bad name: $NAME"; exit 2; }
    echo "$PORT" | grep -Eq '^[0-9]{2,5}$' || { echo "Bad port: $PORT"; exit 2; }
    [ -f "$CA/rootCA-key.pem" ] && command -v caddy >/dev/null || setup
    D="$NAME.test"
    CAROOT="$CA" mkcert -cert-file "$CERTS/$D.pem" -key-file "$CERTS/$D-key.pem" "$D" "*.$D" >/dev/null 2>&1
    chown root:caddy "$CERTS/$D.pem" "$CERTS/$D-key.pem"; chmod 640 "$CERTS/$D.pem" "$CERTS/$D-key.pem"
    cat > "$SITES/$NAME.caddy" <<EOF
# PhoenixGe local site (Center > Developer)
$D, *.$D {
	tls $CERTS/$D.pem $CERTS/$D-key.pem
	reverse_proxy 127.0.0.1:$PORT
}
EOF
    hosts_set "$D" add
    caddy validate --config /etc/caddy/Caddyfile --adapter caddyfile >/dev/null 2>&1 || { rm -f "$SITES/$NAME.caddy"; echo "Caddy config error"; exit 1; }
    systemctl reload caddy 2>/dev/null || systemctl restart caddy
    echo "https://$D -> http://127.0.0.1:$PORT" ;;
  site-rm)
    NAME=$(echo "$2" | tr 'A-Z' 'a-z')
    echo "$NAME" | grep -Eq '^[a-z0-9-]+$' || exit 2
    rm -f "$SITES/$NAME.caddy" "$CERTS/$NAME.test.pem" "$CERTS/$NAME.test-key.pem"
    hosts_set "$NAME.test" rm
    systemctl reload caddy 2>/dev/null || true
    echo "Removed $NAME.test" ;;
  php)
    V=$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null || echo "")
    need php-cli php-xml php-mysql php-pgsql php-sqlite3 php-bcmath php-gd php-curl php-mbstring php-zip php-intl composer unzip
    echo "PHP ${V} ready for Laravel" ;;
  *) echo "usage: $0 setup | site-add NAME PORT | site-rm NAME | php"; exit 2 ;;
esac
