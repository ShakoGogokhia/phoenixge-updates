"""Let games started from Flatpak launchers (Heroic, Steam, Lutris) record FPS for Phoenix Games and the overlay.

Games started straight from such a launcher never go through phoenix-game-run, and the sandbox hides both the host
MangoHud and ~/.local/share/phoenixge/perf. This sets per-user Flatpak overrides so MangoHud (the Flatpak Vulkan
layer org.freedesktop.Platform.VulkanLayer.MangoHud, installed by /usr/lib/phoenixge/flatpak-gaming.sh) loads in
their games and logs into perf/_incoming - hidden unless the FPS counter is wanted (settings.overlay_wanted).
With fps_log off and no FPS counter the overrides are removed again.

    python3 flatpak_mangohud.py      run at login (autostart) and whenever Center changes an FPS setting
"""
import os
import shutil
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import perf  # noqa: E402
import settings  # noqa: E402

LAUNCHERS = ("com.heroicgameslauncher.hgl", "com.valvesoftware.Steam", "net.lutris.Lutris")
PERF_FS = "xdg-data/phoenixge/perf:create"


def installed(app):
    return subprocess.run(["flatpak", "info", app], capture_output=True).returncode == 0


def sync():
    if not shutil.which("flatpak"):
        return 0
    conf = settings.load()
    show = settings.overlay_wanted(conf)
    for app in filter(installed, LAUNCHERS):
        if conf["fps_log"] or show:
            perf.INCOMING.mkdir(parents=True, exist_ok=True)
            cfg = ["read_cfg", "log_interval=100", f"output_folder={perf.INCOMING}"]
            if conf["fps_log"]:
                cfg.insert(1, "autostart_log=1")
            if not show:
                cfg.append("no_display")
            args = [f"--filesystem={PERF_FS}", "--env=MANGOHUD=1", "--env=MANGOHUD_CONFIG=" + ",".join(cfg)]
        else:
            args = [f"--nofilesystem={PERF_FS}", "--unset-env=MANGOHUD", "--unset-env=MANGOHUD_CONFIG"]
        subprocess.run(["flatpak", "override", "--user", *args, app], capture_output=True)
    return 0


if __name__ == "__main__":
    sys.exit(sync())
