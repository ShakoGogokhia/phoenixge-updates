"""PhoenixGe gaming settings - one small INI file per user, read by every gaming helper.

File: ~/.config/phoenixge/gaming.conf  (missing file or missing keys = defaults below)

    [gaming]
    # --- while a game runs (GameMode start/end hooks, see /etc/gamemode.ini) ---
    power_profile = true        # switch power-profiles-daemon to "performance", restore the previous profile afterwards
    do_not_disturb = true       # Plasma Do Not Disturb (notification inhibit) while playing
    pause_updates = true        # stop update/maintenance timers (apt-daily, PhoenixGe first-boot, flatpak, fwupd, man-db...)
                                # and run already running apt/PackageKit/flatpak processes at idle CPU/IO priority
    pause_autotheme = true      # do not switch the day/night theme in the middle of a game
    suspend_compositor = false  # X11 session only (Wayland cannot run without the compositor): suspend KWin compositing
    # --- games started from Phoenix Games (phoenix-game-run) ---
    gamemode = true             # register the game with GameMode (CPU governor, priority + everything above)
    fps_log = true              # record FPS / temperatures with MangoHud into ~/.local/share/phoenixge/perf/<game>/
    fps_overlay = auto          # auto = follow PhoenixGe Center's "Show FPS counter" switch; true / false = force
    keep_logs = 20              # recorded sessions kept per game (oldest are deleted)
    # --- PhoenixGe Overlay (Meta+G) ---
    overlay_mode = game         # game = only while a game runs (started with the game, quits after it); always
    discord = true              # Discord "Playing ..." status while the game runs
    discord_client_id =         # Discord application id; empty = the built-in PhoenixGe id (discord_rpc.CLIENT_ID)

PhoenixGe Center reads/writes it with load() / save().
"""
import configparser
import os
from pathlib import Path

HOME = Path.home()
CONF = Path(os.environ.get("XDG_CONFIG_HOME") or HOME / ".config") / "phoenixge/gaming.conf"
# PhoenixGe Center's "Show FPS counter (MangoHud) in every game" switch
CENTER_OVERLAY_FILE = Path(os.environ.get("XDG_CONFIG_HOME") or HOME / ".config") / "environment.d/phoenixge-mangohud.conf"

DEFAULTS = {
    "power_profile": True,
    "do_not_disturb": True,
    "pause_updates": True,
    "pause_autotheme": True,
    "suspend_compositor": False,
    "gamemode": True,
    "fps_log": True,
    "fps_overlay": "auto",
    "keep_logs": 20,
    "overlay_mode": "game",
    "discord": True,
    "discord_client_id": "",
}


def _convert(key, raw):
    d = DEFAULTS[key]
    raw = raw.strip()
    if isinstance(d, bool):
        return raw.lower() in ("1", "true", "yes", "on")
    if isinstance(d, int):
        try:
            return int(raw)
        except ValueError:
            return d
    return raw


def load():
    conf = dict(DEFAULTS)
    cp = configparser.ConfigParser(inline_comment_prefixes=("#", ";"))
    try:
        cp.read(CONF)
    except configparser.Error:
        return conf
    if cp.has_section("gaming"):
        for k, v in cp.items("gaming"):
            if k in DEFAULTS:
                conf[k] = _convert(k, v)
    return conf


def save(conf):
    cp = configparser.ConfigParser()
    cp["gaming"] = {k: (str(v).lower() if isinstance(v, bool) else str(v)) for k, v in {**DEFAULTS, **conf}.items()
                    if k in DEFAULTS}
    CONF.parent.mkdir(parents=True, exist_ok=True)
    tmp = CONF.with_suffix(".tmp")
    with open(tmp, "w") as f:
        cp.write(f)
    tmp.replace(CONF)


def overlay_wanted(conf=None):
    """Should the MangoHud overlay be visible (otherwise MangoHud only records, hidden)?"""
    v = str((conf or load()).get("fps_overlay", "auto")).lower()
    if v in ("1", "true", "yes", "on"):
        return True
    if v in ("0", "false", "no", "off"):
        return False
    return CENTER_OVERLAY_FILE.exists()


def overlay_always(conf=None):
    """PhoenixGe Overlay mode: True = always available, False (default) = only while a game is running."""
    return str((conf or load()).get("overlay_mode", "game")).lower() == "always"


def game_running(fresh=15):
    """Is a game running right now? A MangoHud log under perf/ that is still being written (Heroic/Steam/Phoenix
    Games with FPS recording) or an active GameMode session (games started with gamemoderun / phoenix-game-run)."""
    import glob
    import subprocess
    import time
    root = Path(os.environ.get("XDG_DATA_HOME") or HOME / ".local/share") / "phoenixge/perf"
    now = time.time()
    for p in glob.glob(str(root / "**" / "*.csv"), recursive=True):
        try:
            if now - os.stat(p).st_mtime < fresh:
                return True
        except OSError:
            pass
    try:
        r = subprocess.run(["gamemoded", "-s"], capture_output=True, text=True, timeout=3)
        return "is active" in r.stdout
    except (OSError, subprocess.SubprocessError):
        return False
