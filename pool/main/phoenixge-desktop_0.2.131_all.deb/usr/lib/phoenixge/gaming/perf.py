"""FPS history: MangoHud CSV logs per game session + a small chart widget for Phoenix Games.

Logs live in ~/.local/share/phoenixge/perf/<game-dir>/<program>_<YYYY-MM-DD_HH-MM-SS>.csv (written by MangoHud,
started by phoenix-game-run). MangoHud log format (src/logging.cpp, 0.7/0.8):

    os,cpu,gpu,ram,kernel,driver,cpuscheduler                 <- system info header
    Debian GNU/Linux 13 (trixie),AMD Ryzen 7 ...,...          <- system info values
    --------------------FRAME METRICS--------------------     <- only with log_versioning (+ a "v1" line)
    fps,frametime,cpu_load,cpu_power,gpu_load,cpu_temp,gpu_temp,gpu_core_clock,gpu_mem_clock,gpu_vram_used,
        gpu_power,ram_used,swap_used,process_rss,cpu_mhz,elapsed
    60.1,16.6,23,...,123456789                                 <- one row per log_interval (100 ms);
                                                                   frametime in ms, elapsed in ns since log start
Columns are looked up by name (older/newer MangoHud add or drop columns). "<name>_summary.csv" files (written
when logging stops) are ignored - the summary is computed here from the samples.

Public API:
    game_dir(game_id) -> Path
    list_sessions(game_id) -> [{"path", "start", "program"}], newest first
    parse_log(path) -> {"system": {...}, "columns": [...], "rows": [{col: float}]}
    summary(log_or_path) -> {"duration", "samples", "avg_fps", "low1_fps", "min_fps", "max_fps",
                             "cpu_temp_avg", "cpu_temp_max", "gpu_temp_avg", "gpu_temp_max",
                             "gpu_load_avg", "gpu_load_max", "cpu_load_avg"}   (None where the sensor gave nothing)
    series(log_or_path, max_points=600) -> {"t": [...s], "fps": [...], "cpu_temp": [...], "gpu_temp": [...]}
    last_summary(game_id) -> summary of the newest session or None
    prune(game_id, keep=20)
    PerfChart(game_id, parent=None, accent="#ff8a00")   (PySide6 QWidget; only built when PySide6 is importable)
"""
import math
import os
import re
import time
from datetime import datetime
from pathlib import Path

PERF_ROOT = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local/share") / "phoenixge/perf"
INCOMING = PERF_ROOT / "_incoming"   # global MangoHud logging (games started outside Phoenix Games)
NAME_RE = re.compile(r"^(?P<prog>.+)_(?P<ts>\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2})\.csv$")


def safe_name(game_id):
    return re.sub(r"[^A-Za-z0-9._-]+", "_", game_id).strip("._") or "game"


def game_dir(game_id):
    return PERF_ROOT / safe_name(game_id)


def _is_log(p):
    return p.suffix == ".csv" and not p.name.endswith("_summary.csv")


def log_start(path):
    m = NAME_RE.match(Path(path).name)
    if m:
        try:
            return datetime.strptime(m["ts"], "%Y-%m-%d_%H-%M-%S").timestamp()
        except ValueError:
            pass
    try:
        return Path(path).stat().st_mtime
    except OSError:
        return 0.0


def list_sessions(game_id):
    d = game_dir(game_id)
    if not d.is_dir():
        return []
    out = []
    for p in d.iterdir():
        if _is_log(p):
            m = NAME_RE.match(p.name)
            out.append({"path": str(p), "start": log_start(p), "program": m["prog"] if m else p.stem})
    out.sort(key=lambda s: -s["start"])
    return out


def _num(s):
    try:
        v = float(s)
    except ValueError:
        return None
    return v if math.isfinite(v) else None


def parse_log(path):
    """Parse one MangoHud CSV. Tolerates a cut-off last line (game crashed / still running)."""
    system, columns, rows = {}, None, []
    with open(path, encoding="utf-8", errors="replace") as f:
        lines = f.read().splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        i += 1
        if not line or line.startswith("---") or line == "v1":
            continue
        fields = [x.strip() for x in line.split(",")]
        if columns is None:
            if fields[0] == "os" and i < len(lines):
                vals = lines[i].split(",")
                # cpu/gpu names have no commas in practice; be safe and only map when the counts match
                if len(vals) == len(fields):
                    system = dict(zip(fields, (v.strip() for v in vals)))
                i += 1
            elif fields[0] == "fps":
                columns = fields
            continue
        if len(fields) != len(columns):
            continue
        row = {}
        for k, v in zip(columns, fields):
            n = _num(v)
            if n is not None:
                row[k] = n
        if "fps" in row:
            rows.append(row)
    return {"system": system, "columns": columns or [], "rows": rows, "path": str(path)}


def _load(log_or_path):
    return log_or_path if isinstance(log_or_path, dict) else parse_log(log_or_path)


def _stats(vals):
    vals = [v for v in vals if v is not None and v > 0]   # 0 = sensor not available
    if not vals:
        return None, None
    return sum(vals) / len(vals), max(vals)


def summary(log_or_path):
    log = _load(log_or_path)
    rows = log["rows"]
    fps = [r["fps"] for r in rows if r.get("fps", 0) > 0]
    res = {"samples": len(rows), "duration": 0.0, "avg_fps": None, "low1_fps": None, "min_fps": None,
           "max_fps": None, "cpu_temp_avg": None, "cpu_temp_max": None, "gpu_temp_avg": None, "gpu_temp_max": None,
           "gpu_load_avg": None, "gpu_load_max": None, "cpu_load_avg": None}
    if not rows:
        return res
    el = [r["elapsed"] for r in rows if "elapsed" in r]
    if len(el) >= 2:
        res["duration"] = max(0.0, (el[-1] - el[0]) / 1e9)
    if fps:
        s = sorted(fps)
        n = max(1, int(len(s) * 0.01))
        res.update(avg_fps=sum(fps) / len(fps), low1_fps=sum(s[:n]) / n, min_fps=s[0], max_fps=s[-1])
    res["cpu_temp_avg"], res["cpu_temp_max"] = _stats([r.get("cpu_temp") for r in rows])
    res["gpu_temp_avg"], res["gpu_temp_max"] = _stats([r.get("gpu_temp") for r in rows])
    res["gpu_load_avg"], res["gpu_load_max"] = _stats([r.get("gpu_load") for r in rows])
    res["cpu_load_avg"], _ = _stats([r.get("cpu_load") for r in rows])
    return res


def series(log_or_path, max_points=600):
    """Down-sampled time series for charts (each point = average of its bucket)."""
    rows = _load(log_or_path)["rows"]
    out = {"t": [], "fps": [], "cpu_temp": [], "gpu_temp": []}
    if not rows:
        return out
    t0 = rows[0].get("elapsed", 0.0)
    step = max(1, math.ceil(len(rows) / max_points))
    for i in range(0, len(rows), step):
        b = rows[i:i + step]
        out["t"].append((b[0].get("elapsed", t0 + i * 1e8) - t0) / 1e9)
        for k in ("fps", "cpu_temp", "gpu_temp"):
            vals = [r[k] for r in b if r.get(k, 0) > 0]
            out[k].append(sum(vals) / len(vals) if vals else None)
    return out


def last_summary(game_id):
    for s in list_sessions(game_id):
        res = summary(s["path"])
        if res["samples"]:
            res["start"] = s["start"]
            return res
    return None


def prune(game_id, keep=20):
    for s in list_sessions(game_id)[keep:]:
        p = Path(s["path"])
        p.unlink(missing_ok=True)
        p.with_name(p.stem + "_summary.csv").unlink(missing_ok=True)


def prune_incoming(max_age_days=2):
    if not INCOMING.is_dir():
        return
    limit = time.time() - max_age_days * 86400
    for p in INCOMING.iterdir():
        try:
            if p.is_file() and p.stat().st_mtime < limit:
                p.unlink()
        except OSError:
            pass


def collect_incoming(game_id, since, until, dirs=None, skip=("fossilize_replay", "steamwebhelper", "steam", "wine",
                                                                  "explorer.exe", "services.exe")):
    """Move MangoHud logs that globally enabled logging wrote during [since, until] into the game's folder.
    Returns the moved paths. Logs with no frames (helper processes) are dropped."""
    moved = []
    dest = game_dir(game_id)
    for d in dirs or [INCOMING]:
        d = Path(d)
        if not d.is_dir():
            continue
        for p in d.iterdir():
            if not _is_log(p):
                continue
            st = log_start(p)
            m = NAME_RE.match(p.name)
            if not (since - 5 <= st <= until + 5) or (m and m["prog"].lower() in skip):
                continue
            try:  # still being written -> another game that is still running (e.g. started from Heroic meanwhile)
                if time.time() - p.stat().st_mtime < 15:
                    continue
            except OSError:
                continue
            try:
                if not any(r.get("fps", 0) > 0 for r in parse_log(p)["rows"]):
                    p.unlink()
                    continue
                dest.mkdir(parents=True, exist_ok=True)
                target = dest / p.name
                os.replace(p, target)
                sp = p.with_name(p.stem + "_summary.csv")
                if sp.exists():
                    os.replace(sp, dest / sp.name)
                moved.append(str(target))
            except OSError:
                pass
    return moved


# ------------------------------------------------------------------ chart widget (Phoenix Games embeds this)
try:
    from PySide6.QtCore import QPointF, QRectF, Qt
    from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen
    from PySide6.QtWidgets import QSizePolicy, QWidget
except ImportError:  # parser is usable without Qt
    QWidget = None

if QWidget is not None:
    def _fmt(v, unit="", nd=0):
        return "-" if v is None else f"{v:.{nd}f}{unit}"

    class PerfChart(QWidget):
        """FPS (accent) + GPU temp (red) + CPU temp (dashed) of the last recorded session, summary row on top."""

        def __init__(self, game_id=None, parent=None, accent="#ff8a00"):
            super().__init__(parent)
            self.accent = QColor(accent)
            self.setMinimumHeight(220)
            self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            self.game_id, self.data, self.sum, self.when = None, None, None, None
            if game_id:
                self.set_game(game_id)

        def set_game(self, game_id):
            self.game_id = game_id
            self.reload()

        def reload(self):
            self.data = self.sum = self.when = None
            for s in list_sessions(self.game_id) if self.game_id else []:
                log = parse_log(s["path"])
                if log["rows"]:
                    self.data, self.sum, self.when = series(log), summary(log), s["start"]
                    break
            self.update()

        def paintEvent(self, _e):
            p = QPainter(self)
            p.setRenderHint(QPainter.Antialiasing)
            w, h = self.width(), self.height()
            bg = QPainterPath(); bg.addRoundedRect(QRectF(0, 0, w, h), 14, 14)
            p.fillPath(bg, QColor("#16161d"))
            f = QFont(); f.setPixelSize(13); f.setBold(True); p.setFont(f)
            p.setPen(QColor("#f5f5f5"))
            title = "Last session"
            if self.when:
                mins = int(self.sum["duration"] // 60)
                title += time.strftime("  ·  %d %b %H:%M", time.localtime(self.when)) + f"  ·  {mins} min"
            p.drawText(QRectF(16, 10, w - 32, 20), Qt.AlignLeft | Qt.AlignVCenter, title)
            if not self.data or not self.data["t"]:
                p.setPen(QColor("#9a9aa6")); f.setBold(False); p.setFont(f)
                p.drawText(QRectF(16, 0, w - 32, h), Qt.AlignCenter | Qt.TextWordWrap,
                           "No performance data yet.\nPlay this game from Phoenix Games to record FPS and temperatures.")
                return
            s = self.sum
            items = [("AVG FPS", _fmt(s["avg_fps"]), self.accent), ("1% LOW", _fmt(s["low1_fps"]), self.accent),
                     ("GPU TEMP", f"{_fmt(s['gpu_temp_avg'], '°')} / {_fmt(s['gpu_temp_max'], '°')}", QColor("#ff4d5e")),
                     ("CPU TEMP", f"{_fmt(s['cpu_temp_avg'], '°')} / {_fmt(s['cpu_temp_max'], '°')}", QColor("#7aa2ff")),
                     ("GPU LOAD", _fmt(s["gpu_load_avg"], "%"), QColor("#cfcfd8"))]
            cw = (w - 32) / len(items)
            for i, (label, value, col) in enumerate(items):
                x = 16 + i * cw
                f.setPixelSize(10); f.setBold(False); p.setFont(f); p.setPen(QColor("#9a9aa6"))
                p.drawText(QRectF(x, 34, cw, 14), Qt.AlignLeft, label)
                f.setPixelSize(18); f.setBold(True); p.setFont(f); p.setPen(col)
                p.drawText(QRectF(x, 48, cw, 24), Qt.AlignLeft, value)
            # plot area
            L, T, R, B = 44, 84, w - 40, h - 26
            if R - L < 40 or B - T < 30:
                return
            t = self.data["t"]; tmax = max(t[-1], 1e-6)
            fps_vals = [v for v in self.data["fps"] if v]
            fmax = max(30.0, math.ceil(max(fps_vals or [60]) * 1.1 / 30) * 30)
            temps = [v for k in ("gpu_temp", "cpu_temp") for v in self.data[k] if v]
            tlo, thi = (30.0, 100.0) if not temps else (min(30.0, math.floor(min(temps) / 10) * 10),
                                                         max(90.0, math.ceil(max(temps) / 10) * 10))
            grid = QPen(QColor(255, 255, 255, 22)); grid.setWidth(1)
            f.setPixelSize(10); f.setBold(False); p.setFont(f)
            for k in range(4):
                y = T + (B - T) * k / 3
                p.setPen(grid); p.drawLine(QPointF(L, y), QPointF(R, y))
                p.setPen(self.accent); p.drawText(QRectF(0, y - 7, L - 6, 14), Qt.AlignRight | Qt.AlignVCenter,
                                                  f"{fmax * (1 - k / 3):.0f}")
                p.setPen(QColor("#ff4d5e")); p.drawText(QRectF(R + 6, y - 7, 34, 14), Qt.AlignLeft | Qt.AlignVCenter,
                                                        f"{tlo + (thi - tlo) * (1 - k / 3):.0f}°")
            p.setPen(QColor("#9a9aa6"))
            p.drawText(QRectF(L, B + 6, R - L, 14), Qt.AlignLeft, "0:00")
            p.drawText(QRectF(L, B + 6, R - L, 14), Qt.AlignRight, f"{int(tmax // 60)}:{int(tmax % 60):02d}")

            def line(vals, lo, hi, pen):
                path, started = QPainterPath(), False
                for tv, v in zip(t, vals):
                    if v is None:
                        started = False
                        continue
                    pt = QPointF(L + (R - L) * tv / tmax, B - (B - T) * (min(max(v, lo), hi) - lo) / (hi - lo))
                    path.lineTo(pt) if started else path.moveTo(pt)
                    started = True
                p.setPen(pen); p.setBrush(Qt.NoBrush); p.drawPath(path)

            cpu = QPen(QColor("#7aa2ff")); cpu.setWidthF(1.4); cpu.setStyle(Qt.DashLine)
            gpu = QPen(QColor("#ff4d5e")); gpu.setWidthF(1.6)
            fp = QPen(self.accent); fp.setWidthF(2.2)
            line(self.data["cpu_temp"], tlo, thi, cpu)
            line(self.data["gpu_temp"], tlo, thi, gpu)
            line(self.data["fps"], 0.0, fmax, fp)
