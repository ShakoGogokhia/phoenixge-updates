#!/bin/sh
# Turn on daily Timeshift snapshots (system disk, keep 5 daily + 3 boot). Run as root (pkexec).
# btrfs root with the @ subvolume (PhoenixGe default since the safe-updates change) -> Timeshift btrfs mode:
# instant snapshots that also appear in GRUB ("PhoenixGe - restore previous state"). Otherwise rsync mode.
set -e
mkdir -p /etc/timeshift
UUID=$(findmnt -no UUID /)
BTRFS=false
if [ "$(findmnt -no FSTYPE /)" = btrfs ]; then
  case ",$(findmnt -no OPTIONS /)," in
    *,subvol=/@,*|*,subvol=@,*) BTRFS=true ;;
  esac
fi
# rsync mode copies the whole system into /timeshift on the SAME disk (first snapshot = full copy, ~15 GB without the
# excluded Flatpak apps/Android/caches, which are reinstallable). On a small Linux partition that fills the disk ->
# no snapshot at every boot there (daily only, incremental with hard links) and refuse when space is short.
BOOT=$BTRFS
if [ "$BTRFS" = false ]; then
  NEED=$(du -xsk --exclude=/home --exclude=/root --exclude=/var/lib/flatpak --exclude=/var/lib/waydroid \
         --exclude=/var/cache --exclude=/var/tmp --exclude=/timeshift --exclude=/swapfile / 2>/dev/null | awk '{print $1}')
  FREE=$(df -Pk / | awk 'NR==2{print $4}')
  if [ "$FREE" -lt $(( NEED + 10485760 )) ]; then
    echo "Not enough space for snapshots: a snapshot needs ~$((NEED/1048576)) GB and $((FREE/1048576)) GB are free (+10 GB kept spare)."
    echo "Free some space or make the Linux partition bigger, then try again."
    exit 1
  fi
fi
cat > /etc/timeshift/timeshift.json <<J
{
  "backup_device_uuid" : "$UUID",
  "parent_device_uuid" : "",
  "do_first_run" : "false",
  "btrfs_mode" : "$BTRFS",
  "include_btrfs_home_for_backup" : "false",
  "include_btrfs_home_for_restore" : "false",
  "stop_cron_emails" : "true",
  "schedule_monthly" : "false",
  "schedule_weekly" : "false",
  "schedule_daily" : "true",
  "schedule_hourly" : "false",
  "schedule_boot" : "$BOOT",
  "count_monthly" : "2",
  "count_weekly" : "3",
  "count_daily" : "5",
  "count_hourly" : "6",
  "count_boot" : "3",
  "date_format" : "%Y-%m-%d %H:%M:%S",
  "exclude" : [ "/home/**", "/root/**", "/var/lib/flatpak/**", "/var/lib/waydroid/**", "/var/cache/**", "/var/tmp/**", "/swapfile" ],
  "exclude-apps" : []
}
J
[ "$BOOT" = true ] || rm -f /etc/cron.d/timeshift-boot
timeshift --check >/dev/null 2>&1 || true
if [ "$BTRFS" = true ]; then MODE="btrfs"; else MODE="rsync"; fi
echo "Daily snapshots are on ($MODE mode, keep 5 daily$( [ "$BOOT" = true ] && echo ', 3 at boot')). First snapshot is being made now..."
timeshift --create --comments "PhoenixGe first snapshot" --yes
mkdir -p /var/lib/phoenixge && touch /var/lib/phoenixge/pre-update-snapshot.stamp  # counts as the pre-update snapshot for an hour
# btrfs: show the snapshot in the GRUB "restore previous state" menu
[ -x /usr/lib/phoenixge/snapshot-menu-refresh.sh ] && /usr/lib/phoenixge/snapshot-menu-refresh.sh || true
