#!/bin/sh
# DeepFaceLive (real-time face swap for webcam / streams) into ~/.local/share/deepfacelive, with a start-menu entry.
# Upstream (github.com/iperov/DeepFaceLive) has no Linux build and is archived: it needs Python 3.8 + onnxruntime-gpu 1.15
# (CUDA 11.8 / cuDNN 8). We use uv for a private Python 3.8 and take CUDA/cuDNN from NVIDIA's pip wheels, so nothing
# touches the system. ~7 GB. NVIDIA GPU strongly recommended (CPU works, but only a few frames per second).
#   deepfacelive.sh            install or update
#   deepfacelive.sh --remove   uninstall (your workspace ~/DeepFaceLive stays)
set -e
D="$HOME/.local/share/deepfacelive"
APP="$HOME/.local/share/applications/deepfacelive.desktop"
BIN="$HOME/.local/bin"

if [ "${1:-}" = --remove ]; then
  rm -rf "$D" "$APP" "$BIN/deepfacelive"
  echo "DeepFaceLive removed (your workspace ~/DeepFaceLive was kept)."
  exit 0
fi

command -v git >/dev/null || { echo "git is missing - install the 'Developer pack' (Store > Coding) first."; exit 1; }
if command -v nvidia-smi >/dev/null && nvidia-smi -L >/dev/null 2>&1; then
  echo "NVIDIA GPU: $(nvidia-smi --query-gpu=name --format=csv,noheader | head -n1)"
else
  echo "WARNING: no working NVIDIA GPU found - DeepFaceLive will run on the CPU and be very slow."
fi
FREE=$(df -Pk "$HOME" | awk 'NR==2{print int($4/1048576)}')
[ "$FREE" -ge 9 ] || { echo "Needs ~9 GB free in your home folder, only ${FREE} GB free."; exit 1; }

# uv (private Python 3.8 + fast installs), user-local
mkdir -p "$BIN" "$D"
UV=$(command -v uv || true)
if [ -z "$UV" ]; then
  echo "Getting uv…"
  T=$(mktemp -d)
  curl -fL --retry 3 -o "$T/uv.tgz" https://github.com/astral-sh/uv/releases/latest/download/uv-x86_64-unknown-linux-gnu.tar.gz
  tar -xzf "$T/uv.tgz" -C "$T"
  install -m755 "$T"/uv-x86_64-unknown-linux-gnu/uv "$BIN/uv"
  rm -rf "$T"; UV="$BIN/uv"
fi

# the program (shallow clone; the big ONNX models are split into parts in git -> merged below)
if [ -d "$D/app/.git" ]; then
  git -C "$D/app" pull --ff-only || true
else
  rm -rf "$D/app"
  git clone --depth 1 https://github.com/iperov/DeepFaceLive.git "$D/app"
fi

echo "Python 3.8 environment…"
[ -x "$D/venv/bin/python" ] || "$UV" venv --python 3.8 "$D/venv"
# same versions as upstream's Linux Dockerfile + the CUDA 11 / cuDNN 8 libraries onnxruntime-gpu 1.15 loads
VIRTUAL_ENV="$D/venv" "$UV" pip install --python "$D/venv/bin/python" \
  onnxruntime-gpu==1.15.1 numpy==1.21.6 h5py numexpr protobuf==3.20.3 \
  opencv-python==4.8.0.74 opencv-contrib-python==4.8.0.74 pyqt6==6.5.1 onnx==1.14.0 \
  torch==1.13.1 torchvision==0.14.1 \
  nvidia-cuda-runtime-cu11 nvidia-cudnn-cu11 nvidia-cublas-cu11 nvidia-cufft-cu11 nvidia-curand-cu11

# glibc >= 2.41 (Debian 13) refuses libraries that ask for an executable stack; onnxruntime-gpu 1.15 is one of them.
# It doesn't need it: clear the flag in the PT_GNU_STACK header of every such library in the venv.
"$D/venv/bin/python" - "$D/venv" <<'PY'
import os, struct, sys
for dp, _dn, fn in os.walk(sys.argv[1]):
    for f in fn:
        if ".so" not in f:
            continue
        p = os.path.join(dp, f)
        try:
            with open(p, "r+b") as fh:
                h = fh.read(64)
                if h[:4] != b"\x7fELF" or h[4] != 2:   # 64-bit ELF only
                    continue
                phoff, = struct.unpack_from("<Q", h, 32)
                phentsize, phnum = struct.unpack_from("<HH", h, 54)
                for i in range(phnum):
                    off = phoff + i * phentsize
                    fh.seek(off); ptype, flags = struct.unpack("<II", fh.read(8))
                    if ptype == 0x6474E551 and flags & 1:   # PT_GNU_STACK with PF_X
                        fh.seek(off + 4); fh.write(struct.pack("<I", flags & ~1))
                        print("execstack cleared:", f)
        except OSError:
            pass
PY

echo "Merging the model files…"
(cd "$D/app" && "$D/venv/bin/python" main.py dev merge_large_files --delete-parts)

# launcher: CUDA libs from the wheels; XWayland (PyQt6 6.5 + Wayland is unreliable)
cat > "$BIN/deepfacelive" <<EOF
#!/bin/sh
D="$D"
LIBS=\$(find "\$D/venv/lib/python3.8/site-packages/nvidia" -maxdepth 2 -type d -name lib 2>/dev/null | tr '\n' ':')
export LD_LIBRARY_PATH="\${LIBS}\${LD_LIBRARY_PATH:-}"
export QT_QPA_PLATFORM=xcb
mkdir -p "\$HOME/DeepFaceLive"
cd "\$D/app" && exec "\$D/venv/bin/python" main.py run DeepFaceLive --userdata-dir "\$HOME/DeepFaceLive" "\$@"
EOF
chmod +x "$BIN/deepfacelive"

ICON=camera-web
[ -f "$D/app/resources/gfx/icons/app_icon.png" ] && ICON="$D/app/resources/gfx/icons/app_icon.png"
mkdir -p "$(dirname "$APP")"
cat > "$APP" <<EOF
[Desktop Entry]
Type=Application
Name=DeepFaceLive
Comment=Real-time face swap for webcam and streams
Exec=$BIN/deepfacelive
Icon=$ICON
Categories=AudioVideo;Video;
Terminal=false
EOF

# check that the GPU path really works
"$D/venv/bin/python" - <<EOF
import glob, os, ctypes
for l in glob.glob("$D/venv/lib/python3.8/site-packages/nvidia/*/lib/*.so*"):
    try: ctypes.CDLL(l)
    except OSError: pass
import onnxruntime as ort
print("onnxruntime providers:", ort.get_available_providers())
EOF
touch "$D/.installed"
echo "DeepFaceLive ready: start menu > DeepFaceLive (workspace: ~/DeepFaceLive)."
echo "To use it as a webcam in Discord/Zoom/Chrome: OBS Studio > capture the DeepFaceLive window > Start Virtual Camera."
echo "Only use faces of people who agreed to it."
