/*
    PhoenixGe Launcher - the start menu from design/<Theme>-Start.dc.html
    (category rail, search, pinned grid, all apps, user card, power buttons).
    SPDX-License-Identifier: GPL-2.0-or-later
*/
pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Layouts
import QtQuick.Effects
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.kirigami as Kirigami
import org.kde.plasma.private.kicker as Kicker
import org.kde.plasma.private.sessions as Sessions
import org.kde.coreaddons as KCoreAddons

import "code/styles.js" as Styles

PlasmoidItem {
    id: root

    readonly property var s: Styles.get(Plasmoid.configuration.theme)
    readonly property bool railRight: s.layout === "right"   // design: categories on the right (Ash, Inferno, Cyber, Glass)
    readonly property bool chips: s.layout === "chips"       // design: categories as chips under the search (Kolkhi, Pastel, Forest)
    property int category: 0              // row in rootModel (0 = all applications)
    readonly property bool searching: searchText.length > 0
    property string searchText: ""

    Plasmoid.icon: Plasmoid.configuration.icon
    preferredRepresentation: compactRepresentation
    activationTogglesExpanded: true

    onExpandedChanged: {
        if (expanded) {
            rootModel.refresh();
            category = 0;
            searchText = "";
        }
    }

    // ------------------------------------------------------------ models
    Kicker.RootModel {
        id: rootModel
        autoPopulate: false
        appletInterface: root
        flat: true
        sorted: true
        showSeparators: false
        showTopLevelItems: false
        showAllApps: true
        showAllAppsCategorized: false
        showRecentApps: false
        showRecentDocs: false
        showPowerSession: false
        showFavoritesPlaceholder: false

        Component.onCompleted: {
            favoritesModel.initForClient("org.phoenixge.launcher.favorites.instance-" + Plasmoid.id);
            refresh();
            if (!Plasmoid.configuration.favoritesPorted) {
                seedFavorites.start();
            }
        }
    }

    Instantiator {
        id: favIds
        model: rootModel.favoritesModel
        delegate: QtObject {
            required property var model
            readonly property string fid: model.favoriteId || ""
        }
    }

    // first run: pin exactly the apps from the design (KAStats loads asynchronously, so wait a moment)
    Timer {
        id: seedFavorites
        interval: 1500
        onTriggered: {
            var fav = rootModel.favoritesModel;
            var want = Plasmoid.configuration.favorites;
            var have = [];
            for (var k = 0; k < favIds.count; ++k) {
                if (favIds.objectAt(k)) have.push(favIds.objectAt(k).fid);
            }
            for (var i = 0; i < have.length; ++i) {
                if (want.indexOf(have[i]) < 0) fav.removeFavorite(have[i]);
            }
            addFavorites.start();
        }
    }
    Timer {  // second step: removals of preferred:// defaults are async, add the design apps afterwards
        id: addFavorites
        interval: 800
        onTriggered: {
            var fav = rootModel.favoritesModel;
            var want = Plasmoid.configuration.favorites;
            for (var j = 0; j < want.length; ++j) {
                if (!fav.isFavorite(want[j])) fav.addFavorite(want[j], -1);
            }
            Plasmoid.configuration.favoritesPorted = true;
        }
    }

    Kicker.RunnerModel {
        id: runnerModel
        appletInterface: root
        mergeResults: true
        favoritesModel: rootModel.favoritesModel
        query: root.searchText
    }

    Sessions.SessionManagement { id: session }
    KCoreAddons.KUser { id: kuser }

    function launch(model, row) {
        if (model && model.trigger(row, "", null)) {
            root.expanded = false;
        }
    }

    // ------------------------------------------------------------ start button
    compactRepresentation: MouseArea {
        id: button
        hoverEnabled: true
        Layout.minimumWidth: height
        Layout.preferredWidth: height
        onClicked: root.expanded = !root.expanded

        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width, parent.height) - 4
            height: width
            radius: root.s.startRadius
            color: (root.expanded || button.containsMouse) ? root.s.startBg : Qt.rgba(root.s.startBg.r, root.s.startBg.g, root.s.startBg.b, root.s.startBg.a * 0.7)
            border.color: root.s.startBorder
            border.width: 1

            Kirigami.Icon {
                anchors.centerIn: parent
                width: Math.round(parent.width * 0.7)
                height: width
                source: Plasmoid.configuration.icon
            }
        }
    }

    // ------------------------------------------------------------ menu
    fullRepresentation: Rectangle {
        id: menu
        Layout.preferredWidth: root.s.width
        Layout.preferredHeight: root.s.height
        Layout.minimumWidth: root.s.width
        Layout.minimumHeight: root.s.height
        Layout.maximumWidth: root.s.width
        Layout.maximumHeight: root.s.height
        color: root.s.panelBg
        radius: root.s.radius
        border.color: root.s.panelBorder
        border.width: 1

        // the category rail is flush with the popup frame (like the design): reach under the frame padding
        readonly property int pad: 8
        Item {
            visible: !root.chips
            x: root.railRight ? menu.width - root.s.railWidth : -menu.pad; y: -menu.pad
            width: root.s.railWidth + menu.pad
            height: menu.height + 2 * menu.pad
            clip: true
            Rectangle { x: root.railRight ? -20 : 0; width: parent.width + 20; height: parent.height; radius: 18; color: root.s.railBg }
            Rectangle { x: root.railRight ? 0 : parent.width - 1; anchors { top: parent.top; bottom: parent.bottom } width: 1; color: root.s.railBorder }
        }

        Keys.onEscapePressed: root.expanded = false
        Component.onCompleted: searchInput.forceActiveFocus()
        Connections {
            target: root
            function onExpandedChanged() { if (root.expanded) searchInput.forceActiveFocus(); }
        }

        RowLayout {
            anchors.fill: parent
            anchors.margins: 1
            spacing: 0
            layoutDirection: root.railRight ? Qt.RightToLeft : Qt.LeftToRight

            // ---------------- categories rail
            Rectangle {
                visible: !root.chips
                Layout.fillHeight: true
                Layout.preferredWidth: root.s.railWidth
                color: "transparent"

                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 14
                    anchors.topMargin: 24
                    spacing: 4

                    Text {
                        text: "CATEGORIES"
                        font.family: root.s.font; font.pixelSize: 11; font.letterSpacing: 2
                        color: root.s.dim
                        leftPadding: 12; bottomPadding: 10
                    }

                    ListView {
                        id: catList
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        clip: true
                        spacing: 4
                        model: rootModel
                        boundsBehavior: Flickable.StopAtBounds
                        delegate: Rectangle {
                            id: cat
                            required property int index
                            required property var model
                            readonly property bool sel: root.category === index && !root.searching
                            width: ListView.view.width
                            height: 38
                            radius: 10
                            color: sel ? root.s.selBg : (catMouse.containsMouse ? root.s.hoverBg : "transparent")

                            Text {
                                anchors { left: parent.left; leftMargin: 12; right: countText.left; verticalCenter: parent.verticalCenter }
                                text: cat.index === 0 ? "All" : cat.model.display
                                elide: Text.ElideRight
                                font.family: root.s.font; font.pixelSize: 13
                                color: cat.sel ? root.s.accentFg : root.s.fg
                            }
                            Text {
                                id: countText
                                anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                                text: { var m = rootModel.modelForRow(cat.index); return m ? m.count : ""; }
                                font.family: root.s.font; font.pixelSize: 11
                                color: root.s.dim
                            }
                            MouseArea {
                                id: catMouse
                                anchors.fill: parent
                                hoverEnabled: true
                                onClicked: { root.searchText = ""; searchInput.text = ""; root.category = cat.index; }
                            }
                        }
                    }

                    // user card
                    Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 60
                        radius: 12
                        color: root.s.userBg
                        RowLayout {
                            anchors.fill: parent
                            anchors.margins: 12
                            spacing: 10
                            Rectangle {
                                Layout.preferredWidth: 36; Layout.preferredHeight: 36
                                radius: 18
                                gradient: Gradient {
                                    orientation: Gradient.Horizontal
                                    GradientStop { position: 0; color: root.s.avatarA }
                                    GradientStop { position: 1; color: root.s.avatarB }
                                }
                                Text {
                                    anchors.centerIn: parent
                                    text: (kuser.loginName || "?").charAt(0).toUpperCase()
                                    font.family: root.s.font; font.pixelSize: 14; font.weight: Font.Bold
                                    color: "#ffffff"
                                }
                            }
                            ColumnLayout {
                                spacing: 0
                                Text { text: kuser.loginName; font.family: root.s.font; font.pixelSize: 13; font.weight: Font.DemiBold; color: root.s.fg }
                                Text { text: "Administrator"; font.family: root.s.font; font.pixelSize: 11; color: root.s.dim }
                            }
                        }
                        MouseArea { anchors.fill: parent; onClicked: { Qt.openUrlExternally("file://" + kuser.homeDir); root.expanded = false; } }
                    }
                }
            }

            // ---------------- main area
            ColumnLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.margins: 24
                Layout.leftMargin: 28
                Layout.rightMargin: 28
                spacing: 20

                // search
                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 46
                    radius: root.s.searchRadius
                    color: root.s.searchBg
                    border.color: root.s.searchBorder
                    border.width: 1
                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: 18
                        anchors.rightMargin: 14
                        spacing: 10
                        Glyph { name: "search"; tint: root.s.accentFg; Layout.preferredWidth: 18; Layout.preferredHeight: 18 }
                        TextInput {
                            id: searchInput
                            Layout.fillWidth: true
                            font.family: root.s.font; font.pixelSize: 14
                            color: root.s.fg
                            selectionColor: root.s.accent
                            clip: true
                            onTextChanged: root.searchText = text
                            Keys.onReturnPressed: if (root.searching && results.count > 0) root.launch(results.model, 0)
                            Keys.onEnterPressed: if (root.searching && results.count > 0) root.launch(results.model, 0)
                            Keys.onDownPressed: if (root.searching) { results.forceActiveFocus(); results.currentIndex = 0; }
                            Text {
                                anchors.verticalCenter: parent.verticalCenter
                                visible: !searchInput.text
                                text: "Search apps, files, games"
                                font: searchInput.font
                                color: root.s.dim
                            }
                        }
                        Rectangle {
                            Layout.preferredHeight: 22
                            Layout.preferredWidth: metaText.implicitWidth + 16
                            radius: 6
                            color: "transparent"
                            border.color: root.s.badgeBorder
                            Text { id: metaText; anchors.centerIn: parent; text: "Meta"; font.family: root.s.font; font.pixelSize: 11; color: root.s.dim }
                        }
                    }
                }

                // ---- categories as chips (Kolkhi / Pastel / Forest designs)
                Flow {
                    visible: root.chips && !root.searching
                    Layout.fillWidth: true
                    spacing: 8
                    Repeater {
                        model: rootModel
                        Rectangle {
                            id: chip
                            required property int index
                            required property var model
                            readonly property bool sel: root.category === index
                            height: 30; width: chipLabel.implicitWidth + 28; radius: 15
                            color: sel ? root.s.accent : root.s.btnBg
                            Text {
                                id: chipLabel
                                anchors.centerIn: parent
                                text: chip.index === 0 ? "All" : chip.model.display
                                font.family: root.s.font; font.pixelSize: 12; font.weight: chip.sel ? Font.DemiBold : Font.Normal
                                color: chip.sel ? root.s.onAccent : root.s.fg
                            }
                            MouseArea { anchors.fill: parent; onClicked: { root.searchText = ""; searchInput.text = ""; root.category = chip.index; } }
                        }
                    }
                }

                // ---- search results
                ListView {
                    id: results
                    visible: root.searching
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    clip: true
                    spacing: 4
                    model: runnerModel.count > 0 ? runnerModel.modelForRow(0) : null
                    highlightFollowsCurrentItem: true
                    keyNavigationEnabled: true
                    Keys.onReturnPressed: root.launch(model, currentIndex)
                    Keys.onEnterPressed: root.launch(model, currentIndex)
                    delegate: AppRow {
                        width: ListView.view.width
                        highlighted: ListView.isCurrentItem && results.activeFocus
                        onClicked: root.launch(results.model, index)
                    }
                }

                // ---- pinned
                RowLayout {
                    visible: !root.searching && root.category === 0
                    Layout.fillWidth: true
                    Text { text: "Pinned"; font.family: root.s.font; font.pixelSize: 15; font.weight: Font.DemiBold; color: root.s.fg; Layout.fillWidth: true }
                    Text {
                        text: "Edit"; font.family: root.s.font; font.pixelSize: 12; color: root.s.accentFg
                        MouseArea { anchors.fill: parent; onClicked: { Plasmoid.internalAction("configure").trigger(); } }
                    }
                }
                GridView {
                    id: pinned
                    visible: !root.searching && root.category === 0
                    Layout.fillWidth: true
                    Layout.preferredHeight: Math.min(2, Math.ceil(count / root.s.pinnedCols)) * cellHeight
                    interactive: false
                    cellWidth: width / root.s.pinnedCols
                    cellHeight: root.s.tile + 40
                    model: rootModel.favoritesModel
                    delegate: Item {
                        id: tile
                        required property int index
                        required property var model
                        width: GridView.view.cellWidth
                        height: GridView.view.cellHeight
                        Column {
                            anchors.horizontalCenter: parent.horizontalCenter
                            spacing: 8
                            Kirigami.Icon {
                                anchors.horizontalCenter: parent.horizontalCenter
                                width: root.s.tile; height: root.s.tile
                                source: tile.model.decoration
                                scale: tileMouse.containsMouse ? 1.06 : 1
                                Behavior on scale { NumberAnimation { duration: 120 } }
                            }
                            Text {
                                anchors.horizontalCenter: parent.horizontalCenter
                                width: tile.width - 8
                                horizontalAlignment: Text.AlignHCenter
                                text: tile.model.display
                                elide: Text.ElideRight
                                font.family: root.s.font; font.pixelSize: 12
                                color: root.s.fg
                            }
                        }
                        MouseArea { id: tileMouse; anchors.fill: parent; hoverEnabled: true; onClicked: root.launch(rootModel.favoritesModel, tile.index) }
                    }
                }

                Rectangle { visible: !root.searching && root.category === 0; Layout.fillWidth: true; Layout.preferredHeight: 1; color: root.s.divider }

                // ---- all apps / category
                RowLayout {
                    visible: !root.searching
                    Layout.fillWidth: true
                    Text {
                        Layout.fillWidth: true
                        text: root.category === 0 ? "All apps" : (allApps.model ? allApps.model.description || "" : "")
                        font.family: root.s.font; font.pixelSize: 15; font.weight: Font.DemiBold; color: root.s.fg
                    }
                    Text { text: "A–Z"; font.family: root.s.font; font.pixelSize: 12; color: root.s.dim }
                }
                GridView {
                    id: allApps
                    visible: !root.searching
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    clip: true
                    boundsBehavior: Flickable.StopAtBounds
                    cellWidth: width / 2
                    cellHeight: 44
                    model: rootModel.count > 0 ? rootModel.modelForRow(root.category) : null
                    delegate: Item {
                        id: cell
                        required property int index
                        required property var model
                        width: GridView.view.cellWidth
                        height: GridView.view.cellHeight
                        AppRow {
                            anchors { fill: parent; rightMargin: 16; bottomMargin: 4 }
                            index: cell.index
                            model: cell.model
                            onClicked: root.launch(allApps.model, cell.index)
                        }
                    }
                }

                // ---- power
                RowLayout {
                    Layout.alignment: Qt.AlignRight
                    spacing: 8
                    PowerButton { glyph: "sleep"; tip: "Sleep"; onClicked: session.suspend() }
                    PowerButton { glyph: "lock"; tip: "Lock"; onClicked: session.lock() }
                    PowerButton { glyph: "restart"; tip: "Restart"; onClicked: session.requestReboot() }
                    PowerButton { glyph: "power"; tip: "Shut down"; primary: true; onClicked: session.requestShutdown() }
                }
            }
        }
    }

    // ------------------------------------------------------------ pieces
    component AppRow: Rectangle {
        id: row
        property int index
        property var model
        property bool highlighted: false
        signal clicked()
        height: 40
        radius: 10
        color: (highlighted || rowMouse.containsMouse) ? root.s.hoverBg : "transparent"
        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 10
            anchors.rightMargin: 10
            spacing: 12
            Kirigami.Icon { source: row.model ? row.model.decoration : ""; Layout.preferredWidth: root.s.listIcon; Layout.preferredHeight: root.s.listIcon }
            ColumnLayout {
                spacing: 0
                Layout.fillWidth: true
                Text { Layout.fillWidth: true; text: row.model ? row.model.display : ""; elide: Text.ElideRight; font.family: root.s.font; font.pixelSize: 13; color: root.s.fg }
                Text {
                    Layout.fillWidth: true
                    visible: text.length > 0
                    text: row.model && row.model.description ? row.model.description : ""
                    elide: Text.ElideRight
                    font.family: root.s.font; font.pixelSize: 11; color: root.s.dim
                }
            }
        }
        MouseArea { id: rowMouse; anchors.fill: parent; hoverEnabled: true; onClicked: row.clicked() }
    }

    component PowerButton: Rectangle {
        id: pb
        property string glyph
        property string tip
        property bool primary: false
        signal clicked()
        Layout.preferredWidth: 38
        Layout.preferredHeight: 38
        radius: 10
        color: primary ? root.s.accent : (pbMouse.containsMouse ? root.s.hoverBg : root.s.btnBg)
        Glyph {
            anchors.centerIn: parent
            width: 18; height: 18
            name: pb.glyph
            tint: pb.primary ? root.s.onAccent : root.s.fg
        }
        MouseArea { id: pbMouse; anchors.fill: parent; hoverEnabled: true; onClicked: { root.expanded = false; pb.clicked(); } }
    }

    // line icon (stroke-only SVG) recolored without filling its shapes (Kirigami isMask fills closed paths)
    component Glyph: Item {
        id: gl
        property string name
        property color tint
        Image { id: gimg; anchors.fill: parent; source: Qt.resolvedUrl("icons/" + gl.name + ".svg"); sourceSize: Qt.size(64, 64); visible: false }
        MultiEffect { anchors.fill: parent; source: gimg; colorization: 1.0; colorizationColor: gl.tint }
    }
}
