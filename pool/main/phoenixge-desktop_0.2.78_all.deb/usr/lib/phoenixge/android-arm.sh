#!/bin/sh
# ARM translation for Waydroid (many Play Store apps/games are ARM-only). Run as root.
# Uses waydroid_script (github.com/casualsnek/waydroid_script): libndk on AMD CPUs, libhoudini on Intel.
set -e
apt-get install -y git python3-venv lzip
D=/opt/waydroid_script
[ -d "$D" ] && git -C "$D" pull --ff-only || git clone --depth 1 https://github.com/casualsnek/waydroid_script "$D"
python3 -m venv "$D/venv"
"$D/venv/bin/pip" install -q -r "$D/requirements.txt"
if grep -q GenuineIntel /proc/cpuinfo; then T=libhoudini; else T=libndk; fi
"$D/venv/bin/python3" "$D/main.py" install "$T"
echo "ARM support ($T) installed - restart Android (Center > Android > Restart)."
