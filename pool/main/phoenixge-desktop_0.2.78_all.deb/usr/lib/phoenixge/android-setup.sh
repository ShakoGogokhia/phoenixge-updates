#!/bin/sh
# Android apps on PhoenixGe (Waydroid). Run as root (PhoenixGe Center > Android):  android-setup.sh [gapps]
# gapps = Android with Google Play (needs a one-time device registration, see Center).
set -e
TYPE=VANILLA; [ "$1" = gapps ] && TYPE=GAPPS
if ! command -v waydroid >/dev/null; then
  apt-get update; apt-get install -y curl ca-certificates lsb-release
  . /etc/os-release
  # official Waydroid repository (Waydroid is not in Debian)
  curl -fsSL https://repo.waydro.id | bash -s "$VERSION_CODENAME" || curl -fsSL https://repo.waydro.id | bash -s bookworm
  apt-get install -y waydroid
fi
echo "Downloading Android ($TYPE, about 1 GB)..."
waydroid init -s "$TYPE" -f
# PCs with only an NVIDIA GPU: Waydroid has no NVIDIA acceleration -> software rendering (apps fine, 3D games slow)
G=$(lspci -nn | grep -Ei 'vga|3d')
if echo "$G" | grep -q 10de && ! echo "$G" | grep -Eq '8086|1002'; then
  P=/var/lib/waydroid/waydroid_base.prop
  sed -i '/^ro.hardware.gralloc=/d;/^ro.hardware.egl=/d' "$P"
  printf 'ro.hardware.gralloc=default\nro.hardware.egl=swiftshader\n' >> "$P"
  echo "NVIDIA only: software rendering enabled."
fi
systemctl enable --now waydroid-container
echo "Android is installed."
