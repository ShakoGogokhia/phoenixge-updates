#!/bin/sh
# Opt-in "gaming kernel": newest Debian backports kernel (7.x, has ntsync = faster Windows games with
# Proton/Wine) + matching headers, and the backports NVIDIA driver when an NVIDIA card is present.
# The old kernel stays installed: pick it under "Advanced options" in the boot menu if something breaks.
# Run as root (PhoenixGe Center > Gaming).
set -e
. /etc/os-release
cat > /etc/apt/sources.list.d/phoenixge-backports.sources <<S
Types: deb
URIs: http://deb.debian.org/debian
Suites: ${VERSION_CODENAME}-backports
Components: main contrib non-free non-free-firmware
Signed-By: /usr/share/keyrings/debian-archive-keyring.gpg
S
apt-get update
PKGS="linux-image-amd64 linux-headers-amd64"
if lspci -nn | grep -Ei 'vga|3d' | grep -q 10de && dpkg -l nvidia-driver 2>/dev/null | grep -q '^ii'; then
  PKGS="$PKGS nvidia-driver firmware-nvidia-gsp"
  dpkg -l nvidia-open-kernel-dkms 2>/dev/null | grep -q '^ii' && PKGS="$PKGS nvidia-open-kernel-dkms" || PKGS="$PKGS nvidia-kernel-dkms"
fi
DEBIAN_FRONTEND=noninteractive apt-get install -y -t "${VERSION_CODENAME}-backports" $PKGS
echo ntsync > /etc/modules-load.d/ntsync.conf
echo "Done. Restart the computer to use the new kernel (old kernel: boot menu > Advanced options)."
