#!/bin/sh
# Install Debian packages for PhoenixGe Center (run with pkexec).  apt-install.sh [-b] PKG...
# -b: from Debian backports (newer versions). Docker: adds the calling user to the docker group.
set -e
BPO=""
if [ "$1" = "-b" ]; then
  shift
  . /etc/os-release
  [ -f /etc/apt/sources.list.d/phoenixge-backports.sources ] || cat > /etc/apt/sources.list.d/phoenixge-backports.sources <<S
Types: deb
URIs: http://deb.debian.org/debian
Suites: ${VERSION_CODENAME}-backports
Components: main contrib non-free non-free-firmware
Signed-By: /usr/share/keyrings/debian-archive-keyring.gpg
S
  BPO="-t ${VERSION_CODENAME}-backports"
fi
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y $BPO "$@"
case " $* " in *" docker.io "*) [ -n "$PKEXEC_UID" ] && usermod -aG docker "$(id -nu "$PKEXEC_UID")" && echo "Added to the docker group - log out and in again." ;; esac
echo "Installed: $*"
