// PhoenixGe Live Fire wallpaper: the theme wallpaper + embers rising from the bottom + a slow breathing glow.
// Pauses when a window covers the desktop is not needed - particles are cheap (GPU), ~60 sprites.
import QtQuick
import QtQuick.Particles
import org.kde.plasma.plasmoid

WallpaperItem {
    id: root
    readonly property string imagePath: {
        var p = String(configuration.Image || "");
        // a wallpaper package folder -> pick its biggest image
        if (p.endsWith("/")) p = p + "contents/images/1920x1080.png";
        return p;
    }

    Rectangle { anchors.fill: parent; color: "#0d0806" }
    Image {
        anchors.fill: parent
        source: root.imagePath
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
        sourceSize: Qt.size(root.width, root.height)
        onStatusChanged: if (status === Image.Error && !String(source).endsWith(".jpg")) source = String(root.imagePath).replace(".png", ".jpg")
    }
    // breathing glow at the bottom
    Rectangle {
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
        height: parent.height * 0.45
        gradient: Gradient {
            GradientStop { position: 0; color: "transparent" }
            GradientStop { position: 1; color: Qt.rgba(Qt.color(configuration.Color).r, Qt.color(configuration.Color).g, Qt.color(configuration.Color).b, 0.22) }
        }
        SequentialAnimation on opacity {
            loops: Animation.Infinite
            NumberAnimation { from: 0.55; to: 1.0; duration: 3200; easing.type: Easing.InOutSine }
            NumberAnimation { from: 1.0; to: 0.55; duration: 3200; easing.type: Easing.InOutSine }
        }
    }
    ParticleSystem { id: sys; running: root.visible }
    Emitter {
        system: sys
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
        height: 20
        emitRate: Math.max(4, configuration.Amount / 4)
        lifeSpan: 9000; lifeSpanVariation: 3000
        size: 7; sizeVariation: 5; endSize: 2
        velocity: AngleDirection { angle: 270; angleVariation: 12; magnitude: root.height / 9; magnitudeVariation: root.height / 18 }
        acceleration: PointDirection { xVariation: 8 }
    }
    Wander { system: sys; xVariance: 40; pace: 40 }
    ImageParticle {
        system: sys
        source: "qrc:///particleresources/glowdot.png"
        color: configuration.Color
        colorVariation: 0.15
        alpha: 0.85
        entryEffect: ImageParticle.Fade
    }
}
